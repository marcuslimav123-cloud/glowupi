


{"result":[{"TPa_Codigo":"473483","TPa_Descricao":"Dinheiro","PagamentoBandeira":"","TBa_Taxa":"","TPa_Cartao":"0"},{"TPa_Codigo":"473484","TPa_Descricao":"Cart\u00e3o de Cr\u00e9dito","PagamentoBandeira":"","TBa_Taxa":"","TPa_Cartao":"1"},{"TPa_Codigo":"473485","TPa_Descricao":"Cart\u00e3o de D\u00e9bito","PagamentoBandeira":"","TBa_Taxa":"","TPa_Cartao":"1"},{"TPa_Codigo":"473486","TPa_Descricao":"PIX","PagamentoBandeira":"","TBa_Taxa":"","TPa_Cartao":"1"}]}