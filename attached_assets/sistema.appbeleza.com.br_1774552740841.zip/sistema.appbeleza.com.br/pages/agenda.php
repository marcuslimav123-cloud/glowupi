<head/><section class="content">
    <div class="row">
        <hr class="hidden-lg hidden-md">

        <div class="col-sm-12 col-lg-9 col-md-8" id="divCalendar">
                        <div class="box box-default box-solid">
                <div class="box-header with-border" id="headerAgenda">

                                        <div class="row" align="center">
                        <div class="col-md-12">
                            <div class="pull-left">
                                <button class="btn btn-sm bg-grafite" id="btnAgendaPrev"><i class="ion ion-chevron-left"></i></button>
                                <button class="btn btn-sm bg-grafite" id="btnAgendaNext"><i class="ion ion-chevron-right"></i></button>
                                <button class="btn btn-sm bg-grafite" id="btnAgendaToday" style="margin-left: 5px">Hoje</button>
                                <button class="btn btn-sm" ng-click='insereServicoEncaixe()' style="margin-left: 10px; background-color:#795548; color:#fff;">+ Encaixe</button>
                            </div>
                            <h3 class="box-title titleAgenda" style="padding-top: 8px;padding-left: 25px;"><label id="headerCalendar"></label></h3>
                            <div class="pull-right hidden-xs">
                                <button class="btn btn-sm bg-blue-gray" id="btnAgendaDay">Dia</button>
                                <button class="btn btn-sm bg-blue-gray" id="btnAgendaWeek">Semana</button>
                                <button class="btn btn-sm bg-blue-gray" id="btnAgendaMonth">Mês</button>
                                <button class="btn btn-sm bg-grafite" style="margin-left: 5px" id="btnPrintAgenda" onclick='PrintAgenda($("#headerCalendar").html(),$("#calendar"))'><i class="ion ion-printer"></i></button>
                                <button class="btn btn-sm bg-grafite" style="margin-left: 5px" id="btnPrintAgenda" ng-click='isAgendamentoAntigo(2)'><i class="ion ion-refresh"></i></button>
                            </div>
                        </div>
                    </div>
                    

                </div>
                <div class="overlay divLoaderCalendarWidget" style="display:none;">
                        <i class="fa fa-circle-o-notch fa-spin"></i>
                </div>
                <div class="box-body" id="divCalendario">

                    <div id="calendar"></div>

                </div>
                <div class="box-footer" style="background-color:#D2D6DE;">
                    <div class="row">
                        <div class="col-md-12" id="rowNameProf">
                            <div id="divNameProf"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-12 col-lg-3 col-md-4">
            <div id="div-legenda-data">

                <label class="container"><b>Bloquear Horario</b>
                    <input type="checkbox" id="cbBloqHorario">
                    <span class="checkmark"></span>
                </label>
                <br>
                <div id='btnShowRodizio' style="display:none;">
                    <button class="btn bg-teal-dark" style="width: 100%;" ng-click="buscaInfoRodizio();">Ver Rodízio</button>
                    <br><br>
                </div>
                <div id='btnSelecionarCategoriaAgenda'>
                    <button class="btn bg-teal-dark" style="width: 100%;" ng-click="buscaCategoriasAgenda();">Agenda por Categorias</button>
                    <br><br>
                </div>
                <div class="box box-solid">
                    <div class="box box-info">
                        <div class="overlay divLoaderCalendarWidget" style="display:none;">
                                <i class="fa fa-circle-o-notch fa-spin"></i>
                        </div>
                        <div class="box-body">
                            
                            <div id="dvCalendario" align="center" style="width: 100%"></div>
                            <button class="btn btn-xs btn-block btn-default" ng-click="buscaHorariosDisponives()">Horários disponíveis</button>
                            <button class="btn btn-xs btn-block btn-default" ng-click="buscaListaAgendamentos()">Lista de Agendamentos</button>
                            <!-- <button class="btn btn-xs btn-block btn-primary" ng-click="displayModalJornada()">Horários de trabalho</button> -->
                            <button class="btn btn-xs btn-block bg-purple" ng-click="displayModalListaEspera()">Lista de Espera</button>
                            
                        </div>
                    </div>
                </div>
                <button type="button" class="btn btn-default btn-block" name="button" ng-click="catalogo()"><i class="fa fa-book" aria-hidden="true"></i>&nbspProdutos / Serviços</button>
                <button type="button" class="btn btn-warning btn-block" name="button" ng-click="buscaTabelaComandaTotem()" ng-show="mostrabtntotem"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbspTotem</button>
                <br>
                <div class="box box-solid" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title">Legenda</h3>
                            <div class="box-tools pull-right">
                                <button type="button" id="btnHideLegenda" class="btn btn-box-tool" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"><i class="fa fa-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="box-body collapse" id="collapseExample">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn btn-primary btn-xs  btn-block" style="pointer-events: none;">Agendado</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn btn-success btn-xs  btn-block" style="pointer-events: none;">Realizado</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn btn-warning btn-xs  btn-block" style="pointer-events: none;">Sem Cadastro</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn btn-danger btn-xs  btn-block " style="pointer-events: none;">Ausência</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn  btn-xs btn-block" style="background-color:#455A64; color:#fff;pointer-events: none;">Bloqueado</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn  btn-xs btn-block" style="background-color:#795548; color:#fff;pointer-events: none;">Encaixe</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn  btn-xs btn-block" style="background-color:#9C27B0; color:#fff;pointer-events: none;">Confirmado</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 5px;">
                                    <button type="button" class="btn  btn-xs btn-block" style="background-color:#0401aa; color:#fff;pointer-events: none;">Sem Preferência</button>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xs-12 col-sm-12">
                                    <button type="button" class="btn  btn-xs btn-block" style="background-color:#520034; color:#fff;pointer-events: none;">No Local</button>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                                <hr>
                                </div>

                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt;  ">
                                    <i class="fa fa-microphone-slash"></i> <small>Cliente não deseja conversar</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-birthday-cake"></i> <small>Aniversariante</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-gift"></i> <small>Agendamento de pacote</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-ticket"></i> <small>Cupom de desconto aplicado</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt;  ">
                                    <i class="fa fa-credit-card-alt"></i> <small>Pago via integração</small>
                                </div>
                              
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                                <hr>
                                </div>

                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-desktop"></i> <small>Agendamento feito via sistema</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-apple"></i> <small>Agendamento feito via app IOS</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-android"></i> <small>Agendamento feito via app Android</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-facebook-official"></i> <small>Agendamento feito via Site/Facebook</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-map-marker"></i> <small>Agendamento feito via Totem</small>
                                </div>

                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-home"></i> <small>Agendado por profissional</small>
                                </div>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " style="margin-bottom: 1pt; ">
                                    <i class="fa fa-user"></i> <small>Agendado por cliente</small>
                                </div>


                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                                <hr>
                                </div>

                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 1pt;">
                                    <i class="fa fa-star" style="background-color: orange;padding:4px;color:white;border-radius:50%"></i> <small>Clube de Assinaturas</small>
                                </div>
                                <br>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12" style="margin-bottom: 1pt;">
                                    <i class="fa fa-star" style="background-color: #cd0707;padding:4px;color:white;border-radius:50%"></i> <small>Assinante Inadimplente</small>
                                </div>

                                <hr>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 multiUniClass" style="margin-bottom: 1pt; display:none;">
                                    <i class="fa fa-star" style="background-color: #FFD700;padding:4px;color:black;border-radius:50%"></i> <small>Assinante Multi-Unidade</small>
                                </div>
                                <br>
                                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 multiUniClass" style="margin-bottom: 1pt;  display:none;">
                                    <i class="fa fa-star" style="background-color: #FF4500;padding:4px;color:black;border-radius:50%"></i> <small>Inadimplente Multi-Unidade</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="infohorario-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-info"></i> Selecione o que deseja fazer </h4>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal">
                        <div class="box-body">
                            <div class="row">
                                <div class="table-responsive">
                                    <table class="table">
                                        <tr>
                                            <th style="width:20%">Usuário:</th>
                                            <td><span id="HasAssinaturaAgendamento"></span><label id="lblUsuario"></label>
                                                <button type='button' class="btn btn-default btn-flat btn-xs cliqueBotao" id="btnEdtClienteAgenda" ng-click="editaClienteAgenda()"><i class='fa fa-pencil'></i></button>
                                                <button type='button' class="btn btn-primary btn-flat btn-xs" id="btnAssociaCliente" ng-click="mostraClientes()"><i class="fa fa-user"></i> Alterar Cliente</button>
                                                <button type='button' class="btn btn-success btn-flat btn-xs" id="btnInfoCliente" ng-click="infoClientes()"><i class="fa fa-info"></i> Info</button>
                                                <div id="listaTagsClientes">
                                                    
                                                </div>
                                                <b id="cpfnf">CPF: <span id="lblCPFCliente"></span></b>
                                            </td>
                                            
                                        </tr>
                                        <tr ng-show="semCadastro">
                                            <th></th>
                                            <td>
                                                <div class="row">
                                                    <div class="col-xs-8">
                                                        <div class="input-group input-group-sm">
                                                            <span class="input-group-btn">
                                                                <button type='button' class="btn btn-flat btn-sm" data-toggle='modal' data-target='#cadastrarcliente-modal' ng-click="buscaGeraComboTelefone()"><i class="fa fa-plus"></i> Novo</button>
                                                            </span>
                                                            <div id="the-basics">
                                                                <input class="typeahead form-control input-sm" type="text" placeholder="Selecione o Cliente">
                                                            </div>
                                                            <span class="input-group-btn">
                                                                <button type='button' class="btn btn-flat btn-sm" data-toggle='modal' id="confirmarAssociar"><i class="fa fa-check-circle"></i> Confirmar</button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr id="divRecorrencia">
                                            <th>Recorrência</th>
                                            <td><label id="lblRecorrencia"></label></td>
                                        </tr>
                                        <tr>
                                            <th>Serviço</th>
                                            <td><label id="lblServico"></label> - <small id="iniAgendamento"></small> até <small id="fimAgendamento"></small></td>
                                        </tr>
                                        <tr>
                                            <th>Origem</th>
                                            <td id="tdOrigem"></td>
                                            <label id="treAgendaCodigo" hidden></label>
                                        </tr>
                                        <tr>
                                            <th>Data/Usuário Cadastro</th>
                                            <td id="tdDatCadastro"></td>
                                        </tr>

                                        <tr>
                                            <th>Valor</th>
                                            <td><label id="lblValor"></label><span id="tipoclube"></span></td>
                                        </tr>
                                        <tr id="trComanda">
                                            <th>Comanda</th>
                                            <td>
                                                <b><span id="comandaBotaoValor"></span> | <span id="comandaBotao"></span></b>&nbsp
                                                <button type='button' id="btnVerComandaAgendamentoFinalizado" class="btn btn-primary btn-flat btn-xs" ng-click="mostraComanda()">Ver</button>
                                                <button type='button' id="btnVerComandaAgendamento" class="btn btn-primary btn-flat btn-xs" ng-click="mostraComandaAberta()">Ver</button>
                                            </td>
                                        </tr>
                                        <tr id="trEditaAgendamento">
                                            <th>Editar</th>
                                            <td><button type='button' class="btn btn-primary btn-flat btn-sm" id="btnEditarAgendamento" ng-click="editarAgendamento()"><i class="fa fa-pencil"></i> Editar Agendamento</button></td>
                                            <label id="lblProfissional" style="display:none;"></label>
                                        </tr>
                                        <tr id="trTipoPagamento">
                                            <th>Pagamento</th>
                                            <td id="AgendamentoPagamento"></td>
                                            <label id="lblProfissional" style="display:none;"></label>
                                        </tr>
                                        <tr>
                                            <th>Celular</th>
                                            <td><label id="lblCelular"></label> <button id="btnAgendamentoWhats" class="btn btn-success btn-xs" ng-click="openWhatsAgendamento()"><i class="fa fa-whatsapp"></i></button></td>
                                        </tr>
                                        <tr>
                                            <th>E-mail</th>
                                            <td>
                                                <label id="lblEmail"></label>
                                            </td>
                                        </tr>
                                        <tr id="trComprovante">
                                            <th>Comprovante</th>
                                            <td>
                                                <button id="trComprovanteEmail" type='button' class="btn btn-primary btn-flat btn-sm" onClick="EnviaEmailComanda($('#lblComCodigo').html())"><i class="fa fa-envelope"></i>&nbsp Enviar Comprovante<small>&nbsp(Não Fiscal)</small></button>
                                                <button id="trComprovantePDF" type='button' class="btn btn-info btn-flat btn-sm" ng-click="geraCupomComanda()"><i class="fa fa-file-pdf-o"></i>&nbsp Comprovante em PDF</button>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th>Observações</th>
                                            <td>
                                                <div class="input-group input-group-sm" style="padding-right: 13px;">
                                                    <input id="lblObs" type="text" class="form-control">
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-primary btn-flat" id="btnAtualizaObs" type="button">Alterar</button>
                                                    </span>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr id="sendWhatsappReminder">
                                            <th>Enviar lembrete</th>
                                            <td>
                                                <div class="btn btn-group">
                                                    <button id="btnSendWhatsReminder" class="btn btn-sm btn-success btn-flat"><i class="fa fa-whatsapp"></i> WhatsApp Web</button>
                                                    <a id="showFaqwhats" target="blank" href="https://appbarber-appbeleza.zendesk.com/hc/pt-br/articles/360016638871-Lembretes-via-WhatsApp" class="btn btn-sm btn-flat btn-warning"><i class="fa fa-question-circle"></i></a>
                                                </div>
                                                <div class="btn btn-group">
                                                    <button id="btnNovoLembrete" class="btn btn-sm bg-teal-dark btn-flat" ng-click="cadastrarlembrete()">App/SMS*</button>
                                                    <a id="showFaqwhats" target="blank" href="https://appbarber-appbeleza.zendesk.com/hc/pt-br/articles/360026065451-Como-funcionam-os-lembretes-" class="btn btn-sm btn-flat btn-warning"><i class="fa fa-question-circle"></i></a>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr id="trTagsAgendamento">
                                            <th>Tags <button ng-click="newTagAgendamento()" class="btn btn-xs btn-primary btn-flat"><i class="fa fa-plus"></i></button></th>
                                            <td id="listaTagsAgendamento">
                                                
                                            </td>
                                        </tr>

                                    </table>
                                </div>
                            </div>
                            <label id="lblIDAgendamento" hidden></label>
                            <label id="lblValorHdn" hidden></label>
                            <label id="lblSerCodigo" hidden></label>
                            <label id="lblComCodigo" hidden></label>
                            <label id="lblCItCodigo" hidden></label>
                            <label id="lblPesCodigo" hidden></label>
                        </div>
                        <div class="box-footer">
                            <button id="btnRealizadoAg" class="btn btn-sm btn-success">Realizado/<small>Comanda</small></button>
                            <button id="btnAusenteAg" class="btn btn-sm btn-danger" data-dismiss="modal">Ausência</button>
                            <button id="btnCancelarAg" class="btn btn-sm" style=" color: #ffffff;background-color:#aba9a9">Cancelar</button>
                            <button id="btnMaisServico" class="btn btn-sm" style=" color: #ffffff;background-color:#ae5cf2" ng-click="realizadoEncaixe()"><i class="fa fa-plus"></i> Servico</button>
                            <button id="btnMaisProduto" class="btn btn-sm" style=" color: #ffffff;background-color:#704718" ng-click="realizadoVenda()"><i class="fa fa-plus"></i> Produto</button>
                            <button id="btnReabrirAg" class="btn btn-sm btn-success" style="float: left; display:none;" data-dismiss="modal">Reabrir</button>
                            <button id="btnConfirmaAg" class="btn btn-sm bg-teal-dark" style=" display:none;" data-dismiss="modal">Confirmar</button>
                            <button id="btnNoLocal" class="btn btn-sm bg-orage" style=" display:none;" data-dismiss="modal">No Local</button>
                            <button id="btnPreferenciaAg" class="btn btn-sm btn-success" style="float: left; display:none;" data-dismiss="modal">Preferencia</button>
                            <button id="btnAlteraEncaixe" class="btn btn-sm btn-success" style="float: left; display:none;">Alterar p/ Encaixe</button>
                            <button id="btnFecharAg" class="btn btn-sm btn-primary" style="float: right;" data-dismiss="modal">Fechar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="agendaHorario-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-starapp-55">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-plus-square-o"></i> Agendar novo horário </h4>
                </div>
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab1" data-toggle="tab">Agendar Horário</a></li>
                        <li><a href="#tab2" data-toggle="tab">Bloquear Horário <i data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Bloquear horários quando não houver expediente por demais motivos (ex.: férias, reuniões, etc.)."></i> </a></li>
                        <li><a href="#tab3" data-toggle="tab">Desbloquear Horário</a></li>
                        <li><a href="#tab4" data-toggle="tab">Agenda Recorrente</a></li>
                    </ul>
                    <div class="tab-content">
                        <!-- Inicio Aba 1 -->
                        <div class="tab-pane active" id="tab1">
                            <form id="formHorario" action="#" method="POST">
                                <div class="modal-body">
                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-lg-4 col-xs-6">
                                                <div class="form-group">
                                                    <label>Dia:</label>
                                                    <input type="hidden" id="geralinkconfirmacao"/>
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                        <input type="text" id="edtData" name="edtData" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="edtData2"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-xs-6">
                                                <div class="bootstrap-timepicker">
                                                    <div class="form-group">
                                                        <label>Hora Início:</label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-clock-o"></i>
                                                            </div>
                                                            <input type="text" id="edtHoraIni" name="edtHoraIni" class="form-control timepicker"/>
                                                            <input type="hidden" id="edtHoraIni2"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-xs-6">
                                                <div class="form-group">
                                                    <label id="lblProfissional">Profissional:</label>
                                                    <select class="form-control" id="edtProfissional" name="edtProfissional"></select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" id="servicos_select"></div>
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <button type="button" name="button" class="btn btn-default btn-block btn-flat btn-xs" ng-click="adicionaServico()"><i class="fa fa-plus"></i>&nbsp&nbspAdicionar serviço</button>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12">
                                                <div class="form-group">
                                                    <label id="lblCliente">Cliente:</label>
                                                    <div class="input-group">
                                                        <select class="form-control select2 cliente" id="cliente_menu" name="cliente_menu" ng-model="cliente_menu" style="width: 100%">
                                                            <option value="0">Sem Cadastro</option>
                                                        </select>
                                                        <span class="input-group-btn">
                                                            <button type="button" id="btnNovoClienteAg" data-toggle='modal' data-target='#cadastrarcliente-modal' class="btn btn-primary btn-flat cliqueBotao"><i class="fa fa-plus"></i></button>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" ng-show="cliente_menu != 0">
                                            <div class="col-md-12">
                                                <div class="row text-center">
                                                </div>
                                                <div class="row" style="margin-bottom: 10px;margin-top:5px">
                                                    <div class="col-md-6">
                                                        <label for="jaAusentouFlag">Já se ausentou: </label><span id="jaAusentouFlag">Não</span>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="saldoContaCliAge">Conta do Cliente: </label><span id="saldoContaCliAge"></span>
                                                    </div>
                                                </div>
                                                <div class="row" style="margin-bottom: 10px;margin-top:5px">
                                                    <div class="col-md-6">
                                                        <label for="assinanteFlag">Assinante: </label><span id="IsAssinanteCliente"></span>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="assinanteFlag">Pacotes: </label><span id="HasPacotesCliente"></span>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6">
                                                        <div class="form-group">
                                                            <label>Adicionar lembrete?</label>
                                                            <select class="form-control" id="add_lembrete_menu" name="add_lembrete_menu" ng-model="add_lembrete_menu">
                                                                <option value="1">Sim</option>
                                                                <option value="0">Não</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6">
                                                        <div class="form-group">
                                                            <label>Lembrar quanto tempo antes:</label>
                                                            <select class="form-control" id="qtd_lembrete_menu" name="qtd_lembrete_menu">
                                                                <option value="5">5 Minutos</option>
                                                                <option value="10">10 Minutos</option>
                                                                <option value="15">15 Minutos</option>
                                                                <option value="20">20 Minutos</option>
                                                                <option value="25">25 Minutos</option>
                                                                <option value="30">30 Minutos</option>
                                                                <option value="35">35 Minutos</option>
                                                                <option value="40">40 Minutos</option>
                                                                <option value="45">45 Minutos</option>
                                                                <option value="50">50 Minutos</option>
                                                                <option value="60" selected>1 Hora</option>
                                                                <option value="120">2 Horas</option>
                                                                <option value="180">3 Horas</option>
                                                                <option value="240">4 Horas</option>
                                                                <option value="300">5 Horas</option>
                                                                <option value="360">6 Horas</option>
                                                                <option value="720">12 Horas</option>
                                                                <option value="1440">1 Dia</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row flex" ng-show="add_lembrete_menu == 1 && cliente_menu != 0">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-4 col-sm-4">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="cbEnviaSms" id="cbEnviaSms"> Enviar SMS
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4">
                                                        <h5> Saldo de SMS: <label id="lblSaldoSMSAg"></label></h5>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4 align-left">
                                                        <button class="btn bg-teal-dark pull-right" ui-sref="sms" ng-show="saldoSMS == 0">
                                                            <i class="fa fa-plus"></i>&nbsp&nbspComprar Crédito SMS
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="row" style="margin-top: 10px;">
                                                    <div class="col-md-4 col-sm-4">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="cbEnviaWhats" id="cbEnviaWhats"> Enviar WhatsApp
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4">
                                                        <h5> Saldo de WhatsApp: <label id="lblSaldoWhatsAg"></label></h5>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4 align-left">
                                                        <button class="btn bg-teal-dark pull-right" ui-sref="whatsapp" ng-show="saldoWhats == 0">
                                                            <i class="fa fa-plus"></i>&nbsp&nbspComprar Créditos WhatsApp
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Observações</label>
                                            <textarea class="form-control" rows="3" id="txtObs"></textarea>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                        <button type="button" id="btnInserirAg" class="btn btn-success btn-block">AGENDAR</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Fim Aba 1 -->

                        <!-- Inicio Aba 2 -->
                        <div class="tab-pane" id="tab2">
                            <form id="formHorarioBloqueado" action="#" method="POST">
                                <div class="modal-body">
                                    <div class="box-body">
                                        <div class="form-group">
                                            <label id="lblTipo">Tipo:</label>
                                            <select class="form-control" id="edtTipoBloqueio">
                                                <option value="0">Horário único</option>
                                                <option value="1">Recorrente</option>
                                            </select>
                                        </div>


                                        <!-- <div class="form-group">
                                            <label id="lblTipo">Quantidade de Dias:</label>
                                            <input type="number" name="edtQuantidadeDiasBloqueado" id="edtQuantidadeDiasBloqueado" class="form-control" min="1" max="180" placeholder="Quantidade de Dias (máximo: 180)">
                                        </div> -->

                                        <div class="row" id="qtdDiasDiv">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label id="lblTipo">Quantidade de Dias:</label>
                                                    <input type="number" name="edtQuantidadeDiasBloqueado" id="edtQuantidadeDiasBloqueado" class="form-control" min="1" max="180" placeholder="Quantidade de Dias (máximo: 180)">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="edtPeriodicidadeBloqueado">Periodicidade</label>
                                                    <input type="number" name="edtPeriodicidadeBloqueado" id="edtPeriodicidadeBloqueado" class="form-control" min="1" max="30" placeholder="Periodicidade(máximo: 30)">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="form-group">
                                                    <label>Dia Inicio:</label>
                                                    <div class="input-group date DateBloqueio">
                                                        <div class="input-group-addon" id="addonini">
                                                            <i class="fa fa-calendar" id="datainibloqueio"></i>
                                                        </div>
                                                        <input type="text" id="edtDataBloqueado" name="edtDataBloqueado" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="edtData2Bloqueado"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="bootstrap-timepicker">
                                                    <div class="form-group">
                                                        <label>Hora Início:</label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-clock-o"></i>
                                                            </div>
                                                            <!-- <input type="text" id="edtHoraIniBloqueado" name="edtHoraIniBloqueado" class="form-control timepicker" /> -->
                                                            <select name="edtHoraIniBloqueado" id="edtHoraIniBloqueado" class="input-large form-control select2" style="width:100%;" required>
                                                                <option value="" selected>Hora</option>
                                                                ﻿<option value='00:00'>00:00</option><option value='00:15'>00:15</option><option value='00:30'>00:30</option><option value='00:45'>00:45</option><option value='01:00'>01:00</option><option value='01:15'>01:15</option><option value='01:30'>01:30</option><option value='01:45'>01:45</option><option value='02:00'>02:00</option><option value='02:15'>02:15</option><option value='02:30'>02:30</option><option value='02:45'>02:45</option><option value='03:00'>03:00</option><option value='03:15'>03:15</option><option value='03:30'>03:30</option><option value='03:45'>03:45</option><option value='04:00'>04:00</option><option value='04:15'>04:15</option><option value='04:30'>04:30</option><option value='04:45'>04:45</option><option value='05:00'>05:00</option><option value='05:15'>05:15</option><option value='05:30'>05:30</option><option value='05:45'>05:45</option><option value='06:00'>06:00</option><option value='06:15'>06:15</option><option value='06:30'>06:30</option><option value='06:45'>06:45</option><option value='07:00'>07:00</option><option value='07:15'>07:15</option><option value='07:30'>07:30</option><option value='07:45'>07:45</option><option value='08:00'>08:00</option><option value='08:15'>08:15</option><option value='08:30'>08:30</option><option value='08:45'>08:45</option><option value='09:00'>09:00</option><option value='09:15'>09:15</option><option value='09:30'>09:30</option><option value='09:45'>09:45</option><option value='10:00'>10:00</option><option value='10:15'>10:15</option><option value='10:30'>10:30</option><option value='10:45'>10:45</option><option value='11:00'>11:00</option><option value='11:15'>11:15</option><option value='11:30'>11:30</option><option value='11:45'>11:45</option><option value='12:00'>12:00</option><option value='12:15'>12:15</option><option value='12:30'>12:30</option><option value='12:45'>12:45</option><option value='13:00'>13:00</option><option value='13:15'>13:15</option><option value='13:30'>13:30</option><option value='13:45'>13:45</option><option value='14:00'>14:00</option><option value='14:15'>14:15</option><option value='14:30'>14:30</option><option value='14:45'>14:45</option><option value='15:00'>15:00</option><option value='15:15'>15:15</option><option value='15:30'>15:30</option><option value='15:45'>15:45</option><option value='16:00'>16:00</option><option value='16:15'>16:15</option><option value='16:30'>16:30</option><option value='16:45'>16:45</option><option value='17:00'>17:00</option><option value='17:15'>17:15</option><option value='17:30'>17:30</option><option value='17:45'>17:45</option><option value='18:00'>18:00</option><option value='18:15'>18:15</option><option value='18:30'>18:30</option><option value='18:45'>18:45</option><option value='19:00'>19:00</option><option value='19:15'>19:15</option><option value='19:30'>19:30</option><option value='19:45'>19:45</option><option value='20:00'>20:00</option><option value='20:15'>20:15</option><option value='20:30'>20:30</option><option value='20:45'>20:45</option><option value='21:00'>21:00</option><option value='21:15'>21:15</option><option value='21:30'>21:30</option><option value='21:45'>21:45</option><option value='22:00'>22:00</option><option value='22:15'>22:15</option><option value='22:30'>22:30</option><option value='22:45'>22:45</option><option value='23:00'>23:00</option><option value='23:15'>23:15</option><option value='23:30'>23:30</option><option value='23:45'>23:45</option><option value='00:00'>00:00</option>                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-xs-6">

                                                <div class="form-group" id="datafimhide">
                                                    <label>Dia Fim:</label>
                                                    <div class="input-group date DateBloqueioFim">
                                                        <div class="input-group-addon" id="addonfim">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                        <input type="text" id="edtDataFimBloqueado" name="edtDataFimBloqueado" class="form-control asblock" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="edtDataFim2Bloqueado"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="bootstrap-timepicker">
                                                    <div class="form-group">
                                                        <label>Hora Fim:</label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-clock-o"></i>
                                                            </div>
                                                            <!-- <input type="text" id="edtHoraFimBloqueado" name="edtHoraFimBloqueado" class="form-control timepicker" /> -->

                                                            <select name="edtHoraFimBloqueado" id="edtHoraFimBloqueado" class="input-large form-control select2" style="width:100%;" required>
                                                                <option value="" selected>Hora</option>
                                                                ﻿<option value='00:00'>00:00</option><option value='00:15'>00:15</option><option value='00:30'>00:30</option><option value='00:45'>00:45</option><option value='01:00'>01:00</option><option value='01:15'>01:15</option><option value='01:30'>01:30</option><option value='01:45'>01:45</option><option value='02:00'>02:00</option><option value='02:15'>02:15</option><option value='02:30'>02:30</option><option value='02:45'>02:45</option><option value='03:00'>03:00</option><option value='03:15'>03:15</option><option value='03:30'>03:30</option><option value='03:45'>03:45</option><option value='04:00'>04:00</option><option value='04:15'>04:15</option><option value='04:30'>04:30</option><option value='04:45'>04:45</option><option value='05:00'>05:00</option><option value='05:15'>05:15</option><option value='05:30'>05:30</option><option value='05:45'>05:45</option><option value='06:00'>06:00</option><option value='06:15'>06:15</option><option value='06:30'>06:30</option><option value='06:45'>06:45</option><option value='07:00'>07:00</option><option value='07:15'>07:15</option><option value='07:30'>07:30</option><option value='07:45'>07:45</option><option value='08:00'>08:00</option><option value='08:15'>08:15</option><option value='08:30'>08:30</option><option value='08:45'>08:45</option><option value='09:00'>09:00</option><option value='09:15'>09:15</option><option value='09:30'>09:30</option><option value='09:45'>09:45</option><option value='10:00'>10:00</option><option value='10:15'>10:15</option><option value='10:30'>10:30</option><option value='10:45'>10:45</option><option value='11:00'>11:00</option><option value='11:15'>11:15</option><option value='11:30'>11:30</option><option value='11:45'>11:45</option><option value='12:00'>12:00</option><option value='12:15'>12:15</option><option value='12:30'>12:30</option><option value='12:45'>12:45</option><option value='13:00'>13:00</option><option value='13:15'>13:15</option><option value='13:30'>13:30</option><option value='13:45'>13:45</option><option value='14:00'>14:00</option><option value='14:15'>14:15</option><option value='14:30'>14:30</option><option value='14:45'>14:45</option><option value='15:00'>15:00</option><option value='15:15'>15:15</option><option value='15:30'>15:30</option><option value='15:45'>15:45</option><option value='16:00'>16:00</option><option value='16:15'>16:15</option><option value='16:30'>16:30</option><option value='16:45'>16:45</option><option value='17:00'>17:00</option><option value='17:15'>17:15</option><option value='17:30'>17:30</option><option value='17:45'>17:45</option><option value='18:00'>18:00</option><option value='18:15'>18:15</option><option value='18:30'>18:30</option><option value='18:45'>18:45</option><option value='19:00'>19:00</option><option value='19:15'>19:15</option><option value='19:30'>19:30</option><option value='19:45'>19:45</option><option value='20:00'>20:00</option><option value='20:15'>20:15</option><option value='20:30'>20:30</option><option value='20:45'>20:45</option><option value='21:00'>21:00</option><option value='21:15'>21:15</option><option value='21:30'>21:30</option><option value='21:45'>21:45</option><option value='22:00'>22:00</option><option value='22:15'>22:15</option><option value='22:30'>22:30</option><option value='22:45'>22:45</option><option value='23:00'>23:00</option><option value='23:15'>23:15</option><option value='23:30'>23:30</option><option value='23:45'>23:45</option><option value='00:00'>00:00</option>                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label id="lblProfissionalBloqueado">Profissional:</label>
                                            <select class="form-control" id="edtProfissionalBloqueado">
                                            </select>
                                            <div id="select">
                                            <select class="form-control" id="edtMultiProfissionalBloqueado" name="edtMultiProfissionalBloqueado" style="width:100%;">
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Observações</label>
                                            <textarea class="form-control" rows="3" id="txtObsBloqueado"></textarea>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                    <button type="button" tabindex="-1" id="btnInserirBloqueado" class="btn btn-danger btn-block">BLOQUEAR</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Fim Aba 2 -->

                        <!-- Inicio Aba 3 -->
                        <div class="tab-pane" id="tab3">
                            <form id="formHorarioDesbloquear" action="#" method="POST">
                                <div class="modal-body">
                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="form-group">
                                                    <label>Dia Inicio:</label>
                                                    <div class="input-group date">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                        <input type="text" id="edtDataDesbloquearAgenda" name="edtDataDesbloquearAgenda" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="edtData2DesbloquearAgenda"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="bootstrap-timepicker">
                                                    <div class="form-group">
                                                        <label>Hora Início:</label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-clock-o"></i>
                                                            </div>
                                                            <input type="text" id="edtHoraIniDesbloquearAgenda" name="edtHoraIniDesbloquearAgenda" class="form-control timepicker"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-xs-6">

                                                <div class="form-group">
                                                    <label>Dia Fim:</label>
                                                    <div class="input-group date">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                        <input type="text" id="edtDataFimDesbloquearAgenda" name="edtDataFimDesbloquearAgenda" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="edtDataFim2DesbloquearAgenda"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="bootstrap-timepicker">
                                                    <div class="form-group">
                                                        <label>Hora Fim:</label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-clock-o"></i>
                                                            </div>
                                                            <input type="text" id="edtHoraFimDesbloquearAgenda" name="edtHoraFimDesbloquearAgenda" class="form-control timepicker"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label id="lblProfissionalDesbloquear">Profissional:</label>
                                            <select class="form-control" id="edtProfissionalDesbloquear"></select>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                        <button type="button" id="btnInserirDesbloquearAgenda" class="btn btn-primary btn-block">DESBLOQUEAR</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Fim Aba 3 -->

                        <!-- Inicio Aba 4 -->
                        <div class="tab-pane" id="tab4">
                            <form id="formAgendamentoRecorrente" action="#" method="POST">
                                <div class="modal-body">
                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Tipo</label>
                                                    <select class="form-control" name="tipoRecorrencia" id="tipoRecorrencia">
                                                        <option value="1">Agendar</option>
                                                        <option value="2">Cancelar</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-xs-6" id="divDataRecorrente">
                                                <div class="form-group">
                                                    <label>Dia Inicio:</label>
                                                    <div class="input-group date">
                                                        <div class="input-group-addon" id="celendardisabled" style="cursor:default;">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                        <input type="text" id="dataAgendamentoRecorrente" name="dataAgendamentoRecorrente" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="dataAgendamentoRecorrente2" name="dataAgendamentoRecorrente2"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-xs-6" id="divHoraRecorrente">
                                                <div class="bootstrap-timepicker">
                                                    <div class="form-group">
                                                        <label>Hora :</label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-clock-o"></i>
                                                            </div>
                                                            <input type="text" id="horaAgendamentoRecorrente" name="horaAgendamentoRecorrente" class="form-control timepicker" required="true">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-xs-6" id="divProfissionalRecorrente">
                                                <div class="form-group">
                                                    <label id="lblProfissionalDesbloquear">Profissional:</label>
                                                    <select class="form-control" id="profissionalRecorrencia" name="profissionalRecorrencia" required="true"></select>
                                                    <input type="hidden" name="profissionalRecorrencia2" id="profissionalRecorrencia2">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-8 col-xs-12">
                                                <div class="form-group">
                                                    <label id="lblServico">Serviço:</label>
                                                    <select class="form-control select2" id="servico_menuRecorrente" name="servico_menuRecorrente" style="width: 100%" required="true">
                                                        <br>
                                                        <option data-tempo="0" value="">Selecione um Serviço</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-xs-12">
                                                <div class="form-group">
                                                    <label for="duracaoAgendamentoRecorrente">Duração</label>
                                                    <select name="duracaoAgendamentoRecorrente" id="duracaoAgendamentoRecorrente" class="form-control"></select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12 col-sm-12">
                                                <div class="form-group">
                                                    <label id="lblCliente">Cliente:</label>
                                                    <div class="input-group">
                                                        <select class="form-control select2 cliente" id="cliente_menu2" name="cliente_menu2" ng-model="cliente_menu2" style="width: 100%" required="true"></select>
                                                        <span class="input-group-btn">
                                                            <button type="button" id="btnNovoClienteAgRecorrente" data-toggle='modal' data-target='#cadastrarcliente-modal' class="btn btn-primary" ng-click="buscaGeraComboTelefone()"><i class="fa fa-plus"></i></button>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" id="QtdPeriodicidadeRecorrente">
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="form-group">
                                                    <label id="lblServico">Periodicidade:</label>
                                                    <select class="form-control select2" id="recorrenciaPeriodicidade" name="recorrenciaPeriodicidade" style="width: 100%" required>
                                                        <br>
                                                        <option value="7">Semanal</option>
                                                        <option value="15">A cada duas semanas</option>
                                                        <option value="21">A cada três semanas</option>
                                                        <option value="30">Mensal</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="form-group">
                                                    <label id="lblServico">Quantidade de agendamentos:</label>
                                                    <select class="form-control select2" id="recorrenciaQtd" name="recorrenciaQtd" style="width: 100%" required>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" id="datasCancelaRecorrente">
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="form-group">
                                                    <label>Dia Início:</label>
                                                    <div class="input-group date dataIniCancelaRecorrente">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                        <input type="text" id="dataIniCancelaRecorrente" name="dataIniCancelaRecorrente" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="dataIni2CancelaRecorrente"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-xs-6">
                                                <div class="form-group">
                                                    <label>Dia Fim:</label>
                                                    <div class="input-group date dataFimCancelaRecorrente">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                        <input type="text" id="dataFimCancelaRecorrente" name="dataFimCancelaRecorrente" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                        <input type="hidden" id="dataFim2CancelaRecorrente"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                        <button type="submit" id="btnAgendarRecorrente" class="btn btn-success btn-block">AGENDAR</button>
                                        <button type="button" id="btnCancelarRecorrente" class="btn btn-warning btn-block" ng-click="cancelaRecorrente()">Cancelar Agendamentos Recorrentes do Período</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Fim Aba 4 -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="insertServicoEncaixe-modal" tabindex="-1" role="dialog" data-backdrop="false" aria-hidden="true">
        <div class="modal-dialog modal-starapp-50">
            <div class="modal-content">
                <div class="modal-header" align="center">
                    <h4 class="modal-title"> Inserir Encaixe</h4>
                </div>
                <div class="modal-body">
                    <form id="formInsereServicoEncaixe">
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label>Cliente*</label>
                                    <div class="input-group">
                                        <select class="form-control select2 cliente" id="insertClienteEncaixe" name="clienteEncaixe" style="width: 100%">
                                            <option value="" selected>Sem Cadastro</option>
                                        </select>
                                        <span class="input-group-btn">
                                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#cadastrarcliente-modal" ng-click="buscaGeraComboTelefone()"><i class="fa fa-plus"></i> Novo</button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Serviço*</label>
                                    <br>
                                    <select name="insertServicoEncaixe" id="insertServicoEncaixe" class="input-large form-control select2" style="width:100%;" required>
                                        <option selected="true" value="">Selecione um Serviço</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Profissional*</label>
                                    <br>
                                    <select name="insertProfissionalEncaixe" id="comInsertProfissionalEncaixe" class="input-large form-control select2" style="width:100%;" required>
                                        <option selected="true" value="">Selecione um Profissional</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Data Início*</label>
                                    <div class="input-group date divDataIni divDataServicoEncaixe">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" maxlength="10" onKeyPress="mascara(this,soData)" name="dataIniEncaixe" id="comDataIniEncaixe" class="form-control" placeholder="Data Início" data-inputmask="'alias': 'dd/mm/yyyy'" required>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Hora*</label>
                                    <select name="horaIniEncaixe" id="comHoraIniEncaixe" class="input-large form-control select2" style="width:100%;" required>
                                        <option value="" selected>Hora</option>
                                        <option value='00:00'>00:00</option><option value='00:05'>00:05</option><option value='00:10'>00:10</option><option value='00:15'>00:15</option><option value='00:20'>00:20</option><option value='00:25'>00:25</option><option value='00:30'>00:30</option><option value='00:35'>00:35</option><option value='00:40'>00:40</option><option value='00:45'>00:45</option><option value='00:50'>00:50</option><option value='00:55'>00:55</option><option value='01:00'>01:00</option><option value='01:05'>01:05</option><option value='01:10'>01:10</option><option value='01:15'>01:15</option><option value='01:20'>01:20</option><option value='01:25'>01:25</option><option value='01:30'>01:30</option><option value='01:35'>01:35</option><option value='01:40'>01:40</option><option value='01:45'>01:45</option><option value='01:50'>01:50</option><option value='01:55'>01:55</option><option value='02:00'>02:00</option><option value='02:05'>02:05</option><option value='02:10'>02:10</option><option value='02:15'>02:15</option><option value='02:20'>02:20</option><option value='02:25'>02:25</option><option value='02:30'>02:30</option><option value='02:35'>02:35</option><option value='02:40'>02:40</option><option value='02:45'>02:45</option><option value='02:50'>02:50</option><option value='02:55'>02:55</option><option value='03:00'>03:00</option><option value='03:05'>03:05</option><option value='03:10'>03:10</option><option value='03:15'>03:15</option><option value='03:20'>03:20</option><option value='03:25'>03:25</option><option value='03:30'>03:30</option><option value='03:35'>03:35</option><option value='03:40'>03:40</option><option value='03:45'>03:45</option><option value='03:50'>03:50</option><option value='03:55'>03:55</option><option value='04:00'>04:00</option><option value='04:05'>04:05</option><option value='04:10'>04:10</option><option value='04:15'>04:15</option><option value='04:20'>04:20</option><option value='04:25'>04:25</option><option value='04:30'>04:30</option><option value='04:35'>04:35</option><option value='04:40'>04:40</option><option value='04:45'>04:45</option><option value='04:50'>04:50</option><option value='04:55'>04:55</option><option value='05:00'>05:00</option><option value='05:05'>05:05</option><option value='05:10'>05:10</option><option value='05:15'>05:15</option><option value='05:20'>05:20</option><option value='05:25'>05:25</option><option value='05:30'>05:30</option><option value='05:35'>05:35</option><option value='05:40'>05:40</option><option value='05:45'>05:45</option><option value='05:50'>05:50</option><option value='05:55'>05:55</option><option value='06:00'>06:00</option><option value='06:05'>06:05</option><option value='06:10'>06:10</option><option value='06:15'>06:15</option><option value='06:20'>06:20</option><option value='06:25'>06:25</option><option value='06:30'>06:30</option><option value='06:35'>06:35</option><option value='06:40'>06:40</option><option value='06:45'>06:45</option><option value='06:50'>06:50</option><option value='06:55'>06:55</option><option value='07:00'>07:00</option><option value='07:05'>07:05</option><option value='07:10'>07:10</option><option value='07:15'>07:15</option><option value='07:20'>07:20</option><option value='07:25'>07:25</option><option value='07:30'>07:30</option><option value='07:35'>07:35</option><option value='07:40'>07:40</option><option value='07:45'>07:45</option><option value='07:50'>07:50</option><option value='07:55'>07:55</option><option value='08:00'>08:00</option><option value='08:05'>08:05</option><option value='08:10'>08:10</option><option value='08:15'>08:15</option><option value='08:20'>08:20</option><option value='08:25'>08:25</option><option value='08:30'>08:30</option><option value='08:35'>08:35</option><option value='08:40'>08:40</option><option value='08:45'>08:45</option><option value='08:50'>08:50</option><option value='08:55'>08:55</option><option value='09:00'>09:00</option><option value='09:05'>09:05</option><option value='09:10'>09:10</option><option value='09:15'>09:15</option><option value='09:20'>09:20</option><option value='09:25'>09:25</option><option value='09:30'>09:30</option><option value='09:35'>09:35</option><option value='09:40'>09:40</option><option value='09:45'>09:45</option><option value='09:50'>09:50</option><option value='09:55'>09:55</option><option value='10:00'>10:00</option><option value='10:05'>10:05</option><option value='10:10'>10:10</option><option value='10:15'>10:15</option><option value='10:20'>10:20</option><option value='10:25'>10:25</option><option value='10:30'>10:30</option><option value='10:35'>10:35</option><option value='10:40'>10:40</option><option value='10:45'>10:45</option><option value='10:50'>10:50</option><option value='10:55'>10:55</option><option value='11:00'>11:00</option><option value='11:05'>11:05</option><option value='11:10'>11:10</option><option value='11:15'>11:15</option><option value='11:20'>11:20</option><option value='11:25'>11:25</option><option value='11:30'>11:30</option><option value='11:35'>11:35</option><option value='11:40'>11:40</option><option value='11:45'>11:45</option><option value='11:50'>11:50</option><option value='11:55'>11:55</option><option value='12:00'>12:00</option><option value='12:05'>12:05</option><option value='12:10'>12:10</option><option value='12:15'>12:15</option><option value='12:20'>12:20</option><option value='12:25'>12:25</option><option value='12:30'>12:30</option><option value='12:35'>12:35</option><option value='12:40'>12:40</option><option value='12:45'>12:45</option><option value='12:50'>12:50</option><option value='12:55'>12:55</option><option value='13:00'>13:00</option><option value='13:05'>13:05</option><option value='13:10'>13:10</option><option value='13:15'>13:15</option><option value='13:20'>13:20</option><option value='13:25'>13:25</option><option value='13:30'>13:30</option><option value='13:35'>13:35</option><option value='13:40'>13:40</option><option value='13:45'>13:45</option><option value='13:50'>13:50</option><option value='13:55'>13:55</option><option value='14:00'>14:00</option><option value='14:05'>14:05</option><option value='14:10'>14:10</option><option value='14:15'>14:15</option><option value='14:20'>14:20</option><option value='14:25'>14:25</option><option value='14:30'>14:30</option><option value='14:35'>14:35</option><option value='14:40'>14:40</option><option value='14:45'>14:45</option><option value='14:50'>14:50</option><option value='14:55'>14:55</option><option value='15:00'>15:00</option><option value='15:05'>15:05</option><option value='15:10'>15:10</option><option value='15:15'>15:15</option><option value='15:20'>15:20</option><option value='15:25'>15:25</option><option value='15:30'>15:30</option><option value='15:35'>15:35</option><option value='15:40'>15:40</option><option value='15:45'>15:45</option><option value='15:50'>15:50</option><option value='15:55'>15:55</option><option value='16:00'>16:00</option><option value='16:05'>16:05</option><option value='16:10'>16:10</option><option value='16:15'>16:15</option><option value='16:20'>16:20</option><option value='16:25'>16:25</option><option value='16:30'>16:30</option><option value='16:35'>16:35</option><option value='16:40'>16:40</option><option value='16:45'>16:45</option><option value='16:50'>16:50</option><option value='16:55'>16:55</option><option value='17:00'>17:00</option><option value='17:05'>17:05</option><option value='17:10'>17:10</option><option value='17:15'>17:15</option><option value='17:20'>17:20</option><option value='17:25'>17:25</option><option value='17:30'>17:30</option><option value='17:35'>17:35</option><option value='17:40'>17:40</option><option value='17:45'>17:45</option><option value='17:50'>17:50</option><option value='17:55'>17:55</option><option value='18:00'>18:00</option><option value='18:05'>18:05</option><option value='18:10'>18:10</option><option value='18:15'>18:15</option><option value='18:20'>18:20</option><option value='18:25'>18:25</option><option value='18:30'>18:30</option><option value='18:35'>18:35</option><option value='18:40'>18:40</option><option value='18:45'>18:45</option><option value='18:50'>18:50</option><option value='18:55'>18:55</option><option value='19:00'>19:00</option><option value='19:05'>19:05</option><option value='19:10'>19:10</option><option value='19:15'>19:15</option><option value='19:20'>19:20</option><option value='19:25'>19:25</option><option value='19:30'>19:30</option><option value='19:35'>19:35</option><option value='19:40'>19:40</option><option value='19:45'>19:45</option><option value='19:50'>19:50</option><option value='19:55'>19:55</option><option value='20:00'>20:00</option><option value='20:05'>20:05</option><option value='20:10'>20:10</option><option value='20:15'>20:15</option><option value='20:20'>20:20</option><option value='20:25'>20:25</option><option value='20:30'>20:30</option><option value='20:35'>20:35</option><option value='20:40'>20:40</option><option value='20:45'>20:45</option><option value='20:50'>20:50</option><option value='20:55'>20:55</option><option value='21:00'>21:00</option><option value='21:05'>21:05</option><option value='21:10'>21:10</option><option value='21:15'>21:15</option><option value='21:20'>21:20</option><option value='21:25'>21:25</option><option value='21:30'>21:30</option><option value='21:35'>21:35</option><option value='21:40'>21:40</option><option value='21:45'>21:45</option><option value='21:50'>21:50</option><option value='21:55'>21:55</option><option value='22:00'>22:00</option><option value='22:05'>22:05</option><option value='22:10'>22:10</option><option value='22:15'>22:15</option><option value='22:20'>22:20</option><option value='22:25'>22:25</option><option value='22:30'>22:30</option><option value='22:35'>22:35</option><option value='22:40'>22:40</option><option value='22:45'>22:45</option><option value='22:50'>22:50</option><option value='22:55'>22:55</option><option value='23:00'>23:00</option><option value='23:05'>23:05</option><option value='23:10'>23:10</option><option value='23:15'>23:15</option><option value='23:20'>23:20</option><option value='23:25'>23:25</option><option value='23:30'>23:30</option><option value='23:35'>23:35</option><option value='23:40'>23:40</option><option value='23:45'>23:45</option><option value='23:50'>23:50</option><option value='23:55'>23:55</option><option value='00:00'>00:00</option>                                    </select>
                                </div>
                            </div>
                        </div>
                        <small class="text-red">* Este serviço será adicionado como Encaixe. Nos encaixes, não são verificados choques de horário.</small>
                        <div class="box-footer">
                            <button type="submit" id="btnSalvaEncaixeAgenda" class="btn btn-success">Salvar</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="cadastrarcliente-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-envelope-o"></i> Novo Cadastro </h4>
                </div>
                <form id="formCadastro" autocomplete="off">
                    <div class="modal-body">
                        <div class="box-body">
                            <div class="box box-primary">
                                <div class="box-header" data-toggle="tooltip" title="(*) Campos Obrigatórios.">
                                    <h3 class="box-title">Dados Pessoais</h3>
                                    <button type="submit" class="btn btn-xs btn-primary pull-right">Cadastrar</button>
                                </div>
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Nome*</label>
                                                <input type="text" name="cliNome" id="cliNome" class="form-control" placeholder="Nome" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Celular*</label>
                                                <input type="tel" id="cliCelular" name="cliCelular" class="form-control">
                                                <input type="hidden" id="cliDialCode" name="cliDialCode">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>E-mail <i data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Obrigatório para clientes com usuário."></i></label>
                                                <input autocomplete="off" onkeyup="this.value=this.value.replace(/[' ']/g,'')" type="text" name="cliEnderecoEletronico" id="cliEnderecoEletronico" class="form-control" ng-model="loginEmail">
                                            </div>

                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Telefone</label>
                                                <input type="text" maxlength="15" name="cliTelefone" id="cliTelefone" class="form-control" placeholder="Telefone">
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>CPF</label>
                                                <input type="text" maxlength="14" onKeyPress="mascara(this,soCpf)" name="cliCpf" class="form-control" placeholder="CPF">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>RG</label>
                                                <input type="text" maxlength="14" name="cliRG" class="form-control" placeholder="RG">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Sexo</label>
                                                <select name="cliSexo" class="input-large form-control">
                                                    <option value="" selected>Sexo</option>
                                                    <option value="Feminino">Feminino</option>
                                                    <option value="Masculino">Masculino</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Data Nascimento</label>
                                                <div class="input-group date">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input type="text" name="cliDataNascimento" id="cliDataNascimento" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>País</label>
                                                <select name="cliPaisNovoCadastro" id="cliPaisNovoCadastro" class="input-large form-control"></select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Estado</label>
                                                
                                                <select name="cliEstado" id="cliEstado" class="input-large form-control" style="width: 100%;">
                                                    <!-- <option selected="selected" value="-1">Estado</option>
                                                    <option id='AC' value=5>Acre</option><option id='AL' value=2>Alagoas</option><option id='AM' value=4>Amazonas</option><option id='AP' value=3>Amapá</option><option id='BA' value=6>Bahia</option><option id='CE' value=7>Ceará</option><option id='DF' value=8>Distrito Federal</option><option id='ES' value=9>Espírito Santo</option><option id='GO' value=10>Goiás</option><option id='MA' value=11>Maranhão</option><option id='MG' value=14>Minas Gerais</option><option id='MS' value=13>Mato Grosso do Sul</option><option id='MT' value=12>Mato Grosso</option><option id='PA' value=15>Pará</option><option id='PB' value=16>Paraíba</option><option id='PE' value=18>Pernambuco</option><option id='PI' value=19>Piauí</option><option id='PR' value=17>Paraná</option><option id='RJ' value=20>Rio de Janeiro</option><option id='RN' value=21>Rio Grande do Norte</option><option id='RO' value=23>Rondônia</option><option id='RR' value=24>Roraima</option><option id='RS' value=22>Rio Grande do Sul</option><option id='SC' value=1>Santa Catarina</option><option id='SE' value=26>Sergipe</option><option id='SP' value=25>São Paulo</option><option id='TO' value=27>Tocantins</option> -->
                                                </select>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Cidade</label>
                                                
                                                <select name="cliCidade" id="cliCidade" class="input-large form-control" disabled style="width: 100%;">
                                                </select>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Endereço Completo</label>
                                                <textarea name="cliEndereco" id="cliEndereco" class="form-control" rows="3" placeholder="Endereço Completo"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Bairro</label>
                                                <input type="text" name="cliBairro" id="cliBairro" class="form-control" placeholder="Bairro">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>CEP</label>
                                                <input type="text" maxlength="9" onKeyPress="mascara(this,soCep)" name="cliCep" id="cliCep" class="form-control" placeholder="CEP">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Número</label>
                                                <input type="text" name="cliNumero" id="cliNumero" class="form-control" placeholder="Número">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Complemento</label>
                                                <input type="text" name="cliComplemento" id="cliComplemento" class="form-control" placeholder="Complemento">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Observações</label>
                                                <input type="text" name="cliObservacao" id="cliObservacao" class="form-control" placeholder="Observações">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="cliOnde">Como Soube do Estabelecimento?</label>
                                                <input class="form-control" id="cliOnde" name="cliOnde">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="box box-primary" hidden>
                                <div class="box-header" data-toggle="tooltip" title="Para usuário do Aplicativo">
                                    <h3 class="box-title">Dados Usuário</h3>
                                </div>
                                <div class="box-body">
                                                                        <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{"usuario" | translate}}</label>
                                                <input type="password" style="display:none;"/>
                                                <input type="text" id="cliLoginIdAg" class="form-control" placeholder="E-mail" autocomplete="off" disabled="true" value="{{loginEmail}}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Senha</label>
                                                <input type="password" style="display:none;"/>
                                                <input onkeyup="this.value=this.value.replace(/[' ']/g,'')" type="password" name="cliSenha" class="form-control" placeholder="Senha" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>(*) Campos Obrigatórios.</label>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Cadastrar</button>
                                <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade" id="rodizio-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" style="width:70%;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-envelope-o"></i> Rodízio </h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="box box-success box-solid" id="rodizioAberto" style="box-shadow: 5px 5px 5px #888888;">
                                    <div class="box-body">
                                        <table id="tbBuscaRodAgenda" class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th style="display:none;">Row</th>
                                                    <th style="display:none;">Codigo</th>
                                                    <th>Ordem</th>
                                                    <th>Nome</th>
                                                    <th style="display:none;">Data</th>
                                                    <th>Agendamentos</th>
                                                    <th>Status</th>
                                                    <th style="width:30px;"></th>
                                                    <th style="width:30px;"></th>
                                                    <th style="width:70px;"></th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cancelarAgendamento-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-exclamation-circle"></i> Cancelar Comanda </h4>
                </div>
                <form id="formCancelaAgendamento">
                    <div class="modal-body">
                        <div class="box-body">
                            <div class="box box-danger">
                                <div class="box-header" data-toggle="tooltip"></div>
                                <div class="box-body">
                                    <div class="row"></div>
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label>Motivo do Cancelamento*</label>
                                                <textarea class="form-control" name="ageMotivo" id="ageMotivo" required></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary">Salvar</button>
                                    <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editarAgendamento-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-starapp-30">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-pencil"></i> Editar Agendamento </h4>
                </div>
                <div class="modal-body">
                    <form id="formAlteraAgendamento">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Tipo</label>
                                        <select name="tipoAlteraAgendamento" id="tipoAlteraAgendamento" class="form-control select2">
                                            <option value="0">Tipo</option>
                                            <option value="1">Apenas Horário</option>
                                            <option value="2">Apenas Serviço</option>
                                            <option value="3">Apenas Profissional</option>
                                            <option value="4">Horário e Profissional</option>
                                            <option value="5">Horário e Serviço</option>
                                            <option value="6">Profissional e Serviço</option>
                                            <option value="7">Serviço, Profissional e Horário</option>
                                            <option value="8">Duração</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div id="divAlteraAgendamentoData">
                                    <div class="col-lg-6 col-sm-6">
                                        <div class="form-group">
                                            <label>Data</label>
                                            <div class="input-group date dateAltAge">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" id="dataAlteraAgendamento" name="dataAlteraAgendamento" class="form-control date" data-inputmask="'alias': 'dd/mm/yyyy'">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-sm-6">
                                        <div class="bootstrap-timepicker">
                                            <div class="form-group">
                                                <label>Hora</label>
                                                <div class="input-group">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-clock-o"></i>
                                                    </div>
                                                    <input type="text" id="horaAlteraAgendamento" name="horaAlteraAgendamento" class="form-control timepicker ui-timepicker-input" autocomplete="off">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="divAlteraAgendamentoProfissional">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Profissional</label>
                                            <select name="profissionalAlteraAgendamento" id="profissionalAlteraAgendamento" class="form-control select2"></select>
                                        </div>
                                    </div>
                                </div>
                                <div id="divAlteraAgendamentoServico">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Serviço</label>
                                            <select name="servicoAlteraAgendamento" id="servicoAlteraAgendamento" class="form-control select2"></select>
                                        </div>
                                    </div>
                                </div>
                                <div id="divAlteraAgendamentoDuracao">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Duração</label>
                                            <select name="DuracaoAlteraAgendamento" id="DuracaoAlteraAgendamento" class="form-control select2"></select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <button class="btn btn-primary">Salvar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="aletraAgendamentoObs-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-exclamation-circle"></i> Observação </h4>
                </div>
                <form id="formAlteraAgendamentoObs">
                    <input type="hidden" id="idAgendamentoAlteraObs">
                    <div class="modal-body">
                        <div class="box-body">
                            <div class="box box-success">
                                <div class="box-header" data-toggle="tooltip"></div>
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label>Observação*</label>
                                                <textarea class="form-control" name="ageAlteraObs" id="ageAlteraObs" required></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary">Salvar</button>
                                    <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade" id="buscaHorariosDisponivel-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-starapp-80">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-exclamation-circle"></i> Verificar horários disponíveis </h4>
                </div>
                <form id="formBuscaHorariosDisponiveis">
                    <div class="modal-body">
                        <div class="box-body">
                            <div class="box box-success">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-3 col-sm-3">
                                            <div class="form-group">
                                                <label>Profissional</label>
                                                <select name="profisisonalHorDisp" id="profisisonalHorDisp" class="form-control">
                                                    <option value="">Selecione um Profissional</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <div class="form-group">
                                                <label>Serviço</label>
                                                <select name="servicoHorDisp" id="servicoHorDisp" class="form-control">
                                                    <option value="">Selecione um Profissional</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3">
                                            <div class="form-group">
                                                <label>De</label>
                                                <div class="input-group date dataIniDisp">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input type="text" name="dataIniHorarioDisp" id="dataIniHorarioDisp" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <div class="form-group">
                                                <label>Até</label>
                                                <div class="input-group date dataFimDisp">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input type="text" name="dataFimHorarioDisp" id="dataFimHorarioDisp" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button class="btn btn-primary pull-right">Pesquisar</button>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-12" id="divTabelaHorDisp">
                                            <table id="tabelaHorDisp" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th style='width:40%'>Data</th>
                                                        <th style='width:40%'>Nº Horarios Livres</th>
                                                        <th style='width:10%'>Ver Horários</th>
                                                        <th style='width:10%'>Ver</th>
                                                    </tr>
                                                </thead>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade in" id="clubeinfo-modal" style=" padding-right: 15px;">
        <div class="modal-dialog modal-starapp-30">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span></button>
                    <h4 class="modal-title">Informações clube</h4>
                </div>
                <div class="modal-body">
                    <div class="panel price bg-purple">
                        <div class="panel-heading arrow_box text-center">
                            <h4 id="nomeClube"></h4>
                        </div>
                        <ul class="list-group list-group-flush text-center">
                            <li class="list-group-item" id="nomeservicoclube" style="color:black;"></li>
                            <li class="list-group-item" id="clubedesconto" style="color:black;"></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cadastrarlembrete-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-envelope-o"></i> Novo Lembrete </h4>
                </div>
                <form id="formInserirLembrete">
                    <div class="modal-body">
                        <div class="box-body">

                            <input type="hidden" name="pesCodigoClienteLembrete" id="pesCodigoClienteLembrete" class="form-control">
                            <input type="hidden" name="usuCodigoCodigoLembrete" id="usuCodigoCodigoLembrete" class="form-control">
                            <input type="hidden" name="ageCodigoLembrete" id="ageCodigoLembrete" class="form-control">
                            <input type="hidden" name="dataInicioLembrete" id="dataInicioLembrete" class="form-control">
                            <input type="hidden" name="horaInicioLembrete" id="horaInicioLembrete" class="form-control">
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <h4>Data do agendamento: <b><span id="dataAgendamentoLembrete"></span></b></h4>
                                </div>
                            </div>

                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label>Lembrar quanto tempo antes:</label>
                                    <select class="form-control" id="min_lembrete" name="min_lembrete">
                                        <option value="5">5 Minutos</option>
                                        <option value="10">10 Minutos</option>
                                        <option value="15">15 Minutos</option>
                                        <option value="20">20 Minutos</option>
                                        <option value="25">25 Minutos</option>
                                        <option value="30">30 Minutos</option>
                                        <option value="35">35 Minutos</option>
                                        <option value="40">40 Minutos</option>
                                        <option value="45">45 Minutos</option>
                                        <option value="50">50 Minutos</option>
                                        <option value="60">1 Hora</option>
                                        <option value="120">2 Horas</option>
                                        <option value="180">3 Horas</option>
                                        <option value="240">4 Horas</option>
                                        <option value="300">5 Horas</option>
                                        <option value="360">6 Horas</option>
                                        <option value="720">12 Horas</option>
                                        <option value="1440">1 Dia</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="cbEnviaSmsLem" id="cbEnviaSmsLem"> Enviar SMS
                                            </label>
                                        </div>

                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <h5> Saldo de SMS: <label id=lblSaldoSMSLem></label></h5><a id="btnCompraSmsLem" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i>&nbspComprar sms</a>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="cbEnviaWhatsLem" id="cbEnviaWhatsLem"> Enviar WhatsApp
                                            </label>
                                        </div>

                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <h5> Saldo de WhatsApp: <label id=lblSaldoWhatsLem></label></h5><a id="btnCompraWhatsLem" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i>&nbspComprar WhatsApp</a>
                                    </div>
                                </div>
                            </div>

                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Salvar</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade" id="listaAgendamentoModal-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-starapp-90">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-exclamation-circle"></i> Lista de Agendamentos </h4>
                </div>

                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-success">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6 col-xs-12">
                                        <div class="form-group">
                                            <label>De</label>
                                            <div class="input-group date dataIniLista">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" name="dataIniListaAgendamento" id="dataIniListaAgendamento" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Até</label>
                                            <div class="input-group date dataFimLista">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" name="dataFimListaAgendamento" id="dataFimListaAgendamento" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-xs-12">
                                        <div class="form-group">
                                            <label>Profissional</label>
                                            <select name="profListaAgendamento" id="profListaAgendamento" class="form-control"></select>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-12">
                                        <div class="form-group">
                                            <label>Serviço</label>
                                            <select name="serListaAgendamento" id="serListaAgendamento" class="form-control"></select>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-12">
                                        <div class="form-group">
                                            <label>Cliente</label>
                                            <select name="cliListaAgendamento" id="cliListaAgendamento" class="form-control select2 clientes" style="width:100%"></select>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <button class="btn btn-primary pull-right" ng-click="pesquisaListaAgendamento()">Pesquisar</button>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-12" id="divListaAgendamento">
                                        <table id="tableListaAgendamento" class="table table-striped"></table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cancelarAgendamentoLista-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-exclamation-circle"></i> Cancelar Comanda </h4>
                </div>

                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-danger">
                            <div class="box-header" data-toggle="tooltip"></div>
                            <div class="box-body">
                                <div class="row">
                                    <input type="hidden" id="AgeCodigoListaCancela">

                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Motivo do Cancelamento*</label>
                                            <textarea class="form-control" name="ageMotivoLista" id="ageMotivoLista" required></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="button" class="btn btn-primary" ng-click="cancelaAgendamentoLista()">Salvar</button>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editarAgendamentoLista-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-starapp-30">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-pencil"></i> Editar Agendamento </h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div class="row">
                            <input type="hidden" id="citCodigoAlteraAgendamentoLista">
                            <input type="hidden" id="dataOriginalAgendamento">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Tipo</label>
                                    <select name="tipoAlteraAgendamentoLista" id="tipoAlteraAgendamentoLista" class="form-control select2">
                                        <option value="0">Tipo</option>
                                        <option value="1">Apenas Horário</option>
                                        <option value="2">Apenas Serviço</option>
                                        <option value="3">Apenas Profissional</option>
                                        <option value="4">Horário e Profissional</option>
                                        <option value="5">Horário e Serviço</option>
                                        <option value="6">Profissional e Serviço</option>
                                        <option value="7">Serviço, Profissional e Horário</option>
                                        <option value="8">Duração</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div id="divAlteraAgendamentoDataLista">
                                <div class="col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label>Data</label>
                                        <div class="input-group date dateAltAgeLista">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" id="dataAlteraAgendamentoLista" name="dataAlteraAgendamentoLista" class="form-control date" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6">
                                    <div class="bootstrap-timepicker">
                                        <div class="form-group">
                                            <label>Hora</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-clock-o"></i>
                                                </div>
                                                <input type="text" id="horaAlteraAgendamentoLista" name="horaAlteraAgendamentoLista" class="form-control timepicker ui-timepicker-input" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="divAlteraAgendamentoProfissionalLista">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Profissional</label>
                                        <select name="profissionalAlteraAgendamentoLista" id="profissionalAlteraAgendamentoLista" class="form-control select2"></select>
                                    </div>
                                </div>
                            </div>
                            <div id="divAlteraAgendamentoServicoLista">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Serviço</label>
                                        <select name="servicoAlteraAgendamentoLista" id="servicoAlteraAgendamentoLista" class="form-control select2"></select>
                                    </div>
                                </div>
                            </div>
                            <div id="divAlteraAgendamentoDuracaoLista">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Duração</label>
                                        <select name="DuracaoAlteraAgendamentoLista" id="DuracaoAlteraAgendamentoLista" class="form-control select2"></select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-primary" ng-click="alteraAgendamentoLista()">Salvar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="addtagagendamento-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-exclamation-circle"></i> Adicionar Tag </h4>
                </div>
                <div class="modal-body">
                    <div clas="col-md-12">
                        <div class="row">
                            <input type="hidden" id="AgeCodigoTagAgendamento">
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label>Nova tag*</label>
                                    <input class="form-control" name="tagAgendamentoText" id="tagAgendamentoText" maxlength="50" required></input>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 text-center">
                                <div class="form-group">
                                    <label for="picker">*Cor da Tag</label>
                                    <div id="picker" style="margin-left:36%"></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="box box-warning">
                                <div class="box-header" data-toggle="tooltip"></div>
                                <div class="box-body">
                                    <div class="col-md-12 text-center">
                                        <label>Exemplo</label>
                                        <div class="form-group">
                                            <label id="tagExemplo" class="label" style="background-color: #ebebeb;">Exemplo</label>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-primary pull-right" ng-click="addTagAgendamento()">Salvar</button>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

</section>

<div class="modal fade" id="modalListaEspera-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog  modal-starapp-70">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-clock-o"></i> Lista de Espera <span id="dataListaEspera"></span></h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <button class="btn btn-md btn-success pull-right" ng-click="insereClienteListaEsperaAgenda()"><i class="fa fa-plus"></i>&nbsp&nbspAdicionar na Lista de Espera</button>
                        <button type="submit" ng-click="atualizaDadosListaEspera();" class="btn btn-primary pull-right" style="margin-right: 5px;">Pesquisar</button>
                    </div>
                </div>
                <div class="row">
                    <div clas="col-md-12 table-responsive">
                        <table id="tbBuscaListaAgenda" class="table table-striped " style="width: 100%;"></table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="insereClienteListaAgenda-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><br>
            </div>
            <form id="formListaEsperaAgenda" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-success">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <label>Cliente*</label>
                                            <select class="form-control select2 clientes" style='width: 100%' id="pesCodigoClienteListaAgenda" name="pesCodigoClienteListaAgenda" required="true"></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <label>Serviço*</label>
                                            <select class="form-control select2" style='width: 100%' id="servicoListaAgenda" name="servicoListaAgenda" required="true"></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 ">
                                        <div class="form-group">
                                            <label>Data :*</label>
                                            <div class="input-group date divDataListaAgenda">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" id="DataListaAgenda" name="DataListaAgenda" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Observação*</label>
                                            <textarea id="ObsListaDataAgenda" name="ObsListaDataAgenda" class="form-control" required="true"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>(*) Campos Obrigatórios.</label>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-success">Salvar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="listaHorariosProfissionalDetalhes-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><br>
            </div>
            
            <div class="modal-body">
                
                <div class="row">
                    <div class="col-md-12" ng-repeat="profissional in listaProfissional">

                        <div class="panel box box-primary ">
                            <div class="box-header with-border">
                                <h4 class="box-title text-center" style="width:100%">
                                    
                                    {{profissional.Apelido}}
                                    
                                    
                                </h4>
                            </div>
                            
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-3 text-center" disabled ng-repeat="horarios in profissional.horarios">
                                        <button type="button" style="margin-bottom: 10px;" class="btn btn-block bg-navy" ng-click="goToDataAgenda(horarios.DataIni,profissional.data,profissional.tempo,profissional.PesCodigoPrincipal,profissional.dialivre,profissional.servico)"> {{horarios.DataIni}}</button>
                                    </div>
                                        <!-- <div> {{horarios.horarios}}</div> -->
                                   
                                </div>
                                <div class="row">
                                    <div class="col-md-12" id="btnCopiarHorarios">
                                       
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="selecionarCategoria-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-users"></i> Categorias </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12 ">
                            <h3 align="center">Categorias</h3>
                            <div class="col-md-12" id="categoriasRodizioAgenda" style="border: 1px solid #00a65a;display:block;border-radius:3px;box-shadow: 5px 5px 5px #888888;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
