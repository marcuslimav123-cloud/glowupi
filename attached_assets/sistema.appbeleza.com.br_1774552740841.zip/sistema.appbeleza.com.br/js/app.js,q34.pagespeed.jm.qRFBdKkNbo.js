var $_CONFIG = {};
$_CONFIG.acoes = {};
localStorage.setItem('host', 'https://ws.appbeleza.com.br/Service.php');
localStorage.setItem('host_local', './js');
$.ajax({
    dataType: 'json',
    url: '/lang/' + document.body.lang + '.json?v=' + version,
    async: false,
    success: function(data) {
        $_CONFIG.language = data;
    }
});
var appBeleza = angular.module('appBeleza', ['ui.router', 'pascalprecht.translate', 'oc.lazyLoad']).config(function($stateProvider, $urlRouterProvider, $translateProvider) {
    $translateProvider.useStaticFilesLoader({
        prefix: '/lang/',
        suffix: '.json'
    });
    $translateProvider.preferredLanguage(document.body.lang);
    $stateProvider.state('agenda', {
        url: '/agenda',
        templateUrl: '/pages/agenda.php',
        controller: 'agendaCtrl'
    }).state('comandasAbertas', {
        url: '/comandasabertas',
        templateUrl: '/pages/cadastros/comandasAbertas.php',
        controller: 'comandasAbertasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/comandasAbertasCtrl.js?' + version);
            }]
        }
    }).state('comandasHistorico', {
        url: '/comandashistorico',
        templateUrl: '/pages/cadastros/comandasHistorico.php',
        controller: 'comandasHistoricoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/comandasHistoricoCtrl.js?' + version);
            }]
        }
    }).state('clientes', {
        url: '/clientes',
        templateUrl: '/pages/cadastros/clientes.php',
        controller: 'clientesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/clientesCtrl.js?' + version);
            }]
        }
    }).state('profissionais', {
        url: '/profissionais',
        templateUrl: '/pages/cadastros/profissionais.php',
        controller: 'profissionalCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/profissionalCtrl.js?' + version);
            }]
        }
    }).state('servicos', {
        url: '/servicos',
        templateUrl: '/pages/cadastros/servicos.php',
        controller: 'servicosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/servicosCtrl.js?' + version);
            }]
        }
    }).state('pacotes', {
        url: '/pacotes',
        templateUrl: '/pages/cadastros/pacotes.php',
        controller: 'pacotesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/pacotesCtrl.js?' + version);
            }]
        }
    }).state('pacotesVenda', {
        url: '/pacotesVenda',
        templateUrl: '/pages/cadastros/pacotesVenda.php',
        controller: 'pacotesVendaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/pacotesVendaCtrl.js?' + version);
            }]
        }
    }).state('mensagens', {
        url: '/mensagens',
        templateUrl: '/pages/cadastros/mensagens.php',
        controller: 'mensagensCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/mensagensCtrl.js?' + version);
            }]
        }
    }).state('noticias', {
        url: '/noticias',
        templateUrl: '/pages/cadastros/noticias.php',
        controller: 'noticiasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/noticiasCtrl.js?' + version);
            }]
        }
    }).state('grupos', {
        url: '/grupos',
        templateUrl: '/pages/cadastros/grupos.php',
        controller: 'gruposCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/gruposCtrl.js?' + version);
            }]
        }
    }).state('rodizio', {
        url: '/rodizio',
        templateUrl: '/pages/cadastros/rodizio.php',
        controller: 'rodizioCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/rodizioCtrl.js?' + version);
            }]
        }
    }).state('parametros', {
        url: '/parametros',
        templateUrl: '/pages/cadastros/parametros.php',
        controller: 'parametrosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/parametrosCtrl.js?' + version);
            }]
        }
    }).state('tipoPagamentos', {
        url: '/tipopagamentos',
        templateUrl: '/pages/cadastros/tipoPagamentos.php',
        controller: 'tipoPagamentosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/tipoPagamentosCtrl.js?' + version);
            }]
        }
    }).state('comissaoProf', {
        url: '/comissaoprofissionais',
        templateUrl: '/pages/relatorios/relComissaoProfissionais.php',
        controller: 'comissaoProfCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/comissaoProfCtrl.js?' + version);
            }]
        }
    }).state('relAgendameto', {
        url: '/relatorioagendamento',
        templateUrl: '/pages/relatorios/relAgendamentos.php',
        controller: 'relAgendametoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relAgendamentoCtrl.js?' + version);
            }]
        }
    }).state('relSolClientes', {
        url: '/relatoriosolicitacoes',
        templateUrl: '/pages/relatorios/relSolicitacaoCliente.php',
        controller: 'relSolClientesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relSolClientesCtrl.js?' + version);
            }]
        }
    }).state('relClientes', {
        url: '/relAgendamentoClientes',
        templateUrl: '/pages/relatorios/relAgendaClientes.php',
        controller: 'relClientesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relClientesCtrl.js?' + version);
            }]
        }
    }).state('relProfissionais', {
        url: '/relatorioprofissionais',
        templateUrl: '/pages/relatorios/relAgendaProfissionais.php',
        controller: 'relProfissionaisCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relProfissionaisCtrl.js?' + version);
            }]
        }
    }).state('relFidelidade', {
        url: '/relatoriofidelidade',
        templateUrl: '/pages/relatorios/relProgramaFidelidade.php',
        controller: 'relFidelidadeCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relFidelidadeCtrl.js?' + version);
            }]
        }
    }).state('relRetorno', {
        url: '/relatorioclientes',
        templateUrl: '/pages/relatorios/relRetornoClientes.php',
        controller: 'relRetornoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relRetornoCtrl.js?' + version);
            }]
        }
    }).state('relGerencialAgendamentos', {
        url: '/relatoriogerencialagendamentos',
        templateUrl: '/pages/relatorios/relGerencial.php',
        controller: 'relGerencialAgendamentosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialAgendamentosCtrl.js?' + version);
            }]
        }
    }).state('relGerencialPerfil', {
        url: '/relatoriogerencialperfil',
        templateUrl: '/pages/relatorios/relGerencialCliente.php',
        controller: 'relGerencialPerfilCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialPerfilCtrl.js?' + version);
            }]
        }
    }).state('profissionalJornada', {
        url: '/profissionaljornada',
        templateUrl: '/pages/cadastros/profissionalJornada.php',
        controller: 'profissionalJornadaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/profissionalJornadaCtrl.js?' + version);
            }]
        }
    }).state('profissionalServico', {
        url: '/profissionalservico',
        templateUrl: '/pages/cadastros/servicoProfissional.php',
        controller: 'profissionalServicoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/profissionalServicoCtrl.js?' + version);
            }]
        }
    }).state('contaCliente', {
        url: '/contacliente',
        templateUrl: '/pages/cadastros/contacliente.php',
        controller: 'contaClienteCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/contaClienteCtrl.js?' + version);
            }]
        }
    }).state('estoque', {
        url: '/estoque',
        templateUrl: '/pages/cadastros/produtos.php',
        controller: 'estoqueCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/estoqueCtrl.js?' + version);
            }]
        }
    }).state('caixa', {
        url: '/caixa',
        templateUrl: '/pages/cadastros/caixa.php',
        controller: 'caixaCtrl'
    }).state('lembretes', {
        url: '/lembretes',
        templateUrl: '/pages/cadastros/lembretes.php',
        controller: 'lembretesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/lembretesCtrl.js?' + version);
            }]
        }
    }).state('relCaixa', {
        url: '/relatoriocaixa',
        templateUrl: '/pages/relatorios/relCaixa.php',
        controller: 'relCaixaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relCaixaCtrl.js?' + version);
            }]
        }
    }).state('movCaixa', {
        url: '/entradasaida',
        templateUrl: '/pages/cadastros/movCaixa.php',
        controller: 'movCaixaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/movCaixaCtrl.js?' + version);
            }]
        }
    }).state('pesquisa', {
        url: '/pesquisa',
        templateUrl: '/pages/cadastros/pesquisa.php',
        controller: 'pesquisaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/pesquisaCtrl.js?' + version);
            }]
        }
    }).state('conta', {
        url: '/conta',
        templateUrl: '/pages/cadastros/conta.php',
        controller: 'contaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/contaCtrl.js?' + version);
            }]
        }
    }).state('relGerencialFinanceiro', {
        url: '/relatoriogerencialfinanceiro',
        templateUrl: '/pages/relatorios/relGerencialFinanceiro.php',
        controller: 'relGerenciamentoFinanceiroCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerenciamentoFinanceiroCtrl.js?' + version);
            }]
        }
    }).state('relResumo', {
        url: '/relatorioresumo',
        templateUrl: '/pages/relatorios/relResumo.php',
        controller: 'relResumoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relResumoCtrl.js?' + version);
            }]
        }
    }).state('categorias', {
        url: '/categorias',
        templateUrl: '/pages/cadastros/categorias.php',
        controller: 'categoriasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/categoriasCtrl.js?' + version);
            }]
        }
    }).state('acessos', {
        url: '/acessos',
        templateUrl: '/pages/cadastros/acessos.php',
        controller: 'acessosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/acessosCtrl.js?' + version);
            }]
        }
    }).state('permissao', {
        url: '/permissao',
        templateUrl: '/pages/cadastros/semPermissao.php',
        controller: 'permissaoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/permissaoCtrl.js?' + version);
            }]
        }
    }).state('despesas', {
        url: '/despesas',
        templateUrl: '/pages/cadastros/despesas.php',
        controller: 'despesasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/despesasCtrl.js?' + version);
            }]
        }
    }).state('receitas', {
        url: '/receitas',
        templateUrl: '/pages/cadastros/receitas.php',
        controller: 'receitasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/receitasCtrl.js?' + version);
            }]
        }
    }).state('relGerencialComandas', {
        url: '/relGerencialComandas',
        templateUrl: '/pages/relatorios/relGerencialComandas.php',
        controller: 'relGerencialComandasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialComandasCtrl.js?' + version);
            }]
        }
    }).state('relGerencialComandasItens', {
        url: '/relGerencialComandasItens',
        templateUrl: '/pages/relatorios/relGerencialComandasItens.php',
        controller: 'relGerencialComandasItensCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialComandasItensCtrl.js?' + version);
            }]
        }
    }).state('relGerencialEstoque', {
        url: '/relGerencialEstoque',
        templateUrl: '/pages/relatorios/relGerencialEstoque.php',
        controller: 'relGerencialEstoqueCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialEstoqueCtrl.js?' + version);
            }]
        }
    }).state('fila', {
        url: '/filaDeEspera',
        templateUrl: '/pages/cadastros/fila.php',
        controller: 'filaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/filaCtrl.js?' + version);
            }]
        }
    }).state('relFila', {
        url: '/relFilas',
        templateUrl: '/pages/relatorios/relFila.php',
        controller: 'relFilaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relFilaCtrl.js?' + version);
            }]
        }
    }).state('listaEspera', {
        url: '/listaDeEspera',
        templateUrl: '/pages/cadastros/listaDeEspera.php',
        controller: 'listaDeEsperaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/listaDeEsperaCtrl.js?' + version);
            }]
        }
    }).state('sms', {
        url: '/sms',
        templateUrl: '/pages/cadastros/sms.php',
        controller: 'smsCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/smsCtrl.js?' + version);
            }]
        }
    }).state('relMenRecebida', {
        url: '/relMenRecebida',
        templateUrl: '/pages/relatorios/relMensagemRecebida.php',
        controller: 'relMensagemRecebidaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relMensagemRecebidaCtrl.js?' + version);
            }]
        }
    }).state('relDiasSemVir', {
        url: '/relAgendamentoInformacoes',
        templateUrl: '/pages/relatorios/relDiasSemVir.php',
        controller: 'relDiasSemVirCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relDiasSemVirCtrl.js?' + version);
            }]
        }
    }).state('painelFinanceiro', {
        url: '/painelFinanceiro',
        templateUrl: '/pages/relatorios/painelFinanceiro.php',
        controller: 'painelFinanceiroCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/painelFinanceiroCtrl.js?' + version);
            }]
        }
    }).state('divulgacao', {
        url: '/divulgacao',
        templateUrl: '/pages/cadastros/divulgacao.php',
        controller: 'divulgacaoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/divulgacaoCtrl.js?' + version);
            }]
        }
    }).state('relGerencialPacotes', {
        url: '/relGerencialPacotes',
        templateUrl: '/pages/relatorios/relGerencialPacotes.php',
        controller: 'relGerencialPacotesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialPacotesCtrl.js?' + version);
            }]
        }
    }).state('relGerencialRankings', {
        url: '/relGerencialRankings',
        templateUrl: '/pages/relatorios/relGerencialRankings.php',
        controller: 'relGerencialRankingsCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialRankingsCtrl.js?' + version);
            }]
        }
    }).state('subcontas', {
        url: '/subcontas',
        templateUrl: '/pages/cadastros/subcontas.php',
        controller: 'subcontasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/subcontasCtrl.js?' + version);
            }]
        }
    }).state('contaProfissional', {
        url: '/contaProfissional',
        templateUrl: '/pages/cadastros/contaprofissional.php',
        controller: 'contaProfissionalCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/contaProfissionalCtrl.js?' + version);
            }]
        }
    }).state('clubeVantagens', {
        url: '/clubeVantagens',
        templateUrl: '/pages/cadastros/clubevantagens.php',
        controller: 'clubeVantagensCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/clubeVantagensCtrl.js?' + version);
            }]
        }
    }).state('relAniversariantes', {
        url: '/relAniversariantes',
        templateUrl: '/pages/relatorios/relAniversariantes.php',
        controller: 'relAniversariantesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relAniversariantesCtrl.js?' + version);
            }]
        }
    }).state('cupomDesconto', {
        url: '/cupomDesconto',
        templateUrl: '/pages/cadastros/cupomdesconto.php',
        controller: 'cupomDescontoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/cupomDescontoCtrl.js?' + version);
            }]
        }
    }).state('assinaturas', {
        url: '/assinaturas',
        templateUrl: '/pages/cadastros/assinaturas.php',
        controller: 'assinaturasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/assinaturasCtrl.js?' + version);
            }]
        }
    }).state('assinantes', {
        url: '/assinantes',
        templateUrl: '/pages/cadastros/assinantes.php',
        controller: 'assinantesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/assinantesCtrl.js?' + version);
            }]
        }
    }).state('equipamentos', {
        url: '/equipamentos',
        templateUrl: '/pages/cadastros/equipamentos.php',
        controller: 'equipamentosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/equipamentosCtrl.js?' + version);
            }]
        }
    }).state('fornecedores', {
        url: '/fornecedores',
        templateUrl: '/pages/cadastros/fornecedores.php',
        controller: 'fornecedoresCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/fornecedoresCtrl.js?' + version);
            }]
        }
    }).state('cadastroFormulario', {
        url: '/formularios',
        templateUrl: '/pages/cadastros/formulariosAnamnese.php',
        controller: 'formularioCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/formularioCtrl.js?' + version);
            }]
        }
    }).state('anamnese', {
        url: '/anamnese/{codigo}',
        templateUrl: '/pages/cadastros/anamnese.php',
        controller: 'anamneseCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/anamneseCtrl.js?' + version);
            }]
        }
    }).state('tipoAnamnese', {
        url: '/tipoAnamnese',
        templateUrl: '/pages/cadastros/tipoAnamnese.php',
        controller: 'tipoAnamneseCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/tipoAnamneseCtrl.js?' + version);
            }]
        }
    }).state('tipoBandeira', {
        url: '/tipoBandeira',
        templateUrl: '/pages/cadastros/tipoBandeira.php',
        controller: 'tipoBandeiraCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/tipoBandeiraCtrl.js?' + version);
            }]
        }
    }).state('tipoRemuneracao', {
        url: '/tipoRemuneracao',
        templateUrl: '/pages/cadastros/tipoPessoaPagamento.php',
        controller: 'tipoPessoaPagamentoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/tipoPessoaPagamentoCtrl.js?' + version);
            }]
        }
    }).state('documentos', {
        url: '/documentos',
        templateUrl: '/pages/cadastros/documentos.php',
        controller: 'documentosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/documentosCtrl.js?' + version);
            }]
        }
    }).state('clientedocumento', {
        url: '/clientedocumento/{codigo}',
        templateUrl: '/pages/cadastros/clienteDocumento.php',
        controller: 'clienteDocumentoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/clienteDocumentoCtrl.js?' + version);
            }]
        }
    }).state('tipoDeducao', {
        url: '/tipoDeducao',
        templateUrl: '/pages/cadastros/tipoPessoaDeducao.php',
        controller: 'tipoPessoaDeducaoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/tipoPessoaDeducaoCtrl.js?' + version);
            }]
        }
    }).state('cursos', {
        url: '/cursos',
        templateUrl: '/pages/cadastros/cursos.php',
        controller: 'cursosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/cursosCtrl.js?' + version);
            }]
        }
    }).state('migracao', {
        url: '/migracao',
        templateUrl: '/pages/cadastros/migracao.php',
        controller: 'migracaoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/migracaoCtrl.js?' + version);
            }]
        }
    }).state('emissoes', {
        url: '/emissoes',
        templateUrl: '/pages/relatorios/emissoes.php',
        controller: 'emissoesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/emissoesCtrl.js?' + version);
            }]
        }
    }).state('videos', {
        url: '/videos',
        templateUrl: '/pages/cadastros/videos.php',
        controller: 'videosCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/videosCtrl.js?' + version);
            }]
        }
    }).state('tutoriais', {
        url: '/tutoriais',
        templateUrl: '/pages/cadastros/tutoriais.php',
        controller: 'tutoriaisCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/tutoriaisCtrl.js?' + version);
            }]
        }
    }).state('whatsapp', {
        url: '/whatsapp',
        templateUrl: '/pages/cadastros/whatsapp.php',
        controller: 'whatsappCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/whatsappCtrl.js?' + version);
            }]
        }
    }).state('caixinhaProfissionais', {
        url: '/caixinha',
        templateUrl: '/pages/cadastros/caixinhaProfissionais.php',
        controller: 'caixinhaProfissionaisCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/caixinhaProfissionaisCtrl.js?' + version);
            }]
        }
    }).state('mensagemPadrao', {
        url: '/mensagemPadrao',
        templateUrl: '/pages/cadastros/mensagemPadrao.php',
        controller: 'mensagemPadraoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/mensagemPadraoCtrl.js?' + version);
            }]
        }
    }).state('painelFiscal', {
        url: '/fiscal',
        templateUrl: '/pages/cadastros/fiscal.php',
        controller: 'fiscalCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/fiscalCtrl.js?' + version);
            }]
        }
    }).state('contratacao', {
        url: '/contratacao',
        templateUrl: '/pages/plans/contratacao.php',
        controller: 'contratacaoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/plans/contratacaoCtrl.js?' + version);
            }]
        }
    }).state('renovacao', {
        url: '/renovacao',
        templateUrl: '/pages/plans/renovacao.php',
        controller: 'renovacaoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/plans/renovacaoCtrl.js?' + version);
            }]
        }
    }).state('contadigital', {
        url: '/contadigital',
        templateUrl: '/pages/contadigital/index.php',
        controller: 'contaDigitalCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/contaDigitalCtrl.js?' + version);
            }]
        }
    }).state('profissionaldocumento', {
        url: '/profissionaldocumento/{codigo}',
        templateUrl: '/pages/cadastros/profissionalDocumento.php',
        controller: 'profissionalDocumentoCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/profissionalDocumentoCtrl.js?' + version);
            }]
        }
    }).state('relGerencialAssinaturas', {
        url: '/relGerencialAssinaturas',
        templateUrl: '/pages/relatorios/relGerencialAssinaturas.php',
        controller: 'relGerencialAssinaturaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relGerencialAssinaturaCtrl.js?' + version);
            }]
        }
    }).state('preferenciasLocais', {
        url: '/preferenciasLocais',
        templateUrl: '/pages/cadastros/preferenciasLocais.php',
        controller: 'preferenciasLocaisCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/preferenciasLocaisCtrl.js?' + version);
            }]
        }
    }).state('notaFiscal', {
        url: '/notaFiscal',
        templateUrl: '/pages/cadastros/notaFiscal.php',
        controller: 'notaFiscalCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/notaFiscalCtrl.js?' + version);
            }]
        }
    }).state('tipoTransportadora', {
        url: '/trasnportadora',
        templateUrl: '/pages/cadastros/tipoTransportadora.php',
        controller: 'tipoTransportadoraCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/tipoTransportadoraCtrl.js?' + version);
            }]
        }
    }).state('avaliacoes', {
        url: '/avaliacoes',
        templateUrl: '/pages/cadastros/avaliacoes.php',
        controller: 'avaliacoesCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/avaliacoesCtrl.js?' + version);
            }]
        }
    }).state('restricaoCliente', {
        url: '/restricaoCliente',
        templateUrl: '/pages/cadastros/restricaoCliente.php',
        controller: 'restricaoClienteCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/restricaoClienteCtrl.js?' + version);
            }]
        }
    }).state('funcionamentoEmpresa', {
        url: '/funcionamentoEmpresa',
        templateUrl: '/pages/cadastros/funcionamentoEmpresa.php',
        controller: 'funcionamentoEmpresaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/funcionamentoEmpresaCtrl.js?' + version);
            }]
        }
    }).state('chatbot', {
        url: '/chatbot',
        templateUrl: '/pages/cadastros/chatbot.php',
        controller: 'chatbotCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/chatbotCtrl.js?' + version);
            }]
        }
    }).state('relRecorrente', {
        url: '/relAgendamentoRecorrente',
        templateUrl: '/pages/relatorios/relAgendamentoRecorrente.php',
        controller: 'relAgendamentoRecorrenteCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relAgendamentoRecorrenteCtrl.js?' + version);
            }]
        }
    }).state('alertaEmpresa', {
        url: '/alertas',
        templateUrl: '/pages/cadastros/alertas.php',
        controller: 'alertaCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/alertaCtrl.js?' + version);
            }]
        }
    }).state('relAgendamentosAssinaturas', {
        url: '/relAgendamentosAssinaturas',
        templateUrl: '/pages/relatorios/relAgendamentosAssinaturas.php',
        controller: 'relAgendamentosAssinaturasCtrl',
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(localStorage.getItem('host_local') + '/controllers/relAgendamentosAssinaturasCtrl.js?' + version);
            }]
        }
    });
    $urlRouterProvider.otherwise('/agenda');
});