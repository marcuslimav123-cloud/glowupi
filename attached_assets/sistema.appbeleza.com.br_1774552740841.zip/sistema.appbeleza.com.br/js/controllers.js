var $App = function() {

    var timePicker = function(el, minTime, step) {
        $(el).timepicker({
            'timeFormat': 'H:i',
            'forceRoundTime': true,
            'minTime': minTime,
            'maxTime': '11:59pm',
            'step': step
        });
    };

    var datePicker = function(el) {
        $(el).datepicker({
            language: 'pt-BR',
            orientation: 'top auto',
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true
        });
    };

    var fileinput = function(el, maxsize) {
        $(el).fileinput({
            maxFilesNum: 1,
            showPreview: false,
            browseLabel: $_CONFIG.language.btn_procurar,
            removeLabel: $_CONFIG.language.btn_remover,
            browseIcon: '',
            maxFileSize: maxsize,
            allowedFileExtensions: ['jpg', 'png', 'jpeg'],
            showUpload: false
        });
    };

    var formatDateSort = function() {
        $.fn.dataTable.moment('DD/MM/YYYY');
        $.fn.dataTable.moment('DD/MM/YYYY hh:mm');
    };
    var toogleComboProfissionais = function(isShow) {
        if (isShow) {
            $('#navProf').show();
            $('#formProf').show();
        } else {
            $('#navProf').hide();
            $('#formProf').hide();
        }
    };
    var changeFont = function(font) {
        $('#font-style').attr('href', '/css/font-' + font + '.css');
    };
    var queryParams = function(name, url) {
        if (!url) url = location.href;
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(url);
        return results == null ? null : results[1];
    };

    var showPIXModal = function(valor, qrcode, tipo, codexterno) {
        $("#txtValorPIX").html(valor);
        var html = `<button class="btn btn-xs btn-primary text-center btnClipLinkPixCopiaecola" data-clipboard-text="${qrcode}" ><i class="fa fa-copy" alt="Copiar"></i> PIX Copia e Cola</button>`;
        $("#divPixCopiaECola").html(html);

        var clipboardPix = new ClipboardJS('.btnClipLinkPixCopiaecola');
        clipboardPix.on('success', function(e) {
            toastr.success("Código copiado com sucesso!");
        });

        $('#pix-qrcode').html("");

        $('#pix-qrcode').qrcode({
            text: qrcode,
            width: 256,
            height: 256
        });

        $(".overlay-qrcode-pix").hide();
        var tipoBuscaPIX = 1;
        if (tipo == 1) {
            // Contratação			
            $("#confirmaContratar-modal").modal('hide');
        } else if (tipo == 2) {
            // Renovação
            $("#confirmaContratar-modal").modal('hide');
        } else if (tipo == 3) {
            // PIX Monthly
            $("#pixMonthly-modal").modal('hide');
        } else if (tipo == 4) {
            // PIX Sms
            $("#comprarSMS-modal").modal('hide');
            tipoBuscaPIX = 2;

        } else if (tipo == 5) {
            // PIX Sms
            $("#comprarWhats-modal").modal("hide");
            tipoBuscaPIX = 3;

        } else {
            // Perfil / Conta
            $("#confirmaContratar-modal").modal('hide');
        }


        $("#contratacaoPixQRCode-modal").modal();

        var intervalPix = setInterval(function() {
            $.ajax({
                dataType: "json",
                method: "POST",
                url: "/php/buscaPagamentoPIX.php",
                data: {
                    codigoPIX: qrcode,
                    codigoexterno: codexterno,
                    tipo: tipoBuscaPIX
                },
                success: function(data) {
                    if (data && data.result && data.result.length > 0) {

                        if (data.result[0].erro == "0") {
                            console.log(data.result[0].resultado);
                            clearInterval(intervalPix);

                            swal({
                                    title: "",
                                    text: data.result[0].resultado,
                                    html: true,
                                    type: "success"
                                },
                                function() {
                                    window.location.assign("/index.php");
                                });

                        } else {
                            console.log(data.result[0].resultado);
                        }

                    } else {
                        console.log("Pagamento Pendente");
                    }
                }
            });
        }, 15000)

        $("#contratacaoPixQRCode-modal").on('hide.bs.modal', function() {
            clearInterval(intervalPix);
        });
    }

    var showCartaoModal = function(cardid) {
        // verDadosCartao-modal
        $("#verDadosCartao-modal").modal();
        $("#verDadosCartao-modal").unbind('hide.bs.modal');

        $("#verDadosCartao-modal").on('hide.bs.modal', function() {

            $("#txtDadosCartaoNumber").html("");
            $("#txtDadosCartaoHolderName").html("");
            $("#txtDadosCartaoExp").html("");
            $("#txtDadosCartaoBrand").html("");
            $(".overlayDadosCartao").show();
        });
        $.ajax({
            dataType: "json",
            method: "POST",
            url: "/php/pagarme/buscaDadosCartao.php",
            data: {
                cardid: cardid
            },
            success: function(data) {
                $(".overlayDadosCartao").hide();
                $("#txtDadosCartaoNumber").html(`${data.first_digits}******${data.last_digits}`);
                $("#txtDadosCartaoHolderName").html(data.holder_name);
                $("#txtDadosCartaoExp").html(formatCardDateExp(data.expiration_date));



                $("#txtDadosCartaoBrand").html(formatBrand(data.brand));
            }
        });


    }

    var formatCardDateExp = function(exp) {
        return [exp.slice(0, 2), '/', exp.slice(2)].join('');
    }

    var formatBrand = function(brand) {
        var strBrand = "";
        switch (brand) {
            case 'pix':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='PIX' src='https://dash.zoop.com.br/assets/icons/banking/pix.png' alt='PIX' height='20' width='21'></img>";
                break;
            case 'mastercard':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='MasterCard' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/mastercard.svg' alt='MasterCard' height='22' width='34'></img>";
                break;
            case 'visa':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='Visa' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/visa.svg' alt='Visa' height='22' width='34'></img>";
                break;
            case 'amex':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='American Express' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/american-express.svg' alt='American Express' height='22' width='34'></img>";
                break;
            case 'american express':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='American Express' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/american-express.svg' alt='American Express' height='22' width='34'></img>";
                break;
            case 'elo':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='Elo' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/elo.svg' alt='Elo' height='22' width='34'></img>";
                break;
            case 'aura':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='Aura' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/aura.svg' alt='Aura' height='22' width='34'></img>";
                break;
            case 'discover':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='Discover' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/discover.svg' alt='Discover' height='22' width='34'></img>";
                break;
            case 'hipercard':
                strBrand = "<img data-toggle='tooltip' data-placement='top' title='' data-original-title='MasterCard' src='https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/hipercard.svg' alt='MasterCard' height='22' width='34'></img>";
                break;
            default:
                strBrand = brand;
                break;
        }
        return strBrand;
    }

    var formatBrandImage = function(brand) {
        var strBrand = "";
        switch (brand) {
            case 'mastercard':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/mastercard.svg";
                break;
            case 'visa':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/visa.svg";
                break;
            case 'amex':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/american-express.svg";
                break;
            case 'american express':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/american-express.svg";
                break;
            case 'elo':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/elo.svg";
                break;
            case 'aura':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/aura.svg";
                break;
            case 'discover':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/discover.svg";
                break;
            case 'hipercard':
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/hipercard.svg";
                break;
            case 'pix':
                strBrand = "https://dash.zoop.com.br/assets/icons/banking/pix.png";
                break;
            default:
                strBrand = "https://appbarber-appbeleza.dash.zoop.com.br/assets/icons/cardbrand/mastercard.svg";
                break;
        }

        return strBrand;
    }

    var buscaAcao = function() {
        $.ajax({
            dataType: 'json',
            url: localStorage.getItem('host'),
            data: {
                id: $_CONFIG.ID,
                metodo: 'buscaAcao'
            },
            success: function(data) {
                if (data.result[0].erro == '0') {
                    $_CONFIG.acoes.msgAction = data.result[0].mensagem;
                    $_CONFIG.acoes.lastAction = data.result[0].descricao;
                    $_CONFIG.acoes.dateAction = new Date();

                    if (data.result[0].video != '') { //Vídeo

                        $('#titleModalAcaoVideo').html(data.result[0].mensagem);
                        videoId = queryParams('v', data.result[0].video);
                        if (typeof($_CONFIG.acoes.playerVideoAcao) === 'undefined') {
                            $_CONFIG.acoes.playerVideoAcao = new YT.Player('player-acao', {
                                height: window.outerHeight * 0.75,
                                width: '100%',
                                videoId: videoId,
                                events: {
                                    'onReady': function() {
                                        $('#acao-video-modal').modal();
                                        $_CONFIG.acoes.playerVideoAcao.playVideo();
                                    }
                                },
                                playerVars: {
                                    'rel': 0
                                }
                            });
                        } else {
                            $_CONFIG.acoes.playerVideoAcao.loadVideoById(videoId);
                            $('#acao-video-modal').modal();
                        }

                    } else if (data.result[0].imagem != '') { //Imagem

                        $('#titleModalAcaoImagem').html(data.result[0].mensagem);
                        var downloadingImage = new Image();
                        downloadingImage.onload = function() {
                            $('#imgAcao')[0].src = this.src;
                            $('#imgAcao').click(function() {
                                var win = window.open(this.src, '_blank');
                                win.focus();
                            });
                        };
                        downloadingImage.src = data.result[0].imagem;
                        $('#acao-imagem-modal').modal();

                    } else if (data.result[0].mensagem != '') { //Mensagem

                        $.ajax({
                            dataType: 'html',
                            url: '/php/atualizaAcaoLog.php',
                            method: 'POST',
                            data: {
                                tipo: 5,
                                acao: $_CONFIG.acoes.lastAction
                            }
                        });

                        swal({
                                title: '',
                                text: data.result[0].mensagem,
                                html: true,
                                showCancelButton: false,
                                confirmButtonColor: sSistemaCor,
                                allowEscapeKey: false,
                                confirmButtonText: 'Fechar',
                                closeOnConfirm: true
                            },
                            function() {
                                $.ajax({
                                    dataType: 'html',
                                    url: '/php/atualizaAcaoLog.php',
                                    method: 'POST',
                                    data: {
                                        tipo: 6,
                                        acao: $_CONFIG.acoes.lastAction
                                    }
                                });
                            });
                    }
                }
            }
        });
    };
    var sendMessage = function(title, msg, pos, fnOnClick) {
        var callback = null;
        var position = 'toast-top-right';

        if (typeof pos === 'string') {
            position = pos;
        }

        if (typeof fnOnClick === 'function') {
            callback = fnOnClick;
        }

        toastr.options = {
            'closeButton': true,
            'debug': false,
            'newestOnTop': false,
            'progressBar': false,
            'positionClass': position,
            'preventDuplicates': false,
            'onclick': callback,
            'timeOut': 0,
            'closeDuration': 0,
            'showEasing': 'swing',
            'hideEasing': 'swing',
            'showMethod': 'slideDown',
            'hideMethod': 'slideUp'
        }

        toastr.info(msg, title);

        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": false,
            "positionClass": "toast-bottom-center",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "preventDuplicates": true,
            "progressBar": true,
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }

    };

    var sendMessageColor = function(title, msg, pos, fnOnClick, color) {
        var callback = null;
        var position = 'toast-top-right';

        if (typeof pos === 'string') {
            position = pos;
        }

        if (typeof fnOnClick === 'function') {
            callback = fnOnClick;
        }

        toastr.options = {
            'closeButton': true,
            'debug': false,
            'newestOnTop': false,
            'progressBar': false,
            'positionClass': position,
            'preventDuplicates': false,
            'onclick': callback,
            'timeOut': 0,
            'closeDuration': 0,
            'showEasing': 'swing',
            'hideEasing': 'swing',
            'showMethod': 'slideDown',
            'hideMethod': 'slideUp'
        }

        switch (color) {
            case 'error':
                toastr.error(msg, title);
                break;
            case 'success':
                toastr.success(msg, title);
                break;
            case 'warning':
                toastr.warning(msg, title);
                break;
            case 'info':
                toastr.info(msg, title);
                break;
            default:
                toastr.info(msg, title);
                break;
        }


        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": false,
            "positionClass": "toast-bottom-center",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "preventDuplicates": true,
            "progressBar": true,
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }

    };



    return {
        formatDateSort: function() {
            formatDateSort();
        },
        timePicker: function(el, minTime, step) {
            timePicker(el, minTime, step);
        },
        datePicker: function(el) {
            datePicker(el);
        },
        fileinput: function(el) {
            fileinput(el);
        },
        showMessage: function(title, msg, pos, fnOnClick) {
            sendMessage(title, msg, pos, fnOnClick);
        },
        showMessageColor: function(title, msg, pos, fnOnClick, color) {
            sendMessageColor(title, msg, pos, fnOnClick, color);
        },
        changeFont: function(font) {
            changeFont(font);
        },
        buscaAcao: function() {
            buscaAcao();
        },
        toogleComboProfissionais: function(isShow) {
            toogleComboProfissionais(isShow);
        },
        funProxDiaUtil: function(strDate, format = "dd/mm/YYYY") {
            funProxDiaUtil(strDate, format);
        },
        showPIXModal: function(valor, qrcode, tipo, codexterno) {
            showPIXModal(valor, qrcode, tipo, codexterno);
        },
        showCartaoModal: function(cardid) {
            showCartaoModal(cardid);
        }
    };
}();

var $Options = {
    servicoDuplo: '0',
    lat: '',
    longit: '',
    markerTitle: '',
    clientesNomes: new Array(),
    clientesIds: new Object(),
    whatsapp: new Object(),
    resultado: '',
    sistema: '',
    sistemaCor: '',
    sistemaMini: ''
};

var servicoDuplo = '0';
var lat = '';
var longit = '';
var markerTitle = '';
var clientesNomes = new Array();
var clientesIds = new Object();
var resultado;
var sSistema = '';
var sSistemaCor = '';
var sSistemaMini = '';

if (location.host == 'sistema.appbeleza.com.br') {


    sSistema = 'AppBeleza';
    sSistemaCor = '#600239';
    sSistemaMini = '';

    $Options.sistema = 'AppBeleza';
    $Options.sistemaCor = '#600239';

    $Options.whatsapp.agenda = "Olá [{cliente}], você agendou [{servico}] para o dia [{dataAge}] às [{horaAge}] com [{profissional}] no(a) [{estabelecimento}].\n\nBaixe já o " + $Options.sistema + " para seu dispositivo 📲✂ \n\nhttps://" + $Options.sistema.toLowerCase() + ".com.br/download";
} else if ((location.host == 'bfg.appbeleza.com.br') || (location.host == 'bfg.localhost')) {
    sSistema = 'BFG';
    sSistemaCor = '#A2092F';
    sSistemaMini = 'BFG';

    $Options.sistema = 'BFG';
    $Options.sistemaMini = 'BFG';
    $Options.sistemaCor = '#A2092F';
    $Options.whatsapp.agenda = "Olá [{cliente}], você agendou [{servico}] para o dia [{dataAge}] às [{horaAge}] com [{profissional}] no(a) [{estabelecimento}].\n\nBaixe já o " + $Options.sistema + " para seu dispositivo 📲✂ \n\nhttps://" + $Options.sistema.toLowerCase() + ".com.br/download";

} else {
    sSistema = 'AppBarber';
    sSistemaCor = '#00233d';
    sSistemaMini = '';

    $Options.sistema = 'AppBarber';
    $Options.sistemaCor = '#00233d';

    $Options.whatsapp.agenda = "Olá [{cliente}], você agendou [{servico}] para o dia [{dataAge}] às [{horaAge}] com [{profissional}] no(a) [{estabelecimento}].\n\nBaixe já o " + $Options.sistema + " para seu dispositivo 📲💈 \n\nhttps://" + $Options.sistema.toLowerCase() + ".com.br/download";

}

var timerSessao = setInterval(function() {
    if ($_CONFIG.ID != localStorage.getItem('SES_ID')) {
        swal({
                title: 'Tempo da Sessão Excedida',
                text: 'Realize o login novamente.',
                type: 'warning',
                showCancelButton: false,
                confirmButtonColor: sSistemaCor,
                allowEscapeKey: false,
                confirmButtonText: 'Ir para Login',
                closeOnConfirm: true
            },
            function() {
                window.location.href = '/login.php';
            });

    }
}, 10000); // 10000 milisegundos

var timerSessaoLogin = setInterval(function() {
    $.ajax({
        dataType: 'html',
        url: '/php/verificaSessaoTimer.php?e=' + $_CONFIG.CODUSUARIO,
        success: function(data) {
            if (data != 1) {
                swal({
                        title: 'Tempo da Sessão Excedida',
                        text: 'Realize o login novamente.',
                        type: 'warning',
                        showCancelButton: false,
                        confirmButtonColor: sSistemaCor,
                        allowEscapeKey: false,
                        confirmButtonText: 'Ir para Login',
                        closeOnConfirm: true
                    },
                    function() {
                        window.location.href = '/login.php';
                    });

            }
        }
    });
}, 600000); // 600000 em milisegundos = 


$('#stringSistema').html($Options.sistema);
$('#stringSistemaMini').html($Options.sistemaMini);
setTimeout(() => {
    $('.logo-lg').removeClass('hidden');
}, 1000);


function changeHeightBody() {

}

function validaPerfil(perfil) {
    $.ajax({
        dataType: 'json',
        method: 'POST',
        url: '/php/verificaPerfil.php',
        data: {
            perfil: perfil
        },
        success: function(data) {
            if (data.erro == '1') {
                window.location.href = '#/permissao';
            }
        },
        error: function(data) {
            window.location.href = '#/permissao';
        }
    });
}

function validaGestor() {
    $.ajax({
        dataType: 'json',
        url: '/php/verificaGestor.php',
        success: function(data) {
            if (data.erro == '1') {
                window.location.href = '#/permissao';
            }
        },
        error: function(data) {
            window.location.href = '#/permissao';
        }
    });
}

function validaID() {
    $.ajax({
        dataType: 'json',
        url: '/php/validaID.php',
        success: function(data) {
            console.log(data);
            if (!data.isvalid) {
                swal({
                        title: 'Tempo da Sessão Excedida',
                        text: 'Realize o login novamente.',
                        type: 'warning',
                        showCancelButton: false,
                        confirmButtonColor: sSistemaCor,
                        allowEscapeKey: false,
                        confirmButtonText: 'Ir para Login',
                        closeOnConfirm: true
                    },
                    function() {
                        window.location.href = '/login.php';
                    });

            }
        }
    });
}


var timerValidaId = setInterval(function() {
    validaID();
}, 3600000); // 600000 em milisegundos = 

validaID();

function validarEmail(email) {
    var exclude = /[^@\-\.\w]|^[_@\.\-]|[\._\-]{2}|[@\.]{2}|(@)[^@]*\1/;
    var check = /@[\w\-]+\./;
    var checkend = /\.[a-zA-Z]{2,3}$/;
    if (((email.search(exclude) != -1) || (email.search(check)) == -1) || (email.search(checkend) == -1)) {
        return false;
    } else {
        return true;
    }
}

$.browser.device = (/android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent.toLowerCase()));
var isMobile = false;
if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) ||
    /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4)))
    isMobile = true;

var isPortrait = false;
if (window.innerHeight > window.innerWidth) {
    isPortrait = true;
}
if (window.innerWidth > window.innerHeight) {
    isPortrait = false;
}
var parTempo = '';
var isLoadv3 = false;


var funProxDiaUtil = (strDate, format) => {
    if (format === undefined) {
        format = "DD/MM/YYYY";
    }
    var dataaux = moment(strDate);
    var dayofweek = dataaux.day();
    console.log(dataaux.format("DD/MM/YYYY"));
    if (dayofweek === 0) {
        console.log("is sunday");
        var newdate = moment(strDate).add(1, 'd');
        var isHoliday = funFeriado(newdate).isHoliday;
        if (isHoliday) {
            console.log("is sunday and is holiday");
            return funProxDiaUtil(newdate.format("YYYY-MM-DD"));
        } else {
            console.log("is sunday and isn't holiday");
            var proxDiaUtil = newdate.format(format);
            return proxDiaUtil;
        }
    } else if (dayofweek === 6) {

        var newdate = moment(strDate).add(2, 'd');
        var isHoliday = funFeriado(newdate).isHoliday;

        if (isHoliday) {
            console.log("is saturday and is holiday");
            return funProxDiaUtil(newdate.format("YYYY-MM-DD"));
        } else {
            console.log("is saturday and isn't holiday");
            var proxDiaUtil = newdate.format(format);
            return proxDiaUtil;
        }
    } else {
        console.log("is weekday");
        var isHoliday = funFeriado(dataaux).isHoliday;
        if (isHoliday) {
            var newdate = moment(strDate).add(1, 'd');
            return funProxDiaUtil(newdate.format("YYYY-MM-DD"));
        } else {
            var proxDiaUtil = moment(strDate).format(format);
            return proxDiaUtil;
        }
    }
};

var funFeriado = (data) => {
    if (data === undefined) {
        return listFeriado;
    } else {
        if (listFeriado[data.format("DD/MM/YYYY")] === undefined) {
            return {
                isHoliday: false
            }
        } else {
            return {
                isHoliday: true,
                holiday: listFeriado[data.format("DD/MM/YYYY")],
                date: data.format("DD/MM/YYYY")
            };
        }
    }
}

function getProximoDiaUtil(dataReferencia) {
    const depoisDas1530 = dataReferencia.getHours() > 15 || (dataReferencia.getHours() === 15 && dataReferencia.getMinutes() > 30);
    const diasASomar = depoisDas1530 ? 2 : 1;

    // Converte lista de feriados em Set para busca eficiente
    const feriados = new Set(Object.keys(listFeriado).map(data => {
        const [dia, mes, ano] = data.split('/');
        return `${ano}-${mes.padStart(2, '0')}-${dia.padStart(2, '0')}`;
    }));

    // Função recursiva para achar o próximo dia útil
    function buscarDiaUtil(dataAtual, diasRestantes) {
        const proximaData = new Date(dataAtual);
        proximaData.setDate(proximaData.getDate() + 1);

        const diaSemana = proximaData.getDay(); // 0 = domingo, 6 = sábado
        const dataFormatada = proximaData.toISOString().split('T')[0];

        const ehUtil = diaSemana !== 0 && diaSemana !== 6 && !feriados.has(dataFormatada);

        if (ehUtil) {
            diasRestantes--;
        }

        return diasRestantes === 0 ?
            proximaData :
            buscarDiaUtil(proximaData, diasRestantes);
    }

    const resultado = buscarDiaUtil(dataReferencia, diasASomar);

    // Formata para DD/MM/YYYY
    const dia = resultado.getDate().toString().padStart(2, '0');
    const mes = (resultado.getMonth() + 1).toString().padStart(2, '0');
    const ano = resultado.getFullYear();
    return `${dia}/${mes}/${ano}`;
}

var listFeriado = {

    /*
    	-- 2025
    	1/1/25	quarta-feira	Confraternização Universal
    	3/3/25	segunda-feira	Carnaval
    	4/3/25	terça-feira	Carnaval
    	18/4/25	sexta-feira	Paixão de Cristo
    	21/4/25	segunda-feira	Tiradentes
    	1/5/25	quinta-feira	Dia do Trabalho
    	19/6/25	quinta-feira	Corpus Christi
    	7/9/25	domingo	Independência do Brasil
    	12/10/25	domingo	Nossa Sr.a Aparecida - Padroeira do Brasil
    	2/11/25	domingo	Finados
    	15/11/25	sábado	Proclamação da República
    	20/11/25	quinta-feira	Dia Nacional de Zumbi e da Consciência Negra
    	25/12/25	quinta-feira	Natal

    	-- 2026
    	1/1/26	quinta-feira	Confraternização Universal
    	16/2/26	segunda-feira	Carnaval
    	17/2/26	terça-feira	Carnaval
    	3/4/26	sexta-feira	Paixão de Cristo
    	21/4/26	terça-feira	Tiradentes
    	1/5/26	sexta-feira	Dia do Trabalho
    	4/6/26	quinta-feira	Corpus Christi
    	7/9/26	segunda-feira	Independência do Brasil
    	12/10/26	segunda-feira	Nossa Sr.a Aparecida - Padroeira do Brasil
    	2/11/26	segunda-feira	Finados
    	15/11/26	domingo	Proclamação da República
    	20/11/26	sexta-feira	Dia Nacional de Zumbi e da Consciência Negra
    	25/12/26	sexta-feira	Natal
    */

    "01/01/2025": "Confraternização Universal",
    "03/03/2025": "Carnaval",
    "04/03/2025": "Carnaval",
    "18/04/2025": "Paixão de Cristo",
    "21/04/2025": "Tiradentes",
    "01/05/2025": "Dia do Trabalho",
    "19/06/2025": "Corpus Christi",
    "07/09/2025": "Independência do Brasil",
    "12/10/2025": "Nossa Sr.a Aparecida",
    "02/11/2025": "Finados",
    "15/11/2025": "Proclamação da República",
    "20/11/2025": "Dia Nacional de Zumbi e da Consciência Negra",
    "25/12/2025": "Natal",
    "01/01/2026": "Confraternização Universal",
    "16/02/2026": "Carnaval",
    "17/02/2026": "Carnaval",
    "03/04/2026": "Paixão de Cristo",
    "21/04/2026": "Tiradentes",
    "01/05/2026": "Dia do Trabalho",
    "04/06/2026": "Corpus Christi",
    "07/09/2026": "Independência do Brasil",
    "12/10/2026": "Nossa Sr.a Aparecida",
    "02/11/2026": "Finados",
    "15/11/2026": "Proclamação da República",
    "20/11/2026": "Dia Nacional de Zumbi e da Consciência Negra",
    "25/12/2026": "Natal"
}

var arrayFeriados = [
    "01/01/2025",
    "03/03/2025",
    "04/03/2025",
    "18/04/2025",
    "21/04/2025",
    "01/05/2025",
    "19/06/2025",
    "07/09/2025",
    "12/10/2025",
    "02/11/2025",
    "15/11/2025",
    "20/11/2025",
    "25/12/2025",
    "01/01/2026",
    "16/02/2026",
    "17/02/2026",
    "03/04/2026",
    "21/04/2026",
    "01/05/2026",
    "04/06/2026",
    "07/09/2026",
    "12/10/2026",
    "02/11/2026",
    "15/11/2026",
    "20/11/2026",
    "25/12/2026",
];



// var listFeriado = {

// 	"01/01": "Confraternização Universal",
// 	"10/04": "Paixão de Cristo",
// 	"21/04": "Tiradentes",
// 	"01/05": "Dia Mundial do Trabalho",
// 	"07/09": "Independência do Brasil",
// 	"12/10": "Nossa Senhora Aparecida",
// 	"02/11": "Finados",
// 	"15/11": "Proclamação da República",
// 	"25/12": "Natal",
// }

// var arrayFeriados = [
// 	"01/01/2023",
// 	"10/04/2023",
// 	"21/04/2023",
// 	"01/05/2023",
// 	"07/09/2023",
// 	"12/10/2023",
// 	"02/11/2023",
// 	"15/11/2023",
// 	"25/12/2023",
// 	"01/01/2024",
// 	"10/04/2024",
// 	"21/04/2024",
// 	"01/05/2024",
// 	"07/09/2024",
// 	"12/10/2024",
// 	"02/11/2024",
// 	"15/11/2024",
// 	"25/12/2024",
// ];