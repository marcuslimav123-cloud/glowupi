angular.module('appBeleza').controller('agendaCtrl', function($rootScope, $scope, $compile, $state, $translate) {
    $rootScope.header = $Options.sistema + ' | Agenda';
    $scope.idCliente = $_CONFIG.ID;
    $scope.firstLoad = true;
    $scope.servicoSelect = '';
    $scope.numeroServicos = 0;
    $scope.datahoraencaixe = '';
    $scope.timerAgendaMS = 300000;
    $scope.calEvent;
    $scope.calendar;
    $scope.limitScrollAgenda = 20;
    $scope.finalAgendamentoRecorrente = -1;
    $scope.hasnf = 0;

    var listJornada = [];
    if (localStorage.getItem('listJornada') != null) {
        listJornada = localStorage.getItem('listJornada').split(',')
    }
    var nIntervId;
    var timevalor;
    var heightAgenda = 2100;

    var curTimeZone;

    var tipoCategoria = 1;
    var tcacodigo = '';

    var slotsTempo = {
        '5': 300,
        '10': 150,
        '15': 100,
        '20': 75,
        '30': 50,
        '40': 40,
        '45': 35,
        '60': 30,
        '90': 20,
        '120': 15
    }

    var heightAgenda = $_CONFIG.TAMANHOSLOT != '' ? (parseInt($_CONFIG.TAMANHOSLOT) * slotsTempo[$_CONFIG.TEMPOPADRAO]) : ($_CONFIG.TEMPOPADRAO == '5' ? 5000 : 2100)
    var mMinTime = $_CONFIG.INICIOAGENDA_PRINCIPAL;
    var mMaxTime = $_CONFIG.FIMAGENDA_PRINCIPAL;
    var mMinTimeTimePicker = $_CONFIG.INICIOAGENDA_SECUNDARIO;

    $scope.buscaparcategoria = function() {

        $.ajax({
            dataType: 'json',
            url: '/pages/actions/buscaParametro.php',
            async: false,
            method: 'POST',
            data: {
                parcodigo: 141
            },
            success: function(data) {
                if (data.result.length > 0) {
                    if (data.result[0].PVa_Vlr_Principal == '1') {
                        $("#btnSelecionarCategoriaAgenda").show()
                    } else {
                        $("#btnSelecionarCategoriaAgenda").hide()
                    }
                } else {
                    $("#btnSelecionarCategoriaAgenda").hide()
                }
            }
        });

        $.ajax({
            dataType: 'json',
            url: '/pages/actions/buscaParametro.php',
            async: false,
            method: 'POST',
            data: {
                parcodigo: 142
            },
            success: function(data) {
                if (data.result.length > 0) {
                    if (data.result[0].PVa_Vlr_Principal != '') {
                        if (data.result[0].PVa_Vlr_Principal <= 5) {
                            $scope.limitScrollAgenda = 5
                        } else {
                            $scope.limitScrollAgenda = data.result[0].PVa_Vlr_Principal
                        }
                    } else {
                        $scope.limitScrollAgenda = 20;
                    }
                }
            }
        });

        $.ajax({
            dataType: 'json',
            url: '/pages/actions/buscaParametro.php',
            async: false,
            method: 'POST',
            data: {
                parcodigo: 161
            },
            success: function(data) {
                if (data.result.length > 0) {
                    if (data.result[0].PVa_Vlr_Principal != '') {
                        if (data.result[0].PVa_Vlr_Principal == 1) {
                            $(".multiUniClass").show()
                        } else {
                            $(".multiUniClass").hide()
                        }
                    } else {
                        $(".multiUniClass").hide()
                    }
                }
            }
        });

        $.ajax({
            dataType: 'json',
            url: '/pages/actions/buscaParametro.php',
            async: false,
            method: 'POST',
            data: {
                parcodigo: 64
            },
            success: function(data) {
                if (data.result.length > 0) {
                    if (data.result[0].PVa_Vlr_Principal != '') {
                        if (data.result[0].PVa_Vlr_Principal == 1) {
                            $("#cpfnf").show()
                            $scope.hasnf = 1;
                        } else {
                            $("#cpfnf").hide()
                            $scope.hasnf = 0;
                        }
                    } else {
                        $("#cpfnf").hide()
                        $scope.hasnf = 0;
                    }
                }
            }
        });

    }
    $scope.buscaparcategoria();

    var intervalTimeZone;

    buscaEstados($_CONFIG.PAIS);
    $App.formatDateSort();

    $('#btnHideLegenda').click((e) => {
        $('#collapseExample').toggle('1000');
        icon = $(e.currentTarget).find('i');
        icon.toggleClass('fa fa-plus fa fa-minus');
    })

    validaPerfil($state.current.name);

    $('#btnAgendaPrev').on('click', () => {
        $('#btnAgendaPrev').attr('disabled', true);
        $('#calendar').fullCalendar('prev');
        $('#btnAgendaPrev').attr('disabled', false);
    });

    $('#btnAgendaNext').on('click', () => {
        $('#btnAgendaNext').attr('disabled', true);
        $('#calendar').fullCalendar('next');
        $('#btnAgendaNext').attr('disabled', false);
    });

    $('#btnAgendaToday').on('click', () => {
        $('#btnAgendaToday').attr('disabled', true);
        $('#calendar').fullCalendar('gotoDate', curTimeZone);
        $('#btnAgendaToday').attr('disabled', false);
    });

    $('#btnAgendaDay').addClass('disabled');

    $('#btnAgendaDay').on('click', () => {
        $('#calendar').fullCalendar('changeView', 'resourceDay');
        $('#btnAgendaDay').addClass('disabled');
        $('#btnAgendaWeek').removeClass('disabled');
        $('#btnAgendaMonth').removeClass('disabled');
    });

    $('#btnAgendaWeek').on('click', () => {
        $('#calendar').fullCalendar('changeView', 'agendaWeek');
        $('#btnAgendaDay').removeClass('disabled');
        $('#btnAgendaWeek').addClass('disabled');
        $('#btnAgendaMonth').removeClass('disabled');
    });

    $('#btnAgendaMonth').on('click', () => {
        $('#calendar').fullCalendar('changeView', 'month');
        $('#btnAgendaDay').removeClass('disabled');
        $('#btnAgendaWeek').removeClass('disabled');
        $('#btnAgendaMonth').addClass('disabled');
    });

    $('#btnFechaItemComanda').on('click', () => {
        $('#comandaInsert-modal').modal('hide');
        $('#comanda-modal').modal('show');
    });

    $('#btnFechaItemComandaSer').on('click', () => {
        $('#comandaInsertSer-modal').modal('hide');
        $('#comanda-modal').modal('show');
    });

    $("#messageRenovar").on('click', (e) => {
        if (e.target.type != "button") {
            window.location.hash = '#/renovacao';
        }
    });

    $('#bar-date')
        .css('top', $('.navbar').height())
        .css('left', $('.sidebar').width())
        .css('width', '100%');

    $('#bar-info-date').css('height', '30px');



    if (!isMobile) {
        $('#divCalendario').css('overflow-y', 'scroll');
        $('#divCalendario').height($('html').height() - $('.navbar').height() - 165);
    }

    $scope.fixNameProf = function() {
        $('#divNameProf').html('');
        var tr = $('.fc-agenda-days').children('thead').children().children();
        var html = '<tfoot class="text-center"><tr>';

        tr.each((idx, el) => {
            if ($('#calendar').fullCalendar('getView').calendar.fetchResources().length <= $scope.limitScrollAgenda) {

                if (!$(el).hasClass('fc-agenda-gutter')) {
                    if ($(el).hasClass('fc-last')) {
                        if (el.previousElementSibling.style.width == '50px') {
                            var elWidth = $('#divCalendario').width() - 50;
                        } else {
                            var elWidth = el.previousElementSibling.style.width;
                        }
                    } else {
                        var elWidth = el.style.width;
                    }
                    jQuery('<label/>', {
                        text: el.innerHTML.replace('&nbsp;', ' ')
                    }).css({
                        'text-align': 'center',
                        'background-color': '#D2D6DE',
                        'border-style': 'solid;',
                        'border-left-color': 'grey',
                        'width': elWidth,
                        'left': el.offsetLeft
                    }).appendTo('#divNameProf');
                }
            } else {
                html += `<td style="border: 1px solid #D2D6DE;background-color: fafafa;"><b>${el.innerHTML.replace('&nbsp;', ' ')}</b></td>`
            }


        });
        html += '</tfoot>';
        if ($('#calendar').fullCalendar('getView').calendar.fetchResources().length > $scope.limitScrollAgenda) {
            $('.fc-agenda-days').append(html)
        }
    };

    $('#navProf').show();
    $('#formProf').show();

    $('#cbEnviaSms').change((e) => {

        if (e.currentTarget.checked && ($('#lblSaldoSMSAg').html() == '0')) {
            toastr.error('Saldo insuficiente para enviar SMS');
            e.currentTarget.checked = false;
        }
    });

    $('#cbEnviaWhats').change((e) => {

        if (e.currentTarget.checked && ($('#lblSaldoWhatsAg').html() == '0')) {
            toastr.error('Saldo insuficiente para enviar WhatsApp');
            e.currentTarget.checked = false;
        }
    });

    $scope.buscaInfoRodizio = function() {
        $('#rodizio-modal').modal();
        setTimeout(() => {
            if (typeof(tabelaRodizio) != "undefined") {
                $('#tbBuscaRodAgenda tbody').unbind('click')
                tabelaRodizio.api().destroy();
            }
            tabelaRodizio = $('#tbBuscaRodAgenda').dataTable({
                'ajax': '/pages/cadastros/buscaRodizio.php',
                'order': [
                    [0, 'asc']
                ],
                "scrollX": isPortrait,
                'columnDefs': [{
                    'targets': [0, 1, 4],
                    'visible': false,
                    'searchable': false
                }],
                'paging': false,
                'ordering': false,
                'info': false,
                'searching': false,
                'language': {
                    'url': '//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json'
                },
                initComplete: () => {
                    $compile($('#tbBuscaRodAgenda'))($scope);
                    $('#tbBuscaRodAgenda_paginate').click(() => {
                        $compile($('#tbBuscaRodAgenda'))($scope);
                    });
                    $('#tbBuscaRodAgenda_filter').change(() => {
                        $compile($('#tbBuscaRodAgenda'))($scope);
                    });
                    $('#tbBuscaRodAgenda_length').change(() => {
                        $compile($('#tbBuscaRodAgenda'))($scope);
                    });
                    if (tabelaRodizio.fnGetData().length > 0) {
                        $('#divLoader').hide();
                        $('#boxRodizio').show();
                        $('#semRodizio').hide();
                    } else {
                        $('#lblTotalRodizio').html('');
                        $('#lblValorInicial').html('');
                        $('#lblNome').html('');
                        $('#lblData').html('');
                        $('#boxRodizio').hide();
                        $('#semRodizio').show();
                        resizeContent();
                    }

                    $('[data-toggle="popover"]').popover({
                        container: 'body'
                    });
                },
                'columns': [{
                        'data': 'DT_RowId'
                    },
                    {
                        'data': 'Codigo'
                    },
                    {
                        'data': 'Ordem'
                    },
                    {
                        'data': 'Nome'
                    },
                    {
                        'data': 'Data'
                    },
                    {
                        'data': 'Agendamentos'
                    },
                    {
                        'data': 'Status'
                    },
                    {
                        'data': 'BtnUp'
                    },
                    {
                        'data': 'BtnDown'
                    },
                    {
                        'data': 'BtnStatus'
                    }
                ]
            });

        }, 500);
    };

    var atualizaDadosRodizio = () => {
        $('[data-toggle="popover"]').popover('hide');
        tabelaRodizio.api().ajax.reload(() => {
            $('[data-toggle="popover"]').popover({
                container: 'body'
            });
            $compile($('#tbBuscaRodAgenda'))($scope);
            $('#tbBuscaRodAgenda_paginate').click(() => {
                $compile($('#tbBuscaRodAgenda'))($scope);
            });
        });
    }

    $scope.atualizaRodizio = function(direcao, ordem, rodcodigo, procodigo) {
        $.ajax({
            dataType: 'json',
            method: 'POST',
            url: '/pages/cadastros/atualizaRodizio.php',
            data: {
                tcacodigo: tcacodigo,
                tipo: tipoCategoria,
                direcao: direcao,
                ordem: ordem,
                rodcodigo: rodcodigo,
                procodigo: procodigo
            },
            success: (data) => {
                if (data.result[0].erro == '0') {
                    toastr['success']('Atualizado com Sucesso.');
                    atualizaDadosRodizio();
                } else {
                    swal('Falha ao Atualizar.', data, 'error');
                }
            },
            error: (result) => {
                swal('Falha na conexão.', '', 'error');
            }
        });
    }

    $scope.atualizaStatus = function(status, rodcodigo, procodigo) {

        $.ajax({
            dataType: 'json',
            method: 'POST',
            url: '/pages/cadastros/atualizaRodizio.php',
            data: {
                tcacodigo: tcacodigo,
                tipo: tipoCategoria,
                status: status,
                rodcodigo: rodcodigo,
                procodigo: procodigo
            },
            success: (data) => {
                if (data.result[0].erro == '0') {
                    toastr['success']('Atualizado com Sucesso.');
                    atualizaDadosRodizio();
                } else {
                    swal('Falha ao Atualizar.', data.result[0].resultado, 'error');
                }
            },
            error: (result) => {
                swal('Falha na conexão.', '', 'error');
            }
        });
    }

    $.ajax({
        dataType: 'json',
        url: '/pages/cadastros/buscaRodizio.php',
        success: (data) => {
            if (data.recordsTotal > 0) {
                $('#btnShowRodizio').show();
            } else {
                $('#btnShowRodizio').hide();
            }
        }
    });

    $scope.clientes = '';
    $scope.semCadastro = false;
    $scope.alteraDataAgendamento = false;
    $scope.objAgenda = Array();
    $('#calendar').fullCalendar('removeEvents');

    $scope.initAgenda = true;

    $('.input-group.date').datepicker({
        language: 'pt-BR',
        orientation: 'auto',
        autoclose: true,
        format: 'dd/mm/yyyy'
    });

    var datainirec = moment().locale('pt-br').format('L');
    var datafimrec = moment().add(+7, 'days').locale('pt-br').format('L');
    $('.date.dataIniCancelaRecorrente').datepicker('update', datainirec);
    $('.date.dataFimCancelaRecorrente').datepicker('update', datafimrec);

    $('.dataFimDisp').datepicker('update', datainirec);
    $('.dataIniDisp').datepicker('update', datainirec);

    $('.dataIniLista').datepicker('update', datainirec);
    $('.dataFimLista').datepicker('update', datainirec);

    $('.divDataListaAgenda').datepicker('update', datainirec);

    $scope.mostraClientes = function() {
        $scope.semCadastro = !$scope.semCadastro;
        $('.typeahead').typeahead('val', '');
    };

    var emitBuscaCliente = $rootScope.$on('AgendabuscaClientes', function(event, pescodigo) {
        $scope.buscaClientes(pescodigo.any);
    });

    $scope.buscaClientes = function(pescodigo) {
        if (hasManyClients) {
            $('.select2.cliente').select2({
                ajax: {
                    url: '/pages/actions/buscaClientesMany.php',
                    dataType: 'json',
                    delay: 250,
                    data: (params) => {
                        return {
                            nome: params.term
                        };
                    },
                    processResults: (data, params) => {
                        return {
                            results: data.result
                        };
                    },
                    cache: true
                },
                placeholder: 'Sem Cadastro',
                escapeMarkup: (markup) => {
                    return markup;
                },
                minimumInputLength: 3,
                templateResult: thumbCliente3,
                templateSelection: formatRepoSelection
            });

            $.ajax({
                dataType: 'json',
                url: '/pages/actions/buscaClientes.php',
                async: false,
                method: 'POST',
                data: {
                    tipo: 2
                },
                success: function(data) {
                    for (var i = 0; i < data.result.length; i++) {
                        var codigo = data.result[i].Pes_Codigo;
                        var nome = data.result[i].Pes_Nome;
                        var foto = data.result[i].Paf_Imagem;
                        var usucod = data.result[i].Usu_Codigo;
                        var celular = data.result[i].Paf_Celular;
                    }

                    $scope.clientes = data.result;
                    nomeCliente = new Array();
                    clientesNomes.length = 0;

                    $.each($scope.clientes, (index, cliente) => {
                        clientesNomes.push(cliente.Pes_Nome + ' | ' + cliente.Paf_Celular);
                        clientesIds[cliente.Pes_Nome + ' | ' + cliente.Paf_Celular] = cliente.Pes_Codigo;
                    });

                    var clientes = new Bloodhound({
                        datumTokenizer: Bloodhound.tokenizers.whitespace,
                        queryTokenizer: Bloodhound.tokenizers.whitespace,
                        local: clientesNomes
                    });

                    $('.typeahead').typeahead('destroy');
                    $('#the-basics .typeahead').typeahead(null, {
                        limit: 20,
                        source: clientes
                    }).on('typeahead:selected', (e) => {
                        var arrNome = e.currentTarget.value.split(' | ');
                        nomeSelecionado = arrNome[0];
                        idSelecionado = clientesIds[e.currentTarget.value];
                    });
                }
            });

        } else {
            $.ajax({
                dataType: 'json',
                url: '/pages/actions/buscaClientes.php',
                async: false,
                method: 'POST',
                data: {
                    tipo: 2
                },
                success: function(data) {
                    var html = [];
                    var html2 = [];

                    html.push('<option data-usucodigo="" data-imagem="" data-celular="" value="" selected>Sem Cadastro</option>');
                    html2.push('<option data-usucodigo="" data-imagem="" data-celular="" value="" selected>Sem Cliente</option>');
                    for (var i = 0; i < data.result.length; i++) {
                        var codigo = data.result[i].Pes_Codigo;
                        var nome = data.result[i].Pes_Nome;
                        var foto = data.result[i].Paf_Imagem;
                        var usucod = data.result[i].Usu_Codigo;
                        var celular = data.result[i].Paf_Celular;
                        var observacao = data.result[i].PAF_Observacao;
                        var ausente = data.result[i].PAF_Ausente;
                        if (celular != '') {
                            html.push('<option data-usucodigo="' + usucod + '" data-imagem="' + foto + '" data-celular="' + celular + '" data-observacao="' + observacao + '" value="' + codigo + '" data-ausente="' + ausente + '">' + nome + ' - ' + celular + '</option>');
                            html2.push('<option data-usucodigo="' + usucod + '" data-imagem="' + foto + '" data-celular="' + celular + '" data-observacao="' + observacao + '" value="' + codigo + '" data-ausente="' + ausente + '">' + nome + ' - ' + celular + '</option>');
                        } else {
                            html.push('<option data-usucodigo="' + usucod + '" data-imagem="' + foto + '" data-celular="' + celular + '" data-observacao="' + observacao + '" value="' + codigo + '" data-ausente="' + ausente + '">' + nome + '</option>');
                            html2.push('<option data-usucodigo="' + usucod + '" data-imagem="' + foto + '" data-celular="' + celular + '" data-observacao="' + observacao + '" value="' + codigo + '" data-ausente="' + ausente + '">' + nome + '</option>');
                        }
                    }

                    setTimeout(() => {
                        document.getElementById('cliente_menu').innerHTML = html.join('');
                        document.getElementById('cliente_menu2').innerHTML = html2.join('');
                        document.getElementById('insertClienteEncaixe').innerHTML = html2.join('');
                        if (pescodigo != '') {
                            $('#cliente_menu').val(pescodigo).trigger('change');
                            $('#cliente_menu2').val(pescodigo).trigger('change');
                            $('#insertClienteEncaixe').val(pescodigo).trigger('change');
                        } else {
                            $('#cliente_menu').val('').trigger('change');
                            $('#cliente_menu2').val('').trigger('change');
                            $('#insertClienteEncaixe').val('').trigger('change');
                        }
                    }, 300);

                    $scope.clientes = data.result;
                    nomeCliente = new Array();
                    clientesNomes.length = 0;

                    $.each($scope.clientes, (index, cliente) => {
                        clientesNomes.push(cliente.Pes_Nome + ' | ' + cliente.Paf_Celular);
                        clientesIds[cliente.Pes_Nome + ' | ' + cliente.Paf_Celular] = cliente.Pes_Codigo;

                    });

                    var clientes = new Bloodhound({
                        datumTokenizer: Bloodhound.tokenizers.whitespace,
                        queryTokenizer: Bloodhound.tokenizers.whitespace,
                        local: clientesNomes
                    });

                    $('.typeahead').typeahead('destroy');
                    $('#the-basics .typeahead').typeahead(null, {
                        limit: 20,
                        source: clientes
                    }).on('typeahead:selected', (e) => {
                        var arrNome = e.currentTarget.value.split(' | ');
                        nomeSelecionado = arrNome[0];
                        idSelecionado = clientesIds[e.currentTarget.value];

                    });

                    if (data.result.length > 800) {
                        $('.select2.cliente').select2({
                            templateResult: thumbCliente,
                            minimumInputLength: 3
                        });
                    } else {
                        $('.select2.cliente').select2({
                            templateResult: thumbCliente
                        });
                    }
                }
            });
        }

    };

    $('#btnInserirDesbloquearAgenda').click(() => {
        var profissionalDesbloquear = $('#edtProfissionalDesbloquear').val();
        var diaIniDesbloquear = formataData($('#edtData2DesbloquearAgenda').val());
        var diaFimDesbloquear = formataData($('#edtDataFim2DesbloquearAgenda').val());
        var horaIniDesbloquear = $('#edtHoraIniDesbloquearAgenda').val();
        var horaFimDesbloquear = $('#edtHoraFimDesbloquearAgenda').val();
        showLoader(true);
        $.ajax({
            dataType: 'json',
            url: "/pages/actions/removeHorarioBloqueado.php",
            method: 'POST',
            data: {
                profissional: profissionalDesbloquear,
                diaini: diaIniDesbloquear,
                diafim: diaFimDesbloquear,
                horaini: horaIniDesbloquear,
                horafim: horaFimDesbloquear
            },
            success: (data) => {
                if (data.result[0].erro == 1) {
                    swal(data.result[0].resultado, '', 'error');
                } else {
                    $('#agendaHorario-modal').modal('hide');
                    toastr.success(data.result[0].resultado);
                    $scope.atualizaEventos();
                    $('#formHorarioDesbloquear').each((_, el) => {
                        el.reset();
                    });
                }
                showLoader(false);
            }
        });
    });

    $.ajax({
        dataType: 'json',
        url: "/pages/actions/buscaProfissionais.php",
        success: (data) => {
            var html = '';
            var html2 = '';
            var html3 = '<option value="">Selecione um Profissional</option>';
            html2 += '<option value="">Profissional</option>';
            for (var i = 0; i < data.profissionais.length; i++) {
                var codigo = data.profissionais[i].Pes_Codigo;
                var nome = data.profissionais[i].Pes_Nome;
                var apelido = data.profissionais[i].Pes_Apelido;
                html += '<option value="' + codigo + '">' + nome + '</option>';
                html2 += '<option value="' + codigo + '">' + apelido + '</option>';
                html3 += '<option value="' + codigo + '">' + apelido + '</option>';
            }

            $('#edtProfissional').html(html);
            $('#comInsertProfissionalEncaixe').html(html2);
            $('#profissionalRecorrencia').html(html);
            $('#edtProfissionalBloqueado').html(html);
            $('#edtProfissionalDesbloquear').html(html);
            $('#profisisonalHorDisp').html(html3);
            $('#profListaAgendamento').html(html2);
            $('#comProfissionalComissao').html(html2);
            $('#edtMultiProfissionalBloqueado').html(html2);
            $('#comInsertProfissionalEncaixe').select2();
            $('#comInsertProfissionalEncaixe').change((e) => {

                setTimeout(() => {
                    if (e.currentTarget.value != '' && $('#insertServicoEncaixe').val() != '') {
                        if ($('#insertServicoEncaixe option:selected').get(0).dataset.tipoitem == '1') {
                            buscaAssocProfissionalServico($('#insertServicoEncaixe').val(), $('#comInsertProfissionalEncaixe').val());
                        }
                    }
                }, 300);
            });



        }
    });
    $.ajax({
        dataType: 'json',
        url: '/pages/actions/buscaParametro.php',
        method: 'POST',
        data: {
            parcodigo: 5,
            origem: 1
        },
        success: function(data) {
            if (data.result.length > 0) {
                $_CONFIG.TEMPOPADRAO = data.result[0].PVa_Vlr_Principal;
            }

            $.ajax({
                dataType: 'json',
                url: '/pages/actions/buscaParametro.php',
                method: 'POST',
                async: false,
                data: {
                    parcodigo: 133,
                    origem: 1
                },
                success: function(param2) {
                    if (param2.result.length > 0) {
                        if (param2.result[0].PVa_Vlr_Principal != '') {
                            $_CONFIG.FIMAGENDA_PRINCIPAL = param2.result[0].PVa_Vlr_Principal;
                            $_CONFIG.FIMAGENDA_SECUNDARIO = param2.result[0].PVa_Vlr_Secundario;
                        }
                    }
                }
            });

            $.ajax({
                dataType: 'json',
                url: '/pages/actions/buscaParametro.php',
                method: 'POST',
                async: false,
                data: {
                    parcodigo: 43,
                    origem: 1
                },
                success: function(param3) {
                    if (param3.result.length > 0) {
                        if (param3.result[0].PVa_Vlr_Principal != '') {
                            $_CONFIG.INICIOAGENDA_PRINCIPAL = param3.result[0].PVa_Vlr_Principal;
                            $_CONFIG.INICIOAGENDA_SECUNDARIO = param3.result[0].PVa_Vlr_Secundario;
                        }
                    }

                    try {
                        $scope.objAgenda = JSON.parse(getStorage('agenda'));
                    } catch (e) {
                        $scope.objAgenda = '';
                    }
                    $('#calendar').fullCalendar('destroy');

                    $App.timePicker('.timepicker', mMinTimeTimePicker, 5);

                    initCalendar();
                    initContextMenu();
                }
            });
        }
    });

    $scope.adicionaServico = function() {
        $scope.criaServicoSelect();
    }

    $scope.criaServicoSelect = function() {

        var servicoHtml = '';
        servicoHtml = '<div id="divSelectServico' + $scope.numeroServicos + '">'
        servicoHtml += '<div class="col-lg-7 col-xs-6">';
        servicoHtml += '<div class="form-group">';
        servicoHtml += '<label id="lblServico">Serviço:</label>';
        servicoHtml += '<select class="form-control select2" id="servico_menu' + $scope.numeroServicos + '" data-idx="' + $scope.numeroServicos + '" name="servico_menu' + $scope.numeroServicos + '" style="width: 100%" required><br>';
        servicoHtml += '<option data-tempo="0" value="-1" data-valor="" data-tipopreco="" >Selecione um Serviço</option>';
        for (var i = 0; i < $scope.servicoSelect.length; i++) {
            servicoHtml += '<option data-tempo="' + $scope.servicoSelect[i].Ser_Intervalo_Padrao + '" value="' + $scope.servicoSelect[i].Ser_Codigo + '" data-valor="' + $scope.servicoSelect[i].Ser_Valor + '" data-tipopreco="' + $scope.servicoSelect[i].Ser_Tip_Preco + '" data-tipoitem="' + $scope.servicoSelect[i].TipoItem + '">' + $scope.servicoSelect[i].Ser_Descricao + '</option>';
        }
        servicoHtml += '</select>';
        servicoHtml += '</div></div>';

        if ($scope.numeroServicos !== 0) {
            servicoHtml += '<div class="col-lg-5 col-xs-6">';
            servicoHtml += '<div class="form-group">';
            servicoHtml += '<label id="lblTempo">Duração: <i data-toggle="popover" tabindex="0" data-trigger="hover" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Você pode estipular uma duração maior do que a definida para o serviço."></i></label>';
            servicoHtml += '<div class="input-group">'
            servicoHtml += '<select class="form-control select2" id="tempo_menu' + $scope.numeroServicos + '" name="tempo_menu' + $scope.numeroServicos + '" style="width: 100%" disabled>';
            servicoHtml += '</select>';
            servicoHtml += '<span class="input-group-btn"><button type="button" id="btnRemoveServicoSelect' + $scope.numeroServicos + '"  ng-click="removeServicoCombo()"  class="btn btn-link btn-flat"><i class="fa fa-trash-o"></i></button></span>'
            servicoHtml += '</div>'
            servicoHtml += '</div>';
            servicoHtml += '</div>';

        } else {
            servicoHtml += '<div class="col-lg-5 col-xs-6">';
            servicoHtml += '<div class="form-group">';
            servicoHtml += '<label id="lblTempo">Duração: <i data-toggle="popover" tabindex="0" data-trigger="hover" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Você pode estipular uma duração maior do que a definida para o serviço."></i></label>';
            servicoHtml += '<select class="form-control select2" id="tempo_menu' + $scope.numeroServicos + '" name="tempo_menu' + $scope.numeroServicos + '" style="width: 100%" disabled>';
            servicoHtml += '</select>';
            servicoHtml += '</div>';
            servicoHtml += '</div>';
        }
        servicoHtml += '</div>';
        if ($scope.numeroServicos == 0) {
            $('#servicos_select').html(servicoHtml);
        } else {
            $('#servicos_select').append(servicoHtml);
        }

        $('#servico_menu' + $scope.numeroServicos).change((e) => {
            var tempoPadrao = parseInt($_CONFIG.TEMPOPADRAO);
            //var tempoPadrao = 5;
            var tempoServico = parseInt(e.currentTarget.options[e.currentTarget.selectedIndex].dataset.tempo);
            var idx = e.currentTarget.dataset.idx;
            var hasservicetime = 1;
            if (tempoServico != undefined) {
                var html = '';
                for (var i = tempoPadrao; i < tempoPadrao * 15; i = i + tempoPadrao) {

                    if (i == tempoServico) {
                        html += '<option value="' + i + '" selected>' + i + ' Minutos</option>';
                        hasservicetime = 0;
                    } else {
                        html += '<option value="' + i + '">' + i + ' Minutos</option>';
                    }
                }
                if (hasservicetime == 1) {
                    html = `<option value="${tempoServico}">${tempoServico} Minutos</option>` + html
                }

                $('#tempo_menu' + idx).prop('disabled', false);
            } else {
                var html = '';
                $('#tempo_menu' + idx).prop('disabled', true);
            }
            $('#tempo_menu' + idx).html(html);

            $('#tempo_menu' + idx).val(tempoServico).trigger('change');

            if (idx == 0) {
                if ($("#cliente_menu").val() != '') {

                    $.ajax({
                        url: '/pages/cadastros/buscaPacotesPessoaCombo.php',
                        type: 'POST',
                        dataType: 'json',
                        async: false,
                        data: {
                            pescodigo: $("#cliente_menu").val(),
                            codigo: $("#servico_menu0").val(),
                            tipo: 1
                        },
                        success: function(data) {
                            if (data.result.length > 0) {
                                $("#HasPacotesCliente").html(" <b style='color:green'>Possuí pacotes para o serviço</b>")
                            } else {
                                $("#HasPacotesCliente").html(" <b style='color:orange'>Sem pacotes disponíveis para o serviço</b>")
                            }

                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        }
                    });
                }
            }

        });

        $('#servico_menu' + $scope.numeroServicos).select2({
            templateResult: thumbServico
        });

        $compile($('#btnRemoveServicoSelect' + $scope.numeroServicos))($scope);
        $compile($('#tempo_menu' + $scope.numeroServicos))($scope);
        $scope.numeroServicos++;
    }

    function thumbServico(state) {
        if (!state.id) {
            return state.text;
        }

        if (((state.element.dataset.tipopreco == 'Igual a') || (state.element.dataset.tipopreco == 'A partir de')) && ((state.element.dataset.valor.length != 0))) {
            var $state = $(
                '<span>' + state.text + '<br><small style="color:#adadad">' + state.element.dataset.tipopreco + ' - ' + $_CONFIG.MOEDA + ' ' + state.element.dataset.valor + '</small></span>'
            );
        } else if (((state.element.dataset.tipopreco != 'Igual a') && (state.element.dataset.tipopreco != 'A partir de')) && ((state.element.dataset.valor.length != 0))) {
            var $state = $(
                '<span>' + state.text + '<br><small style="color:#adadad">' + $_CONFIG.MOEDA + ' ' + state.element.dataset.valor + '</small></span>'
            );
        } else {
            var $state = $(
                '<span>' + state.text + '</span>'
            );
        }

        return $state;
    };

    $scope.removeServicoCombo = function() {
        if ($scope.numeroServicos == 1) {
            toastr.error('O Agendamento deve possuir ao menos um servico!');
        } else {
            $('#divSelectServico' + ($scope.numeroServicos - 1)).remove();
            $scope.numeroServicos--;
        }
    }

    $scope.realizadoEncaixe = function() {
        $('#idComanda').html($('#lblComCodigo').html());
        $('#btnFechaItemComandaSer').hide();
        $('#btnFechaServicoModal').show();
        insereServicoComanda(0, $scope.datahoraencaixe);
    }

    $scope.realizadoVenda = function() {
        $('#TprTipoComanda').html('1')
        $('#treAgendaCodigo').html('1');
        $scope.buscaProdutoCombo()
        $('#comCodigoInsert').val($('#lblComCodigo').html());
        $('#comanda-modal').modal('hide');
        $('#comandaInsert-modal').modal('show');
        $('#insereProdutoOrigem').val(0);
        $('#btnFechaItemComandaModal').show();
        $('#btnFechaItemComanda').hide();
        $("#listaServicoUso").hide()
    }

    $('#comandaInsertSer-modal').on('hide.bs.modal', function() {
        $('#btnFechaItemComandaSer').show();
        $('#btnFechaServicoModal').hide();
    });


    $('#infohorario-modal').on('show.bs.modal', function() {
        $('.popover').popover('hide');
    });

    $('#infohorario-modal').on('hide.bs.modal', function() {
        if ($scope.semCadastro) {
            $('#btnAssociaCliente').click();
        };
    });

    $scope.$on('$destroy', function() {
        clearInterval(nIntervId);
        nIntervId = null;
        clearInterval(intervalTimeZone);
        $('#users_menu').unbind('change');
        $('#btnRealizadoAg').unbind('click');
        $('#calendar').fullCalendar('removeEvents');
        clearTimeout(timevalor);

        $.contextMenu('destroy', 'has-menu');

        $('.popover').popover('hide');
        $scope.firstLoad = false;
        isAntigo = false;
        emit();
        emitBuscaCliente();
        for (var i = 0; i < listJornada.length; i++) {
            localStorage.removeItem(listJornada[i]);
        }
        setTimeout(function() {
            localStorage.removeItem('listJornada')
        }, 2000)
    });

    $('[data-toggle="popover"]').popover({
        container: 'body'
    });

    $scope.atualizaCalendario = function() {
        clearInterval(nIntervId);
        nIntervId = null;
        nIntervId = setInterval(
            function() {
                if (updateSchedule) {
                    var view = $('#calendar').fullCalendar('getView');
                    $scope.buscaAgendaV3(1, view.calendar.getDate().locale('pt-BR').format('L'));
                }
            },
            $scope.timerAgendaMS
        );
    }
    // para poder usar buscaComanda()) em sistemaCtrl
    var emit = $rootScope.$on('BuscaAgenda', function() {
        $scope.isAgendamentoAntigo(2);
    });

    $scope.desbloquearHorario = function(agecodigo) {
        swal({
                title: "Deseja desbloquear este horário?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Sim",
                cancelButtonText: "Não",
                closeOnConfirm: true
            },
            function() {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    url: "/pages/actions/cancelaHorario.php",
                    method: "POST",
                    data: {
                        agendamento: agecodigo
                    },
                    success: function(data) {
                        if (data.cancelaHorario[0].erro == 1) {
                            swal(data.cancelaHorario[0].resultado, "", "error");
                        } else {
                            toastr.success("Horário desbloqueado com sucesso.");
                            $scope.isAgendamentoAntigo(2);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    }
                });
            });
    }

    $scope.buscaAgendaV3 = function(tipo, day) {
        if (tipo != 1) {
            $scope.showLoaderSchedule();
        }

        $.ajax({
            dataType: "json",
            url: "/pages/actions/buscaAgenda3.php",
            type: 'POST',
            data: {
                profissional: $('#users_menu').val(),
                tipo: tipo,
                dia: day
            },
            success: function(data) {
                if (tipo != 1) {
                    $scope.hideLoaderSchedule();
                }

                setStorage("agenda", JSON.stringify(data).replaceAll("%20", " "));
                $scope.atualizaAgenda();

            },
            error: function() {
                if (tipo != 1) {
                    $scope.hideLoaderSchedule();
                }
            }
        });
    }
    $("#btnRefreshAgenda").click(function() {
        $("#btnRefreshAgenda").attr('disabled', true);
        setTimeout(function() {
            $("#btnRefreshAgenda").attr('disabled', false);
        }, 1000)
    })
    $scope.isAgendamentoAntigo = function(tipo) {
        showLoader(true);
        var isAntigo = false;
        try {
            var view = $("#calendar").fullCalendar("getView");
            var day = view.calendar.getDate();
            var dayNow = view.calendar.getNow();
            isAntigo = (day.diff(dayNow, "days") < 0);
        } catch (err) {
            isAntigo = false;
        }

        if (isAntigo) {
            isLoadv3 = true;
            clearInterval(nIntervId);
        } else {
            $scope.atualizaCalendario();
        }

        if (view.name == "resourceDay") {
            $scope.buscaAgendaV3(1, view.calendar.getDate().locale("pt-BR").format("L"));
        } else if (view.name == "month") {
            $scope.buscaAgendaV3(2, view.calendar.getDate().locale("pt-BR").format("L"));
        } else {
            $scope.buscaAgendaV3(3, view.calendar.getDate().locale("pt-BR").format("L"));
        }
        showLoader(false)
    }

    $scope.atualizaEventos = function() {
        $scope.isAgendamentoAntigo(2);
    }

    $scope.showLoaderSchedule = function() {
        $(".divLoaderCalendarWidget").show();
    }

    $scope.hideLoaderSchedule = function() {
        $(".divLoaderCalendarWidget").hide();
    }

    $scope.atualizaAgenda = function() {

        if (!$scope.initAgenda) {

            var aux = $('#calendar').fullCalendar('clientEvents').filter((data) => {
                return data.id == -99
            });
            $('#calendar').fullCalendar('removeEvents');

            JSON.parse(getStorage("agenda")).forEach((data) => {
                aux.push(data);
            });
            $('#calendar').fullCalendar('addEventSource', aux);
        }
    }

    var execTime = false;
    var carregando = false;
    var active;
    var resources = new Array();

    $.each($("#users_menu").children(), function(index, registro) {
        var idProf = registro.value;
        var nomeProf = registro.text;
        var resourcesItem = {
            id: idProf,
            name: nomeProf
        };
        resources.push(resourcesItem);
        setStorage("profissionais_" + $_CONFIG.CODESTABELECIMENTO, $('#users_menu').val());

    });

    $('#users_menu').on('change', function() {

        setStorage("profissionais", $('#users_menu').val());
        setStorage("profissionais_" + $_CONFIG.CODESTABELECIMENTO, $('#users_menu').val());

        $('#calendar').fullCalendar('render');
        $("#txtProfissional").html("Profissional: " + document.getElementById("users_menu").options[document.getElementById("users_menu").selectedIndex].text);
        //$scope.isAgendamentoAntigo(2);

        $('#users_menu').multiselect('refresh');
    });


    function thumbCliente(state) {
        if (!state.id) {
            return state.text;
        }
        var celular = "";

        if (state.element.dataset.imagem == "" || state.element.dataset.imagem == undefined) {
            if (state.element.dataset.observacao == "" || state.element.dataset.observacao == undefined) {
                var $state = $(

                    '<span><img src="/img/nopicture.png" class="img-thumb" class="img-thumb" /> ' + state.text + '</span>'
                );
            } else {
                var $state = $(
                    `<div class="row">

						<div class="col-md-1">
							<img src="/img/nopicture.png" class="img-thumb" />
						</div>
						<div class="col-md-10">
							${state.text}<br>
							<small style="color:#adadad; margin-left:5px">${state.element.dataset.observacao}</small>
						</div>
					</div>`
                );
            }
        } else {
            if (state.element.dataset.observacao == "" || state.element.dataset.observacao == undefined) {
                var $state = $(
                    '<span><img src="' + state.element.dataset.imagem + '" class="img-thumb" /> ' + state.text + '</span>'
                )
            } else {
                var $state = $(
                    `<div class="row">

						<div class="col-md-1">
							<img src="${state.element.dataset.imagem}" style="height:50px;width:50px" />
						</div>
						<div class="col-md-10">
							${state.text}<br>
							<small style="color:#adadad; margin-left:5px">${state.element.dataset.observacao}</small>
						</div>
					</div>`
                )
            }
        }
        return $state;


    };

    function thumbCliente3(state) {
        if (!state.id) {
            return state.Pes_Nome;
        }
        var celular = "";

        if (state.Paf_Imagem == "" || state.Paf_Imagem == undefined) {
            if (state.PAF_Observacao == "" || state.PAF_Observacao == undefined) {
                var $state = $(

                    '<span><img src="/img/nopicture.png" class="img-thumb" class="img-thumb" /> ' + state.Pes_Nome + ' - ' + state.Paf_Celular + '</span>'
                );
            } else {
                var $state = $(
                    `<div class="row">

						<div class="col-md-1">
							<img src="/img/nopicture.png" class="img-thumb" />
						</div>
						<div class="col-md-10">
							${state.Pes_Nome} - ${state.Paf_Celular}<br>

							<small style="color:#adadad; margin-left:5px">${state.PAF_Observacao}</small>
						</div>
					</div>`
                );
            }
        } else {
            if (state.PAF_Observacao == "" || state.PAF_Observacao == undefined) {
                var $state = $(
                    '<span><img src="' + state.Paf_Imagemm + '" class="img-thumb" /> ' + state.Pes_Nome + ' - ' + state.Paf_Celular + '</span>'
                )
            } else {
                var $state = $(
                    `<div class="row">

						<div class="col-md-1">
							<img src="${state.Paf_Imagem}" style="height:50px;width:50px" />
						</div>
						<div class="col-md-10">
							${state.Pes_Nome} - ${state.Paf_Celular}<br>

							<small style="color:#adadad; margin-left:5px">${state.PAF_Observacao}</small>
						</div>
					</div>`
                )
            }
        }
        return $state;


    };

    // $("#datemask").inputmask("dd/mm/yyyy", {
    // 	"placeholder": "dd/mm/yyyy"
    // });

    $("[data-inputmask]").inputmask();

    $('.sidebar-toggle').on('click', function() {
        setTimeout(function() {
            $('#calendar').fullCalendar('render');
        }, 500);
    });

    $("#agendaHorario-modal").on("hidden.bs.modal", function() {
        document.getElementById("formHorario").reset();
        document.getElementById("formHorarioBloqueado").reset();
        $("#servico_menu").val("-1").trigger('change');
        $("#cliente_menu").val("").trigger('change');
    });

    $("#edtHoraIniBloqueado").on("change", function() {
        if (($("#edtHoraIniBloqueado")[0].selectedIndex + 1) != $("#edtHoraIniBloqueado")[0].length) {
            $("#edtHoraFimBloqueado")[0].selectedIndex = ($("#edtHoraIniBloqueado")[0].selectedIndex + 1)
        } else {
            $("#edtHoraFimBloqueado")[0].selectedIndex = ($("#edtHoraIniBloqueado")[0].selectedIndex)
        }
    });

    $("#dvCalendario").datepicker({
        todayBtn: "linked",
        language: 'pt-BR',
        format: 'dd/mm/yyyy',
        todayHighlight: true
    }).on('changeDate', function(e) {
        var dataClicada = e.date;


        $('#calendar').fullCalendar('gotoDate', dataClicada);
        $('#calendar').fullCalendar('changeView', "resourceDay");
        $("#headerCalendar").html($(".fc-header-title").html().replace("<h2>", "").replace("</h2>", ""));

        if (!execTime) {
            for (var i = 0; i < active.length; i++) {
                atualizaJornada(dataClicada, active[i]);
            }
        }
    });
    if ($_CONFIG.CODUSUARIO == 1909716 || $_CONFIG.CODUSUARIO == 582226 || $_CONFIG.CODUSUARIO == 425495 || $_CONFIG.CODUSUARIO == 425497 || $_CONFIG.CODUSUARIO == 582218 || $_CONFIG.CODUSUARIO == 425492 || $_CONFIG.CODUSUARIO == 1707108) {
        $("#btnConfirmaAg").show()
    }

    $('#edtDataBloqueado').on('change', function() {
        $('#edtData2Bloqueado').val(formataData($('#edtDataBloqueado').val()));
    });

    $('#edtDataFimBloqueado').on('change', function() {
        $('#edtDataFim2Bloqueado').val(formataData($('#edtDataFimBloqueado').val()));
    });

    $("#btnInserirAg").on("click", function() {
        showLoader(true)
        var profissional = $("#edtProfissional").val();
        var dia = $('#edtData2').val();
        var hora = $("#edtHoraIni").val();
        var cliente = $("#cliente_menu").val();
        var txtObs = $("#txtObs").val();
        var dataInicio = moment(dia + " " + hora, "YYYY-MM-DD HH:mm");

        var stringData = new Array();
        var stringItem = new Array();
        var stringTipoItem = new Array();
        var stringProfissional = new Array();
        var stringDuracao = new Array();
        var dataAux = dataInicio;

        for (var i = 0; i < $scope.numeroServicos; i++) {
            stringItem.push($("#servico_menu" + i).val())
            stringTipoItem.push($("#servico_menu" + i + " option:selected").get(0).dataset.tipoitem)
            stringProfissional.push(profissional),
                stringDuracao.push(parseInt($("#tempo_menu" + i).val()));
            stringData.push(dataAux.format("YYYY-MM-DD HH:mm"));
            dataAux = dataAux.add(parseInt($("#tempo_menu" + i).val()), "m")
        }

        if ($("#cbEnviaSms").get(0).checked) {
            var cbEnviaSms = 1;
        } else {
            var cbEnviaSms = 0;
        }
        if ($('#cbEnviaWhats').get(0).checked) {
            var cbEnviaWhats = 1;
        } else {
            var cbEnviaWhats = 0;
        }

        $.ajax({
            dataType: "json",
            type: "POST",
            url: "/pages/cadastros/insereAgendamentov5.php",
            data: {
                item: stringItem.toString(),
                tipoitem: stringTipoItem.toString(),
                profissional: stringProfissional.toString(),
                dataagendamento: stringData.toString(),
                duracao: stringDuracao.toString(),
                cliente: cliente,
                cupom: '',
                numitens: $scope.numeroServicos,
                ageorigem: 2,
                observacao: txtObs,
                lembrete: $("#add_lembrete_menu").val(),
                tempolembrete: $("#qtd_lembrete_menu").val(),
                sms: cbEnviaSms,
                whats: cbEnviaWhats
            },
            success: function(data) {
                if (data.data[0].erro == 0) {
                    toastr.success(data.data[0].resultado);
                    $scope.isAgendamentoAntigo(2);
                    $('#agendaHorario-modal').modal('hide');
                    showLoader(false);
                } else if (data.data[0].erro == 1) {
                    swal(data.data[0].resultado, "", "error");
                    showLoader(false);
                } else {
                    swal(data.data[0].resultado, "", "error");
                    showLoader(false);
                }
            },
            error: function(result) {

                showLoader(false);
            }
        });
    });

    $scope.buscaSaldoSMS = function() {
        $.ajax({
            dataType: "json",
            url: '/pages/actions/buscaSaldoSMS.php',
            success: function(data) {
                if (data.result.length > 0) {
                    $("#lblSaldoSMSAg").html(data.result[0].Saldo);
                    $scope.saldoSMS = data.result[0].Saldo;
                    $scope.$apply();
                }
            }
        });
    }

    $scope.buscaSaldoWhats = function() {
        $.ajax({
            dataType: "json",
            url: '/pages/cadastros/buscaSaldoWhats.php',
            method: "POST",
            data: {
                tipo: 1
            },
            success: function(data) {
                if (data.data.length > 0) {
                    $("#lblSaldoWhatsAg").html(data.data[0].Saldo);
                    $scope.saldoWhats = data.data[0].Saldo;
                    $scope.$apply();
                }
            }
        });
    }


    $("#select").hide();
    $("#qtdDiasDiv").hide();

    $("#edtTipoBloqueio").on('change', function() {
        $scope.bloqueioTipo();
    });

    $scope.bloqueioTipo = function() {
        if ($("#edtTipoBloqueio").val() == "1") {
            $("#edtDataBloqueado").prop('disabled', true);
            $("#edtDataFimBloqueado").prop('disabled', true);
            $("#addonini").hide();
            $("#addonfim").hide();
            $("#datafimhide").hide();
            $("#edtProfissionalBloqueado").hide();
            $("#select").show();
            $("#qtdDiasDiv").show();
        } else {
            $("#edtDataBloqueado").prop('disabled', false);
            $("#edtDataFimBloqueado").prop('disabled', false);
            $("#addonini").show();
            $("#addonfim").show();
            $("#datafimhide").show();
            $("#edtProfissionalBloqueado").show();
            $("#select").hide();
            $("#qtdDiasDiv").hide();
        }
    }

    $("#edtQuantidadeDiasBloqueado").keyup(function() {
        if ($("#edtQuantidadeDiasBloqueado").val() > 180) {
            $("#edtQuantidadeDiasBloqueado").val(180);
        }
    });

    $("#btnInserirBloqueado").on('click', function() {
        if ($("#edtTipoBloqueio").val() == "0") {
            var id = $scope.idCliente;
            var profissionalBloqueado = $("#edtProfissionalBloqueado").val();
            var diaIniBloqueado = $('#edtData2Bloqueado').val();
            var diaFimBloqueado = $('#edtDataFim2Bloqueado').val();
            var horaIniBloqueado = $("#edtHoraIniBloqueado").val();
            var horaFimBloqueado = $("#edtHoraFimBloqueado").val();
            var txtObsBloqueado = $("#txtObsBloqueado").val();
            showLoader(true);
            $.ajax({
                dataType: "json",
                url: "/pages/actions/agendaHorarioBloqueado.php",
                method: "POST",
                data: {
                    profissional: profissionalBloqueado,
                    diaini: diaIniBloqueado,
                    diafim: diaFimBloqueado,
                    horaini: horaIniBloqueado,
                    horafim: horaFimBloqueado,
                    observacao: txtObsBloqueado
                },
                success: function(data) {
                    if (data.agendaHorarioBloqueado[0].erro == 1) {
                        swal(data.agendaHorarioBloqueado[0].resultado, "", "error");
                    } else {
                        $('#agendaHorario-modal').modal('hide');
                        swal(data.agendaHorarioBloqueado[0].resultado, "", "success");
                        $scope.isAgendamentoAntigo(2);
                        $("#edtTipoBloqueio").val(0);
                        $scope.bloqueioTipo();
                    }
                    showLoader(false);
                },
                error: function(result) {
                    swal("Falha na conexão.", "", "error");
                    showLoader(false);
                }
            });
        } else {
            var profissionalBloqueado = $("#edtMultiProfissionalBloqueado").val();
            var diaIniBloqueado = $('#edtData2Bloqueado').val();
            var diaFimBloqueado = $('#edtDataFim2Bloqueado').val();
            var horaIniBloqueado = $("#edtHoraIniBloqueado").val();
            var horaFimBloqueado = $("#edtHoraFimBloqueado").val();
            var txtObsBloqueado = $("#txtObsBloqueado").val();
            var qtdDias = $("#edtQuantidadeDiasBloqueado").val();
            var periodicidade = $("#edtPeriodicidadeBloqueado").val();
            showLoader(true);
            $("#btnInserirBloqueado").attr('disabled', true);
            $("#btnInserirBloqueado").html('<i class="fa fa-spinner fa-pulse"></i> Cadastrando...');
            $.ajax({
                dataType: "json",
                type: "POST",
                url: "/pages/cadastros/insereAgendamentoBloqueadoRecorrentev2.php",
                data: {
                    profissionalBloqueado: profissionalBloqueado,
                    diaIniBloqueado: diaIniBloqueado,
                    diaFimBloqueado: diaFimBloqueado,
                    horaIniBloqueado: horaIniBloqueado,
                    horaFimBloqueado: horaFimBloqueado,
                    txtObsBloqueado: txtObsBloqueado,
                    qtdDias: qtdDias,
                    periodicidade: periodicidade
                },
                success: function(data) {
                    if (data.falha == "0") {
                        $('#agendaHorario-modal').modal('hide');
                        swal("Horários bloqueados com sucesso", "", "success");
                        $scope.isAgendamentoAntigo(2);

                        $("#edtTipoBloqueio").val(0);
                        $scope.bloqueioTipo();
                        showLoader(false);
                        $("#btnInserirBloqueado").removeAttr('disabled');
                        $("#btnInserirBloqueado").html('BLOQUEAR');
                    } else {

                        swal("Erro ao bloquear horários, confira seus dados de bloqueio", "", "error");
                        showLoader(false);
                        $("#btnInserirBloqueado").removeAttr('disabled');
                        $("#btnInserirBloqueado").html('BLOQUEAR');
                    }
                },
                error: function(result) {
                    swal("Falha na conexão.", "", "error");
                    showLoader(false);
                }
            });
        }

    });

    $("#btnCancelarAg").on('click', () => {
        var agendamentoID = $("#lblIDAgendamento").html();
        $("#cancelarAgendamento-modal").modal();
        $('#formCancelaAgendamento').unbind('submit');
        $('#formCancelaAgendamento').submit((e) => {
            formCancela = $(e.currentTarget);
            showLoader(true);
            $.ajax({
                dataType: "json",
                url: "/pages/actions/cancelaHorario.php",
                method: "POST",
                data: {
                    agendamento: agendamentoID,
                    motivo: $("#ageMotivo").val()
                },
                success: (data) => {
                    if (data.cancelaHorario[0].erro == 1) {
                        swal(data.cancelaHorario[0].resultado, "", "error");
                    } else {
                        $('#infohorario-modal').modal('hide');
                        toastr.success("Agendamento foi cancelado com sucesso.");
                        $scope.isAgendamentoAntigo(2);
                    }
                    $("#cancelarAgendamento-modal").modal("hide");
                    formCancela.each((_, el) => {
                        el.reset();
                    });
                    showLoader(false);
                },
                error: () => {
                    swal("Falha na conexão.", "", "error");
                    showLoader(false);
                }
            });
            return true;
        });
    });

    $("#btnConfirmaAg").on('click', () => {
        showLoader(true);
        $.ajax({
            dataType: "json",
            url: "/pages/actions/atualizaHorario.php",
            method: "POST",
            data: {
                agendamento: $("#lblIDAgendamento").html(),
                tipo: 5
            },
            success: (data) => {
                if (data.result[0].erro == "0") {
                    toastr.success(data.result[0].resultado);
                } else {
                    toastr.error(data.result[0].resultado);
                }
                $scope.isAgendamentoAntigo(2);
                showLoader(false);
            },
            error: () => {
                showLoader(false);
            }
        });
    });



    $("#btnNoLocal").on('click', () => {
        showLoader(true);
        $.ajax({
            dataType: "json",
            url: "/pages/actions/atualizaHorario.php",
            method: "POST",
            data: {
                agendamento: $("#lblIDAgendamento").html(),
                tipo: 8
            },
            success: (data) => {
                if (data.result[0].erro == "0") {
                    toastr.success(data.result[0].resultado);
                } else {
                    toastr.error(data.result[0].resultado);
                }
                $scope.isAgendamentoAntigo(2);
                showLoader(false);
            },
            error: () => {
                showLoader(false);
            }
        });
    });

    $("#btnPreferenciaAg").click(() => {
        showLoader(true);
        $.ajax({
            dataType: "json",
            url: "/pages/actions/atualizaHorario.php",
            method: "POST",
            data: {
                agendamento: $("#lblIDAgendamento").html(),
                tipo: 6
            },
            success: (data) => {
                if (data.result[0].erro == "0") {
                    toastr.success(data.result[0].resultado);
                } else {
                    toastr.error(data.result[0].resultado);
                }
                $scope.isAgendamentoAntigo(2);
                showLoader(false);
            },
            error: () => {
                showLoader(false);
            }
        });
    });

    $("#btnAlteraEncaixe").click(() => {
        showLoader(true);
        $.ajax({
            dataType: "json",
            url: "/pages/actions/atualizaHorario.php",
            method: "POST",
            data: {
                agendamento: $("#lblIDAgendamento").html(),
                tipo: 7
            },
            success: (data) => {
                if (data.result[0].erro == "0") {
                    toastr.success(data.result[0].resultado);
                } else {
                    toastr.error(data.result[0].resultado);
                }
                $scope.isAgendamentoAntigo(2);
                showLoader(false);
            },
            error: () => {
                showLoader(false);
            }
        });
    });

    $("#btnRealizadoAg").click(() => {
        if ($scope.finalAgendamentoRecorrente == 2) {
            $App.showMessageColor("Agendamento recorrente", "Este é um dos últimos agendamentos recorrentes do cliente, caso necessário renove pela sua agenda", 1, '', 'info')
        } else if ($scope.finalAgendamentoRecorrente == 1) {
            $App.showMessageColor("Agendamento recorrente", "Este é o penúltimo agendamento recorrente do cliente", 1, '', 'info')
        } else if ($scope.finalAgendamentoRecorrente == 0) {
            $App.showMessageColor("Agendamento recorrente", "Esse é o último agendamento recorrente da lista, você pode lançar uma nova lista de agendamentos para o cliente pela sua agenda", 1, '', 'warning')
        }

        $('#ageValor').val($('#lblValorHdn').html());
        $('#codCliente').val($('#lblPesCodigo').html())
        if ($('#codCliente').val() == "") {
            $("#btnAssociaClienteComanda").show();
        } else {
            $("#btnAssociaClienteComanda").hide();
        }
        $scope.buscaPessoaConta();
        $scope.atualizaTipoPagemento();
        var agendamentoID = $("#lblIDAgendamento").html();

        $.ajax({
            dataType: "json",
            url: localStorage.getItem("host"),
            data: {
                metodo: 'buscaComanda',
                id: $scope.idCliente,
                agecodigo: agendamentoID,
                tipo: 3
            },
            success: (data) => {
                if (data.result[0].TPR_Codigo == 3) {
                    $("#labelTipoClienteComanda").html("Profissional: ");
                    $("#iconInfoCliente").hide();
                    $("#infoPontosCli").hide();
                    $("#TprTipoComanda").html(data.result[0].TPR_Codigo);
                } else {
                    $("#labelTipoClienteComanda").html("Cliente: ");
                    $("#iconInfoCliente").show();
                    $("#TprTipoComanda").html(data.result[0].TPR_Codigo);

                    if (data.result[0].Cliente != "") {
                        $("#nomeClienteComanda").html(data.result[0].Cliente);
                        $("#iconInfoCliente").show();
                    } else {
                        $("#nomeClienteComanda").html("Sem Cadastro");
                        $("#iconInfoCliente").hide();
                    }
                    $("#infoPontosCli").show();

                    $.ajax({
                        dataType: "html",
                        url: '/pages/relatorios/buscaProgramaFidelidade.php',
                        method: "POST",
                        data: {
                            selCliente: data.result[0].CodigoCliente,
                            selTipo: 1
                        },
                        dataType: "json",
                        success: function(data) {

                            if (data.data.length == 1) {
                                $("#stringPontosCli").html(data.data[0].TotalPontos);
                            } else {
                                $("#stringPontosCli").html(0);
                            }

                        }
                    });
                }

                $("#idComanda").html(data.result[0].Com_Codigo);
                if (data.result[0].CCE_Cod_Externo != '') {
                    $("#idComandaExterno").html('N˚: ' + data.result[0].CCE_Cod_Externo);
                    $("#idComandaExterno").show();
                } else {
                    $("#idComandaExterno").html('');
                    $("#idComandaExterno").hide();
                }
                $("#dataComanda").html(data.result[0].Com_Dat_Cadastro);
                $("#edtComCartao").val(data.result[0].Com_Cod_Externo);
                $("#codCliente").val()
                $('#infohorario-modal').modal('hide');
                $('#comanda-modal').modal('show');
                // setTimeout(function () {
                // 	$rootScope.$emit("buscaTransacao", data.result[0].Com_Codigo);
                // }, 500)


                $scope.buscaItensComanda(data.result[0].Com_Codigo);

            },
            error: () => {
                swal("Falha na conexão.", "", "error");
            }
        });
    });

    $("#btnAtualizaObs").click(() => {
        var agendamentoID = $("#lblIDAgendamento").html();
        var obs = $("#lblObs").val();
        showLoader(true);
        $.ajax({
            dataType: "json",
            url: "/pages/actions/atualizaHorario.php",
            method: "POST",
            data: {
                agendamento: agendamentoID,
                tipo: '2',
                observacao: unescape(escape(obs).replaceAll('%u', '\\u'))
            },
            success: (data) => {
                if (data.result[0].erro == 1) {
                    swal(data.result[0].resultado, "", "error");
                } else {
                    toastr.success("Observação atualizada com sucesso.");
                    $scope.isAgendamentoAntigo(2);
                }
                showLoader(false);
            },
            error: () => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
    });

    $("#btnAusenteAg").click(function() {
        var agendamentoID = $("#lblIDAgendamento").html();
        swal({
                title: "Marcar agendamento como ausência?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Sim",
                cancelButtonText: "Não"
            },
            function() {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    url: "/pages/actions/atualizaHorario.php",
                    method: "POST",
                    data: {
                        agendamento: agendamentoID,
                        status: '5',
                        tipo: 1
                    },
                    success: function(data) {
                        if (data.result[0].erro == 1) {
                            toastr.error(data.result[0].resultado);
                        } else {
                            $('#infohorario-modal').modal('hide');
                            toastr.success("Agendamento marcado como ausente.");
                        }
                        $scope.isAgendamentoAntigo(2);
                        $scope.buscaClientes();
                        showLoader(false);
                    },
                    error: function(result) {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    }
                });
            });
    });

    $("#btnReabrirAg").click(function() {
        var comCod = $("#lblComCodigo").html();
        var citCod = $('#lblCItCodigo').html();

        swal({
                title: "Reabrir este Agendamento?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Sim",
                cancelButtonText: "Não"
            },
            function() {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    url: '/pages/cadastros/atualizaComandav2.php',
                    method: "POST",
                    data: {
                        id: $scope.idCliente,
                        comcodigo: comCod,
                        tipo: 4,
                        citcodigo: citCod
                    },
                    success: function(data) {
                        if (data.data[0].erro == 1) {
                            toastr.error(data.data[0].resultado);
                        } else {
                            $('#infohorario-modal').modal('hide');
                            toastr.success("Agendamento e Comanda reabertos com sucesso.");
                        }
                        $scope.isAgendamentoAntigo(2);
                        showLoader(false);
                    },
                    error: function(result) {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    }
                });
            });
    });

    function atualizaJornada(diaAtual, profissional) {
        diaAtual = moment(diaAtual);

        $('#calendar').fullCalendar('removeEvents', -99);
        execTime = true;
        var validadata = localStorage.getItem(`jornada${profissional}|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`)

        if (validadata == null) {
            $.ajax({
                dataType: "json",
                url: "/pages/actions/buscaJornadaProfissionais.php",
                method: "POST",
                data: {
                    dia: diaAtual.day() + 1,
                    profissional: profissional,
                    dataAgenda: diaAtual.locale("pt-br").format("L")
                },
                success: function(data) {

                    if (data.jornada.length == 0) {
                        setStorage(`jornada${profissional}|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`, JSON.stringify(data))
                        setStorage(`current_agenda_date`, `|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`)
                        listJornada.push(`jornada${profissional}|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`);
                        setStorage('listJornada', listJornada)
                        var originalEventObject = $(this).data('eventObject');
                        var horaIni = $.extend({}, originalEventObject);

                        var dia = diaAtual.date();
                        var mes = diaAtual.month() + 1;
                        var ano = diaAtual.year();
                        horaIni.id = -99;
                        horaIni.start = new Date(ano + "/" + mes + "/" + dia + " 00:00:00");
                        horaIni.end = new Date(ano + "/" + mes + "/" + dia + " 23:59:59");
                        horaIni.backgroundColor = "#444444";
                        horaIni.borderColor = "#444444";
                        horaIni.codStatus = 6;
                        horaIni.resources = profissional;
                        $('#calendar').fullCalendar('renderEvent', horaIni, true);

                    } else {
                        setStorage(`jornada${profissional}|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`, JSON.stringify(data))
                        setStorage(`current_agenda_date`, `|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`)
                        listJornada.push(`jornada${profissional}|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`);
                        setStorage('listJornada', listJornada)
                        if (data.jornada[0].PJo_Hor_Ini1 != null) {
                            //var originalEventObject = $(this).data('eventObject');
                            var originalEventObject = {};
                            var horaIni = $.extend({}, originalEventObject);

                            var dia = diaAtual.date();
                            var mes = diaAtual.month() + 1;
                            var ano = diaAtual.year();
                            horaIni.id = -99;
                            horaIni.start = new Date(ano + "/" + mes + "/" + dia + " 00:00:00");
                            horaIni.end = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Ini1);
                            horaIni.backgroundColor = "#444444";
                            horaIni.borderColor = "#444444";
                            horaIni.codStatus = 6;
                            horaIni.resources = profissional;
                            $('#calendar').fullCalendar('renderEvent', horaIni, true);

                        }

                        if (data.jornada[0].PJo_Hor_Ini2 != null && data.jornada[0].PJo_Hor_Ini2 != "") {
                            var originalEventObject = $(this).data('eventObject');
                            var horaIni = $.extend({}, originalEventObject);
                            var dia = diaAtual.date();
                            var mes = diaAtual.month() + 1;
                            var ano = diaAtual.year();
                            horaIni.id = -99;
                            horaIni.start = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Fim1);
                            horaIni.end = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Ini2);
                            horaIni.backgroundColor = "#444444";
                            horaIni.borderColor = "#444444";
                            horaIni.codStatus = 6;
                            horaIni.resources = profissional;
                            $('#calendar').fullCalendar('renderEvent', horaIni, true);

                        } else {
                            var originalEventObject = $(this).data('eventObject');
                            var horaIni = $.extend({}, originalEventObject);
                            var dia = diaAtual.date();
                            var mes = diaAtual.month() + 1;
                            var ano = diaAtual.year();
                            horaIni.id = -99;
                            horaIni.start = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Fim1);
                            horaIni.end = new Date(ano + "/" + mes + "/" + dia + " 23:59:59");
                            horaIni.backgroundColor = "#444444";
                            horaIni.borderColor = "#444444";
                            horaIni.codStatus = 6;
                            horaIni.resources = profissional;
                            $('#calendar').fullCalendar('renderEvent', horaIni, true);

                        }

                        if (data.jornada[0].PJo_Hor_Fim2 != null && data.jornada[0].PJo_Hor_Fim2 != "") {
                            var originalEventObject = $(this).data('eventObject');

                            var horaIni = $.extend({}, originalEventObject);
                            var dia = diaAtual.date();
                            var mes = diaAtual.month() + 1;
                            var ano = diaAtual.year();
                            horaIni.id = -99;
                            horaIni.start = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Fim2);
                            horaIni.end = new Date(ano + "/" + mes + "/" + dia + " 23:59:59");
                            horaIni.backgroundColor = "#444444";
                            horaIni.borderColor = "#444444";
                            horaIni.codStatus = 6;
                            horaIni.resources = profissional;
                            $('#calendar').fullCalendar('renderEvent', horaIni, true);

                        }
                    }
                    execTime = false;

                    if ($('#calendar').fullCalendar('getView').calendar.fetchResources().length > $scope.limitScrollAgenda) {
                        var sizeAgenda = 50 + (144 * $('#calendar').fullCalendar('getView').calendar.fetchResources().length);
                        $(".fc-content").width(sizeAgenda)
                        $('#calendar').fullCalendar('getView').calendar.updateSize();
                    }
                }
            });
        } else {

            setTimeout(function() {
                var data = JSON.parse(getStorage(`jornada${profissional}|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`));
                setStorage(`current_agenda_date`, `|${diaAtual.date()}-${diaAtual.month()}-${diaAtual.year()}`)
                if (data.jornada.length == 0) {
                    var originalEventObject = $(this).data('eventObject');
                    var horaIni = $.extend({}, originalEventObject);
                    var dia = diaAtual.date();
                    var mes = diaAtual.month() + 1;
                    var ano = diaAtual.year();
                    horaIni.id = -99;
                    horaIni.start = new Date(ano + "/" + mes + "/" + dia + " 00:00:00");
                    horaIni.end = new Date(ano + "/" + mes + "/" + dia + " 23:59:59");
                    horaIni.backgroundColor = "#444444";
                    horaIni.borderColor = "#444444";
                    horaIni.codStatus = 6;
                    horaIni.resources = profissional;
                    $('#calendar').fullCalendar('renderEvent', horaIni, true);
                } else {
                    if (data.jornada[0].PJo_Hor_Ini1 != null) {
                        //var originalEventObject = $(this).data('eventObject');
                        var originalEventObject = {};
                        var horaIni = $.extend({}, originalEventObject);

                        var dia = diaAtual.date();
                        var mes = diaAtual.month() + 1;
                        var ano = diaAtual.year();
                        horaIni.id = -99;
                        horaIni.start = new Date(ano + "/" + mes + "/" + dia + " 00:00:00");
                        horaIni.end = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Ini1);
                        horaIni.backgroundColor = "#444444";
                        horaIni.borderColor = "#444444";
                        horaIni.codStatus = 6;
                        horaIni.resources = profissional;
                        $('#calendar').fullCalendar('renderEvent', horaIni, true);
                    }

                    if (data.jornada[0].PJo_Hor_Ini2 != null && data.jornada[0].PJo_Hor_Ini2 != "") {
                        var originalEventObject = $(this).data('eventObject');
                        var horaIni = $.extend({}, originalEventObject);
                        var dia = diaAtual.date();
                        var mes = diaAtual.month() + 1;
                        var ano = diaAtual.year();
                        horaIni.id = -99;
                        horaIni.start = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Fim1);
                        horaIni.end = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Ini2);
                        horaIni.backgroundColor = "#444444";
                        horaIni.borderColor = "#444444";
                        horaIni.codStatus = 6;
                        horaIni.resources = profissional;
                        $('#calendar').fullCalendar('renderEvent', horaIni, true);
                    } else {
                        var originalEventObject = $(this).data('eventObject');
                        var horaIni = $.extend({}, originalEventObject);
                        var dia = diaAtual.date();
                        var mes = diaAtual.month() + 1;
                        var ano = diaAtual.year();
                        horaIni.id = -99;
                        horaIni.start = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Fim1);
                        horaIni.end = new Date(ano + "/" + mes + "/" + dia + " 23:59:59");
                        horaIni.backgroundColor = "#444444";
                        horaIni.borderColor = "#444444";
                        horaIni.codStatus = 6;
                        horaIni.resources = profissional;
                        $('#calendar').fullCalendar('renderEvent', horaIni, true);
                    }

                    if (data.jornada[0].PJo_Hor_Fim2 != null && data.jornada[0].PJo_Hor_Fim2 != "") {
                        var originalEventObject = $(this).data('eventObject');
                        var horaIni = $.extend({}, originalEventObject);
                        var dia = diaAtual.date();
                        var mes = diaAtual.month() + 1;
                        var ano = diaAtual.year();
                        horaIni.id = -99;
                        horaIni.start = new Date(ano + "/" + mes + "/" + dia + " " + data.jornada[0].PJo_Hor_Fim2);
                        horaIni.end = new Date(ano + "/" + mes + "/" + dia + " 23:59:59");
                        horaIni.backgroundColor = "#444444";
                        horaIni.borderColor = "#444444";
                        horaIni.codStatus = 6;
                        horaIni.resources = profissional;
                        $('#calendar').fullCalendar('renderEvent', horaIni, true);
                    }
                }
                execTime = false;
                if ($('#calendar').fullCalendar('getView').calendar.fetchResources().length > $scope.limitScrollAgenda) {


                    var sizeAgenda = 50 + (144 * $('#calendar').fullCalendar('getView').calendar.fetchResources().length);
                    $(".fc-content").width(sizeAgenda)
                    $('#calendar').fullCalendar('getView').calendar.updateSize();

                }
            })

        }
    }

    $("#cliEstado2").change((e) => {
        var estado = e.currentTarget.value;
        $("#cliCidade2").empty();

        if (estado === -1) {
            $("#cliCidade2").attr("disabled", true);
        } else {
            $.ajax({
                dataType: "html",
                url: '/pages/cadastros/buscaCidades.php',
                method: "POST",
                data: {
                    estCodigo: estado
                },
                success: (data) => {
                    $("#cliCidade2").append(data);
                    $("#cliCidade2").attr("disabled", false);
                }
            });
        }
    });
    $("#cliEstado").change((e) => {
        var estado = e.currentTarget.value;
        $("#cliCidade").empty();

        if (estado === -1) {
            $("#cliCidade").attr("disabled", true);
        } else {
            $.ajax({
                dataType: "html",
                url: '/pages/cadastros/buscaCidades.php',
                method: "POST",
                data: {
                    estCodigo: estado
                },
                success: (data) => {
                    $("#cliCidade").append(data);
                    $("#cliCidade").attr("disabled", false);
                }
            });
        }
    });

    $("#cliEstadoEdtAgenda").change((e) => {
        var estado = e.currentTarget.value;
        $("#cliCidadeEdtAgenda").empty();

        if (estado === -1) {
            $("#cliCidadeEdtAgenda").attr("disabled", true);
        } else {
            $.ajax({
                dataType: "html",
                url: '/pages/cadastros/buscaCidades.php',
                method: "POST",
                data: {
                    estCodigo: estado
                },
                success: (data) => {
                    $("#cliCidadeEdtAgenda").append(data);
                    $("#cliCidadeEdtAgenda").attr("disabled", false);
                }
            });
        }
    });

    $("#cliCep").keyup((e) => {
        buscaCEPCliente(e.currentTarget.value);
    });

    $("#cliCep2").keyup((e) => {
        buscaCEPCliente2(e.currentTarget.value);
    });

    var buscaCEPCliente = (cep) => {
        mCep = cep;
        if (cep && cep.length >= parseInt($_CONFIG.language.mascaras.max_cep)) {
            cep = cep.replace("-", "");
            showLoader(true);
            var pais = $_CONFIG.language.mascaras.lang;
            $.ajax({
                dataType: "json",
                method: 'POST',
                url: '/pages/cadastros/buscaPostalCode.php',
                data: {
                    code: cep,
                    pais: pais
                },
                success: (data) => {
                    var estado = "";
                    if (pais == "pt") {
                        estado = $("#" + data.estado.replace(" ", "").toLowerCase() + "").val();
                    } else {
                        estado = $("#" + data.estado + "").val();
                    }
                    $("#cliEstado").val(estado);
                    $("#cliCidade").empty();

                    $.ajax({
                        dataType: "json",
                        url: '/pages/cadastros/buscaCidadesWizard.php',
                        method: "POST",
                        data: {
                            estCodigo: estado,
                            cidNome: data.cidade
                        },
                        success: (result) => {
                            $("#cliCidade").append(result.cidades);
                            $("#cliCidade").attr("disabled", false);
                            setTimeout(() => {
                                $("#cliCidade").val(result.cidcodigo);
                            }, 10);
                            showLoader(false);
                            $("#cliBairro").val(data.bairro);
                            $("#cliEndereco").val(data.endereco);
                        }
                    });
                    showLoader(false);
                },
                error: () => {
                    showLoader(false);
                    swal($_CONFIG.language.mensagens.falha_consulta, $_CONFIG.language.mensagens.falha_cep, "error");
                }
            });
        }
    }

    var buscaCEPCliente2 = (cep) => {
        mCep = cep;
        if (cep && cep.length >= parseInt($_CONFIG.language.mascaras.max_cep)) {
            cep = cep.replace("-", "");
            showLoader(true);
            var pais = $_CONFIG.language.mascaras.lang;
            $.ajax({
                dataType: "json",
                method: 'POST',
                url: '/pages/cadastros/buscaPostalCode.php',
                data: {
                    code: cep,
                    pais: pais
                },
                success: (data) => {
                    var estado = "";
                    if (pais == "pt") {
                        estado = $("#" + data.estado.replace(" ", "").toLowerCase() + "").val();
                    } else {
                        estado = $("#" + data.estado + "").val();
                    }
                    $("#cliEstado2").val(estado);
                    $("#cliCidade2").empty();

                    $.ajax({
                        dataType: "json",
                        url: '/pages/cadastros/buscaCidadesWizard.php',
                        method: "POST",
                        data: {
                            estCodigo: estado,
                            cidNome: data.cidade
                        },
                        success: (result) => {
                            $("#cliCidade2").append(result.cidades);
                            $("#cliCidade2").attr("disabled", false);
                            setTimeout(() => {
                                $("#cliCidade2").val(result.cidcodigo);
                            }, 10);
                            showLoader(false);
                            $("#cliBairro2").val(data.bairro);
                            $("#cliEndereco2").val(data.endereco);
                        }
                    });
                    showLoader(false);
                },
                error: () => {
                    showLoader(false);
                    swal($_CONFIG.language.mensagens.falha_consulta, $_CONFIG.language.mensagens.falha_cep, "error");
                }
            });
        }
    }

    $('#formCadastro').submit((event) => {

        if (($("#cliLoginIdAg").val() != "") && ($("#cliEmail").val() == "")) {
            swal("Insira um E-mail", "Por favor, insira um e-mail para o cliente receber os dados de acesso.", "error");
            return true;
        } else {

            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if (($("#cliEnderecoEletronico").val() != '') && ($("#cliEnderecoEletronico").val().match(mailformat) == null)) {
                swal("Insira um e-mail válido", "O email informado não é valido.", "error");
                return true;
            } else {

                event.preventDefault();
                formCadastro = $(event.currentTarget);
                showLoader(true);
                dataInsere = new FormData(event.currentTarget);
                dataInsere.append("apelido", $("#cliApelido").html());
                dataInsere.append("cliEmail", $("#cliEnderecoEletronico").val());

                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereClientes.php",
                    data: dataInsere,
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: (result) => {

                        if (result.insereCliente[0].erro == "0") {
                            toastr.success(result.insereCliente[0].resultado);
                            cliNome = $("#cliNome").val();
                            cliCelular = $("#cliCelular").val();
                            clientesNomes.push(cliNome + " | " + cliCelular);

                            clientesIds[cliNome + " | " + cliCelular] = result.insereCliente[0].pescodigo;

                            $('#cadastrarcliente-modal').modal("hide");

                            if (clientesNomes.length > 1500) {
                                $("#cliente_menu").append('<option data-usucodigo="" data-imagem="" data-celular="' + cliCelular + '" value="' + result.insereCliente[0].pescodigo + '">' + cliNome + ' - ' + cliCelular + '</option>');
                                $("#cliente_menu2").append('<option data-usucodigo="" data-imagem="" data-celular="' + cliCelular + '" value="' + result.insereCliente[0].pescodigo + '">' + cliNome + ' - ' + cliCelular + '</option>');
                                $("#cliente_menu").val(result.insereCliente[0].pescodigo).trigger('change');
                                $("#cliente_menu2").val(result.insereCliente[0].pescodigo).trigger('change');

                                var clientes = new Bloodhound({
                                    datumTokenizer: Bloodhound.tokenizers.whitespace,
                                    queryTokenizer: Bloodhound.tokenizers.whitespace,
                                    local: clientesNomes
                                });

                                $('.typeahead').typeahead('destroy');
                                $('#the-basics .typeahead').typeahead(null, {
                                    limit: 20,
                                    source: clientes
                                }).on('typeahead:selected', (e) => {
                                    var arrNome = e.currentTarget.value.split(' | ');
                                    nomeSelecionado = arrNome[0];
                                    idSelecionado = clientesIds[e.currentTarget.value];
                                });
                            } else {
                                $scope.buscaClientes(result.insereCliente[0].pescodigo);
                            }
                            formCadastro.each((_, el) => {
                                el.reset();
                            });
                            $("#cliLoginIdAg").val("");
                        } else {
                            swal(result.insereCliente[0].resultado, "", "error");
                        }
                        showLoader(false);
                    },
                    error: () => {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    }
                });
                return true;
            }
        }
    });

    $('#confirmarAssociar').click(() => {
        if (typeof(idSelecionado) != "undefined") {
            if (idSelecionado != "") {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    url: "/pages/actions/atualizaHorario.php",
                    method: "POST",
                    data: {
                        agendamento: $("#lblIDAgendamento").html(),
                        tipo: 3,
                        cliente: idSelecionado
                    },
                    success: (data) => {
                        if (data.result[0].erro == 1) {
                            swal(data.result[0].resultado, "", "error");
                        } else {
                            toastr.success(data.result[0].resultado);
                            $("#cpfnf").hide()
                            $("#lblUsuario").html(nomeSelecionado);
                            $("#btnAssociaCliente").click();
                            $('.typeahead').typeahead('val', '');
                            $("#lblPesCodigo").html(idSelecionado);

                            $scope.atualizaEventos();
                            $("#listaTagsClientes").html("");

                            $.ajax({
                                dataType: "json",
                                url: "/pages/cadastros/buscaClienteTag.php",
                                type: 'GET',
                                data: {
                                    pescodigo: idSelecionado,
                                },
                                success: (data) => {
                                    if (data.data.length > 0) {
                                        var tagClientecontent = "";
                                        for (var i = 0; i < data.data.length; i++) {

                                            tagClientecontent = tagClientecontent + `<label class="label"  style="background-color:${data.data[i].CTa_Cor}">${data.data[i].CTa_Descricao}</label> &nbsp`
                                        }
                                        $("#listaTagsClientes").html(tagClientecontent)
                                        $compile($('#listaTagsClientes'))($scope);
                                    }
                                }
                            });
                            idSelecionado = "";
                            nomeSelecionado = "";
                        }
                        showLoader(false);
                    },
                    error: (result) => {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    }
                });
            } else {
                swal("Selecione um Cliente.", "", "error");
            }
        } else {
            swal("Selecione um Cliente.", "", "error");
        }
        return true;
    });

    function atualizaDados() {
        $('[data-toggle="popover"]').popover("hide");
        tabelaRodizio.api().ajax.reload(() => {
            $('[data-toggle="popover"]').popover({
                container: 'body'
            });
        });
    }

    $scope.atualizaCalendario();
    $scope.initAgenda = false;

    $('#formAgendamentoRecorrente').submit((event) => {
        event.preventDefault();
        formRecorrente = $(event.currentTarget);
        showLoader(true);
        $("#btnAgendarRecorrente").attr("disabled", true);
        $("#btnAgendarRecorrente").html('<i class="fa fa-spinner fa-pulse"></i> Cadastrando...');
        dataRecorrente = new FormData(event.currentTarget);
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/insereAgendamentoRecorrentev2.php",
            data: {
                pescodigocliente: $("#cliente_menu2").val(),
                pescodigoprofissional: $("#profissionalRecorrencia2").val(),
                sercodigo: $("#servico_menuRecorrente").val(),
                periodicidade: $("#recorrenciaPeriodicidade").val(),
                qtdAgendamento: $("#recorrenciaQtd").val(),
                dataAgendamento: $("#dataAgendamentoRecorrente2").val(),
                horaAgendamento: $("#horaAgendamentoRecorrente").val(),
                duracao: $("#duracaoAgendamentoRecorrente").val()
            },
            dataType: "json",
            /*processData: false,
            contentType: false,*/
            success: (result) => {
                var resultado = '<div style="max-height:200px;overflow-y:scroll">';
                for (var i = 0; i < result.data.length; i++) {
                    if (result.data[i].erro == 0) {
                        resultado += '<span style="color:green;"><i class="fa fa-check"></i>&nbsp' + result.data[i].resultado + '</span><br>'
                    } else {
                        resultado += '<span style="color:red;"><i class="fa fa-times"></i>&nbsp' + result.data[i].resultado + '</span><br>'
                    }
                }
                resultado += '</div>'
                swal({
                    title: "<small>Resultado</small>",
                    text: resultado,
                    html: true
                });
                $("#agendaHorario-modal").modal("hide");

                formRecorrente.each((_, el) => {
                    el.reset();
                });
                $scope.isAgendamentoAntigo(2);
                $("#cliente_menu2").val("").trigger('change');
                showLoader(false);
                $("#btnAgendarRecorrente").removeAttr("disabled");
            },
            error: () => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
                $("#btnAgendarRecorrente").removeAttr("disabled");
            }
        });
        return true;
    });

    $scope.editarAgendamento = () => {
        $("#horaAlteraAgendamento").val("");
        $("#editarAgendamento-modal").modal();
        $("#tipoAlteraAgendamento").val(0);
        $("#tipoAlteraAgendamento").change();
        $scope.hideDivsAltera();
        $scope.buscaServicoAlteraAgedamento($("#lblProfissional").html());
        $scope.buscaProfissionalAlteraAgedamento();
    }

    $scope.buscaServicoAlteraAgedamento = function(codigoProfissional) {
        $.ajax({
            method: "GET",
            dataType: "json",
            url: "/pages/actions/buscaServicos.php",
            method: "POST",
            data: {
                tipo: '2',
                profissional: codigoProfissional
            },
            success: (data) => {
                $("#servicoAlteraAgendamento").html('<option value="">Selecione um Serviço</option>');
                for (var i = 0; i < data.servicos.length; i++) {
                    $("#servicoAlteraAgendamento").append('<option value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>');
                };
            }
        });
    }

    $scope.buscaProfissionalAlteraAgedamento = function() {
        $.ajax({
            method: "POST",
            dataType: "json",
            url: "/pages/cadastros/buscaProfissionalSelect.php",
            success: (data) => {
                $("#profissionalAlteraAgendamento").html('<option value="">Selecione um Profissional</option>');
                for (var i = 0; i < data.profissionais.length; i++) {
                    $("#profissionalAlteraAgendamento").append('<option value="' + data.profissionais[i].Pes_Codigo + '">' + data.profissionais[i].Pes_Nome + '</option>');
                };
            }
        });
    }

    $("#profisisonalHorDisp").change(function() {
        if ($("#profisisonalHorDisp").val() != '') {
            $scope.buscaServicoProfissionalDisponivel();
        } else {
            $("#servicoHorDisp").html('<option value="">Selecione um Profissional</option>');
        }
    })

    $scope.buscaServicoProfissionalDisponivel = function() {
        $.ajax({
            method: "POST",
            dataType: "json",
            url: "/pages/cadastros/buscaServicoProfissionalSelect.php",
            data: {
                profissional: $("#profisisonalHorDisp").val()
            },
            success: function(data) {
                $("#servicoHorDisp").html('<option value="">Selecione um Serviço</option>');
                for (var i = 0; i < data.servicos.length; i++) {
                    $("#servicoHorDisp").append('<option value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>');
                };
            }
        });

    }

    $scope.hideDivsAltera = function() {
        $("#divAlteraAgendamentoData").hide();
        $("#divAlteraAgendamentoServico").hide();
        $("#divAlteraAgendamentoProfissional").hide();
        $("#divAlteraAgendamentoDuracao").hide();
    }

    $scope.showDivsAltera = function() {
        $scope.hideDivsAltera();
        $scope.buscaProfissionalAlteraAgedamento();

        if ($("#tipoAlteraAgendamento option:selected").val() == 1) {
            $("#divAlteraAgendamentoData ").show();
        } else if ($("#tipoAlteraAgendamento option:selected").val() == 2) {
            $("#divAlteraAgendamentoServico").show();
        } else if ($("#tipoAlteraAgendamento option:selected").val() == 3) {
            $("#divAlteraAgendamentoProfissional").show();
            //$scope.buscaProfissionalServicoAlteraAgedamento();
        } else if ($("#tipoAlteraAgendamento option:selected").val() == 4) {
            $("#divAlteraAgendamentoData").show();
            $("#divAlteraAgendamentoProfissional").show();
            //$scope.buscaProfissionalServicoAlteraAgedamento();
        } else if ($("#tipoAlteraAgendamento option:selected").val() == 5) {
            $("#divAlteraAgendamentoData").show();
            $("#divAlteraAgendamentoServico").show();
        } else if ($("#tipoAlteraAgendamento option:selected").val() == 6) {
            $("#divAlteraAgendamentoServico").show();
            $("#divAlteraAgendamentoProfissional").show();
        } else if ($("#tipoAlteraAgendamento option:selected").val() == 7) {
            $("#divAlteraAgendamentoData").show();
            $("#divAlteraAgendamentoServico").show();
            $("#divAlteraAgendamentoProfissional").show();
        } else if ($("#tipoAlteraAgendamento option:selected").val() == 8) {
            $("#divAlteraAgendamentoDuracao").show();
            $scope.comboTempoPadrao();
        } else {
            $scope.hideDivsAltera();
        }
    }

    $scope.comboTempoPadrao = function() {
        var combotempo = "";
        for (var i = 1; i < 15; i++) {
            combotempo += "<option value=" + $_CONFIG.TEMPOPADRAO * i + ">" + $_CONFIG.TEMPOPADRAO * i + " Minutos</option>"
        }
        $("#DuracaoAlteraAgendamento").html(combotempo);
        $("#DuracaoAlteraAgendamentoLista").html(combotempo);
    }

    $("#tipoAlteraAgendamento").change(function() {
        $scope.showDivsAltera();
    });

    $("#profissionalAlteraAgendamento").change(function() {
        $scope.buscaServicoAlteraAgedamento($("#profissionalAlteraAgendamento option:selected").val());
    });

    $("#cliEmail").keyup(function() {
        $("#cliLoginIdAg").val($("#cliEmail").val());
    })

    $scope.alteraAgendamentoDrag = function(data, inicio, codigoItem, pescodigo, returnFunc) {

        showLoader(true);
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/alteraAgendamento.php",
            data: {
                dataAlteraAgendamento: data,
                horaAlteraAgendamento: inicio,
                tipoAlteraAgendamento: "4",
                codItem: codigoItem,
                profissionalAlteraAgendamento: pescodigo
            },
            dataType: "json",
            success: function(result) {

                if (result.result[0].erro == "0") {
                    $scope.isAgendamentoAntigo(2);
                    toastr.success(result.result[0].resultado);

                } else {
                    toastr.error(result.result[0].resultado);
                    returnFunc();
                }
                showLoader(false);
            },
            error: function(result) {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
    }

    $scope.alteraAgendamentoResize = function(data, duracao, codigoItem, pescodigo, returnFunc) {

        showLoader(true);
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/alteraAgendamento.php",
            data: {
                dataAlteraAgendamento: data,
                DuracaoAlteraAgendamento: duracao,
                tipoAlteraAgendamento: "8",
                codItem: codigoItem,
                profissionalAlteraAgendamento: ""
            },
            dataType: "json",
            success: function(result) {

                if (result.result[0].erro == "0") {
                    $scope.isAgendamentoAntigo(2);
                    toastr.success(result.result[0].resultado);
                } else {
                    toastr.error(result.result[0].resultado);
                    returnFunc();
                }
                showLoader(false);
            },
            error: function(result) {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
    }

    $('#formAlteraAgendamento').submit((event) => {
        event.preventDefault();
        formAlteraAgendamento = $(event.currentTarget);
        showLoader(true);
        dataAltera = new FormData(event.currentTarget);
        dataAltera.append("codItem", $("#lblCItCodigo").html());
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/alteraAgendamento.php",
            data: dataAltera,
            dataType: "json",
            processData: false,
            contentType: false,
            success: (result) => {
                if (result.result[0].erro == "0") {
                    $('#editarAgendamento-modal').modal("hide");
                    $("#infohorario-modal").modal("hide");
                    $scope.isAgendamentoAntigo(2);
                    toastr.success(result.result[0].resultado);
                } else {
                    swal(result.result[0].resultado, "", "error");
                }
                showLoader(false);
            },
            error: () => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
        return true;
    });

    $("#formInsereServicoEncaixe").submit((event) => {
        event.preventDefault();
        $("#btnSalvaEncaixeAgenda").attr('disabled', true);
        showLoader(true);

        $.ajax({
            dataType: "json",
            type: "POST",
            url: "/pages/cadastros/insereAgendamentoEncaixev3.php",
            data: {
                item: $("#insertServicoEncaixe").val(),
                tipoitem: $("#insertServicoEncaixe option:selected").get(0).dataset.tipoitem,
                profissional: $("#comInsertProfissionalEncaixe").val(),
                cliente: $("#insertClienteEncaixe").val(),
                ageorigem: 2,
                observacao: '',
                comcodigo: '',
                dia: $("#comDataIniEncaixe").val(),
                hora: $("#comHoraIniEncaixe").val()
            },
            success: (data) => {
                if (data.data[0].erro == "0") {
                    toastr.success(data.data[0].resultado);
                    $("#insertServicoEncaixe-modal").modal("hide");
                    $scope.isAgendamentoAntigo(2);

                    $("#btnSalvaEncaixeAgenda").attr('disabled', false);
                } else {
                    swal(data.data[0].resultado, "", "error");
                    $("#btnSalvaEncaixeAgenda").attr('disabled', false);
                }
                showLoader(false);
                $("#comValorInsert").attr("disabled", true);
            },
            error: () => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
                $("#btnSalvaEncaixeAgenda").attr('disabled', false);
            }
        });
        /*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
        //formInsereEncaixe = $(event.currentTarget);
        //dataInsere = new FormData(event.currentTarget);
        //dataInicio = formataData($("#comDataIniEncaixe").val())
        //dataInsere.append('dataInicio', dataInicio);
        // $.ajax({
        // 	type: "POST",
        // 	url: "/pages/cadastros/insereServicoEncaixe.php",
        // 	data: dataInsere,
        // 	dataType: "json",
        // 	processData: false,
        // 	contentType: false,
        // 	success: (result) => {
        // 		if (result.result[0].erro == "0") {
        // 			toastr.success(result.result[0].resultado);
        // 			$("#insertServicoEncaixe-modal").modal("hide");
        // 			$scope.isAgendamentoAntigo(2);
        // 			formInsereEncaixe.each((_, el) => {
        // 				el.reset();
        // 			});
        // 			$("#btnSalvaEncaixeAgenda").attr('disabled', false);
        // 		} else {
        // 			swal(result.result[0].resultado, "", "error");
        // 			$("#btnSalvaEncaixeAgenda").attr('disabled', false);
        // 		}
        // 		showLoader(false);
        // 		$("#comValorInsert").attr("disabled", true);
        // 	},
        // 	error: () => {
        // 		swal("Falha na conexão.", "", "error");
        // 		showLoader(false);
        // 		$("#btnSalvaEncaixeAgenda").attr('disabled', false);
        // 	}
        // });
        return true;
    });

    $scope.buscaProfissionalServicoAlteraAgedamento = function() {
        $.ajax({
            method: "POST",
            dataType: "json",
            url: "/pages/cadastros/buscaProfissionalSelect.php",
            data: {
                sercodigo: $("#lblSerCodigo").html()
            },
            success: (data) => {
                $("#profissionalAlteraAgendamento").html('<option value="">Selecione um Profissional</option>');
                for (var i = 0; i < data.profissionais.length; i++) {
                    $("#profissionalAlteraAgendamento").append('<option value="' + data.profissionais[i].Pes_Codigo + '">' + data.profissionais[i].Pes_Nome + '</option>');
                };
            }
        });
    }

    $scope.buscaAgendamentoTipoPagamento = function(codigocomanda) {

        $.ajax({
            dataType: "json",
            url: "/pages/actions/buscaAgendamentoTipoPagamento.php",
            type: 'POST',
            data: {
                comanda: codigocomanda
            },
            success: (data) => {
                $("#AgendamentoPagamento").html('<b>' + data.result[0].Pagamento + '</b>')
                $("#comandaBotaoValor").html('<b>' + $_CONFIG.MOEDA + data.result[0].ValorComanda + '</b>')
            }
        });
    }

    $scope.buscaNumeroRecorrente = function() {
        var numeroAgendamento = "";
        $("#recorrenciaQtd").html(numeroAgendamento);
        if ($("#recorrenciaPeriodicidade").val() == 7) {
            for (var i = 1; i <= 52; i++) {
                numeroAgendamento += "<option value='" + i + "'>" + i + "</option>";
            }
        } else if (($("#recorrenciaPeriodicidade").val() == 15) || ($("#recorrenciaPeriodicidade").val() == 21)) {
            for (var i = 1; i <= 25; i++) {
                numeroAgendamento += "<option value='" + i + "'>" + i + "</option>";
            }
        } else if ($("#recorrenciaPeriodicidade").val() == 30) {
            for (var i = 1; i <= 12; i++) {
                numeroAgendamento += "<option value='" + i + "'>" + i + "</option>";
            }
        } else {
            for (var i = 1; i <= 10; i++) {
                numeroAgendamento += "<option value='" + i + "'>" + i + "</option>";
            }
        }

        $("#recorrenciaQtd").html(numeroAgendamento);
    }

    $("#recorrenciaPeriodicidade").change(() => {
        $scope.buscaNumeroRecorrente();
    });

    $scope.buscaNumeroRecorrente();

    $scope.mudaTelaRecorrente = function(tipo) {
        if (tipo == 1) {
            $("#divHoraRecorrente").show();
            $("#divDataRecorrente").show();
            $("#divProfissionalRecorrente").removeClass("col-lg-12 col-xs-12");
            $("#divProfissionalRecorrente").addClass("col-lg-5 col-xs-6");
            $("#QtdPeriodicidadeRecorrente").show();
            $("#datasCancelaRecorrente").hide();
            $("#btnCancelarRecorrente").hide();
            $("#btnAgendarRecorrente").show();
        } else if (tipo == 2) {
            $("#divHoraRecorrente").hide();
            $("#divDataRecorrente").hide();
            $("#divProfissionalRecorrente").removeClass("col-lg-5 col-xs-6");
            $("#divProfissionalRecorrente").addClass("col-lg-12 col-xs-12");
            $("#QtdPeriodicidadeRecorrente").hide();
            $("#datasCancelaRecorrente").show();
            $("#btnCancelarRecorrente").show();
            $("#btnAgendarRecorrente").hide();
        }
    }
    $("#tipoRecorrencia").change(() => {
        if ($("#tipoRecorrencia").val() == 1) {
            $scope.mudaTelaRecorrente(1);
        } else {
            $scope.mudaTelaRecorrente(2);
        }
    });
    $("#tipoRecorrencia").change();

    $scope.cancelaRecorrente = function() {

        if ($("#servico_menuRecorrente").val() == '') {
            toastr.error("Informe o Serviço");
        } else if ($("#cliente_menu2").val() == "") {
            toastr.error("Informe o Cliente");
        } else if ($("#dataIniCancelaRecorrente").val() == "") {
            toastr.error("Informe a Data Inicial");
        } else if ($("#dataFimCancelaRecorrente").val() == "") {
            toastr.error("Informe a Data Final");
        } else {
            showLoader(true);
            $.ajax({
                method: "POST",
                dataType: "json",
                url: "/pages/cadastros/cancelaAgendamentoRecorrente.php",
                data: {
                    servico: $("#servico_menuRecorrente").val(),
                    profissional: $("#profissionalRecorrencia").val(),
                    cliente: $("#cliente_menu2").val(),
                    dataini: $("#dataIniCancelaRecorrente").val(),
                    datafim: $("#dataFimCancelaRecorrente").val(),

                },
                success: (data) => {
                    if (data.data[0].erro == "0") {
                        $("#agendaHorario-modal").modal("hide");
                        $("#cliente_menu2").val("");
                        $("#servico_menuRecorrente").val("");
                        $('.date.dataIniCancelaRecorrente').datepicker('update', datainirec);
                        $('.date.dataFimCancelaRecorrente').datepicker('update', datafimrec);
                        swal(data.data[0].resultado, "", "success");
                        showLoader(false);

                    } else {
                        swal(data.data[0].resultado, "", "error");
                        showLoader(false);
                    }

                },
                error: () => {
                    swal("Falha na conexão.", "", "error");
                    showLoader(false);
                }
            });
        }
    }

    if ($_CONFIG.LISTA_PAIS.length > 0) {
        var html = "<option value=''></option>";
        for (var i = 0; i < $_CONFIG.LISTA_PAIS.length; i++) {

            html += "<option id='" + $_CONFIG.LISTA_PAIS[i].Pai_Sigla + "' value='" + $_CONFIG.LISTA_PAIS[i].Pai_Codigo + "'> " + $_CONFIG.LISTA_PAIS[i].Pai_Nome + "</option>";

        }
        $("#cliPaisAgendaEdt").html(html);
        $("#cliPaisNovoCadastro").html(html);
        $("#cliPaisNovoCadastro").val($_CONFIG.PAIS);
    } else {
        $.ajax({
            dataType: "json",
            url: '/pages/cadastros/buscaPais.php',
            method: "POST",
            success: function(data) {
                var html = "";
                var sigla = ($_CONFIG.language.mascaras.lang).toUpperCase()
                for (var i = 0; i < data.result.length; i++) {
                    if (sigla == data.result[i].Pai_Sigla) {
                        html += '<option selected value="' + data.result[i].Pai_Codigo + '" data-sigla="' + data.result[i].Pai_Sigla + '">' + data.result[i].Pai_Nome + '</option>';
                    } else {
                        html += '<option value="' + data.result[i].Pai_Codigo + '" data-sigla="' + data.result[i].Pai_Sigla + '">' + data.result[i].Pai_Nome + '</option>';
                    }
                }
                $("#cliPaisAgendaEdt").html(html);
                $("#cliPaisNovoCadastro").html(html);
                $("#cliPaisNovoCadastro").val($_CONFIG.PAIS);
            }
        });
    }

    function buscaEstados(pais) {
        /*if ($_CONFIG.LISTA_ESTADO.length > 0) {
        	var html = "<option value=''></option>";
        	for (var i = 0; i < $_CONFIG.LISTA_ESTADO.length; i++) {
        		if (pais != "pt") {
        			html += "<option id='" + $_CONFIG.LISTA_ESTADO[i].Est_Sigla + "' value='" + $_CONFIG.LISTA_ESTADO[i].Est_Codigo + "'> " + $_CONFIG.LISTA_ESTADO[i].Est_Nome + "</option>";
        		} else {
        			html += "<option id='" + $_CONFIG.LISTA_ESTADO[i].Est_Nome.replace(" ", "").toLowerCase() + "' value='" + $_CONFIG.LISTA_ESTADO[i].Est_Codigo + "'> " + $_CONFIG.LISTA_ESTADO[i].Est_Nome + "</option>";
        		}
        	}
        	$("#cliEstadoEdtAgenda").html(html);
        }else{*/
        $.ajax({
            dataType: "json",
            url: '/pages/cadastros/buscaEstadoPais.php',
            method: "POST",
            data: {
                paicodigo: pais
            },
            success: function(data) {
                if (data.result.length > 0) {
                    var html = "<option value=''></option>";
                    for (var i = 0; i < data.result.length; i++) {
                        if (pais != "2") {
                            html += "<option id='" + data.result[i].Est_Sigla + "' value='" + data.result[i].Est_Codigo + "'> " + data.result[i].Est_Nome + "</option>";
                        } else {
                            html += "<option id='" + data.result[i].Est_Nome.replace(" ", "").toLowerCase() + "' value='" + data.result[i].Est_Codigo + "'> " + data.result[i].Est_Nome + "</option>";
                        }
                    }
                    $("#cliEstadoEdtAgenda").html(html);
                    $("#cliEstado").html(html);
                }
            }
        });
        /*}*/
    }

    $("#cliPaisAgendaEdt").change(function() {
        buscaEstados(this.value)
    })

    $("#cliPaisNovoCadastro").change(function() {
        buscaEstados(this.value)
    })

    $("#cliCepEdtAgenda").keyup((e, el) => {
        buscaCEPClienteEdt(e.currentTarget.value);
    });

    function buscaCEPClienteEdt(cep) {
        mCep = cep;

        if (cep && cep.length >= parseInt($_CONFIG.language.mascaras.max_cep)) {
            cep = cep.replace("-", "");
            showLoader(true);
            var pais = $_CONFIG.language.mascaras.lang;
            $.ajax({
                dataType: "json",
                method: 'POST',
                url: '/pages/cadastros/buscaPostalCode.php',
                data: {
                    code: cep,
                    pais: pais
                },
                success: function(data) {
                    var estado = "";
                    if (pais == "pt") {
                        estado = $("#" + data.estado.replace(" ", "").toLowerCase() + "").val();
                    } else {
                        estado = $("#" + data.estado + "").val();
                    }
                    $("#cliEstadoEdtAgenda").val(estado);
                    $("#cliCidadeEdAgendat").empty();

                    $.ajax({
                        dataType: "json",
                        url: '/pages/cadastros/buscaCidadesWizard.php',
                        method: "POST",
                        data: {
                            estCodigo: estado,
                            cidNome: data.cidade
                        },
                        success: function(result) {
                            $("#cliCidadeEdtAgenda").append(result.cidades);
                            $("#cliCidadeEdtAgenda").attr("disabled", false);
                            setTimeout(function() {
                                $("#cliCidadeEdtAgenda").val(result.cidcodigo);
                            }, 10);
                            showLoader(false);
                            $("#cliBairroEdtAgenda").val(data.bairro);
                            $("#cliEnderecoEdtAgenda").val(data.endereco);
                        }
                    });
                    showLoader(false);
                },
                error: function() {
                    showLoader(false);
                    toastr.error($_CONFIG.language.mensagens.falha_cep, $_CONFIG.language.mensagens.falha_consulta);
                }
            });
        }
    }

    $scope.editaClienteAgenda = function() {

        $.ajax({
            method: "POST",
            dataType: "json",
            url: "/pages/cadastros/buscaClienteAlteraAgenda.php",
            data: {
                cliente: $("#lblPesCodigo").html(),
            },
            success: function(data) {
                $('#cliSenhaAgenda').val("")
                $('#cliNomeEdtAgenda').val(data.result[0].Pes_Nome);
                $('#cliCpfEdtAgenda').val(data.result[0].Paf_Cpf);
                $('#cliEmailEdtAgenda').val(data.result[0].Paf_Email);
                $("#cliEmailEdtAgenda").change()
                $('#cliCelularEdtAgenda').val(data.result[0].Paf_Celular);
                $('#cliTelefoneEdtAgenda').val(data.result[0].Paf_Telefone);
                $('#cliEnderecoEdtAgenda').val(data.result[0].Paf_Endereco)
                $('#cliSexoEdtAgenda').val(data.result[0].Paf_Sexo);
                $('#cliDataNascimentoEdtAgenda').val(data.result[0].PAF_Dat_Nascimento);
                $('#usucodigoalteracao').val(data.result[0].Usu_Codigo);
                if (data.result[0].Usu_Codigo == "") {
                    $("#possuiusu").hide()
                    $("#npossuiusu").show()
                } else {
                    $("#npossuiusu").hide()
                    $("#possuiusu").show()

                }
                $('#cliEstadoEdtAgenda').val(data.result[0].Est_Sigla);
                $('#cliCepEdtAgenda').val(data.result[0].Paf_CEP);
                $('#cliCodigoEdtAgenda').val(data.result[0].Pes_Codigo);
                if (data.result[0].Pai_Codigo != '') {
                    $("#cliPaisAgendaEdt").val(data.result[0].Pai_Codigo).change()
                    setTimeout(function() {
                        $('#cliEstadoEdtAgenda').val(data.result[0].Est_Codigo).change();
                        setTimeout(function() {
                            $('#cliCidadeEdtAgenda').val(data.result[0].Cid_Codigo).change();
                        }, 1000)
                    }, 1000)
                }

                $('#pesCodigoAltAgenda').val(data.result[0].Pes_Codigo);
                $('#cliObservacaoEdtAgenda').val(data.result[0].Paf_Observacao);
                $('#cliNumeroEdtAgenda').val(data.result[0].Paf_Numero);
                $('#cliComplementoEdtAgenda').val(data.result[0].Paf_Complemento);
                $('#cliBairroEdtAgenda').val(data.result[0].Paf_Bairro);
                $('#cliOndeAgenda').val(data.result[0].PAF_Com_Soube);
                $('#cliOndeEdt').val(data.result[0].PAF_Com_Soube);
                $('#cliRGEdtAgenda').val(data.result[0].Paf_RG);
                $scope.geraComboPaisTelefone('cliCelularEdtAgenda', 'cliDialCodeEdtAgenda', data.result[0].DDI)
                /*$.ajax({
                	dataType: "html",
                	url: '/pages/cadastros/buscaCidades.php',
                	method: "POST",
                	data: {
                		estCodigo: data.result[0].Est_Codigo
                	},
                	success: function (result) {
                		$("#cliCidadeEdtAgenda").append(result);
                		$("#cliCidadeEdtAgenda").attr("disabled", false);
                		$('#cliCidadeEdtAgenda').val(data.result[0].Cid_Codigo);
                	}
                });*/

            },
            error: function(result) {}
        });
        $('[data-toggle="popover"]').popover({
            container: 'body'
        });
        $("#editarClienteAgenda-modal").modal();
    }
    $('#cliFotoEdtAgenda').fileinput({
        maxFilesNum: 1,
        showPreview: false,
        browseLabel: $_CONFIG.language.btn_procurar,
        removeLabel: $_CONFIG.language.btn_remover,
        browseIcon: '',
        allowedFileExtensions: ["jpg", "png"],
        showUpload: false
    });
    $translate('mascaras.celular')
        .then(function(value) {
            if (value != '') {
                $('#cliCelular').mask(value);
                $('#cliCelularEdtAgenda').mask(value);
            }
        });

    $translate('mascaras.telefone')
        .then(function(value) {
            if (value != '') {
                $('#cliTelefone').mask(value);
                $('#cliTelefoneEdtAgenda').mask(value);
            }
        });



    $scope.insereServicoEncaixe = function() {
        $('#formInsereServicoEncaixe').each((_, el) => {
            el.reset();
        });

        if (curTimeZone.getMinutes() < 10) {
            var hora = curTimeZone.getHours() + '0' + curTimeZone.getMinutes();
        } else {
            var hora = curTimeZone.getHours() + '' + curTimeZone.getMinutes();
        }
        $('.divDataServicoEncaixe').datepicker('update', curTimeZone);
        var horas = new Array();
        for (var i = 0; i < $('#comHoraIniEncaixe option').length; i++) {
            horas.push($('#comHoraIniEncaixe option')[i].value.replace(':', ''))
        }

        $('#comHoraIniEncaixe').select2();
        $('#comHoraIniEncaixe').select2('val', '');
        var hour = getproxhora(horas, hora);
        $('#comHoraIniEncaixe').val(hour.toString().splice(2, 0, ':'))
        $('#comHoraIniEncaixe').change();

        $.ajax({
            dataType: 'json',
            url: '/pages/cadastros/buscaServicoSelectCombo.php',
            success: (result) => {
                var combo = '';
                $('#insertServicoEncaixe').html('<option value =""  data-valor="" data-tipopreco="">Selecione um Serviço</option>');
                for (var i = 0; i < result.servicos.length; i++) {

                    combo += '<option value =' + result.servicos[i].Ser_Codigo + ' data-valor="' + result.servicos[i].Ser_Valor + '" data-tipopreco="' + result.servicos[i].Ser_Tip_Preco + '" name="' + result.servicos[i].Ser_Duplo + '" data-tipoitem="' + result.servicos[i].TipoItem + '">' + result.servicos[i].Ser_Descricao + '</option>';
                }
                $('#insertServicoEncaixe').append(combo);
                $('#insertServicoEncaixe').select2({
                    templateResult: thumbServico
                });
                $('#insertServicoEncaixe').select2('val', '');

                $('#insertServicoEncaixe').change((e) => {
                    setTimeout(() => {
                        if (e.currentTarget.value != '' && $('#comInsertProfissionalEncaixe').val() != '') {
                            if ($('#insertServicoEncaixe option:selected').get(0).dataset.tipoitem == '1') {
                                buscaAssocProfissionalServico($('#insertServicoEncaixe').val(), $('#comInsertProfissionalEncaixe').val());
                            }
                        }
                    }, 300);
                });
            }
        });

        var dataatual = moment().locale('pt-br').format('L');

        $('#comInsertProfissional').select2('val', '');
        //$('.divDataServicoEncaixe').datepicker('update', dataatual);

        $('#insertServicoEncaixe-modal').modal('show');
    }

    $scope.mostraComanda = function() {
        $scope.buscaItensComandaVer($('#comandaBotao').html());
        $('#vercomanda-modal').modal('show');
        $('#nomeClienteComandaVer').html($('#lblUsuario').html());
        $('#idComandaVer').html($('#comandaBotao').html());
    }
    $scope.mostraComandaAberta = function() {
        $('#btnRealizadoAg').click();
    }
    $scope.infoClientes = function(tipo) {
        $scope.mostraInfoClientes($('#lblPesCodigo').html())
    }

    $scope.buscaClientes('');

    $("#formAlteraAgendamentoObs").submit((e) => {
        e.preventDefault();
        var agendamentoID = $("#idAgendamentoAlteraObs").val();
        var obs = $('#ageAlteraObs').val();
        showLoader(true);
        $.ajax({
            dataType: 'json',
            url: "/pages/actions/atualizaHorario.php",
            method: "POST",
            data: {
                agendamento: agendamentoID,
                tipo: '2',
                observacao: obs
            },
            success: (data) => {
                if (data.result[0].erro == 1) {
                    swal(data.result[0].resultado, '', 'error');
                } else {
                    toastr.success('Observação atualizada com sucesso.');
                    $scope.isAgendamentoAntigo(2);
                }
                showLoader(false);
            },
            error: () => {
                swal('Falha na conexão.', '', 'error');
                showLoader(false);
            }
        });
    })

    $scope.buscaHorariosDisponives = function() {
        $("#divTabelaHorDisp").hide()
        $('#buscaHorariosDisponivel-modal').modal()
    }

    $scope.listaProfissional = '';
    $('#formBuscaHorariosDisponiveis').submit((e) => {
        e.preventDefault();
        showLoader(true);

        if ($("#profisisonalHorDisp").val() == "") {
            toastr.error("Informe o Profissional");
        } else if ($("#servicoHorDisp").val() == "") {
            toastr.error("Informe o Serviço");
        } else if (($("#dataIniHorarioDisp").val() == "") || ($("#dataFimHorarioDisp").val() == "")) {
            toastr.error("Informe um Período válido");
        } else {
            $("#divTabelaHorDisp").show()
            if (typeof(tbhordisp) != "undefined") {
                tbhordisp.destroy();
                $('#tabelaHorDisp tbody').unbind('click')
            }
            tbhordisp = $('#tabelaHorDisp').DataTable({
                "dom": 'T<"clear">lfrtip',
                "ajax": {
                    "url": "/pages/cadastros/relatorioHorarioDisponivel.php",
                    "method": "POST",
                    "data": (d) => {
                        d.profissional = $("#profisisonalHorDisp").val();
                        d.servico = $("#servicoHorDisp").val();
                        d.dataini = $("#dataIniHorarioDisp").val();
                        d.datafim = $("#dataFimHorarioDisp").val();
                    }
                },
                columnDefs: [{
                    "defaultContent": "-",
                    "targets": "_all"
                }],
                "scrollX": isPortrait,
                "initComplete": (d, i) => {
                    if (i.data[0].erro == "1") {
                        toastr.error(i.data[0].resultado);
                        $('#tabelaHorDisp tbody').unbind('click')
                        $("#divTabelaHorDisp").hide()
                    }
                },
                "columns": [{
                        "data": "dialivre",
                        "type": "moment-DD/MM/YYYY"
                    },
                    {
                        "data": "total"
                    },
                    {
                        "class": 'verListaHorios',
                        "orderable": false,
                        "data": null,
                        "defaultContent": '<button class="btn btn-primary btn-xs"  type="button">Ver horários</button>',
                    },
                    {
                        "class": 'HorarioAnalitico',
                        "orderable": false,
                        "data": null,
                        "defaultContent": '<button class="btn btn-success btn-xs"  type="button" >Ver na agenda</button>',
                    },
                ],

                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json"
                }
            });

            $('#tabelaHorDisp tbody').on('click', 'td.HorarioAnalitico', (e) => {
                var tr = $(e.currentTarget).closest('tr');
                var row = tbhordisp.row(tr);
                var data = row.data();
                showLoader(true);
                $("#buscaHorariosDisponivel-modal").modal('hide');
                var listProf = localStorage.getItem("profissionais").split(",");

                if (_.indexOf(listProf, data.profissional.toString()) == -1) {

                    listProf.push(data.profissional.toString());
                    $('#users_menu').multiselect('deselectAll', false);
                    $('#users_menu').multiselect('select', listProf).change();
                    setTimeout(() => {
                        $('#dvCalendario').datepicker('setDate', data.dialivre);
                    }, 500);
                } else {

                    $('#dvCalendario').datepicker('setDate', data.dialivre);
                }

                showLoader(false);

            });



            $('#tabelaHorDisp tbody').on('click', 'td.verListaHorios', (e) => {
                var tr = $(e.currentTarget).closest('tr');
                var row = tbhordisp.row(tr);
                var data = row.data();
                showLoader(true);
                var htmlhorarios = '';
                var datadia = `${((data.dia < 10) ? '0' : '')}${data.dia}/${((data.mes < 10) ? '0' : '')}${data.mes}/${data.ano}`
                var dataformat = `${data.ano}-${((data.mes < 10) ? '0' : '')}${data.mes}-${((data.dia < 10) ? '0' : '')}${data.dia}`
                var sertempo = data.sertempo;
                var servico = data.servico;
                $.ajax({
                    method: "POST",
                    dataType: "json",
                    url: "/pages/cadastros/buscaHorariosDisponiveisv2.php",
                    data: {
                        servico: data.servico,
                        profissional: data.profissional,
                        dia: data.dia,
                        mes: data.mes,
                        ano: data.ano
                    },
                    success: (data) => {
                        $scope.listaProfissional = data.data
                        $scope.listaProfissional[0].data = dataformat;
                        $scope.listaProfissional[0].tempo = sertempo;
                        $scope.listaProfissional[0].servico = servico;
                        $scope.listaProfissional[0].dialivre = datadia;
                        htmlhorarios = `Horários no(a) *${$_CONFIG.ESTABELECIMENTO}* para o dia *${datadia}* \nProfissional: *${$scope.listaProfissional[0].Apelido}*  \n\n`
                        for (var i = 0; i < $scope.listaProfissional[0].horarios.length; i++) {
                            $scope.listaProfissional[0].horarios[i].DataIni = ($scope.listaProfissional[0].horarios[i].DataIni).split(":")[0] + ':' + ($scope.listaProfissional[0].horarios[i].DataIni).split(":")[1]
                            htmlhorarios = htmlhorarios + ' - ' + ($scope.listaProfissional[0].horarios[i].DataIni).split(":")[0] + ':' + ($scope.listaProfissional[0].horarios[i].DataIni).split(":")[1] + '\n'
                        }

                        $scope.$apply();
                        $("#listaHorariosProfissionalDetalhes-modal").modal()
                        var dadosbotao = ' <button class="btn btn-block btn-primary btnCliphorarios" data-clipboard-text="' + htmlhorarios + '" ><i class="fa fa-copy" alt="Copiar"></i> Copiar horários</button>';
                        $("#btnCopiarHorarios").html(dadosbotao);
                        var clipboard = new ClipboardJS('.btnCliphorarios');
                        clipboard.on('success', function(e) {
                            toastr.success("Copiado!");
                        });
                    }
                });
                //$('#tabelaHorDisp tbody').unbind('click')
                showLoader(false);

            });
        }

        showLoader(false);
        return true;
    });

    $('#infohorario-modal').on('hidden.bs.modal', () => {
        $('#lblUsuario').html("");
        $('#lblIDAgendamento').html("");
        $('#lblServico').html("");
        $('#lblProfissional').html("");
        $('#lblSerCodigo').html("");
        $('#lblFim').html("");
        $('#lblObs').val("");
        $('#lblEmail').html("");
        $('#lblCelular').html("");
        $('#lblValor').html("");
        $('#lblValorHdn').html("");
        $('#lblPesCodigo').html("");
        $('#lblComCodigo').html("");
        $('#lblCItCodigo').html("");
        $("#comandaBotao").html("");
        $('#tdDatCadastro').html("");
        $("#comandaBotaoValor").html("");
        $('#tdOrigem').html("");
    })

    $scope.buscaagendamentoclube = function(tipo, pescodigo, sercodigo, asscodigo, grucodigo, citcodigo) {
        if (tipo == '1') {
            $("#tipoclube").html('');
            $.ajax({
                method: "POST",
                dataType: "json",
                url: "/pages/cadastros/buscaAgendamentoClube.php",
                data: {
                    tipo: tipo,

                    citcodigo: citcodigo
                },
                success: (data) => {
                    if (data.data[0] != undefined) {
                        if (data.data[0].erro != 1) {
                            var servico = $('#lblSerCodigo').html();
                            var pessoa = $('#lblPesCodigo').html();
                            if (data.data[0].Ass_Codigo != '') {
                                var codigo = data.data[0].Ass_Codigo;
                                $("#tipoclube").html(" - Clube de Assinaturas <button class='btn bg-purple btn-flat btn-xs' ng-click='buscaagendamentoclube(2," + pessoa + "," + servico + "," + codigo + ",null,null)'>Detalhes</button>")
                            } else {
                                if (data.data[0].Gru_Codigo != '') {
                                    var codigo = data.data[0].Gru_Codigo;
                                    $("#tipoclube").html(" - Clube de Clientes <button class='btn bg-purple btn-flat btn-xs' ng-click='buscaagendamentoclube(3," + pessoa + "," + servico + ",null," + codigo + ",null)'>Detalhes</button>")
                                }
                            }
                            $compile($('#tipoclube'))($scope);
                        }
                    }

                }
            });
        } else if (tipo == '2') {
            $.ajax({
                method: "POST",
                dataType: "json",
                url: "/pages/cadastros/buscaAgendamentoClube.php",
                data: {
                    tipo: tipo,
                    cliente: pescodigo,
                    servico: sercodigo,
                    asscodigo: asscodigo

                },
                success: function(data) {
                    if (data.data[0] != undefined) {
                        if (data.data[0].erro == 0) {
                            $("#nomeClube").html("Clube de Assinatura - " + data.data[0].Ass_Descricao + "<br>Vencimento: " + data.data[0].DataVencimento);
                            $("#nomeservicoclube").html(data.data[0].Ser_Descricao);
                            $("#clubedesconto").html("Desconto - " + data.data[0].AIt_Desconto + "%");
                            $("#clubeinfo-modal").modal()
                        }
                    }

                }
            });
        } else if (tipo == '3') {
            $.ajax({
                method: "POST",
                dataType: "json",
                url: "/pages/cadastros/buscaAgendamentoClube.php",
                data: {
                    tipo: tipo,
                    cliente: pescodigo,
                    servico: sercodigo,
                    grucodigo: grucodigo

                },
                success: function(data) {
                    if (data.data[0] != undefined) {
                        if (data.data[0].erro == 0) {
                            $("#nomeClube").html("Clube de Clientes - " + data.data[0].Gru_Descricao);
                            $("#nomeservicoclube").html(data.data[0].Ser_Descricao);
                            $("#clubedesconto").html("Desconto - " + data.data[0].SGr_Valor + '%');
                            $("#clubeinfo-modal").modal()
                        }
                    }

                }
            });
        }
    }

    $scope.cadastrarlembrete = function() {

        $.ajax({
            method: "POST",
            dataType: "json",
            url: "/pages/cadastros/buscaClienteAlteraAgenda.php",
            data: {
                cliente: $("#lblPesCodigo").html(),
            },
            success: function(data) {
                $("#usuCodigoCodigoLembrete").val(data.result[0].Usu_Codigo);

            },
            error: function(result) {}
        });
        $scope.buscaSaldoSMSLem()
        $scope.buscaSaldoWhatsLem()
        $("#dataAgendamentoLembrete").html();
        $("#pesCodigoClienteLembrete").val();
        $("#usuCodigoCodigoLembrete").val();
        $("#ageCodigoLembrete").val();
        $("#dataInicioLembrete").val();
        $("#horaInicioLembrete").val();
        $("#cadastrarlembrete-modal").modal();
    }

    $('#formInserirLembrete').submit(function(event) {
        event.preventDefault();
        showLoader(true);
        var qtdlembrete = $("#min_lembrete").val();
        var dataatualenvio = moment($('#dataInicioLembrete').val() + " " + $('#horaInicioLembrete').val()).add(-qtdlembrete, "minutes");
        var dataenvio = dataatualenvio.locale("PT-BR").format("L") + " " + dataatualenvio.hours() + ":" + dataatualenvio.minute();

        if ($("#cbEnviaSmsLem").get(0).checked) {
            var cbEnviaSms = 1;
        } else {
            var cbEnviaSms = 0;
        }
        if ($("#cbEnviaWhatsLem").get(0).checked) {
            var cbEnviaWhats = 1;
        } else {
            var cbEnviaWhats = 0;
        }

        $.ajax({
            dataType: "json",
            url: '/pages/cadastros/insereLembretev2.php',
            method: "POST",
            data: {
                dataenvio: dataenvio,
                pescodigocliente: $("#pesCodigoClienteLembrete").val(),
                usucodigocliente: $("#usuCodigoCodigoLembrete").val(),
                agecodigo: $("#ageCodigoLembrete").val(),
                usasms: cbEnviaSms,
                usawhats: cbEnviaWhats
            },
            success: function(result) {
                if (result.data[0].erro == "0") {
                    swal(result.data[0].resultado, "", "success");
                    $("#cadastarlembrete-modal").modal("hide");

                } else {
                    swal("Falha ao Inserir.", result.data[0].resultado, "error");
                }
                showLoader(false);
            },
            error: function(result) {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });

        return true;
    });
    $scope.buscaSaldoSMSLem = () => {
        $.ajax({
            dataType: "json",
            url: '/pages/cadastros/buscaDadosSMS.php',
            method: "POST",
            data: {
                tipo: 1
            },
            success: (data) => {
                if (data.result.length > 0) {
                    $("#lblSaldoSMSLem").html(data.result[0].Saldo);
                }
            }
        });
    }
    $scope.buscaSaldoWhatsLem = () => {
        $.ajax({
            dataType: "json",
            url: '/pages/cadastros/buscaSaldoWhats.php',
            method: "POST",
            data: {
                tipo: 1
            },
            success: function(data) {
                if (data.data.length > 0) {
                    $("#lblSaldoWhatsLem").html(data.data[0].Saldo);
                }
            }
        });
    }

    $("#cbEnviaSmsLem").change((e) => {

        if (e.currentTarget.checked && ($("#lblSaldoSMSLem").html() == "0")) {
            toastr.error("Saldo insuficiente para enviar SMS");
            e.currentTarget.checked = false;
        }

    });

    $("#cbEnviaWhatsLem").change((e) => {

        if (e.currentTarget.checked && ($("#lblSaldoWhatsLem").html() == "0")) {
            toastr.error("Saldo insuficiente para enviar WhatsApp");
            e.currentTarget.checked = false;
        }

    });

    $("#btnCompraSmsLem").click(() => {
        swal({
            title: "Confirmar :",
            text: "Deseja realmente ir até a compra de sms, os campos preenchidos serão perdidos",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Sim",
            cancelButtonText: "Não",
            closeOnConfirm: true
        }, () => {
            var url = location.href;
            url = url.split('#/')[0];
            url = url + '#/sms';
            window.location.href = url;
            $("#novo-modal").modal("hide");
        });
    })

    $("#btnCompraWhatsLem").click(() => {
        swal({
            title: "Confirmar :",
            text: "Deseja realmente ir até a compra de créditos de WhatsApp, os campos preenchidos serão perdidos",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Sim",
            cancelButtonText: "Não",
            closeOnConfirm: true
        }, () => {
            var url = location.href;
            url = url.split('#/')[0];
            url = url + '#/whatsapp';
            window.location.href = url;
            $("#novo-modal").modal("hide");
        });
    })

    $scope.buscaListaAgendamentos = function() {
        $("#listaAgendamentoModal-modal").modal()
        $("#divListaAgendamento").hide()
        $scope.buscaServicoListaAgendamento();
        $scope.buscaClienteLista()
    }


    $scope.buscaServicoListaAgendamento = function() {
        $.ajax({
            method: "POST",
            dataType: "json",
            url: "/pages/cadastros/buscaServicoSelect.php",
            /*data: {
            	profissional: $("#profisisonalHorDisp").val()
            },*/
            success: (data) => {
                $("#serListaAgendamento").html('<option value="">Serviço</option>');
                $("#servicoListaAgenda").html('<option value="">Serviço</option>');
                $("#servicoListaEsperaAltera").html('<option value="">Serviço</option>');

                for (var i = 0; i < data.servicos.length; i++) {
                    $("#serListaAgendamento").append('<option value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>');
                    $("#servicoListaAgenda").append('<option value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>');
                    $("#servicoListaEsperaAltera").append('<option value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>');
                };
                $("#servicoListaAgenda").select2()
                $("#servicoListaEsperaAltera").select2()
            }
        });

    }


    $scope.pesquisaListaAgendamento = function() {
        $("#divListaAgendamento").show();
        if (typeof(tbListaAgendamento) != "undefined") {
            tbListaAgendamento.destroy();
        }
        tbListaAgendamento = $('#tableListaAgendamento').DataTable({
            dom: 'T<"clear">Blfrtip',
            buttons: [{
                extend: 'excelHtml5',
                text: 'Excel',
                exportOptions: {
                    columns: ':visible'
                },
                footer: 'true'
            }, {
                extend: 'pdfHtml5',
                title: sSistema + ' - Lista Agendamentos',
                orientation: 'landscape',
                footer: true,
                pageSize: 'LEGAL',
                exportOptions: {
                    columns: ':visible'
                }
            }, {
                extend: 'print',
                text: 'Imprimir',
                exportOptions: {
                    columns: ':visible'
                },
                footer: true
            }],
            "ajax": {
                "url": "/pages/relatorios/buscaListaAgendamento.php",
                "method": "POST",
                "data": function(d) {
                    d.profissional = $("#profListaAgendamento").val();
                    d.servico = $("#serListaAgendamento").val();
                    d.cliente = $("#cliListaAgendamento").val();
                    d.dataini = $("#dataIniListaAgendamento").val();
                    d.datafim = $("#dataFimListaAgendamento").val();
                    d.tipo = 1;
                }
            },
            "scrollX": isPortrait,
            "initComplete": function(d, i) {
                if (i.erro == "1") {
                    toastr.error(i.resultado);
                }
            },
            "columns": [{
                    "data": "Age_Dat_Inicio",
                    "type": "moment-DD/MM/YYYY hh:mm",
                    "title": "Data"
                },
                {
                    "data": "CliNome",
                    "title": "Cliente"
                },
                {
                    "data": "ProNome",
                    "title": "Profissional"
                },
                {
                    "data": "Ser_Descricao",
                    "title": "Serviço"
                },
                {
                    "class": 'editaAgendamentoLista',
                    "orderable": false,
                    "data": null,
                    "defaultContent": '<button class="btn btn-success btn-xs"  >Editar</button>',
                },
                {
                    "class": 'cancelaHorarioLista',
                    "orderable": false,
                    "data": null,
                    "defaultContent": '<button class="btn btn-danger btn-xs"  >Cancelar</button>',
                },
            ],

            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json"
            }
        });

        $('#tableListaAgendamento tbody').on('click', 'td.cancelaHorarioLista', (e) => {
            var tr = $(e.currentTarget).closest('tr');
            var row = tbListaAgendamento.row(tr);
            var data = row.data();
            $("#AgeCodigoListaCancela").val(data.Age_Codigo);
            $("#cancelarAgendamentoLista-modal").modal()
        });


        $('#tableListaAgendamento tbody').on('click', 'td.editaAgendamentoLista', (e) => {
            var tr = $(e.currentTarget).closest('tr');
            var row = tbListaAgendamento.row(tr);
            var data = row.data();
            $("#citCodigoAlteraAgendamentoLista").val(data.CIt_Codigo);
            $('.date.dateAltAgeLista').datepicker('update', '');
            $("#dataOriginalAgendamento").val(data.DataAgendamento)
            $('.date.dateAltAgeLista').datepicker('update', data.DataAgendamento);
            $("#tipoAlteraAgendamentoLista").val(0).change();
            $scope.buscaProfissionalAlteraAgendamentoLista();
            $scope.buscaServicoAlteraAgendamentoLista(data.ProCodigo)
            $("#editarAgendamentoLista-modal").modal()
        });
    }


    $scope.cancelaAgendamentoLista = function() {

        if ($("#ageMotivoLista").val() == "") {
            toastr.error('Favor informe o motivo do cancelamento!');
        } else {
            showLoader(true);
            $.ajax({
                dataType: "json",
                url: "/pages/actions/cancelaHorario.php",
                method: "POST",
                data: {
                    agendamento: $("#AgeCodigoListaCancela").val(),
                    motivo: $("#ageMotivoLista").val()
                },
                success: (data) => {
                    if (data.cancelaHorario[0].erro == 1) {
                        swal(data.cancelaHorario[0].resultado, "", "error");
                    } else {
                        $('#cancelarAgendamentoLista-modal').modal('hide');
                        $scope.pesquisaListaAgendamento();
                        $("#ageMotivoLista").val("");
                        toastr.success("Agendamento foi cancelado com sucesso.");
                    }
                    showLoader(false);
                },
                error: () => {
                    swal("Falha na conexão.", "", "error");
                    showLoader(false);
                }
            });

        }
    }


    $scope.buscaClienteLista = function() {
        if (hasManyClients) {
            $('.select2.clientes').select2({
                ajax: {
                    url: "/pages/actions/buscaClientesMany.php",
                    dataType: 'json',
                    delay: 250,
                    data: (params) => {
                        return {
                            nome: params.term
                        };
                    },
                    processResults: (data, params) => {
                        return {
                            results: data.result
                        };
                    },
                    cache: true
                },
                placeholder: 'Selecione o Cliente',
                escapeMarkup: (markup) => {
                    return markup;
                },
                minimumInputLength: 3,
                templateResult: thumbCliente2,
                templateSelection: formatRepoSelection
            });
        } else {
            var html = '';
            var html2 = '';
            $.ajax({
                dataType: 'json',
                url: "/pages/actions/buscaClientes.php",
                method: "POST",
                data: {
                    tipo: 2
                },
                success: (data) => {
                    var html = '<option value="">Cliente</option>';
                    for (var i = 0; i < data.result.length; i++) {
                        var codigo = data.result[i].Pes_Codigo;
                        var nome = data.result[i].Pes_Nome;
                        var usuario = data.result[i].Usu_Codigo;

                        html += '<option value="' + codigo + '" data-usucodigo="' + usuario + '">' + nome + '</option>';
                    }
                    $('#cliListaAgendamento').html(html);
                    $('#pesCodigoClienteListaAgenda').html(html);
                    $('.select2.clientes').select2();
                }
            });
        }
    }

    $scope.alteraAgendamentoLista = function() {
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/alteraAgendamento.php",
            data: {
                dataAlteraAgendamento: $("#dataAlteraAgendamentoLista").val(),
                horaAlteraAgendamento: $("#horaAlteraAgendamentoLista").val(),
                tipoAlteraAgendamento: $("#tipoAlteraAgendamentoLista").val(),
                codItem: $("#citCodigoAlteraAgendamentoLista").val(),
                profissionalAlteraAgendamento: $("#profissionalAlteraAgendamentoLista").val(),
                servicoAlteraAgendamento: $("#servicoAlteraAgendamentoLista").val(),
                DuracaoAlteraAgendamento: $("#DuracaoAlteraAgendamentoLista").val()

            },
            dataType: "json",
            success: (result) => {

                if (result.result[0].erro == "0") {
                    $("#editarAgendamentoLista-modal").modal('hide');
                    $scope.pesquisaListaAgendamento();
                    toastr.success(result.result[0].resultado);

                } else {
                    toastr.error(result.result[0].resultado);
                }
                showLoader(false);
            },
            error: () => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });

    }

    $scope.buscaProfissionalAlteraAgendamentoLista = function() {
        $.ajax({
            method: "POST",
            dataType: "json",
            url: "/pages/cadastros/buscaProfissionalSelect.php",
            success: (data) => {
                $("#profissionalAlteraAgendamentoLista").html('<option value="">Selecione um Profissional</option>');
                for (var i = 0; i < data.profissionais.length; i++) {
                    $("#profissionalAlteraAgendamentoLista").append('<option value="' + data.profissionais[i].Pes_Codigo + '">' + data.profissionais[i].Pes_Nome + '</option>');
                };
            }
        });
    }

    $scope.buscaServicoAlteraAgendamentoLista = function(codigoProfissional) {
        $.ajax({
            method: "GET",
            dataType: "json",
            url: "/pages/actions/buscaServicos.php",
            method: "POST",
            data: {
                tipo: '2',
                profissional: codigoProfissional
            },
            success: (data) => {
                $("#servicoAlteraAgendamentoLista").html('<option value="">Selecione um Serviço</option>');
                for (var i = 0; i < data.servicos.length; i++) {
                    $("#servicoAlteraAgendamentoLista").append('<option value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>');
                };
            }
        });
    }

    $scope.hideDivsAlteraLista = function() {
        $("#divAlteraAgendamentoDataLista").hide();
        $("#divAlteraAgendamentoServicoLista").hide();
        $("#divAlteraAgendamentoProfissionalLista").hide();
        $("#divAlteraAgendamentoDuracaoLista").hide();
    }

    $("#tipoAlteraAgendamentoLista").change(() => {

        $scope.hideDivsAlteraLista();

        $("#profissionalAlteraAgendamentoLista").val('');
        $("#servicoAlteraAgendamentoLista").val('');
        $("#DuracaoAlteraAgendamentoLista").val('');
        $('.date.dateAltAgeLista').datepicker('update', '');
        setTimeout(() => {
            $('.date.dateAltAgeLista').datepicker('update', $("#dataOriginalAgendamento").val());
        }, 200)
        $("#horaAlteraAgendamentoLista").val('');
        $("#dataAlteraAgendamentoLista").val('');
        if ($("#tipoAlteraAgendamentoLista option:selected").val() == 1) {
            $("#divAlteraAgendamentoDataLista ").show();
            $("#profissionalAlteraAgendamentoLista").val('');
            $("#servicoAlteraAgendamentoLista").val('');
            $("#DuracaoAlteraAgendamentoLista").val('');
        } else if ($("#tipoAlteraAgendamentoLista option:selected").val() == 2) {
            $("#divAlteraAgendamentoServicoLista").show();
        } else if ($("#tipoAlteraAgendamentoLista option:selected").val() == 3) {
            $("#divAlteraAgendamentoProfissionalLista").show();
        } else if ($("#tipoAlteraAgendamentoLista option:selected").val() == 4) {
            $("#divAlteraAgendamentoDataLista").show();
            $("#divAlteraAgendamentoProfissionalLista").show();
        } else if ($("#tipoAlteraAgendamentoLista option:selected").val() == 5) {
            $("#divAlteraAgendamentoDataLista").show();
            $("#divAlteraAgendamentoServicoLista").show();
        } else if ($("#tipoAlteraAgendamentoLista option:selected").val() == 6) {
            $("#divAlteraAgendamentoServicoLista").show();
            $("#divAlteraAgendamentoProfissionalLista").show();
        } else if ($("#tipoAlteraAgendamentoLista option:selected").val() == 7) {
            $("#divAlteraAgendamentoDataLista").show();
            $("#divAlteraAgendamentoServicoLista").show();
            $("#divAlteraAgendamentoProfissionalLista").show();
        } else if ($("#tipoAlteraAgendamentoLista option:selected").val() == 8) {
            $("#divAlteraAgendamentoDuracaoLista").show();
            $scope.comboTempoPadrao();
        }
    });

    $("#profissionalAlteraAgendamentoLista").change(() => {
        $scope.buscaServicoAlteraAgendamentoLista($("#profissionalAlteraAgendamentoLista option:selected").val());
    });

    var initCalendar = () => {
        $('#calendar').fullCalendar({
            weekends: true,
            defaultView: 'resourceDay',
            allDayText: $_CONFIG.language.todo_dia,
            allDayDefault: false,
            allDaySlot: false,
            eventDurationEditable: true,
            disableDragging: false,
            editable: false,
            droppable: true,
            minTime: mMinTime,
            maxTime: mMaxTime,
            selectable: true,
            selectHelper: false,
            height: heightAgenda,
            now: curTimeZone,
            selectOverlap: false,
            slotEventOverlap: false,
            handleWindowResize: true,
            slotDuration: '00:' + $_CONFIG.TEMPOPADRAO + ':00',
            resources: resources,
            lazyFetching: true,
            titleFormat: {
                day: 'dddd, D/MMM/YYYY'
            },
            events: $scope.objAgenda,
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'resourceDay,agendaWeek,month'
            },
            buttonText: {
                today: $_CONFIG.language.hoje,
                month: $_CONFIG.language.mes,
                week: $_CONFIG.language.semana,
                day: $_CONFIG.language.dia
            },
            dateFormat: 'dd/mm/yy',
            axisFormat: 'HH:mm',
            timeFormat: 'HH:mm',
            dayNames: $_CONFIG.language.fc_day,
            dayNamesMin: $_CONFIG.language.fc_day_min,
            dayNamesShort: $_CONFIG.language.fc_day_short,
            monthNames: $_CONFIG.language.fc_month,
            monthNamesShort: $_CONFIG.language.fc_month_min,
            columnFormat: {
                month: 'ddd',
                week: 'ddd D/M',
                day: 'dddd d/M'
            },
            eventMouseout: () => {
                clearTimeout(timevalor);

                $('.popover').popover('hide');
            },
            eventMouseover: (event, jsEvent) => {
                if (event.codStatus != 6) {
                    $el = $(jsEvent.currentTarget);
                    var content = '';
                    titulo = event.title
                    if (event.codStatus != 4) {
                        if (!$el[0].hasAttribute('data-original-title')) {
                            timevalor = setTimeout(() => {

                                $.ajax({
                                    dataType: "json",
                                    url: "/pages/actions/buscaAgendamentoTipoPagamento.php",
                                    type: 'POST',
                                    data: {
                                        comanda: event.Com_Codigo
                                    },
                                    success: (data) => {
                                        if (typeof(event.valor) !== 'undefined' && event.valor != '') {
                                            content = content + '<p><h6 class="text-green"><i class="fa fa-dollar"></i>  ' + event.valor + ' - Agendamento</h6></p>';
                                        } else {
                                            content = content;
                                        }
                                        content = content + '<p><h6 class="text-blue"><i class="fa fa-dollar"></i>  ' + data.result[0].ValorComanda + '- Comanda</h6></p>';

                                        if (event.CIt_Pag_Online == '1') {
                                            content = content + '<p><h6 class="text-green"><i class="ion ion-card"></i> Pago Online</h6></p>';
                                        }

                                        if (typeof(event.cupom) !== 'undefined' && event.cupom != '') {
                                            content = content + '<p><h6 class="text-blue"><i class="fa fa-ticket"></i> Cupom: <b>' + event.cupom + '</b></h6></p>';
                                        }

                                        if (event.icon != '') {
                                            content = content + '<p><h6 class="text-red"><i class="fa fa-exclamation-triangle"></i> Já se ausentou</h6></p>';
                                        }

                                        if (event.Age_Origem == '1') {
                                            content = content + '<p><h6><i class="fa fa-apple"></i> iOS - Aplicativo do Profissional</h6></p>';
                                        } else if (event.Age_Origem == '2') {
                                            content = content + '<p><h6><i class="fa fa-desktop"></i> Web </h6></p>';
                                        } else if (event.Age_Origem == '3') {
                                            content = content + '<p><h6><i class="fa fa-android"></i> Android - Aplicativo do Profissional</h6></p>';
                                        } else if (event.Age_Origem == 4) {
                                            content = content + '<p><h6><i class="fa fa-facebook-official"></i> Facebook/Site </h6></p>';
                                        } else if (event.Age_Origem == '8') {
                                            content = content + '<p><h6><i class="fa fa-apple"></i> iOS - Aplicativo do Cliente</h6></p>';
                                        } else if (event.Age_Origem == '9') {
                                            content = content + '<p><h6><i class="fa fa-android"></i> Android - Aplicativo do Cliente</h6></p>';
                                        } else if (event.Age_Origem == '10') {
                                            content = content + '<p><h6><i class="fa fa-map-marker"></i> Totem </h6></p>';
                                        }


                                        $.ajax({
                                            dataType: "json",
                                            url: "/pages/cadastros/buscaAgendamentoTag.php",
                                            type: 'GET',
                                            async: false,
                                            data: {
                                                agecodigo: event.id,
                                                id: $_CONFIG.ID
                                            },
                                            success: (data) => {
                                                if (data.data.length > 0) {
                                                    for (var i = 0; i < data.data.length; i++) {
                                                        content = content + `<label class="label" id="tagLabelPopUp${data.data[i].ATa_Codigo}"  style="background-color:${data.data[i].ATa_Cor}">${data.data[i].ATa_Descricao}</label><br>`
                                                    }
                                                }
                                            }
                                        });

                                        if (event.rec == 1) {
                                            $.ajax({
                                                dataType: "json",
                                                url: "/pages/cadastros/buscaAgendamentoRecorrente.php",
                                                type: 'GET',
                                                async: false,
                                                data: {
                                                    agendamento: event.id,
                                                    id: $_CONFIG.ID
                                                },
                                                success: (data) => {
                                                    if (data.data.length > 0) {
                                                        if (data.data.length > 0) {
                                                            if (data.data[0].erro == undefined) {
                                                                for (var i = 0; i < data.data.length; i++) {
                                                                    content = content + `<b>Agendamento recorrente ${data.data[i].AgendamentoAtual}/${data.data[i].TotalAgendamento}</b>`
                                                                }
                                                            } else {
                                                                content = content + '<b>Este agendamento é recorrente';
                                                            }
                                                        }

                                                    }
                                                }
                                            });
                                        }

                                        content = content + '<br><p class="text-center"><button type="button" id="close" class="btn btn-primary btn-xs" onclick="$(&quot;.popover&quot;).popover(&quot;hide&quot;);">Fechar</button></p>';

                                        $el.popover({
                                            html: true,
                                            title: titulo,
                                            content: content,
                                            trigger: 'click hover focus',
                                            container: 'body',
                                            placement: 'top'
                                        }).popover('show');
                                    }
                                });
                            }, 300);
                        }
                    }

                }
                return true;
            },
            eventDrop: function(calEvent, func, revertFunc) {
                swal({
                    title: 'Deseja realmente alterar este horário?',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#DD6B55',
                    confirmButtonText: $_CONFIG.language.sim,
                    cancelButtonText: $_CONFIG.language.nao,
                    closeOnConfirm: true
                }, function(isConfirmed) {
                    if (isConfirmed) {
                        $scope.alteraAgendamentoDrag(calEvent.start.format('DD/MM/YYYY'), calEvent.start.format('HH:mm'), calEvent.CIt_Codigo, calEvent.resources[0], revertFunc);
                    } else {
                        revertFunc();
                    }
                    $('.popover').popover('hide');
                });
            },
            eventResize: (calEvent, _, revertFunc) => {
                swal({
                    title: 'Deseja realmente alterar este horário?',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#DD6B55',
                    confirmButtonText: $_CONFIG.language.sim,
                    cancelButtonText: $_CONFIG.language.nao,
                    closeOnConfirm: true
                }, function(isConfirmed) {
                    if (isConfirmed) {
                        duracao = (calEvent.end.diff(calEvent.start) / 1000) / 60;
                        $scope.alteraAgendamentoResize(calEvent.start.format('DD/MM/YYYY'), duracao, calEvent.CIt_Codigo, calEvent.resources[0], revertFunc);
                    } else {
                        revertFunc();
                    }
                    $('.popover').popover('hide');
                });
            },
            eventClick: (calEvent, _, view) => {
                clearTimeout(timevalor);



                $("#sendWhatsappReminder").hide();

                if ((view.name == 'month') || (view.name == 'agendaWeek')) {
                    $('#calendar').fullCalendar('gotoDate', calEvent.start);
                    $('#calendar').fullCalendar('changeView', 'resourceDay');
                } else {
                    if (calEvent.id != '0') {
                        if (calEvent.usuario == 'Sem Cadastro') {
                            $('#btnCadastraUsuario').show();
                            $('#ProntuarioCliente').hide();
                            $("#btnEdtClienteAgenda").hide();
                        } else {
                            $('#btnCadastraUsuario').hide();
                            $('#ProntuarioCliente').show();
                            $("#btnEdtClienteAgenda").show();
                            $("#listaTagsClientes").html("");

                            $.ajax({
                                dataType: "json",
                                url: "/pages/cadastros/buscaClienteTag.php",
                                type: 'GET',
                                data: {
                                    pescodigo: calEvent.codCliente,
                                },
                                success: (data) => {
                                    if (data.data.length > 0) {
                                        var tagClientecontent = "";
                                        for (var i = 0; i < data.data.length; i++) {

                                            tagClientecontent = tagClientecontent + `<label class="label"  style="background-color:${data.data[i].CTa_Cor}">${data.data[i].CTa_Descricao}</label> &nbsp`
                                        }
                                        $("#listaTagsClientes").html(tagClientecontent)
                                        $compile($('#listaTagsClientes'))($scope);
                                    }
                                }
                            });
                        }
                        $("#listaTagsAgendamento").html("");
                        $("#lblRecorrencia").html('<i class="fa fa-spinner fa-pulse fa-fw"></i>')
                        $.ajax({
                            dataType: "json",
                            url: "/pages/cadastros/buscaAgendamentoTag.php",
                            type: 'GET',

                            data: {
                                agecodigo: calEvent.id,
                                id: $_CONFIG.ID
                            },
                            success: (data) => {
                                if (data.data.length > 0) {
                                    var tagcontent = "";
                                    for (var i = 0; i < data.data.length; i++) {

                                        tagcontent = tagcontent + `<label class="label" id="tagLabel${data.data[i].ATa_Codigo}" style="background-color:${data.data[i].ATa_Cor}">${data.data[i].ATa_Descricao} &nbsp<i class="fa fa-times pointer" ng-click="removeTagAgendamento(${data.data[i].ATa_Codigo})"></i> </label> &nbsp`
                                    }
                                    $("#listaTagsAgendamento").html(tagcontent)
                                    $compile($('#listaTagsAgendamento'))($scope);
                                }
                            }
                        });

                        if (calEvent.ass_multiunidade != '' && calEvent.ass_multiunidade != undefined) {
                            $("#HasAssinaturaAgendamento").html(`<i class="fa fa-star" style="background-color:#FFD700;border-radius:50%;padding:3px;color:black"></i> `)
                        } else {
                            if (calEvent.assinatura != '' && calEvent.assinatura != undefined) {
                                $("#HasAssinaturaAgendamento").html(`<i class="fa fa-star" style="background-color:orange;border-radius:50%;padding:3px;color:white"></i> `)
                            } else {
                                $("#HasAssinaturaAgendamento").html('')
                            }

                        }

                        if (calEvent.inadimplente_assinatura_multi == '1' && calEvent.inadimplente_assinatura_multi != undefined) {
                            $("#HasAssinaturaAgendamento").html(`<i class="fa fa-star"  style="background-color:#FF4500;border-radius:50%;padding:3px;color:black"></i> `)
                        } else {
                            if (calEvent.inadimplente_assinatura == '1' && calEvent.inadimplente_assinatura != undefined) {
                                $("#HasAssinaturaAgendamento").html(`<i class="fa fa-star" style="background-color:#cd0707;border-radius:50%;padding:3px;color:white"></i> `)
                            }
                        }




                        if (calEvent.rec == 1) {
                            $("#divRecorrencia").show();
                            htmlrecorrente = '';
                            $scope.finalAgendamentoRecorrente = -1;
                            $.ajax({
                                dataType: "json",
                                url: "/pages/cadastros/buscaAgendamentoRecorrente.php",
                                type: 'GET',
                                data: {
                                    agendamento: calEvent.id,
                                    id: $_CONFIG.ID
                                },
                                success: (data) => {

                                    if (data.data.length > 0) {
                                        if (data.data[0].erro == undefined) {
                                            for (var i = 0; i < data.data.length; i++) {
                                                htmlrecorrente += `Agendamento ${data.data[i].AgendamentoAtual}/${data.data[i].TotalAgendamento}`
                                                $scope.finalAgendamentoRecorrente = data.data[i].TotalAgendamento - data.data[i].AgendamentoAtual;
                                            }
                                        } else {
                                            htmlrecorrente += 'Este agendamento é recorrente';
                                            $scope.finalAgendamentoRecorrente = -1;
                                        }
                                        $("#lblRecorrencia").html(htmlrecorrente)
                                    }
                                }
                            });
                        } else {
                            $scope.finalAgendamentoRecorrente = -1;
                            $("#divRecorrencia").hide()
                        }

                        $scope.buscaagendamentoclube(1, "", "", "", "", calEvent.CIt_Codigo);
                        if ($scope.hasnf == 1) {
                            $("#cpfnf").show();
                        }
                        if (calEvent.codStatus == '1') {

                            $('#lblUsuario').html(calEvent.usuario);
                            $('#lblCPFCliente').html(calEvent.PAF_CPF);
                            $('#lblIDAgendamento').html(calEvent.id);
                            $('#lblServico').html(calEvent.servico);
                            $('#lblProfissional').html(calEvent.resources);
                            $('#lblSerCodigo').html(calEvent.sercodigo);
                            $('#lblFim').html(calEvent.end.format('DD/MM/YYYY HH:mm'));

                            $('#fimAgendamento').html(calEvent.end.format('HH:mm'));
                            $("#iniAgendamento").html(calEvent.start.format('HH:mm'));



                            $("#lblObs").val(unescapeUnicode(calEvent.obs));

                            $('#lblEmail').html(calEvent.email);
                            $('#lblCelular').html(calEvent.celular);
                            if (calEvent.celular != '') {
                                $("#btnAgendamentoWhats").attr('disabled', false)
                            } else {
                                $("#btnAgendamentoWhats").attr('disabled', true)
                            }
                            $('#lblValor').html($_CONFIG.MOEDA + calEvent.valor);
                            $('#lblValorHdn').html(calEvent.valor);
                            $('#lblPesCodigo').html(calEvent.codCliente);
                            $('#lblComCodigo').html(calEvent.Com_Codigo);
                            $('#lblCItCodigo').html(calEvent.CIt_Codigo);
                            $("#comandaBotao").html(calEvent.Com_Codigo);

                            $("#dataAgendamentoLembrete").html(calEvent.start.format('DD/MM/YYYY HH:mm'));
                            $("#pesCodigoClienteLembrete").val(calEvent.codCliente);
                            $("#usuCodigoCodigoLembrete").val(calEvent.usuario);
                            $("#ageCodigoLembrete").val(calEvent.id);
                            $("#dataInicioLembrete").val(calEvent.start.format('YYYY/MM/DD'));
                            $("#horaInicioLembrete").val(calEvent.start.format('HH:mm'));

                            $("#btnVerComandaAgendamentoFinalizado").hide();
                            $("#btnVerComandaAgendamento").show();
                            $('#btnRealizadoAg').show();
                            $('#btnAusenteAg').show();
                            $('#btnCancelarAg').show();
                            $('#btnMaisServico').show();


                            $("#btnSendWhatsReminder").unbind('click');
                            if (calEvent.celular != "") {
                                $("#sendWhatsappReminder").show();
                                $("#btnSendWhatsReminder").click(() => {

                                    $.ajax({
                                        type: "POST",
                                        url: "/pages/cadastros/AGENDAMENTO_Busca.php",
                                        data: {
                                            type: 1,
                                            scheduling_code: calEvent.id
                                        },
                                        dataType: "json",
                                        success: (result) => {
                                            var cliente = result.data.scheduling[0].person_name;
                                            var apelido = result.data.scheduling[0].person_nickname;
                                            var servico = result.data.scheduling[0].service_description;
                                            var datahora = result.data.scheduling[0].scheduling_start_date.split(" ");
                                            var dataAge = datahora[0];
                                            var horaAge = datahora[1];
                                            var profissional = result.data.scheduling[0].professional_name;
                                            var profissionalapelido = result.data.scheduling[0].professional_nickname;
                                            var pontosfidelidade = result.data.scheduling[0].person_loyalty_points;
                                            var linkconfirmacao = result.data.scheduling[0].confirmation_link;
                                            var confirmationLinkCode = result.data.scheduling[0].confirmation_link_code;
                                            var hashCode = result.data.scheduling[0].hash_code_invoice;
                                            if (linkconfirmacao != '') {
                                                if (result.data.scheduling[0].has_short_link == 0) {
                                                    if (confirmationLinkCode != '') {

                                                        /*$.ajax({
                                                        	dataType: "json",
                                                        	url: '/pages/cadastros/geraShortLink.php',
                                                        	method: "POST",
                                                        	async: false,
                                                        	data: {
                                                        		longlink: linkconfirmacao
                                                        	},*/
                                                        $.ajax({
                                                            dataType: "json",
                                                            url: '/pages/cadastros/geraShortLinkAWS.php',
                                                            method: "POST",
                                                            async: false,
                                                            data: {
                                                                longlink: linkconfirmacao,
                                                                pesCodigo: $_CONFIG.CODESTABELECIMENTO,
                                                                type: 1
                                                            },
                                                            success: function(data) {
                                                                linkconfirmacao = data.shortLink
                                                                $.ajax({
                                                                    dataType: "json",
                                                                    url: '/pages/cadastros/COMANDA_CONFIRMACAO_Atualiza.php',
                                                                    data: {
                                                                        confirmation_short_link: linkconfirmacao,
                                                                        confirmation_link_code: confirmationLinkCode
                                                                    },
                                                                    method: "POST",
                                                                    async: false,
                                                                    success: function(data) {
                                                                        console.log(data)
                                                                    }
                                                                });
                                                            }
                                                        });
                                                    }
                                                }
                                            } else {
                                                var sistemalink = sSistema.toLowerCase()
                                                var thisNewLink = `https://sites.${sistemalink}.com.br/confirmacao-comanda?invoice=${hashCode}`;
                                                var thisShortLink = '';
                                                /*$.ajax({
                                                	dataType: "json",
                                                	url: '/pages/cadastros/geraShortLink.php',
                                                	method: "POST",
                                                	async: false,
                                                	data: {
                                                		longlink: thisNewLink
                                                	},*/
                                                $.ajax({
                                                    dataType: "json",
                                                    url: '/pages/cadastros/geraShortLinkAWS.php',
                                                    method: "POST",
                                                    async: false,
                                                    data: {
                                                        longlink: thisNewLink,
                                                        pesCodigo: $_CONFIG.CODESTABELECIMENTO,
                                                        type: 1
                                                    },
                                                    success: function(data) {
                                                        thisShortLink = data.shortLink
                                                        linkconfirmacao = data.shortLink
                                                    }
                                                });

                                                $.ajax({
                                                    dataType: "json",
                                                    url: '/pages/cadastros/COMANDA_CONFIRMACAO_Insere.php',
                                                    method: "POST",
                                                    async: false,
                                                    data: {
                                                        invoice_code: calEvent.Com_Codigo,
                                                        short_link: thisShortLink,
                                                        long_link: thisNewLink
                                                    },
                                                    success: function(data) {
                                                        linkconfirmacao = thisShortLink
                                                    }
                                                });
                                            }
                                            var strMessage = $Options.whatsapp.agenda.replace("[{cliente}]", cliente)
                                                .replace("[{apelido}]", apelido)
                                                .replace("[{servico}]", servico)
                                                .replace("[{dataAge}]", dataAge)
                                                .replace("[{horaAge}]", horaAge)
                                                .replace("[{profissional}]", profissional)
                                                .replace("[{profissionalapelido}]", profissionalapelido)
                                                .replace("[{pontosfidelidade}]", pontosfidelidade)
                                                .replace("[{estabelecimento}]", $_CONFIG.ESTABELECIMENTO);
                                            var celular = result.data.scheduling[0].person_phone;

                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/buscaMensagemLayout.php",
                                                dataType: "json",
                                                async: false,
                                                data: {
                                                    tipo: 2,
                                                    tipolayout: 4
                                                },
                                                success: function(result) {
                                                    if (result.data.length > 0) {
                                                        if (result.data[0].MLa_Descricao != undefined) {
                                                            if (result.data[0].MLa_Descricao != "") {
                                                                var texto = (result.data[0].MLa_Descricao).replaceAll('{{cliente}}', cliente)
                                                                texto = texto.replaceAll('{{empresa}}', $_CONFIG.ESTABELECIMENTO)
                                                                texto = texto.replaceAll('{{sistema}}', sSistema)
                                                                texto = texto.replaceAll('{{profissional}}', profissional)
                                                                texto = texto.replaceAll('{{profissionalapelido}}', profissionalapelido)
                                                                texto = texto.replaceAll('{{pontosfidelidade}}', pontosfidelidade)
                                                                texto = texto.replaceAll('{{datahora}}', `${dataAge} ${horaAge}`)
                                                                texto = texto.replaceAll('{{servico}}', servico)
                                                                texto = texto.replaceAll('{{linkconfirmacao}}', linkconfirmacao)
                                                                texto = texto.replaceAll('{{apelido}}', apelido)
                                                                strMessage = unescapeUnicode(texto);
                                                            }
                                                        }
                                                    }
                                                },
                                                error: function(result) {

                                                }
                                            });
                                            sendWhatsReminder(celular, strMessage);
                                        }
                                    });



                                });
                            } else {
                                $("#sendWhatsappReminder").hide();
                            }

                            $scope.datahoraencaixe = calEvent.start;
                            $('#btnMaisProduto').show();
                            $('#btnReabrirAg').hide();
                            $('#informacao').show();
                            $('#infohorario-modal').modal();
                            $('#trEditaAgendamento').show();
                            $('#btnAssociaCliente').show();
                            $('#trTipoPagamento').hide();
                            $("#trComprovante").hide();
                            $('#tdDatCadastro').html('<b>' + calEvent.Age_Dat_Cadastro + '</b>');
                            if (calEvent.Age_Origem == 1) {
                                $('#tdOrigem').html('<i class="fa fa-apple"></i> iOS - Aplicativo do Profissional');
                            } else if (calEvent.Age_Origem == 3) {
                                $('#tdOrigem').html('<i class="fa fa-android"></i> Android - Aplicativo do Profissional');
                            } else if (calEvent.Age_Origem == 2) {
                                $('#tdOrigem').html('<i class="fa fa-desktop"></i> Web');
                            } else if (calEvent.Age_Origem == 4) {
                                $('#tdOrigem').html('<i class="fa fa-facebook-official"></i> Facebook/Site');
                            } else if (calEvent.Age_Origem == 5) {
                                $('#tdOrigem').html('<i class="fa fa-apple"></i> iOS - Prime');
                            } else if (calEvent.Age_Origem == 6) {
                                $('#tdOrigem').html('<i class="fa fa-android"></i> Android - Prime');
                            } else if (calEvent.Age_Origem == 8) {
                                $('#tdOrigem').html('<i class="fa fa-apple"></i> iOS - Aplicativo do Cliente');
                            } else if (calEvent.Age_Origem == 9) {
                                $('#tdOrigem').html('<i class="fa fa-android"></i> Android - Aplicativo do Cliente');
                            } else if (calEvent.Age_Origem == 10) {
                                $('#tdOrigem').html('<i class="fa fa-map-marker"></i> Totem');
                            }
                            if (calEvent.AOp_Sem_Chat == 1) {
                                $('#tdOrigem').append(`<br><b style="color:red">Este cliente optou por não conversar durante o atendimento</b>`);
                            }

                            $('.date.dateAltAge').datepicker('update', calEvent.start.format('DD/MM/YYYY'));
                            $scope.buscaAgendamentoTipoPagamento(calEvent.Com_Codigo);

                        } else if (calEvent.codStatus == '4') {
                            $scope.desbloquearHorario(calEvent.id);
                        } else if (calEvent.codStatus != '6') {
                            $('#lblUsuario').html(calEvent.usuario);
                            $('#lblCPFCliente').html(calEvent.PAF_CPF);

                            $('#lblIDAgendamento').html(calEvent.id);
                            $('#lblServico').html(calEvent.servico);
                            $('#lblProfissional').html(calEvent.resources);
                            $('#lblSerCodigo').html(calEvent.sercodigo);
                            $('#lblFim').html(calEvent.end.format('DD/MM/YYYY HH:mm'));
                            $('#lblObs').val(calEvent.obs);
                            $('#lblEmail').html(calEvent.email);
                            $('#lblCelular').html(calEvent.celular);
                            if (calEvent.celular != '') {
                                $("#btnAgendamentoWhats").attr('disabled', false)
                            } else {
                                $("#btnAgendamentoWhats").attr('disabled', true)
                            }
                            $('#lblValor').html($_CONFIG.MOEDA + calEvent.valor);
                            $('#lblValorHdn').html(calEvent.valor);
                            $('#lblPesCodigo').html(calEvent.codCliente);
                            $('#btnRealizadoAg').hide();
                            $('#btnAusenteAg').hide();
                            $('#btnCancelarAg').hide();
                            $('#btnMaisServico').hide();

                            $('#btnMaisProduto').hide();
                            $('#informacao').show();
                            $('#tdDatCadastro').html('<b>' + calEvent.Age_Dat_Cadastro + '</b>');
                            $('#infohorario-modal').modal();
                            if (calEvent.codStatus == '2' || calEvent.codStatus == '5') {
                                $('#btnReabrirAg').show();
                                $('#lblComCodigo').html(calEvent.Com_Codigo);
                                $("#comandaBotao").html(calEvent.Com_Codigo);
                                if (calEvent.codStatus == '5') {
                                    $('#lblCItCodigo').html(calEvent.CIt_Codigo);
                                }
                                $('#trEditaAgendamento').hide();
                                $('#btnAssociaCliente').hide();
                                $("#btnVerComandaAgendamentoFinalizado").show();
                                $("#btnVerComandaAgendamento").hide();

                                $scope.buscaAgendamentoTipoPagamento(calEvent.Com_Codigo);
                                if (calEvent.codStatus == '2') {

                                    $('#trTipoPagamento').show();
                                    if ($('#lblEmail').html() == "") {
                                        $("#trComprovante").show();

                                        $("#trComprovanteEmail").hide();
                                        $("#trComprovantePDF").show();
                                    } else {
                                        $("#trComprovante").show();

                                        $("#trComprovanteEmail").show();
                                        $("#trComprovantePDF").show();
                                    }
                                } else {
                                    $("#trComprovante").hide();
                                    $("#trComprovanteEmail").hide();
                                    $("#trComprovantePDF").hide();
                                }
                            } else {
                                $('#btnReabrirAg').hide();
                                $('#trEditaAgendamento').show();
                                $('#btnAssociaCliente').show();
                                $('#trTipoPagamento').hide();
                                $("#trComprovante").hide();
                                $("#trComprovanteEmail").hide();
                                $("#trComprovantePDF").hide();
                            }

                            if (calEvent.Age_Origem == 1) {
                                $('#tdOrigem').html('<i class="fa fa-apple"></i> iOS - Aplicativo do Profissional');
                            } else if (calEvent.Age_Origem == 3) {
                                $('#tdOrigem').html('<i class="fa fa-android"></i> Android - Aplicativo do Profissional');
                            } else if (calEvent.Age_Origem == 2) {
                                $('#tdOrigem').html('<i class="fa fa-desktop"></i> Web');
                            } else if (calEvent.Age_Origem == 4) {
                                $('#tdOrigem').html('<i class="fa fa-facebook-official"></i> Facebook/Site');
                            } else if (calEvent.Age_Origem == 5) {
                                $('#tdOrigem').html('<i class="fa fa-apple"></i> iOS - Prime');
                            } else if (calEvent.Age_Origem == 6) {
                                $('#tdOrigem').html('<i class="fa fa-android"></i> Android - Prime');
                            } else if (calEvent.Age_Origem == 8) {
                                $('#tdOrigem').html('<i class="fa fa-apple"></i> iOS - Aplicativo do Cliente');
                            } else if (calEvent.Age_Origem == 9) {
                                $('#tdOrigem').html('<i class="fa fa-android"></i> Android - Aplicativo do Cliente');
                            } else if (calEvent.Age_Origem == 10) {
                                $('#tdOrigem').html('<i class="fa fa-map-marker"></i> Totem');
                            }
                            if (calEvent.AOp_Sem_Chat == 1) {
                                $('#tdOrigem').append(`<br> <b style="color:red">Este cliente optou por não conversar durante o atendimento</b>`);
                            }

                        }
                    }
                }
                $('.popover').popover('hide');
            },
            eventAfterRender: (event, element, view) => {

                if (event.title !== undefined) {
                    event.title = unescapeUnicode(event.title.replaceAll("%20", " "));
                }

                if (event.CIt_Pag_Online == '1') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-credit-card-alt"></i> - ');
                }

                if (typeof(event.cupom) !== 'undefined' && event.cupom != '') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-ticket"></i> - ');
                }

                if (event.Age_Origem == '1') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-apple"></i> - ');
                    element.find('.fc-event-time').append(`<i class="fa fa-home pull-right" style="padding-top: 1pt; padding-right: 1pt;"></i> `);
                } else if (event.Age_Origem == '2') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-desktop"></i> - ');
                } else if (event.Age_Origem == '3') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-android"></i> - ');
                    element.find('.fc-event-time').append(`<i class="fa fa-home pull-right" style="padding-top: 1pt; padding-right: 1pt;"></i> `);
                } else if (event.Age_Origem == '4') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-facebook-official"></i> - ');
                } else if (event.Age_Origem == '5') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-apple"></i> - ');
                    element.find('.fc-event-time').append(`<i class="fa fa-user pull-right" style="padding-top: 1pt; padding-right: 1pt;"></i> `);
                } else if (event.Age_Origem == '6') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-android"></i> - ');
                    element.find('.fc-event-time').append(`<i class="fa fa-user pull-right" style="padding-top: 1pt; padding-right: 1pt;"></i> `);
                } else if (event.Age_Origem == '8') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-apple"></i> - ');
                    element.find('.fc-event-time').append(`<i class="fa fa-user pull-right" style="padding-top: 1pt; padding-right: 1pt;"></i> `);
                } else if (event.Age_Origem == '9') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-android"></i> - ');
                    element.find('.fc-event-time').append(`<i class="fa fa-user pull-right" style="padding-top: 1pt; padding-right: 1pt;"></i> `);
                } else if (event.Age_Origem == '10') {
                    element.find('.fc-event-time').prepend('<i class="fa fa-map-marker"></i> - ');
                }



                if (event.ass_multiunidade != '' && event.ass_multiunidade != undefined) {
                    element.find('.fc-event-time').prepend(`<i class="fa fa-star" style="background-color:#FFD700;border-radius:50%;padding:3px;color:black;"></i> `);
                } else {
                    if (event.assinatura != '' && event.assinatura != undefined) {
                        element.find('.fc-event-time').prepend(`<i class="fa fa-star" style="background-color:orange;border-radius:50%;padding:3px"></i> `);
                    }
                }
                if (event.inadimplente_assinatura_multi == '1' && event.inadimplente_assinatura_multi != undefined) {
                    element.find('.fc-event-time').prepend(`<i class="fa fa-star" style="background-color:#FF4500;border-radius:50%;padding:3px;color:black;"></i> `);
                } else {
                    if (event.inadimplente_assinatura == '1' && event.inadimplente_assinatura != undefined) {
                        element.find('.fc-event-time').prepend(`<i class="fa fa-star" style="background-color:#cd0707;border-radius:50%;padding:3px"></i> `);
                    }
                }


                if (event.isPacote != '' && event.isPacote != undefined && event.isPacote == 1) {
                    element.find('.fc-event-time').prepend(`<i class="fa fa-gift" ></i> `);
                }

                if (event.isAniversario != '' && event.isAniversario != undefined && event.isAniversario == 1) {
                    element.find('.fc-event-time').prepend(`<i class="fa fa-birthday-cake" ></i> `);
                }

                if (event.AOp_Sem_Chat == 1) {
                    element.find('.fc-event-time').prepend(`<i class="fa fa-microphone-slash" style="background-color:white;border-radius:50%;padding:3px;color:red"></i> `);
                }

            },
            viewRender: (view, element) => {

                var dataSelecionada = moment(view.calendar.getDate().format()).toDate();
                if (view.name == 'resourceDay') {

                    $('#dvCalendario').datepicker('setDate', dataSelecionada);
                }

                try {
                    setDateTimeZone();
                } catch (err) {}
                $('.fc-header').hide();
                $scope.fixNameProf();
                $scope.isAgendamentoAntigo(1);

                $($('.fc-view').children().get(1)).children().css({
                    overflow: 'hidden'
                });
            },
            eventRender: (event, element) => {
                if ((event.codStatus == '1')) {
                    event.editable = true;
                    event.durationEditable = true;
                } else {
                    event.editable = false;
                    event.durationEditable = false;
                }
                var originalClass = element[0].className;
                if (event.codStatus == '1') {
                    if (event.Age_Confirmado == '1') {
                        element[0].className = originalClass + ' hasmenu-confirmado';
                    } else if (event.Encaixe == '1') {
                        element[0].className = originalClass + ' hasmenu-encaixe';
                    } else {
                        element[0].className = originalClass + ' hasmenu';
                    }
                } else if ((event.codStatus == '2') || (event.codStatus == "5")) {
                    element[0].className = originalClass + ' hasmenu-realizado';
                } else if (event.codStatus == '4') {
                    element[0].className = originalClass + ' hasmenu-bloqueado';
                }
                element[0].dataset.agecodigo = event.id;
            },
            resourceFilter: (resource) => {
                active = $('#users_menu option:selected').map((a, item) => {
                    return item.value;
                }).get();
                return $.inArray(resource.id, active) > -1;
            },
            select: (startDate, endDate, jsEvent, view) => {
                selecionaHorarioAgenda(startDate, endDate, jsEvent.data.id, view)
            }
        });
    }

    $scope.stateTagColor = "#ebebeb";
    var colorPicker = new iro.ColorPicker("#picker", {
        width: 150,
        color: "#ebebeb",
        borderWidth: 1,
        borderColor: "#fff",
        layout: [{
            component: iro.ui.Wheel,
        }, ]
    });

    colorPicker.on('color:setActive', function(color) {
        $scope.stateTagColor = color.hexString;
    });
    colorPicker.on('input:end', function(color) {
        $scope.stateTagColor = color.hexString;
    });

    colorPicker.on('color:change', function(color) {
        $("#tagExemplo").css('background-color', color.hexString);
    });


    var initContextMenu = () => {

        loadPayments();
        loadPaymentsEncaixe();
        loadPaymentsConfirmado();

        $.contextMenu({
            selector: '.hasmenu-realizado',
            callback: (key, options) => {
                eventSel = $('#calendar').fullCalendar('clientEvents', options.$trigger[0].dataset.agecodigo)[0];

                $('#lblIDAgendamento').html(options.$trigger[0].dataset.agecodigo);
                if (key == 'reabrir') {

                    $('#lblComCodigo').html(eventSel.Com_Codigo);
                    $('#lblCItCodigo').html(eventSel.CIt_Codigo);
                    $('#btnReabrirAg').click();
                } else if (key == 'addtag') {
                    $('#addtagagendamento-modal').modal();
                    colorPicker.reset()
                    $scope.stateTagColor = "#ebebeb";
                    $("#AgeCodigoTagAgendamento").val(eventSel.id)
                } else if (key == 'agradecimento') {
                    var strMessage = '';
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/AGENDAMENTO_Busca.php",
                        data: {
                            type: 1,
                            scheduling_code: eventSel.id
                        },
                        dataType: "json",
                        success: (result) => {
                            var cliente = result.data.scheduling[0].person_name;
                            var celular = result.data.scheduling[0].person_phone;
                            var pesquisa = result.data.scheduling[0].survey_code;
                            var hash_pesquisa = result.data.scheduling[0].hash_code_survey;
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/buscaMensagemLayout.php",
                                dataType: "json",
                                async: false,
                                data: {
                                    tipo: 2,
                                    tipolayout: 9
                                },
                                success: function(result) {
                                    if (result.data.length > 0) {
                                        if (result.data[0].MLa_Descricao != undefined) {
                                            if (result.data[0].MLa_Descricao != "") {
                                                var texto = (result.data[0].MLa_Descricao).replaceAll('{{cliente}}', cliente)
                                                texto = texto.replaceAll('{{empresa}}', $_CONFIG.ESTABELECIMENTO)
                                                texto = texto.replaceAll('{{sistema}}', sSistema)
                                                if (pesquisa != '') {
                                                    var sistema = sSistema.toLowerCase()
                                                    //var thisNewLink = `https://sistema.${sistema}.com.br/avaliar/index.html?i=${$_CONFIG.ID}&a=${pesquisa}`;
                                                    var thisNewLink = `https://sites.${sistema}.com.br/pesquisa-satisfacao?survey=${hash_pesquisa}`;
                                                    var thisShortLink = '';
                                                    /*$.ajax({
                                                    	dataType: "json",
                                                    	url: '/pages/cadastros/geraShortLink.php',
                                                    	method: "POST",
                                                    	async: false,
                                                    	data: {
                                                    		longlink: thisNewLink
                                                    	},*/
                                                    $.ajax({
                                                        dataType: "json",
                                                        url: '/pages/cadastros/geraShortLinkAWS.php',
                                                        method: "POST",
                                                        async: false,
                                                        data: {
                                                            longlink: thisNewLink,
                                                            pesCodigo: $_CONFIG.CODESTABELECIMENTO,
                                                            type: 4
                                                        },
                                                        success: function(data) {
                                                            thisShortLink = data.shortLink
                                                            linkconfirmacao = data.shortLink
                                                        }
                                                    });

                                                    texto = texto.replaceAll('{{linksatisfacao}}', thisShortLink)
                                                } else {
                                                    texto = texto.replaceAll('{{linksatisfacao}}', '')
                                                }
                                                strMessage = unescapeUnicode(texto);
                                            }
                                        }
                                    }
                                },
                                error: function(result) {}
                            });
                            sendWhatsReminder(celular, strMessage);
                        }
                    });
                }
            },
            items: {
                'reabrir': {
                    name: 'Reabrir',
                    icon: 'fa-check'
                },
                'addtag': {
                    name: 'Adicionar Tag',
                    icon: 'fa-tag'
                },
                'agradecimento': {
                    name: 'Mensagem de agradecimento',
                    icon: 'fa-whatsapp'
                }
            }
        });

        $.contextMenu({
            selector: '.hasmenu-bloqueado',
            callback: (key, options) => {
                eventSel = $('#calendar').fullCalendar('clientEvents', options.$trigger[0].dataset.agecodigo)[0];

                if (key == 'desbloquear') {
                    $scope.desbloquearHorario(options.$trigger[0].dataset.agecodigo);
                } else if (key == 'observacao') {
                    $("#idAgendamentoAlteraObs").val(options.$trigger[0].dataset.agecodigo)
                    $('#aletraAgendamentoObs-modal').modal('show');
                } else if (key == 'addtag') {
                    $('#addtagagendamento-modal').modal();
                    colorPicker.reset()
                    $scope.stateTagColor = "#ebebeb";
                    $("#AgeCodigoTagAgendamento").val(eventSel.id)
                }
            },
            items: {
                'desbloquear': {
                    name: 'Desbloquear',
                    icon: 'fa-unlock'
                },
                'observacao': {
                    name: 'Observação',
                    icon: 'fa-comment'
                },
                'addtag': {
                    name: 'Adicionar Tag',
                    icon: 'fa-tag'
                }
            }
        });

    }


    $('#servico_menuRecorrente').change((e) => {
        var tempoPadrao = parseInt($_CONFIG.TEMPOPADRAO);
        var tempoServico = parseInt(e.currentTarget.options[e.currentTarget.selectedIndex].dataset.tempo);
        if (isNaN(tempoServico)) {
            tempoServico = undefined;
        }
        if (tempoServico != undefined && tempoServico != "") {
            var html = '';
            for (var i = tempoPadrao; i < tempoPadrao * 15; i = i + tempoPadrao) {

                if (i == tempoServico) {
                    html += '<option value="' + i + '" selected>' + i + ' Minutos</option>';
                } else {
                    html += '<option value="' + i + '">' + i + ' Minutos</option>';
                }
            }

            $('#duracaoAgendamentoRecorrente').prop('disabled', false);
        } else {

            var html = '<option value="">Duração</option>';
            $('#duracaoAgendamentoRecorrente').prop('disabled', true);
        }
        $('#duracaoAgendamentoRecorrente').html(html);

        $('#duracaoAgendamentoRecorrente').val(tempoServico).trigger('change');
    });

    $('#servico_menuRecorrente').change();

    function setDateTimeZone() {

        if (curTimeZone != undefined) {
            drawTimeLine(curTimeZone);
        } else {

            fetch('/php/timezone.php')
                .then(data => data.json())
                .then((data) => {

                    if (data.error == "0") {
                        curTimeZone = new Date(data.datetime);
                    } else {
                        curTimeZone = new Date();
                    }

                    localStorage.setItem("lastDateRedLine", new Date().getTime());

                    clearInterval(intervalTimeZone);
                    intervalTimeZone = null;
                    intervalTimeZone = setInterval(
                        function() {

                            var lastDateRedLine = parseInt(localStorage.getItem('lastDateRedLine'));

                            if ((new Date().getTime() - lastDateRedLine) > 120000) {
                                curTimeZone = undefined;
                                setDateTimeZone();
                            } else {
                                localStorage.setItem("lastDateRedLine", new Date().getTime());
                                curTimeZone = new Date(curTimeZone.getTime() + 60000);
                                drawTimeLine(curTimeZone);
                            }
                        }, 60000);



                    drawTimeLine(curTimeZone);

                });
        }
    }

    function drawTimeLine(curTime) {

        var parentDiv = jQuery(".fc-agenda-slots:visible").parent();
        var timeline = parentDiv.children(".timelineAgenda");
        if (timeline.length == 0) {
            timeline = jQuery("<hr>").addClass("timelineAgenda").attr("data-toggle", "popover").attr("data-trigger", "hover").attr("tabindex", "0").attr("data-placement", "top").attr("data-content", "Hora Atual");
            parentDiv.prepend(timeline);
            $('[data-toggle="popover"]').popover({
                container: 'body'
            });
        }

        var curCalView = jQuery("#calendar").fullCalendar('getView');
        if (curCalView.start.toDate() < curTime && curCalView.end.toDate() > curTime) {
            timeline.show();
        } else {
            timeline.hide();
            return;
        }

        var minTimeCalendar = curCalView.opt("minTime");
        var mAuxCalendar = minTimeCalendar.substring(0, minTimeCalendar.length - 3);
        var hourMinCalendar = mAuxCalendar.split(":");

        var hourCalendar = parseInt(hourMinCalendar[0]);
        var minuteCalendar = parseInt(hourMinCalendar[1]);

        var percentHourMinCalendar = hourCalendar + (minuteCalendar / 60);

        var maxTimeCalendar = curCalView.opt("maxTime");
        var mAuxCalendarMax = maxTimeCalendar.substring(0, maxTimeCalendar.length - 3);
        var hourMaxCalendar = mAuxCalendarMax.split(":");


        var hourCalendarMax = parseInt(hourMaxCalendar[0]);
        var minuteCalendarMaxAux = parseInt(hourMaxCalendar[1]);

        var momInit = new moment();
        var momEnd = new moment();

        momInit.set('hour', hourCalendar);
        momInit.set('minute', minuteCalendar);
        momInit.set('second', 0);

        momEnd.set('hour', hourCalendarMax);
        momEnd.set('minute', minuteCalendarMaxAux);
        momEnd.set('second', 0);

        var diffHours = momEnd.diff(momInit);

        var diffHoursSum = ((diffHours / 1000) / 60) % parseInt($_CONFIG.TEMPOPADRAO);

        var minuteCalendarMax = parseInt(hourMaxCalendar[1]) + ((diffHoursSum > 0) ? (parseInt($_CONFIG.TEMPOPADRAO) - diffHoursSum) : 0);

        var percentHourMaxCalendar = hourCalendarMax + (minuteCalendarMax / 60);

        var curSeconds = (((curTime.getHours() - percentHourMinCalendar) * 60 * 60) + (curTime.getMinutes() * 60) + curTime.getSeconds());
        var percentOfDay = curSeconds / ((percentHourMaxCalendar - percentHourMinCalendar) * 3600);
        var topLoc = Math.floor(parentDiv.height() * percentOfDay);
        var timeCol = $('.fc-time:visible');
        timeline.css("top", topLoc + "px");

        if (curCalView.name == "agendaWeek") {
            var dayCol = jQuery(".fc-today:visible");
            var left = dayCol.position().left + 1;
            var width = dayCol.width() - 2;
            timeline.css({
                left: left + "px",
                width: width + "px"
            });
        }

    }

    $(".cliqueBotao").click(function() {
        setTimeout(() => {
            $scope.geraComboPaisTelefone("cliCelular", "cliDialCode")
        }, 1000);
    })

    $("#edtPeriodicidadeBloqueado").change(function() {
        if ($("#edtPeriodicidadeBloqueado").val() <= 0) {
            $("#edtPeriodicidadeBloqueado").val(1)
        }
        if ($("#edtPeriodicidadeBloqueado").val() > 30) {
            $("#edtPeriodicidadeBloqueado").val(30)
        }

    })

    $("#edtPeriodicidadeBloqueado").keyup(function() {
        if ($("#edtPeriodicidadeBloqueado").val() <= 0) {
            $("#edtPeriodicidadeBloqueado").val(1)
        }
        if ($("#edtPeriodicidadeBloqueado").val() > 30) {
            $("#edtPeriodicidadeBloqueado").val(30)
        }
    })



    $scope.addTagAgendamento = function() {

        if ($("#tagAgendamentoText").val() != '') {

            $.ajax({
                dataType: "json",
                url: "/pages/cadastros/insereAgendamentoTag.php",
                type: 'POST',

                data: {
                    agecodigo: $("#AgeCodigoTagAgendamento").val(),
                    cor: $scope.stateTagColor,
                    descricao: $("#tagAgendamentoText").val()
                },
                success: (data) => {
                    if (data.data.length > 0) {
                        if (data.data[0].erro == 0) {
                            toastr.success(data.data[0].resultado)


                            $.ajax({
                                dataType: "json",
                                url: "/pages/cadastros/buscaAgendamentoTag.php",
                                type: 'GET',
                                async: false,
                                data: {
                                    agecodigo: $("#AgeCodigoTagAgendamento").val(),
                                    id: $_CONFIG.ID
                                },
                                success: (data) => {
                                    if (data.data.length > 0) {
                                        var tagcontent = "";
                                        for (var i = 0; i < data.data.length; i++) {

                                            tagcontent = tagcontent + `<label class="label" id="tagLabel${data.data[i].ATa_Codigo}" style="background-color:${data.data[i].ATa_Cor}">${data.data[i].ATa_Descricao} &nbsp<i class="fa fa-times pointer" ng-click="removeTagAgendamento(${data.data[i].ATa_Codigo})"></i> </label> &nbsp`
                                        }
                                        $("#listaTagsAgendamento").html(tagcontent)
                                        $compile($('#listaTagsAgendamento'))($scope);
                                    }
                                }
                            });


                            $scope.isAgendamentoAntigo(2)


                            $("#addtagagendamento-modal").modal('hide');
                            $("#tagAgendamentoText").val('')
                        } else {
                            toastr.error(data.data[0].resultado)
                        }
                    }
                }
            });
        } else {
            toastr.error("Favor informe uma descrição para a tag")
        }


    }

    $scope.removeTagAgendamento = function(value) {
        $.ajax({
            dataType: "json",
            url: "/pages/cadastros/removeAgendamentoTag.php",
            type: 'POST',
            data: {
                codigo: value
            },
            success: (data) => {
                if (data.data.length > 0) {
                    if (data.data[0].erro == 0) {
                        toastr.success(data.data[0].resultado)
                        $(`#tagLabel${value}`).remove()
                        $(`#tagLabelPopUp${value}`).remove()
                    } else {
                        toastr.error(data.data[0].resultado)
                    }
                }
            }
        });

    }

    $scope.newTagAgendamento = function() {
        $('#addtagagendamento-modal').modal();
        colorPicker.reset()
        $scope.stateTagColor = "#ebebeb";
        $("#AgeCodigoTagAgendamento").val($("#lblIDAgendamento").html())

    }


    $scope.displayModalListaEspera = function() {
        $("#dataListaEspera").html(moment($('#dvCalendario').datepicker('getDate')).locale("pt-br").format("L"))
        $('.divDataListaAgenda').datepicker('update', moment($('#dvCalendario').datepicker('getDate')).locale("pt-br").format("L"));
        $scope.buscaServicoListaAgendamento();
        if (typeof(tabelaListaf) != "undefined") {
            tabelaListaf.destroy();
        }
        tabelaListaf = $('#tbBuscaListaAgenda').DataTable({
            "dom": 'T<"clear">lfrtip',
            "ajax": {
                "url": './pages/cadastros/buscaListaEspera.php',
                "method": "POST",
                "data": function(d) {
                    d.dataIni = moment($('#dvCalendario').datepicker('getDate')).locale("pt-br").format("L");
                    d.dataFim = moment($('#dvCalendario').datepicker('getDate')).locale("pt-br").format("L");
                }
            },
            "order": [
                [0, "asc"]
            ],
            "columnDefs": [{
                "targets": [0],
                "visible": false,
                "searchable": false
            }],
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json"
            },
            initComplete: function() {
                $compile($('#tbBuscaListaAgenda'))($scope);
                $("#tbBuscaFil_paginate").click(function() {
                    $compile($('#tbBuscaListaAgenda'))($scope);
                });
                $("#tbBuscaFil_filter").change(function() {
                    $compile($('#tbBuscaListaAgenda'))($scope);
                });
                $("#tbBuscaFil_length").change(function() {
                    $compile($('#tbBuscaListaAgenda'))($scope);
                });
                $('[data-toggle="popover"]').popover();
            },
            "fnRowCallback": function(nRow, aData) {

                var id = aData.LEs_Enviado;
                // ID is returned by the server as part of the data
                var $nRow = $(nRow); // cache the row wrapped up in jQuery

                if (id == "Sim") {

                    nRow.children[9].children[0].style.display = 'none';

                    nRow.children[9].className = '';
                }

                return nRow
            },
            "columns": [{
                    "data": "LEs_Codigo",
                    "title": "Codigo"
                },
                {
                    "data": "LEs_Descricao",
                    "title": "Descricao"
                },
                {
                    "data": "LEs_Dat_Cadastro",
                    "title": "Data de Cadastro"
                },
                {
                    "data": "LEs_Data",
                    "title": "Data"
                },
                {
                    "data": "Pes_Nome",
                    "title": "Cliente"
                },
                {
                    "data": "Celular",
                    "title": "Celular"
                },
                {
                    "data": "Usu_Nome",
                    "title": "Cadastrou"
                },
                {
                    "data": "Ser_Descricao",

                    "title": "Servico"
                }, {
                    "data": "Profissional",

                    "title": "Profissional"
                },
                {
                    "data": "LEs_Enviado",
                    "title": "Enviado"
                },
                {
                    "class": 'enviawhats',
                    "orderable": false,
                    "data": null,
                    "defaultContent": "<i class='fa fa-whatsapp' style='cursor:pointer;' data-toggle='popover' data-trigger='hover' data-container='body' data-placement='top' data-content='Enviar mensagem'></i>"
                },
                {
                    "class": 'alterar',
                    "orderable": false,
                    "data": null,
                    "title": "Alterar",
                    "defaultContent": "<i class='fa fa-pencil' style='cursor:pointer;' data-toggle='popover' data-trigger='hover' data-container='body' data-placement='top' data-content='Alterar'></i>"
                },
                {
                    "class": 'remover',
                    "orderable": false,
                    "data": null,

                    "title": "Remover",
                    "defaultContent": "<i class='ion ion-close-circled' style='cursor:pointer;color:red;'  data-toggle='popover' data-trigger='hover' data-container='body' data-placement='top' data-content='Remover da Lista'></i>"
                }
            ]
        });

        $('#tbBuscaListaAgenda tbody').on('click', 'td.enviawhats', function() {
            var tr = $(this).closest('tr');
            var row = tabelaListaf.row(tr);
            var data = row.data();
            $scope.sendWhatsCliente(data.Celular)
        });

        $('#tbBuscaListaAgenda tbody').on('click', 'td.remover', function() {
            var tr = $(this).closest('tr');
            var row = tabelaListaf.row(tr);
            var data = row.data();
            swal({
                    title: "Deseja realmente retirar o cliente da lista?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Sim",
                    cancelButtonText: "Não",
                    closeOnConfirm: true
                },
                function() {
                    showLoader(true);
                    $.ajax({
                        dataType: "json",
                        method: "POST",
                        url: '/pages/cadastros/removeListaEspera.php',
                        data: {
                            lescodigo: data.LEs_Codigo
                        },
                        success: function(data) {
                            if (data.data[0].erro == "0") {
                                toastr["success"]("Lista atualizada com Sucesso.");
                                tabelaListaf.ajax.reload()
                            } else {
                                swal("Falha ao atualizar.", data, "error");
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            swal("Falha na conexão.", "", "error");
                            showLoader(false);
                        }
                    });
                });
        });

        $('#tbBuscaListaAgenda tbody').on('click', 'td.alterar', function() {
            var tr = $(this).closest('tr');
            var row = tabelaListaf.row(tr);
            var data = row.data();
            $("#CodigoListaEspera").val(data.LEs_Codigo);
            $("#servicoListaEsperaAltera").val(data.Ser_Codigo);
            $("#DataListaEsperaAltera").val(data.LEs_Data);
            $("#ObsListaEsperaAltera").val(data.LEs_Descricao);
            $("#servicoListaEsperaAltera").change();
            $("#alteraClienteListaAgenda-modal").modal();
        });

        $('#modalListaEspera-modal').modal();

    }


    $('#formListaEsperaAgenda').submit(function(event) {
        event.preventDefault();
        showLoader(true);
        formLista = $(this)
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/insereListaEspera.php",
            data: {
                DataLista: $("#DataListaAgenda").val(),
                ObsLista: $("#ObsListaDataAgenda").val(),
                pesCodigoCliente: $("#pesCodigoClienteListaAgenda").val(),
                usucodigo: $("#pesCodigoClienteListaAgenda option:selected").get(0).dataset.usucodigo,
                servico: $("#servicoListaAgenda").val()
            },
            dataType: "json",

            success: function(result) {
                if (result.data[0].erro == "0") {
                    tabelaListaf.ajax.reload();
                    toastr.success(result.data[0].resultado);
                    $('#insereClienteListaAgenda-modal').modal("hide");
                    formLista.each(function() {
                        this.reset();
                    });
                } else {
                    toastr.error(result.data[0].resultado);
                }
                showLoader(false);
            },
            error: function(result) {
                toastr.error("Falha na conexão.");
                showLoader(false);
            }
        });
        return true;
    });


    $('#formAlteraListaEsperaAgenda').submit(function(event) {
        event.preventDefault();
        showLoader(true);
        formListaAltera = $(this)
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/alteraListaEspera.php",
            data: {
                lescodigo: $("#CodigoListaEspera").val(),
                DataListaAlt: $("#DataListaEsperaAltera").val(),
                ObsListaAlt: $("#ObsListaEsperaAltera").val(),
                servicoAlt: $("#servicoListaEsperaAltera").val()
            },
            dataType: "json",
            success: function(result) {
                if (result.data[0].erro == "0") {
                    tabelaListaf.ajax.reload();
                    toastr.success(result.data[0].resultado);
                    $('#alteraClienteListaAgenda-modal').modal("hide");
                    formListaAltera.each(function() {
                        this.reset();
                    });
                } else {
                    toastr.error(result.data[0].resultado);
                }
                showLoader(false);
            },
            error: function(result) {
                toastr.error("Falha na conexão.");
                showLoader(false);
            }
        });
        return true;
    });

    $scope.atualizaDadosListaEspera = function() {
        tabelaListaf.ajax.reload();
    }

    $scope.insereClienteListaEsperaAgenda = function() {
        $("#insereClienteListaAgenda-modal").modal();
        $scope.buscaClienteLista();
    }

    function loadPayments() {

        fetch('/pages/cadastros/buscaTipoPagamentoBandeiraFinalizarComanda.php')
            .then(data => data.json())
            .then((data) => {
                var arrayTpa = {};

                var tipoPagamentos = data.result.filter((data) => {
                    return data.PagamentoBandeira == ""
                });
                tipoPagamentos.forEach((pagamento) => {

                    if (pagamento.TPa_Cartao == "1") {
                        var bandeiras = data.result.filter((bandeira) => {
                            return bandeira.PagamentoBandeira == pagamento.TPa_Codigo
                        });
                        var arrayTBa = {};

                        if (bandeiras.length > 0) {

                            bandeiras.forEach((bandeira) => {
                                arrayTBa[bandeira.TPa_Codigo] = {
                                    name: bandeira.TPa_Descricao,
                                    codigo: pagamento.TPa_Codigo
                                };
                            });

                            arrayTpa[pagamento.TPa_Codigo] = {
                                name: pagamento.TPa_Descricao,
                                items: arrayTBa
                            };
                        } else {
                            arrayTpa[pagamento.TPa_Codigo] = {
                                name: pagamento.TPa_Descricao,
                                codigo: pagamento.TPa_Codigo
                            };
                        }

                    } else {
                        arrayTpa[pagamento.TPa_Codigo] = {
                            name: pagamento.TPa_Descricao,
                            codigo: pagamento.TPa_Codigo
                        };
                    }

                });

                // return arrayTpa;
                $.contextMenu({
                    selector: '.hasmenu',
                    callback: (key, options) => {
                        eventSel = $('#calendar').fullCalendar('clientEvents', options.$trigger[0].dataset.agecodigo)[0];
                        $('#lblIDAgendamento').html(options.$trigger[0].dataset.agecodigo);

                        if (key == 'realizado') {
                            $('#lblValorHdn').html(eventSel.valor);
                            $('#lblPesCodigo').html(eventSel.codCliente);
                            $('#btnRealizadoAg').click();
                        } else if (key == 'ausente') {
                            $('#btnAusenteAg').click();
                        } else if (key == 'cancelado') {
                            $('#btnCancelarAg').click();
                        } else if (key == 'confirmado') {
                            $('#btnConfirmaAg').click();
                        } else if (key == 'preferencia') {
                            $('#btnPreferenciaAg').click();
                        } else if (key == 'alt-encaixe') {
                            $('#btnAlteraEncaixe').click();
                        } else if (key == 'encaixe') {
                            $('#idComanda').html(eventSel.Com_Codigo);
                            $('#btnFechaItemComandaSer').hide();
                            $('#btnFechaServicoModal').show();
                            insereServicoComanda(0, eventSel.start);
                        } else if (key == 'venda') {
                            $('#comCodigoInsert').val(eventSel.Com_Codigo);

                            $('#TprTipoComanda').html('1')
                            $('#treAgendaCodigo').html('1');
                            $scope.buscaProdutoCombo();
                            $('#comanda-modal').modal('hide');
                            $('#comandaInsert-modal').modal('show');
                            $('#insereProdutoOrigem').val(0);
                            $('#btnFechaItemComandaModal').show();
                            $('#btnFechaItemComanda').hide();
                        } else if (key == 'addtag') {
                            $("#AgeCodigoTagAgendamento").val(eventSel.id)
                            colorPicker.reset()
                            $scope.stateTagColor = "#ebebeb";
                            $('#addtagagendamento-modal').modal();
                        } else if (key == 'nolocal') {
                            $('#btnNoLocal').click();
                        } else {

                            var pagamentoSelecionado = options.commands[key];

                            showLoader(true);
                            $.ajax({
                                dataType: "json",
                                url: "/pages/actions/buscaAgendamentoTipoPagamento.php",
                                type: 'POST',
                                data: {
                                    comanda: eventSel.Com_Codigo,
                                },
                                success: (data) => {
                                    var codigoBandeira = "";

                                    if (key != pagamentoSelecionado.codigo) {
                                        codigoBandeira = key;
                                    }

                                    $.ajax({
                                        dataType: 'json',
                                        method: "POST",
                                        url: '/pages/cadastros/atualizaComandav3.php',
                                        data: {
                                            comcodigo: eventSel.Com_Codigo,
                                            tpacodigo: pagamentoSelecionado.codigo,
                                            inserecaixa: 1,
                                            inserecontacli: 0,
                                            inserecaixinha: 0,
                                            valorpagamento: data.result[0].ValorComanda.replace(',', '.'),
                                            tbacodigo: codigoBandeira,
                                            tipo: 1,
                                            parcelado: 0,
                                            qtdparcela: 1,
                                            transacao: '',
                                            motivo: '',

                                            numpagamento: 1
                                        },
                                        success: (data) => {
                                            showLoader(false);

                                            if (data.data[0].erro == "0") {
                                                toastr.success(data.data[0].resultado);
                                                $scope.atualizaEventos()
                                            } else {
                                                toastr.error(data.data[0].resultado);
                                            }
                                        },
                                        error: () => {
                                            showLoader(false);
                                        }
                                    })
                                },
                                error: () => {
                                    showLoader(false);
                                }
                            });
                        }
                    },
                    items: {
                        'realizado': {
                            name: 'Abrir Comanda',
                            icon: 'fa-clipboard'
                        },
                        'finalizaAutomatico': {
                            name: 'Finalizar Comanda',
                            icon: 'fa-check',
                            items: arrayTpa
                        },
                        'ausente': {
                            name: 'Ausente',
                            icon: 'fa-close'
                        },
                        'cancelado': {
                            name: 'Cancelado',
                            icon: 'fa-trash-o'
                        },
                        'confirmado': {
                            name: 'Confirmar',
                            icon: 'fa-thumbs-up'
                        },
                        'preferencia': {
                            name: 'Sem Preferência',
                            icon: 'fa-hand-pointer-o'
                        },
                        'encaixe': {
                            name: 'Encaixe',
                            icon: 'fa-scissors'
                        },
                        'venda': {
                            name: 'Venda',
                            icon: 'fa-shopping-cart'
                        },
                        'alt-encaixe': {
                            name: 'Alterar para Encaixe',
                            icon: 'fa-puzzle-piece'
                        },
                        'addtag': {
                            name: 'Adicionar Tag',
                            icon: 'fa-tag'
                        },
                        'nolocal': {
                            name: 'No Local',
                            icon: 'fa-map-marker'
                        }
                    }
                });
            });



    }

    function loadPaymentsEncaixe() {

        fetch('/pages/cadastros/buscaTipoPagamentoBandeiraFinalizarComanda.php')
            .then(data => data.json())
            .then((data) => {
                var arrayTpa = {};

                var tipoPagamentos = data.result.filter((data) => {
                    return data.PagamentoBandeira == ""
                });
                tipoPagamentos.forEach((pagamento) => {

                    if (pagamento.TPa_Cartao == "1") {
                        var bandeiras = data.result.filter((bandeira) => {
                            return bandeira.PagamentoBandeira == pagamento.TPa_Codigo
                        });
                        var arrayTBa = {};

                        if (bandeiras.length > 0) {

                            bandeiras.forEach((bandeira) => {
                                arrayTBa[bandeira.TPa_Codigo] = {
                                    name: bandeira.TPa_Descricao,
                                    codigo: pagamento.TPa_Codigo
                                };
                            });

                            arrayTpa[pagamento.TPa_Codigo] = {
                                name: pagamento.TPa_Descricao,
                                items: arrayTBa
                            };
                        } else {
                            arrayTpa[pagamento.TPa_Codigo] = {
                                name: pagamento.TPa_Descricao,
                                codigo: pagamento.TPa_Codigo
                            };
                        }

                    } else {
                        arrayTpa[pagamento.TPa_Codigo] = {
                            name: pagamento.TPa_Descricao,
                            codigo: pagamento.TPa_Codigo
                        };
                    }

                });

                $.contextMenu({
                    selector: '.hasmenu-encaixe',
                    callback: (key, options) => {
                        eventSel = $('#calendar').fullCalendar('clientEvents', options.$trigger[0].dataset.agecodigo)[0];
                        $('#lblIDAgendamento').html(options.$trigger[0].dataset.agecodigo);
                        if (key == 'realizado') {
                            $('#lblValorHdn').html(eventSel.valor);
                            $('#lblPesCodigo').html(eventSel.codCliente);
                            $('#btnRealizadoAg').click();
                        } else if (key == 'ausente') {
                            $('#btnAusenteAg').click();
                        } else if (key == 'cancelado') {
                            $('#btnCancelarAg').click();
                        } else if (key == 'confirmado') {
                            $('#btnConfirmaAg').click();
                        } else if (key == 'preferencia') {
                            $('#btnPreferenciaAg').click();
                        } else if (key == 'encaixe') {
                            $('#idComanda').html(eventSel.Com_Codigo);
                            $('#btnFechaItemComandaSer').hide();
                            $('#btnFechaServicoModal').show();
                            insereServicoComanda(0, eventSel.start);
                        } else if (key == 'venda') {
                            $('#comCodigoInsert').val(eventSel.Com_Codigo);
                            $('#TprTipoComanda').html('1')
                            $('#treAgendaCodigo').html('1');
                            $scope.buscaProdutoCombo();
                            $('#comanda-modal').modal('hide');
                            $('#comandaInsert-modal').modal('show');
                            $('#insereProdutoOrigem').val(0);
                            $('#btnFechaItemComandaModal').show();
                            $('#btnFechaItemComanda').hide();
                        } else if (key == 'addtag') {
                            $('#addtagagendamento-modal').modal();
                            colorPicker.reset()
                            $scope.stateTagColor = "#ebebeb";
                            $("#AgeCodigoTagAgendamento").val(eventSel.id)
                        } else if (key == 'nolocal') {
                            $('#btnNoLocal').click();
                        } else {

                            var pagamentoSelecionado = options.commands[key];

                            showLoader(true);
                            $.ajax({
                                dataType: "json",
                                url: "/pages/actions/buscaAgendamentoTipoPagamento.php",
                                type: 'POST',
                                data: {
                                    comanda: eventSel.Com_Codigo
                                },
                                success: (data) => {
                                    var codigoBandeira = "";

                                    if (key != pagamentoSelecionado.codigo) {
                                        codigoBandeira = key;
                                    }

                                    $.ajax({
                                        dataType: 'json',
                                        method: "POST",
                                        url: '/pages/cadastros/atualizaComandav3.php',
                                        data: {
                                            comcodigo: eventSel.Com_Codigo,
                                            tpacodigo: pagamentoSelecionado.codigo,
                                            inserecaixa: 1,
                                            inserecontacli: 0,
                                            inserecaixinha: 0,
                                            valorpagamento: data.result[0].ValorComanda.replace(',', '.'),
                                            tbacodigo: codigoBandeira,
                                            tipo: 1,
                                            parcelado: 0,
                                            qtdparcela: 1,
                                            transacao: '',
                                            motivo: '',
                                            numpagamento: 1
                                        },
                                        success: (data) => {
                                            showLoader(false);
                                            if (data.data[0].erro == "0") {
                                                toastr.success(data.data[0].resultado);
                                                $scope.isAgendamentoAntigo(2);
                                            } else {
                                                toastr.error(data.data[0].resultado);
                                            }
                                        },
                                        error: () => {
                                            showLoader(false);
                                        }
                                    })
                                },
                                error: () => {
                                    showLoader(false);
                                }
                            });
                        }
                    },
                    items: {
                        'realizado': {
                            name: 'Abrir Comanda',
                            icon: 'fa-clipboard'
                        },
                        'finalizaAutomatico': {
                            name: 'Finalizar Comanda',
                            icon: 'fa-check',
                            items: arrayTpa
                        },
                        'ausente': {
                            name: 'Ausente',
                            icon: 'fa-close'
                        },
                        'cancelado': {
                            name: 'Cancelado',
                            icon: 'fa-trash-o'
                        },
                        'confirmado': {
                            name: 'Confirmar',
                            icon: 'fa-thumbs-up'
                        },
                        'preferencia': {
                            name: 'Sem Preferência',
                            icon: 'fa-hand-pointer-o'
                        },
                        'encaixe': {
                            name: 'Encaixe',
                            icon: 'fa-scissors'
                        },
                        'venda': {
                            name: 'Venda',
                            icon: 'fa-shopping-cart'
                        },
                        'addtag': {
                            name: 'Adicionar Tag',
                            icon: 'fa-tag'
                        },
                        'nolocal': {
                            name: 'No Local',
                            icon: 'fa-map-marker'
                        }
                    }
                });
            });
    }

    function loadPaymentsConfirmado() {

        fetch('/pages/cadastros/buscaTipoPagamentoBandeiraFinalizarComanda.php')
            .then(data => data.json())
            .then((data) => {
                var arrayTpa = {};

                var tipoPagamentos = data.result.filter((data) => {
                    return data.PagamentoBandeira == ""
                });
                tipoPagamentos.forEach((pagamento) => {

                    if (pagamento.TPa_Cartao == "1") {
                        var bandeiras = data.result.filter((bandeira) => {
                            return bandeira.PagamentoBandeira == pagamento.TPa_Codigo
                        });
                        var arrayTBa = {};

                        if (bandeiras.length > 0) {

                            bandeiras.forEach((bandeira) => {
                                arrayTBa[bandeira.TPa_Codigo] = {
                                    name: bandeira.TPa_Descricao,
                                    codigo: pagamento.TPa_Codigo
                                };
                            });

                            arrayTpa[pagamento.TPa_Codigo] = {
                                name: pagamento.TPa_Descricao,
                                items: arrayTBa
                            };
                        } else {
                            arrayTpa[pagamento.TPa_Codigo] = {
                                name: pagamento.TPa_Descricao,
                                codigo: pagamento.TPa_Codigo
                            };
                        }

                    } else {
                        arrayTpa[pagamento.TPa_Codigo] = {
                            name: pagamento.TPa_Descricao,
                            codigo: pagamento.TPa_Codigo
                        };
                    }

                });

                $.contextMenu({
                    selector: '.hasmenu-confirmado',
                    callback: (key, options) => {
                        eventSel = $('#calendar').fullCalendar('clientEvents', options.$trigger[0].dataset.agecodigo)[0];
                        $('#lblIDAgendamento').html(options.$trigger[0].dataset.agecodigo);
                        if (key == 'realizado') {
                            $('#lblValorHdn').html(eventSel.valor);
                            $('#lblPesCodigo').html(eventSel.codCliente);
                            $('#btnRealizadoAg').click();
                        } else if (key == 'ausente') {
                            $('#btnAusenteAg').click();
                        } else if (key == 'cancelado') {
                            $('#btnCancelarAg').click();
                        } else if (key == 'confirmado') {
                            $('#btnConfirmaAg').click();
                        } else if (key == 'preferencia') {
                            $('#btnPreferenciaAg').click();
                        } else if (key == 'addtag') {
                            $('#addtagagendamento-modal').modal();
                            colorPicker.reset()
                            $scope.stateTagColor = "#ebebeb";
                            $("#AgeCodigoTagAgendamento").val(eventSel.id)
                        } else if (key == 'encaixe') {
                            $('#idComanda').html(eventSel.Com_Codigo);
                            $('#btnFechaItemComandaSer').hide();
                            $('#btnFechaServicoModal').show();
                            insereServicoComanda(0, eventSel.start);
                        } else if (key == 'venda') {
                            $('#comCodigoInsert').val(eventSel.Com_Codigo);
                            $('#TprTipoComanda').html('1')
                            $('#treAgendaCodigo').html('1');
                            $scope.buscaProdutoCombo();
                            $('#comanda-modal').modal('hide');
                            $('#comandaInsert-modal').modal('show');
                            $('#insereProdutoOrigem').val(0);
                            $('#btnFechaItemComandaModal').show();
                            $('#btnFechaItemComanda').hide();
                        } else if (key == 'nolocal') {
                            $('#btnNoLocal').click();
                        } else {

                            var pagamentoSelecionado = options.commands[key];

                            showLoader(true);
                            $.ajax({
                                dataType: "json",
                                url: "/pages/actions/buscaAgendamentoTipoPagamento.php",
                                type: 'POST',
                                data: {
                                    comanda: eventSel.Com_Codigo
                                },
                                success: (data) => {
                                    var codigoBandeira = "";

                                    if (key != pagamentoSelecionado.codigo) {
                                        codigoBandeira = key;
                                    }

                                    $.ajax({
                                        dataType: 'json',
                                        method: "POST",
                                        url: '/pages/cadastros/atualizaComandav3.php',
                                        data: {
                                            comcodigo: eventSel.Com_Codigo,
                                            tpacodigo: pagamentoSelecionado.codigo,
                                            inserecaixa: 1,
                                            inserecontacli: 0,
                                            inserecaixinha: 0,
                                            valorpagamento: data.result[0].ValorComanda.replace(',', '.'),
                                            tbacodigo: codigoBandeira,
                                            tipo: 1,
                                            parcelado: 0,
                                            qtdparcela: 1,
                                            transacao: '',
                                            motivo: '',
                                            numpagamento: 1
                                        },
                                        success: (data) => {
                                            showLoader(false);
                                            if (data.data[0].erro == "0") {
                                                toastr.success(data.data[0].resultado);
                                                $scope.isAgendamentoAntigo(2);
                                            } else {
                                                toastr.error(data.data[0].resultado);
                                            }
                                        },
                                        error: () => {
                                            showLoader(false);
                                        }
                                    })
                                },
                                error: () => {
                                    showLoader(false);
                                }
                            });
                        }
                    },
                    items: {
                        'realizado': {
                            name: 'Abrir Comanda',
                            icon: 'fa-clipboard'
                        },
                        'finalizaAutomatico': {
                            name: 'Finalizar Comanda',
                            icon: 'fa-check',
                            items: arrayTpa
                        },
                        'ausente': {
                            name: 'Ausente',
                            icon: 'fa-close'
                        },
                        'cancelado': {
                            name: 'Cancelado',
                            icon: 'fa-trash-o'
                        },
                        'confirmado': {
                            name: 'Desconfirmar',
                            icon: 'fa-thumbs-down'
                        },
                        'preferencia': {
                            name: 'Sem Preferência',
                            icon: 'fa-hand-pointer-o'
                        },
                        'encaixe': {
                            name: 'Encaixe',
                            icon: 'fa-scissors'
                        },
                        'venda': {
                            name: 'Venda',
                            icon: 'fa-shopping-cart'
                        },
                        'addtag': {
                            name: 'Adicionar Tag',
                            icon: 'fa-tag'
                        },
                        'nolocal': {
                            name: 'No Local',
                            icon: 'fa-map-marker'
                        }
                    }
                });
            });



    }

    $("#cliente_menu").on("change", function() {

        if ($("#cliente_menu").val() != null && $("#cliente_menu").val() != "") {
            if ($("#cliente_menu option:selected").get(0).dataset.ausente == 1) {
                $("#jaAusentouFlag").html(` <i class="fa fa-exclamation-triangle" style="color: red"></i> <span style="color: red">Sim</span>`)
            } else {
                $("#jaAusentouFlag").html(` Não`)
            }
        }

        var codigoCliente = $("#cliente_menu").val()
        var pessoaConta = '';

        if (codigoCliente != '' && codigoCliente != 0 && codigoCliente != null) {

            $.ajax({
                dataType: 'json',
                url: "/pages/actions/buscaPessoaConta.php",
                type: 'POST',
                data: {
                    tipo: '5',
                    cliente: codigoCliente
                },
                success: function(result) {
                    if (result.result[0] != undefined) {
                        if (result.result[0].SaldoReal < 0.00) {
                            pessoaConta += "<span style='color:red'> <i class='fa fa-arrow-down'> </i> " + result.result[0].PCo_Saldo + "</span>";
                        } else if (result.result[0].SaldoReal > 0.00) {
                            pessoaConta += "<span style='color:green'> <i class='fa fa-arrow-up'> </i> " + result.result[0].PCo_Saldo + "</span>";
                        } else {
                            pessoaConta += ` ${$_CONFIG.MOEDA} 0,00`
                        }
                    }
                    $("#saldoContaCliAge").html(pessoaConta);
                },
                error: function(result) {
                    toastr.error("Falha na conexão.");
                    showLoader(false);
                }
            });
            var isAssinante = '';
            $("#IsAssinanteCliente").html(' Não')
            $.ajax({
                dataType: "json",
                url: "/pages/cadastros/buscaAssinaturaPessoaV3.php",
                method: "POST",
                data: {
                    pescodigo: codigoCliente,
                    asscodigo: '',
                    tipo: 3,
                    dataini: '',
                    datafim: ''
                },
                success: function(result) {
                    if (result.data.length > 0) {
                        if (result.data[0].erro == undefined) {
                            if (result.data[0].Ass_Descricao != '') {

                                var status = `<i class="fa fa-circle" style="color:orange" data-toggle="tooltip" title="A Vencer."></i>`
                                if (result.data[0].AssStatus == "Inadimplente") {
                                    status = `<i class="fa fa-circle" style="color:red" data-toggle="tooltip" title="Inadimplente"></i>`
                                } else if (result.data[0].AssStatus == "Em Dia") {
                                    status = `<i class="fa fa-circle" style="color:green" data-toggle="tooltip" title="Em Dia"></i>`
                                } else if (result.data[0].AssStatus == "Atrasado") {
                                    status = `<i class="fa fa-circle" style="color:orange" data-toggle="tooltip" title="Atrasado"></i>`
                                }
                                isAssinante = ` <span>${status} ${result.data[0].Ass_Descricao}</span>`
                            } else {
                                isAssinante = 'Não'
                            }
                            $("#IsAssinanteCliente").html(isAssinante);
                        }
                    }
                }
            });

            $.ajax({
                url: '/pages/cadastros/buscaPacotesPessoaCombo.php',
                type: 'POST',
                dataType: 'json',
                async: false,
                data: {
                    pescodigo: codigoCliente,
                    codigo: $("#servico_menu0").val(),
                    tipo: 1
                },
                success: function(data) {
                    if (data.result.length > 0) {
                        $("#HasPacotesCliente").html(" Possuí pacotes para o serviço")
                    } else {
                        $("#HasPacotesCliente").html(" Sem pacotes disponíveis para o serviço")
                    }

                    showLoader(false);
                },
                error: function(result) {
                    toastr.error("Falha na conexão.");
                    showLoader(false);
                }
            });
        } else {
            $("#saldoContaCliAge").html('');
            $("#IsAssinanteCliente").html('');
        }
    })

    selecionaHorarioAgenda = function(startDate, endDate, profissional, view, servico = '') {
        var cbBloqueio = $('#cbBloqHorario').is(':checked');
        if ((view.name == "month") || (view.name == 'agendaWeek')) {
            $('#calendar').fullCalendar('gotoDate', startDate);
            $('#calendar').fullCalendar('changeView', 'resourceDay');
            $('#dvCalendario').datepicker('setDate', startDate);
        } else {
            if (cbBloqueio) {
                var bloqProfissional = profissional;
                var dataIniBloq = startDate.year() + '/' + (startDate.month() + 1) + '/' + startDate.date();
                var dataFimBloq = endDate.year() + '/' + (endDate.month() + 1) + '/' + endDate.date();
                var horaIniBloq = startDate.hour() + ':' + startDate.minute();
                var horaFimBloq = endDate.hour() + ':' + endDate.minute();
                $.ajax({
                    dataType: 'json',
                    url: "/pages/actions/agendaHorarioBloqueado.php",
                    method: "POST",
                    data: {
                        profissional: bloqProfissional,
                        diaini: dataIniBloq,
                        diafim: dataFimBloq,
                        horaini: horaIniBloq,
                        horafim: horaFimBloq,
                        observacao: 'Agenda Bloqueada'
                    },
                    success: function(data) {
                        if (data.agendaHorarioBloqueado[0].erro == 1) {
                            toastr.error(data.agendaHorarioBloqueado[0].resultado);
                        } else {
                            toastr.success(data.agendaHorarioBloqueado[0].resultado);
                            $scope.atualizaEventos();
                        }
                    }
                });
            } else {
                if (!carregando) {
                    var liveDate = new Date();
                    $.ajax({
                        dataType: 'json',
                        url: "/pages/actions/buscaServicos.php",
                        method: "POST",
                        data: {
                            profissional: profissional,
                            tipo: 9,
                        },
                        success: (data) => {
                            $scope.servicoSelect = data.servicos;
                            $scope.numeroServicos = 0;
                            $scope.criaServicoSelect();
                            $('#servico_menuRecorrente').html('<option  value="">Selecione um Serviço</option>');
                            $('#servicoAlteraAgendamento').html('<option data-tempo="" value="">Selecione um Serviço</option>');
                            for (var i = 0; i < data.servicos.length; i++) {
                                if (data.servicos[i].TipoItem == 1) {
                                    $('#servico_menuRecorrente').append('<option data-tempo="' + data.servicos[i].Ser_Intervalo_Padrao + '" value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>')
                                    $('#servicoAlteraAgendamento').append('<option data-tempo="' + data.servicos[i].Ser_Intervalo_Padrao + '" value="' + data.servicos[i].Ser_Codigo + '">' + data.servicos[i].Ser_Descricao + '</option>')
                                }
                            };

                            if (servico != '') {
                                setTimeout(() => {
                                    $('#servico_menu0').val(servico).change()
                                }, 500)
                            }
                        }
                    });

                    $.ajax({
                        dataType: 'json',
                        url: '/pages/actions/buscaParametro.php',
                        method: 'POST',
                        data: {
                            parcodigo: 52,
                            origem: 1
                        },
                        success: (param3) => {
                            $("#geralinkconfirmacao").val(param3.result[0].PVa_Vlr_Principal);
                        }
                    });

                    $('#cliente_menu').select2('val', '');
                    $('#edtData').val(startDate.format('DD/MM/YYYY'));
                    $('#edtData').attr('disabled', true);
                    $('#dataAgendamentoRecorrente').val(startDate.format('DD/MM/YYYY'));
                    $('#dataAgendamentoRecorrente2').val(startDate.format('YYYY/MM/DD'));
                    $('#dataAgendamentoRecorrente').attr('disabled', true);
                    $('#celendardisabled').attr('disabled', true);
                    $('#celendardisabled').unbind('click');
                    $('#edtData2').val(startDate.format('YYYY/MM/DD'));
                    $('#edtHoraIni').timepicker('setTime', startDate.format('HH:mm'));
                    $('#horaAgendamentoRecorrente').timepicker('setTime', startDate.format('HH:mm'));
                    $('#edtHoraIni2').timepicker('setTime', startDate.format('HH:mm'));
                    $('#edtProfissional').val(profissional);
                    $('#edtProfissional').attr('disabled', true);
                    $('#profissionalRecorrencia').val(profissional);
                    $('#profissionalRecorrencia2').val(profissional);
                    $('#edtProfissionalBloqueado').val(profissional);
                    $('#edtProfissionalDesbloquear').val(profissional);
                    $('#profissionalRecorrencia').attr('disabled', true);
                    $('#edtDataBloqueado').val(startDate.format('DD/MM/YYYY'));
                    $('#edtData2Bloqueado').val(startDate.format('YYYY/MM/DD'));
                    $('#edtDataFimBloqueado').val(startDate.format('DD/MM/YYYY'));
                    $('#edtDataFim2Bloqueado').val(startDate.format('YYYY/MM/DD'));
                    $('.date.dateAltAge').datepicker('update', startDate.format('DD/MM/YYYY'));
                    $('.date.DateBloqueio').datepicker('update', startDate.format('DD/MM/YYYY'));
                    $('.date.DateBloqueioFim').datepicker('update', startDate.format('DD/MM/YYYY'));
                    $('#txtObsBloqueado').val("");
                    $('#add_lembrete_menu').val(0).trigger('change');
                    $('#txtObs').val("");
                    $('#agendaHorario-modal').modal();
                    $scope.buscaSaldoSMS();
                    $scope.buscaSaldoWhats();
                }
            }
        }
    }

    // initCalendar();
    // initContextMenu();
    $scope.goToDataAgenda = function(hora, data, tempo, profissional, dialivre, servico) {
        var dataini = moment(`${data} ${hora}`);
        var datafim = moment(`${data} ${hora}`).add(+tempo, 'minutes');
        var listProf = localStorage.getItem("profissionais").split(",");

        if (_.indexOf(listProf, profissional.toString()) == -1) {

            listProf.push(profissional.toString());
            $('#users_menu').multiselect('deselectAll', false);
            $('#users_menu').multiselect('select', listProf).change();
            setTimeout(() => {
                $('#dvCalendario').datepicker('setDate', dialivre);
            }, 500);
        } else {

            $('#dvCalendario').datepicker('setDate', dialivre);
        }
        $('#calendar').fullCalendar('changeView', 'resourceDay');
        selecionaHorarioAgenda(dataini, datafim, profissional, 'resourceDay', servico)
        $("#listaHorariosProfissionalDetalhes-modal").modal('hide')
        $("#buscaHorariosDisponivel-modal").modal('hide')
    }

    $scope.buscaCategoriasAgenda = function() {

        var htmlcategoria = "";
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/buscaCategoria.php",
            dataType: "json",
            data: {
                tipo: 1
            },
            success: function(result) {
                htmlcategoria += "<br>";
                for (var i = 0; i < result.data.length; i++) {
                    htmlcategoria += "<button id=" + result.data[i].TCa_Codigo + " ng-click='changeCategoriaAgenda(" + result.data[i].TCa_Codigo + ")' class=' btncategoria btn btn-block btn-default' >" + result.data[i].TCa_Descricao + "</button>";
                }
                htmlcategoria += "<br>";

                $("#categoriasRodizioAgenda").html(htmlcategoria);
                $compile($('#categoriasRodizioAgenda'))($scope);
                $("#selecionarCategoria-modal").modal('show')
            },
            error: function(result) {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
    }



    $scope.changeCategoriaAgenda = function(tcacodigo) {
        showLoader(true)
        $.ajax({
            dataType: 'json',
            url: "/pages/cadastros/buscaCategoriaProfissionalv2.php",
            data: {

                tcacodigo: tcacodigo,
                pescodigo: ''
            },
            success: (data) => {
                if (data.data.length > 0) {
                    localStorage.removeItem("profissionais");
                    var listaProf = [];
                    for (var i = 0; i < data.data.length; i++) {
                        listaProf.push(data.data[i].Pes_Codigo)
                    }
                    localStorage.setItem("profissionais", listaProf);
                    setStorage("profissionais_" + $_CONFIG.CODESTABELECIMENTO, listaProf);
                    $('#users_menu').multiselect('deselectAll', false);
                    $('#users_menu').multiselect('select', listaProf).change();

                    $("#selecionarCategoria-modal").modal('hide')
                    showLoader(false)
                } else {
                    toastr.warning('Nenhum profissional associado a essa categoria')
                    showLoader(false)
                }
            }
        });
    }

    $scope.openWhatsAgendamento = function() {
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/AGENDAMENTO_Busca.php",
            data: {
                type: 1,
                scheduling_code: $("#lblIDAgendamento").html()
            },
            dataType: "json",
            success: (result) => {
                var celular = result.data.scheduling[0].person_phone;
                sendWhatsReminder(celular, '');
            }
        });
    }

});