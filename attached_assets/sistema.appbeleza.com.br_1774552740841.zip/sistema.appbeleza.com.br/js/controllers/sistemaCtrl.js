angular
    .module("appBeleza")
    .controller(
        "sistemaCtrl",
        function($rootScope, $scope, $compile, $state, $translate, $sce) {
            $scope.idCliente = $_CONFIG.ID;
            $scope.tiposPagamento = "";
            $scope.manyClients = false;
            $scope.textMax = "110";
            $scope.mensagempreview = "";
            $scope.datamensagempreview = "";
            $scope.horaenviomensagenpreview = "";
            $scope.sistemaName = $Options.sistema;
            $scope.sistemaColor = $Options.sistemaCor;
            $scope.nomeEmpresa = $_CONFIG.ESTABELECIMENTO;
            $scope.parnota = 0;
            $scope.parnfse = 0;
            $scope.parnfe = 0;
            $scope.parnfce = 0;
            $scope.parnfapacote = 0;
            $scope.parnfssinatura = 0;
            $scope.emitnota = 0;
            $scope.nomeProfissionalNota = 0;
            $scope.caixinha = 0;
            $scope.geracomissaoprof = 0;
            $scope.numImagemProntuario = 0;
            $scope.parnfdescontoparceiro = 0;
            $scope.itensComandaNota = "";
            $scope.itensPacoteNota = "";
            $scope.produtosNota = "";
            $scope.produtosNotaPacote = "";
            $scope.dadosEmpresaNota = "";
            $scope.dadosEmpresaNotaPacote = "";
            $scope.dadosEmpresaNotaAssinatura = "";
            $scope.dadosClienteNota = "";
            $scope.dadosClienteNotaPacote = "";
            $scope.dadosClienteNotaAssinatura = "";
            $scope.parValorShowComissao = 0;
            clientesNomesComanda = new Array();
            $scope.tpapagamento = "";
            $scope.tbapagamento = "";
            $scope.tpapagamentopacote = "";
            $scope.tbapagamentopacote = "";
            $scope.arrPagamentopacote = [];
            $scope.valorPagamentoNota = "";
            $scope.arrPagamento = [];
            $scope.parEnderecoNota = 0;
            $scope.parSplit = 0;
            $scope.parTipoSplit = 1;
            $scope.temProfissionalSplit = 0;
            $scope.parDescriaoSalaoParceiro = 0;
            $scope.parDescontoProduto = 0;
            $scope.campoTransporteNota = 0;
            $scope.overrideParceiro = 0;
            $scope.dadosClienteComanda = "";
            $scope.typeCadComanda = 3;
            $scope.parContaDigital = "";
            $scope.parContaDigital2 = "";
            $scope.mostrabtntotem = false;
            $scope.arrayMetadados = [];

            $scope.createChangeCfop = [];

            $("#linhaPagamento0").remove();
            $("#linhaPagamento1").remove();
            $scope.favoritos = [];

            //	$scope.hasNotaNegada = 0;

            $(".navbar .menufavorito")
                .slimscroll({
                    height: "560px",
                    alwaysVisible: false,
                    size: "3px",
                })
                .css("width", "100%");

            if (
                localStorage.getItem("favoritos_" + $_CONFIG.CODUSUARIO) != undefined &&
                localStorage.getItem("favoritos_" + $_CONFIG.CODUSUARIO) != ""
            ) {
                $scope.favoritos = JSON.parse(
                    localStorage.getItem("favoritos_" + $_CONFIG.CODUSUARIO)
                );
            }

            String.prototype.extenso = function(c) {
                var ex = [
                    [
                        "zero",
                        "um",
                        "dois",
                        "três",
                        "quatro",
                        "cinco",
                        "seis",
                        "sete",
                        "oito",
                        "nove",
                        "dez",
                        "onze",
                        "doze",
                        "treze",
                        "quatorze",
                        "quinze",
                        "dezesseis",
                        "dezessete",
                        "dezoito",
                        "dezenove",
                    ],
                    [
                        "dez",
                        "vinte",
                        "trinta",
                        "quarenta",
                        "cinquenta",
                        "sessenta",
                        "setenta",
                        "oitenta",
                        "noventa",
                    ],
                    [
                        "cem",
                        "cento",
                        "duzentos",
                        "trezentos",
                        "quatrocentos",
                        "quinhentos",
                        "seiscentos",
                        "setecentos",
                        "oitocentos",
                        "novecentos",
                    ],
                    [
                        "mil",
                        "milhão",
                        "bilhão",
                        "trilhão",
                        "quadrilhão",
                        "quintilhão",
                        "sextilhão",
                        "setilhão",
                        "octilhão",
                        "nonilhão",
                        "decilhão",
                        "undecilhão",
                        "dodecilhão",
                        "tredecilhão",
                        "quatrodecilhão",
                        "quindecilhão",
                        "sedecilhão",
                        "septendecilhão",
                        "octencilhão",
                        "nonencilhão",
                    ],
                ];
                var a,
                    n,
                    v,
                    i,
                    n = this.replace(c ? /[^,\d]/g : /\D/g, "").split(","),
                    e = " e ",
                    $ = "real",
                    d = "centavo",
                    sl;
                for (
                    var f = n.length - 1, l, j = -1, r = [], s = [], t = "";
                    ++j <= f; s = []
                ) {
                    j && (n[j] = (("." + n[j]) * 1).toFixed(2).slice(2));
                    if (!((a = (v = n[j]).slice((l = v.length) % 3).match(/\d{3}/g)),
                            (v = l % 3 ? [v.slice(0, l % 3)] : []),
                            (v = a ? v.concat(a) : v)).length)
                        continue;
                    for (a = -1, l = v.length; ++a < l; t = "") {
                        if (!(i = v[a] * 1)) continue;
                        (i % 100 < 20 && (t += ex[0][i % 100])) ||
                        ((i % 100) + 1 &&
                            (t +=
                                ex[1][(((i % 100) / 10) >> 0) - 1] +
                                (i % 10 ? e + ex[0][i % 10] : "")));
                        s.push(
                            (i < 100 ?
                                t :
                                !(i % 100) ?
                                ex[2][i == 100 ? 0 : (i / 100) >> 0] :
                                ex[2][(i / 100) >> 0] + e + t) +
                            ((t = l - a - 2) > -1 ?
                                " " +
                                (i > 1 && t > 0 ? ex[3][t].replace("ão", "ões") : ex[3][t]) :
                                "")
                        );
                    }
                    a =
                        (sl = s.length) > 1 ?
                        ((a = s.pop()), s.join(" ") + e + a) :
                        s.join("") ||
                        ((!j && n[j + 1] * 1 > 0) || r.length ? "" : ex[0][0]);
                    a &&
                        r.push(
                            a +
                            (c ?
                                " " +
                                (v.join("") * 1 > 1 ?
                                    j ?
                                    d + "s" :
                                    (/0{6,}$/.test(n[0]) ? "de " : "") +
                                    $.replace("l", "is") :
                                    j ?
                                    d :
                                    $) :
                                "")
                        );
                }
                return r.join(e);
            };

            $.ajax({
                dataType: "json",
                url: "/pages/cadastros/buscaTipoPagamentoSelect.php",
                async: false,
                data: {},
                success: function(result) {
                    $_CONFIG.LISTA_PAGAMAENTO = result.result;
                    $scope.tiposPagamento = result.result;
                },
            });

            $.ajax({
                dataType: "json",
                url: "/pages/cadastros/buscaEstadosCombo.php",
                method: "POST",
                async: false,
                success: function(data) {
                    $_CONFIG.LISTA_ESTADO = data.result;
                },
            });

            $.ajax({
                dataType: "json",
                url: "/pages/cadastros/buscaPais.php",
                method: "POST",
                async: false,
                success: function(data) {
                    $_CONFIG.LISTA_PAIS = data.result;
                },
            });

            $.ajax({
                type: "POST",
                url: "/pages/cadastros/buscaProdutov4Tipo.php",
                async: false,
                data: {
                    tipo: 2,
                },
                dataType: "json",
                success: function(result) {
                    if (result.data.length > 0) {
                        if (result.data[0].TotalProdutos > 1500) {
                            $_CONFIG.HASMANYPRODUCTS = 1;
                        } else {
                            $_CONFIG.HASMANYPRODUCTS = 0;
                        }
                    }
                },
            });

            $.ajax({
                type: "POST",
                url: "/pages/cadastros/buscaPessoaInfoss.php",
                dataType: "json",
                async: false,
                success: function(result) {
                    if (result.data.length > 0) {
                        if (result.data[0].PIf_ID != "") {
                            $scope.mostrabtntotem = true;
                        } else {
                            $scope.mostrabtntotem = false;
                        }
                    }
                },
                error: function(result) {},
            });

            $scope.buscaparcaixinha = function() {
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    async: false,
                    data: {
                        metodo: "buscaParametro",
                        id: $scope.idCliente,
                        parcodigo: 63,
                    },
                    success: function(data) {
                        if (data.result.length > 0) {
                            if (data.result[0].PVa_Vlr_Principal == "1") {
                                $scope.caixinha = 1;
                            } else {
                                $scope.caixinha = 0;
                                $("#itemMenuCaixinha").hide();
                            }
                        } else {
                            $scope.caixinha = 0;
                        }
                    },
                });
            };
            $scope.buscaparcaixinha();

            $scope.buscaparnota = function() {
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaParametroPessoa_v2.php",
                    async: false,
                    data: {
                        tipo: 4,
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            console.log(data);
                            for (var i = 0; i < data.data.length; i++) {
                                if (data.data[i].Par_Codigo == 64) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parnota = 1;
                                    } else {
                                        $scope.parnota = 0;
                                        $("#emissoesItemMenu").hide();
                                    }
                                } else if (data.data[i].Par_Codigo == 65) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parnfse = 1;
                                    } else {
                                        $scope.parnfse = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 66) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parnfe = 1;
                                        $("#divTransportadora").show();
                                    } else {
                                        $scope.parnfe = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 73) {
                                    if (data.data[i].PVa_Vlr_Principal == "3") {
                                        $scope.parnfdescontoparceiro = 1;
                                    } else if (
                                        data.data[i].PVa_Vlr_Principal == "1" ||
                                        data.data[i].PVa_Vlr_Principal == "2"
                                    ) {
                                        $scope.overrideParceiro = 1;
                                    } else {
                                        $scope.parnfdescontoparceiro = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 86) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parnfapacote = 1;
                                    } else {
                                        $scope.parnfapacote = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 87) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parnfce = 1;
                                    } else {
                                        $scope.parnfce = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 103) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parEnderecoNota = 1;
                                    } else {
                                        $scope.parEnderecoNota = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 117) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parDescriaoSalaoParceiro = 1;
                                    } else {
                                        $scope.parDescriaoSalaoParceiro = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 122) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parnfssinatura = 1;
                                    } else {
                                        $scope.parnfssinatura = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 125) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.nomeProfissionalNota = 1;
                                    } else {
                                        $scope.nomeProfissionalNota = 0;
                                    }
                                } else if (data.data[i].Par_Codigo == 150) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.campoTransporteNota = 1;
                                        $("#optTransporteNota").show();
                                    } else {
                                        $scope.campoTransporteNota = 0;
                                        $("#optTransporteNota").hide();
                                    }
                                } else if (data.data[i].Par_Codigo == 120) {
                                    if (data.data[i].PVa_Vlr_Principal == "1") {
                                        $scope.parContaDigital = 1;
                                        $scope.parContaDigital2 = 1;
                                        $("#btnCobrarCliente").show();
                                    } else {
                                        $scope.parContaDigital = 0;
                                        $scope.parContaDigital2 = 0;
                                        $("#btnCobrarCliente").hide();
                                    }
                                } else if (data.data[i].Par_Codigo == 215) {
                                    if ($_CONFIG.ISG != 1) {
                                        if (data.data[i].PVa_Vlr_Principal == "1") {
                                            $(".btnEdtCaixa").hide();
                                        } else {
                                            $(".btnEdtCaixa").show();
                                        }
                                    } else {
                                        $(".btnEdtCaixa").show();
                                    }
                                } else if (data.data[i].Par_Codigo == 216) {
                                    if ($_CONFIG.ISG == 1) {
                                        if (data.data[i].PVa_Vlr_Principal == "1") {
                                            $("#btnVerCaixaAbertoGestor").show();
                                        } else {
                                            $("#btnVerCaixaAbertoGestor").hide();
                                        }
                                    } else {
                                        $("#btnVerCaixaAbertoGestor").hide();
                                    }
                                }
                            }

                            if ($scope.overrideParceiro == 1) {
                                $scope.parnfdescontoparceiro = 1;
                                $scope.parDescriaoSalaoParceiro = 1;
                            }
                        } else {
                            $scope.parnota = 0;
                            $scope.parnfse = 0;
                            $scope.parnfe = 0;
                            $scope.parnfapacote = 0;
                            $scope.parnfce = 0;
                            $scope.parnfdescontoparceiro = 0;
                            $scope.parEnderecoNota = 0;
                            $scope.parDescriaoSalaoParceiro = 0;
                            $scope.parnfssinatura = 0;
                            $scope.nomeProfissionalNota = 0;
                            $scope.campoTransporteNota = 0;
                            $scope.overrideParceiro = 0;
                        }
                    },
                });
            };
            $scope.buscaparnota();

            $scope.buscaParValidaBotaoContaDigital = function() {
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    async: false,
                    data: {
                        metodo: "buscaParametro",
                        id: $scope.idCliente,
                        parcodigo: 174,
                    },
                    success: function(data) {
                        if (data.result.length > 0) {
                            if (data.result[0].PVa_Vlr_Principal == "1") {
                                $scope.parContaDigital = 1;
                                $("#btnCobrarCliente").show();
                            } else {
                                $scope.parContaDigital = 0;
                                $("#btnCobrarCliente").hide();
                            }
                        } else {
                            $scope.caixinha = 0;
                        }
                    },
                });
            };
            if ($scope.parContaDigital == 1) {
                $scope.buscaParValidaBotaoContaDigital();
            }
            if ($scope.parnota == 1) {
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaAviso.php",
                    async: false,
                    data: {
                        tipo: 1,
                        pescodigo: "",
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                if (
                                    data.data[i].CNF_Status == "Negada" ||
                                    data.data[i].CNF_Status == "Aguardando Emissão..."
                                ) {
                                    $scope.hasNotaNegada = 1;
                                    break;
                                }
                            }
                        } else {
                            $scope.hasNotaNegada = 0;
                        }
                    },
                });
            }

            if ($scope.campoTransporteNota == 1) {
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaTipoTransportadora.php",
                    async: false,

                    success: function(data) {
                        var html = '<option value="">Selecione uma Transportadora</option>';
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                html += `<option value="${data.data[i].TTr_Descricao}" data-tipopessoa="${data.data[i].TipoPessoa}" data-cnpj="${data.data[i].TTr_CNPJ}" data-cidade="${data.data[i].Cid_Nome}" data-ie="${data.data[i].TTr_IE}" data-uf="${data.data[i].Est_Sigla}" data-endereco="${data.data[i].TTr_Endereco}">${data.data[i].TTr_Descricao}</option>`;
                            }
                        }
                        $("#transportadoraNotaProd").html(html);
                    },
                });
            }
            var goToEmissao = function goEmissao() {
                $state.go("emissoes");
            };

            var goToServico = function goToServico() {
                $state.go("servicos");
            };

            var goToCaixa = function goToCaixa() {
                $state.go("relCaixa");
            };

            var goToComanda = function goToComanda() {
                $state.go("comandasAbertas");
            };

            var goToRecorrente = function goToRecorrente() {
                $state.go("relRecorrente");
            };

            var goToAssinante = function goToAssinante() {
                $state.go("assinantes");
            };

            var goToEstoque = function goToEstoque() {
                $state.go("relGerencialEstoque");
            };

            if ($scope.hasNotaNegada == 1) {
                $App.showMessageColor(
                    "Módulo fiscal",
                    "Exitem emissões negadas ou pendentes. clique aqui para visualizar",
                    1,
                    goToEmissao,
                    "error"
                );
            }

            var showalertmessages = localStorage.getItem("alertMesssage");

            if (showalertmessages == null) {
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaAviso.php",
                    async: false,
                    data: {
                        tipo: 2,
                        pescodigo: "",
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                if (data.data[i].SVa_Codigo != "") {
                                    $App.showMessage(
                                        "Serviços",
                                        "Existem agendamentos de troca de valor de serviços pendentes. Aplique as alterações para efetivar a troca. Clique aqui para ir aos serviços",
                                        2,
                                        goToServico
                                    );
                                }
                            }
                        }
                    },
                });

                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaAviso.php",
                    async: false,
                    data: {
                        tipo: 3,
                        pescodigo: "",
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                if (data.data[i].FCa_Codigo != "") {
                                    $App.showMessageColor(
                                        "Caixas",
                                        "Existem caixas abertos a mais de 30 dias no seu estabelecimento. Finalize seus caixas para manter seu financeiro atualizado. Clique aqui para ir ao histórico de caixas",
                                        2,
                                        goToCaixa,
                                        "warning"
                                    );
                                }
                            }
                        }
                    },
                });

                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaAviso.php",
                    async: false,
                    data: {
                        tipo: 4,
                        pescodigo: "",
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                if (data.data[i].NumComanda > 0) {
                                    $App.showMessageColor(
                                        "Comandas",
                                        "Existem comandas abertas nos últimos 90 dias. Finalize suas comandas para manter suas informações atualizadas. Clique aqui para ver as comandas abertas",
                                        2,
                                        goToComanda,
                                        "error"
                                    );
                                }
                            }
                        }
                    },
                });

                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaAviso.php",
                    async: false,
                    data: {
                        tipo: 5,
                        pescodigo: "",
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                if (data.data[i].NumAgendamentos > 0) {
                                    $App.showMessageColor(
                                        "Agendamentos Recorrentes",
                                        "Existem agendamentos recorrentes acabando nos próximos 7 dias. Clique aqui para ir até a lista de agendamentos recorrentes",
                                        2,
                                        goToRecorrente
                                    );
                                }
                            }
                        }
                    },
                });

                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaAviso.php",
                    async: false,
                    data: {
                        tipo: 6,
                        pescodigo: "",
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                if (data.data[i].NumAssinaturas > 0) {
                                    $App.showMessageColor(
                                        "Assinantes",
                                        "Existem assinantes com vencimento previsto para os proximos 7 dias. Clique aqui para ir até a lista de assinantes ",
                                        2,
                                        goToAssinante,
                                        "warning"
                                    );
                                }
                            }
                        }
                    },
                });

                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaAviso.php",
                    async: false,
                    data: {
                        tipo: 7,
                        pescodigo: "",
                    },
                    success: function(data) {
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                if (data.data[i].TotalProdVencer > 0) {
                                    $App.showMessageColor(
                                        "Produtos a vencer",
                                        "Existem produtos vencendo nos próximos 30 dias. Clique aqui para ver quais.",
                                        2,
                                        goToEstoque,
                                        "warning"
                                    );
                                }
                            }
                        }
                    },
                });
            }

            $.ajax({
                dataType: "json",
                url: localStorage.getItem("host"),
                async: false,
                data: {
                    metodo: "buscaParametro",
                    id: $scope.idCliente,
                    parcodigo: 60,
                },
                success: function(data) {
                    if (data.result.length > 0) {
                        if (data.result[0].PVa_Vlr_Principal == "1") {
                            $scope.geracomissaoprof = 1;
                        } else {
                            $scope.geracomissaoprof = 0;
                        }
                    } else {
                        $scope.geracomissaoprof = 0;
                    }
                },
            });

            $.ajax({
                dataType: "json",
                url: localStorage.getItem("host"),
                async: false,
                data: {
                    metodo: "buscaParametro",
                    id: $scope.idCliente,
                    parcodigo: 126,
                },
                success: function(data) {
                    if (data.result.length > 0) {
                        if (
                            data.result[0].PVa_Vlr_Principal == "1" ||
                            data.result[0].PVa_Vlr_Principal == "2"
                        ) {
                            $scope.parDescontoProduto = data.result[0].PVa_Vlr_Principal;
                        } else {
                            $scope.parDescontoProduto = 0;
                        }
                    } else {
                        $scope.parDescontoProduto = 0;
                    }
                },
            });

            $.ajax({
                dataType: "json",
                url: "/pages/cadastros/buscaPais.php",
                method: "POST",
                success: function(data) {
                    var html = "";
                    var sigla = $_CONFIG.language.mascaras.lang.toUpperCase();
                    for (var i = 0; i < data.result.length; i++) {
                        if (sigla == data.result[i].Pai_Sigla) {
                            html +=
                                '<option selected value="' +
                                data.result[i].Pai_Codigo +
                                '" data-sigla="' +
                                data.result[i].Pai_Sigla +
                                '">' +
                                data.result[i].Pai_Nome +
                                "</option>";
                        } else {
                            html +=
                                '<option value="' +
                                data.result[i].Pai_Codigo +
                                '" data-sigla="' +
                                data.result[i].Pai_Sigla +
                                '">' +
                                data.result[i].Pai_Nome +
                                "</option>";
                        }
                    }
                    $("#cliPais").html(html);
                    $("#cliPaisEdt").html(html);
                },
            });

            $(".input-group.date").datepicker({
                language: "pt-BR",
                orientation: "top auto",
                autoclose: true,
                format: "dd/mm/yyyy",
            });

            $(".timepicker2").timepicker({
                timeFormat: "H:i",
                forceRoundTime: true,
                step: 30,
            });
            var dataabrecomanda = moment().locale("pt-br").format("L");
            $(".date.DataComandaAbre").datepicker("update", dataabrecomanda);
            $(".date.dataInContaCli").datepicker("update", dataabrecomanda);

            $scope.changeComissao = function() {
                $scope.comissaoReadyOnly = !$scope.comissaoReadyOnly;
            };

            $("#buttonAbreNovaComanda").click(function() {
                // $('.date.DataComandaAbre').datepicker('update', curTimeZone);
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    data: {
                        metodo: "buscaDataAtual",
                        id: $scope.idCliente,
                    },
                    success: function(data) {
                        var datahoralocal = moment(data.buscaDataAtual[0].resultado)
                            .locale("pt-br")
                            .format("L");

                        $(".date.DataComandaAbre").datepicker("update", datahoralocal);
                        if (curTimeZone.getMinutes() < 10) {
                            var hora =
                                curTimeZone.getHours() + "0" + curTimeZone.getMinutes();
                        } else {
                            var hora = curTimeZone.getHours() + "" + curTimeZone.getMinutes();
                        }
                        var horas = new Array();
                        for (var i = 0; i < $("#horaComandaInicio option").length; i++) {
                            horas.push(
                                $("#horaComandaInicio option")[i].value.replace(":", "")
                            );
                        }

                        $("#horaComandaInicio").select2();
                        $("#horaComandaInicio").select2("val", "");
                        var hour = getproxhora(horas, hora);
                        $("#horaComandaInicio").val(hour.toString().splice(2, 0, ":"));
                        $("#horaComandaInicio").change();
                    },
                    error: function() {
                        var dataini = moment().locale("pt-br").format("L");
                        $(".date.DataComandaAbre").datepicker("update", dataini);
                    },
                });
            });

            //Configurações dos input de imagens do prontuario
            $("#aimImagemInsere").fileinput({
                maxFilesNum: 1,
                showPreview: false,
                browseLabel: "Procurar",
                removeLabel: "Remover",
                browseIcon: "",
                allowedFileExtensions: ["png", "jpg", "jpeg"],
                showUpload: false,
            });

            $("#aimImagemEdt").fileinput({
                maxFilesNum: 1,
                showPreview: false,
                browseLabel: "Procurar",
                removeLabel: "Remover",
                browseIcon: "",
                allowedFileExtensions: ["png", "jpg", "jpeg"],
                showUpload: false,
            });

            var custombuttom =
                /* '<li class="dropdown">' +
		        '<a class="btn btn-default dropdown-toggle " data-toggle="dropdown" tabindex="-1" aria-expanded="false">' +
		        '<span >Campo Dinâmico </span>' +
		        '<b class="caret"></b>' +
		        '</a>' +
		        '<ul class="dropdown-menu">' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Cliente_Nome}}" href="javascript:;" unselectable="on">Cliente - Nome</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Cliente_CPF}}" href="javascript:;" unselectable="on">Cliente - CPF</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Cliente_Celular}}" href="javascript:;" unselectable="on">Cliente - Celular</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Cliente_Telefone}}" href="javascript:;" unselectable="on">Cliente - Telefone</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Cliente_Email}}" href="javascript:;" unselectable="on">Cliente - Email</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Cliente_DataNasc}}" href="javascript:;" unselectable="on">Cliente - Data de Nascimento</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Cliente_RG}}" href="javascript:;" unselectable="on">Cliente - RG</a></li>' +

		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Profissional_Nome}}" href="javascript:;" unselectable="on">Profissional - Nome</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Profissional_CPF}}" href="javascript:;" unselectable="on">Profissional - CPF</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Profissional_Celular}}" href="javascript:;" unselectable="on">Profissional - Celular</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Profissional_Telefone}}" href="javascript:;" unselectable="on">Profissional - Telefone</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Profissional_Email}}" href="javascript:;" unselectable="on">Profissional - Email</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Profissional_DataNasc}}" href="javascript:;" unselectable="on">Profissional - Data de Nascimento</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Profissional_RG}}" href="javascript:;" unselectable="on">Profissional - RG</a></li>' +

		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Agendamento_Data}}" href="javascript:;" unselectable="on">Agendamento - Data</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Agendamento_Valor}}" href="javascript:;" unselectable="on">Agendamento - Valor</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Agendamento_Comanda_ValorTotal}}" href="javascript:;" unselectable="on">Agendamento - Valor total da Comanda</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Agendamento_Comanda_ValorPagamento}}" href="javascript:;" unselectable="on">Agendamento - Valor pago na Comanda</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Agendamento_Servico}}" href="javascript:;" unselectable="on">Agendamento - Serviço</a></li>' +

		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Servico_Descricao}}" href="javascript:;" unselectable="on">Serviço - Descrição</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Servico_Valor}}" href="javascript:;" unselectable="on">Serviço - Valor</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Servico_Tempo}}" href="javascript:;" unselectable="on">Serviço - Tempo</a></li>' +

		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Assinatura_Descricao}}" href="javascript:;" unselectable="on">Clube de Assinatura - Descricao</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Assinatura_Valor}}" href="javascript:;" unselectable="on">Clube de Assinatura - Valor</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Assinatura_Periodicidade}}" href="javascript:;" unselectable="on">Clube de Assinatura - Periodicidade</a></li>' +

		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Sistema_HoraAtual}}" href="javascript:;" unselectable="on">Sistema - Hora Atual</a></li>' +
		        '<li><a  data-wysihtml5-command="insertHTML" data-wysihtml5-command-value="{{Sistema_Preenchimento}}" href="javascript:;" unselectable="on">Sistema - Campo de Preenchimento</a></li>' +

		        '</ul>' +
		        '</li>'+*/
                '<li ><a class="btn btn-default" ng-click="printDocumento()" id="btnPrintDocumento"><i class="fa fa-print"></i></a></li>' +
                '<li ><a class="btn btn-default" ng-click="pdfDocumento()" id="btndpfDocumento"><i class="fa fa-file-pdf-o"></i></a></li>';

            var custombuttomprofissional =
                '<li ><a class="btn btn-default" ng-click="printDocumentoProfissional()" id="btnPrintDocumentoProfissional"><i class="fa fa-print"></i></a></li>' +
                '<li ><a class="btn btn-default" ng-click="pdfDocumentoProfissional()" id="btndpfDocumentoProfissional"><i class="fa fa-file-pdf-o"></i></a></li>';

            $("#corpoDocumentoCliente").wysihtml5({
                toolbar: {
                    custom1: custombuttom,
                },
                "font-styles": true,
                emphasis: true,
                lists: true,
                color: false,
                image: false,
                link: false,
                locale: "pt-BR",
            });

            $("#corpoDocumentoProfissional").wysihtml5({
                toolbar: {
                    custom1: custombuttomprofissional,
                },
                "font-styles": true,
                emphasis: true,
                lists: true,
                color: false,
                image: false,
                link: false,
                locale: "pt-BR",
            });

            $compile($("#comComissao"))($scope);
            $compile($("#btnChangeComissao"))($scope);

            $.ajax({
                dataType: "json",
                url: localStorage.getItem("host"),
                data: {
                    metodo: "buscaParametro",
                    id: $scope.idCliente,
                    parcodigo: 23,
                },
                success: function(data) {
                    if (data.result.length > 0) {
                        if (data.result[0].PVa_Vlr_Principal == "1") {
                            $(".campoComissaoComanda").show();

                            $("#comComissao").attr("readonly", true);
                            $("#comProComissao").attr("readonly", true);
                            $scope.parValorShowComissao = 1;
                        } else if (data.result[0].PVa_Vlr_Principal == "2") {
                            $(".campoComissaoComanda").hide();
                            $scope.parValorShowComissao = 2;
                        } else {
                            $(".campoComissaoComanda").show();

                            $("#comComissao").attr("readonly", false);
                            $("#comProComissao").attr("readonly", false);
                            $scope.parValorShowComissao = 0;
                        }
                    } else {
                        $(".campoComissaoComanda").show();
                        $scope.parValorShowComissao = 0;
                        $("#comComissao").attr("readonly", false);
                        $("#comProComissao").attr("readonly", false);
                    }
                },
            });

            //--------------------------------------------------------------------------------------------------------------------------------
            // Funções
            $scope.buscaInfoCombos = function() {
                if (hasManyClients) {
                    $("#comCliente").select2({
                        ajax: {
                            url: localStorage.getItem("host"),
                            dataType: "json",
                            delay: 250,
                            data: function(params) {
                                return {
                                    nome: params.term,
                                    metodo: "buscaClientes_v4",
                                    tipo: 5,
                                    id: $_CONFIG.ID,
                                };
                            },
                            processResults: function(data, params) {
                                return {
                                    results: data.result,
                                };
                            },
                            cache: true,
                        },
                        placeholder: "Sem Cadastro",
                        escapeMarkup: function(markup) {
                            return markup;
                        },
                        minimumInputLength: 3,
                        templateResult: thumbClienteName,
                        templateSelection: formatRepoSelection,
                    });
                } else {
                    $.ajax({
                        dataType: "json",
                        url: localStorage.getItem("host"),
                        data: {
                            metodo: "buscaClientes_v3",
                            id: $_CONFIG.ID,
                            tipo: 2,
                        },
                        success: function(data) {
                            clientesNomesComanda.length = 0;
                            var html =
                                '<option data-usucodigo="" data-imagem="" value="0" selected>Sem Cadastro</option>';
                            for (var i = 0; i < data.result.length; i++) {
                                var codigo = data.result[i].Pes_Codigo;
                                var nome = data.result[i].Pes_Nome;
                                var foto = data.result[i].Paf_Imagem;
                                var usucod = data.result[i].Usu_Codigo;
                                var celular = "";
                                if (data.result[i].Paf_Celular != "") {
                                    celular = " - " + data.result[i].Paf_Celular;
                                }

                                html +=
                                    '<option data-usucodigo="' +
                                    usucod +
                                    '" data-imagem="' +
                                    foto +
                                    '" value="' +
                                    codigo +
                                    '">' +
                                    nome +
                                    "" +
                                    celular +
                                    "</option>";
                                clientesNomesComanda.push(nome);
                            }
                            $("#comCliente").html(html);
                            if (data.result.length > 800) {
                                $("#comCliente").select2({
                                    minimumInputLength: 3,
                                });
                                $scope.manyClients = true;
                            } else {
                                $("#comCliente").select2();
                                $scope.manyClients = false;
                            }
                            $("#comCliente").val("0").trigger("change");
                        },
                    });
                }

                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    data: {
                        metodo: "buscaProfissionais",
                        id: $_CONFIG.ID,
                    },
                    success: function(data) {
                        var html2 = "";
                        html2 += '<option value="">Profissional</option>';
                        for (var i = 0; i < data.profissionais.length; i++) {
                            var codigo = data.profissionais[i].Pes_Codigo;
                            var apelido = data.profissionais[i].Pes_Apelido;
                            html2 +=
                                '<option value="' + codigo + '">' + apelido + "</option>";
                        }
                        $("#comProfissionalComissao").html(html2);
                        $("#profissionalGorjeta").html(html2);
                        $("#profissionalGorjetaAltera").html(html2);
                        $("#profissionalSelVale").html(html2);
                        $("#comProfissional").html(html2);
                        $("#comProfissional").val("").trigger("change");
                        $("#comProfissional").select2();
                    },
                });
            };
            // Atualiza Dados Itens Insert
            $scope.atualizaDadosItensInsert = function(codigo) {
                tabelaCom.ajax.reload(function(e) {
                    e.data.forEach(function(element, index, array) {
                        if (element.Codigo == codigo) {
                            $("#nomeClienteComanda").html(element.Cliente);
                            $("#idComanda").html(element.Codigo);
                            $("#numComanda").html(element.Codigo);
                            $("#numComandaProd").html(element.Codigo);

                            $("#dataComanda").html(element.DataCadastro);
                            $scope.buscaItensComanda(element.Codigo);
                            $("#comanda-modal").modal("show");
                            $compile($("#tbBuscaComandas"))($scope);
                            $("#tbBuscaComandas_paginate").click(function() {
                                $compile($("#tbBuscaComandas"))($scope);
                            });
                        }
                    });
                });
            };

            $("#comProfissionalComissao").change(function() {
                calculaValorInsert();
            });

            // Busca Tipo Inserção

            $("#comTipoManual").change(() => {
                if ($("#comTipoManual").val() == 1) {
                    $("#divClienteCadastroComanda").hide();
                    $("#divProfissionalCadastroComanda").show();
                } else {
                    $("#divProfissionalCadastroComanda").hide();
                    $("#divClienteCadastroComanda").show();
                }
            });
            $("#comTipoManual").change();

            // Busca Profissional Serviço
            $scope.buscaProfissionalServico = function(sercodigo, tipo) {
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    data: {
                        metodo: "buscaProfissionais",
                        servico: sercodigo,
                        id: $_CONFIG.ID,
                        tipo: tipo,
                    },
                    success: function(data) {
                        var html = "";
                        html += '<option value="">Profissional</option>';
                        for (var i = 0; i < data.profissionais.length; i++) {
                            var codigo = data.profissionais[i].Pes_Codigo;
                            var apelido = data.profissionais[i].Pes_Apelido;
                            html += '<option value="' + codigo + '">' + apelido + "</option>";
                        }
                        $("#comInsertProfissional").html(html);
                        $("#comInsertProfissional").val("").trigger("change");
                        $("#comInsertProfissional").select2();
                    },
                });
            };

            $scope.buscaProfissionalServico("", "");
            $("#comInsertProfissional").change(function() {
                setTimeout(function() {
                    if (
                        this.value != "" &&
                        $("#comInsertServico").val() != "" &&
                        $("#comInsertServico option:selected").get(0).dataset.tipoitem ==
                        "1"
                    ) {
                        buscaAssocProfissionalServico(
                            $("#comInsertServico").val(),
                            $("#comInsertProfissional").val()
                        );
                    }
                }, 300);
            });

            $("#comInsertServico").change(function() {
                setTimeout(function() {
                    if (
                        this.value != "" &&
                        $("#comInsertProfissional").val() != "" &&
                        $("#comInsertServico option:selected").get(0).dataset.tipoitem ==
                        "1"
                    ) {
                        buscaAssocProfissionalServico(
                            $("#comInsertServico").val(),
                            $("#comInsertProfissional").val()
                        );
                    }
                }, 300);
            });

            // Busca Tipo Pagamento
            $scope.buscaTipoPagamento = function() {
                $scope.tiposPagamento = $_CONFIG.LISTA_PAGAMAENTO;
                if (j == 0) {
                    $("#parcelarCaixa").prop("checked", false);
                    $("#parcelarCaixa").change();
                    $scope.novoTipoPagamento();
                }
                $("#codigoTransacao0").val("");

                valorCompletoComanda = $("#valorTotalComanda")
                    .html()
                    .replace($_CONFIG.MOEDA, "")
                    .replace(",", ".");
            };

            // Novo Tipo De Pagamento
            var j = 0;
            var valorCompletoComanda = 0;
            $scope.novoTipoPagamento = function() {
                $("#codigoTransacao" + j).val("");
                if ($("#parcelarCaixa").get(0).checked) {
                    swal(
                        "Não é possivel adicionar mais formas de pagamento para uma comanda parcelada",
                        "",
                        "warning"
                    );
                    return false;
                } else if (j > 1) {
                    toastr.error("Limite de tipos de pagamento: 2.");
                } else {
                    var tabelaPagamento =
                        '<div class="row borders" style="margin-top:5px !important;margin-bottom:5px !important;" id="linhaPagamento' +
                        j +
                        '">';
                    tabelaPagamento +=
                        '<div class="col-md-4 col-xs-12"><select  data-idx="' +
                        j +
                        '" id="tipoPagamento' +
                        j +
                        '" class="form-control input-sm"></select></div>';
                    tabelaPagamento +=
                        '<div class="col-md-4 col-xs-12"><select  id="divBandeiraPag' +
                        j +
                        '"  class="form-control input-sm"></select></div>';
                    tabelaPagamento +=
                        '<div class="col-md-3 col-xs-12"><input type="text" class="form-control input-sm valorFormat" data-idx="' +
                        j +
                        '" id="valorPagamento' +
                        j +
                        '"></div>';
                    tabelaPagamento +=
                        '<div class="col-md-1 col-xs-12" > <div class="row" >';
                    tabelaPagamento +=
                        '<button class="btn btn-xs btn-link" ng-click="comandaCodigoTransacao(' +
                        j +
                        ')" id="btnCodigoTransac' +
                        j +
                        '" style="transform: translateY(25%);"><i class="fa fa-tag"></i></button>';
                    tabelaPagamento +=
                        '<input type="hidden" id="codigoTransacao' + j + '">';
                    tabelaPagamento += '<input type="hidden" id="TraCodigo' + j + '">';
                    tabelaPagamento +=
                        '<input type="hidden" id="IdTransaction' + j + '">';
                    tabelaPagamento +=
                        '<input type="hidden" id="StatusTransaction' + j + '">';
                    if (j !== 0) {
                        tabelaPagamento +=
                            '<button  id="btnRemoveTipo' +
                            j +
                            '" class="btn btn-xs btn-link" style="transform: translateY(25%);"><i class="fa fa-trash"></i></button>';
                    } else {
                        tabelaPagamento += "";
                    }
                    tabelaPagamento += "</div></div>";

                    $("#variostiposdepagamento").append(tabelaPagamento);
                    $(".valor").maskMoney({
                        allowZero: true,
                        thousands: "",
                        decimal: ",",
                    });

                    var tiposDePagamento = '<option value ="">Pagamento</option>';
                    for (var i = 0; i < $scope.tiposPagamento.length; i++) {
                        tiposDePagamento +=
                            "<option value =" +
                            $scope.tiposPagamento[i].TPa_Codigo +
                            ' data-pagamentoOnline ="' +
                            $scope.tiposPagamento[i].TPa_Pag_Online +
                            '" data-pagamentoOnlineParcelado ="' +
                            $scope.tiposPagamento[i].TPa_Parcelado +
                            '" data-desconto="' +
                            $scope.tiposPagamento[i].TPa_Desconto +
                            '" data-tipodesconto="' +
                            $scope.tiposPagamento[i].TPa_Tipo_Desconto +
                            '" data-aplicacomissao="' +
                            $scope.tiposPagamento[i].TPa_Aplica_Comissao +
                            '"  data-integracao="' +
                            $scope.tiposPagamento[i].TPa_Integracao +
                            '"  data-tipoIntegracao="' +
                            $scope.tiposPagamento[i].TPa_Tipo +
                            '" >' +
                            $scope.tiposPagamento[i].TPa_Descricao +
                            "</option>";
                    }

                    $compile($("#divPagamentoOptions0"))($scope);
                    $compile($("#btnRemoveTipo"))($scope);
                    $compile($("#btnCodigoTransac" + j))($scope);
                    $compile($("#tipoPagamento" + j))($scope);
                    $("#tipoPagamento" + j).html(tiposDePagamento);

                    $compile($("#divBandeiraPag" + j))($scope);
                    $("#divBandeiraPag" + j).html('<option value ="">Bandeira</option>');
                    $("#valorPagamento" + j).val(0.0);
                    $("#divBandeiraPag" + j).prop("disabled", true);
                    $("#valorPagamento" + j).unbind("change");
                    var valor = 0.0;

                    $("#valorPagamento" + j).change(function() {
                        if ($("#tipoPagamento1 option:selected").val() !== undefined) {
                            if ($("#tipoPagamento1 option:selected").val() !== "") {
                                if (
                                    $("#valorPagamento1").val() !== "" ||
                                    $("#valorPagamento1").val() !== "0,00"
                                ) {
                                    valor =
                                        parseFloat(
                                            $("#valorPagamento0")
                                            .val()
                                            .replace($_CONFIG.MOEDA, "")
                                            .replace(",", ".")
                                        ) +
                                        parseFloat(
                                            $("#valorPagamento1")
                                            .val()
                                            .replace($_CONFIG.MOEDA, "")
                                            .replace(",", ".")
                                        );
                                } else {
                                    toastr.error(
                                        "Por favor, insira o valor relacionado a segunda forma de pagamento."
                                    );
                                }
                            } else {
                                valor =
                                    parseFloat(
                                        $("#valorPagamento0")
                                        .val()
                                        .replace($_CONFIG.MOEDA, "")
                                        .replace(",", ".")
                                    ) +
                                    parseFloat(
                                        $("#valorPagamento1")
                                        .val()
                                        .replace($_CONFIG.MOEDA, "")
                                        .replace(",", ".")
                                    );
                            }
                        } else {
                            valor = parseFloat(
                                $("#valorPagamento0")
                                .val()
                                .replace($_CONFIG.MOEDA, "")
                                .replace(",", ".")
                            );
                        }

                        $("#comValorTotal")
                            .html($_CONFIG.MOEDA + valor.toFixed(2).replace(".", ","))
                            .change();

                        $scope.calculaParcelas($("#comValorTotal").html());
                    });
                    $(".valorFormat").on("keyup", function(e) {
                        formataValorDinheiro(this);
                    });

                    $("#btnRemoveTipo" + j).unbind("click");
                    $("#btnRemoveTipo" + j).click(function() {
                        $("#valorPagamento0").val(valorCompletoComanda);
                        $("#comValorTotal")
                            .html(
                                $_CONFIG.MOEDA +
                                parseFloat(valorCompletoComanda).toFixed(2).replace(".", ",")
                            )
                            .change();
                        $("#valorPagamento0").focus();
                        $("#btnInsereProdutoComanda").prop("disabled", false);
                        $("#btnInsereServicoComanda").prop("disabled", false);
                        $("#btnCobrarCliente").prop("disabled", false);
                        $scope.removeTipoPagemento();
                    });

                    $("#tipoPagamento" + j).unbind("change");
                    $("#tipoPagamento" + j).change(function() {
                        var idx = this.dataset.idx;
                        if (idx == 0 && j == 1) {
                            if (
                                $("#tipoPagamento" + idx + " option:selected").get(0).dataset
                                .desconto != "" &&
                                $("#tipoPagamento" + idx + " option:selected").get(0).dataset
                                .desconto != undefined
                            ) {
                                var displayDesconto = 1;
                                if (
                                    $("#tipoPagamento" + idx + " option:selected").get(0).dataset
                                    .tipodesconto != 2
                                ) {
                                    var tableItemsize = tabelaComItens.api().rows().length;
                                    var numseritem = 0;
                                    var numproitem = 0;
                                    for (let i = 0; i <= tableItemsize; i++) {
                                        if (tabelaComItens.api().rows().data()[i].TipoItem == 1) {
                                            numseritem = numseritem + 1;
                                        } else {
                                            numproitem = numproitem + 1;
                                        }
                                    }

                                    if (
                                        $("#tipoPagamento" + idx + " option:selected").get(0)
                                        .dataset.tipodesconto == 0 &&
                                        numseritem == 0
                                    ) {
                                        displayDesconto = 0;
                                    } else if (
                                        $("#tipoPagamento" + idx + " option:selected").get(0)
                                        .dataset.tipodesconto == 1 &&
                                        numproitem == 0
                                    ) {
                                        displayDesconto = 0;
                                    }
                                }
                                if (displayDesconto == 1) {
                                    swal({
                                            title: "Forma de pagamento com desconto",
                                            text: `<h4>Essa forma de pagamento possui um desconto de ${
                        $("#tipoPagamento" + idx + " option:selected").get(0)
                          .dataset.desconto
                      }%, deseja aplicar a essa comanda?</h4>`,
                                            type: "warning",
                                            showCancelButton: true,
                                            confirmButtonColor: "#DD6B55",
                                            confirmButtonText: $_CONFIG.language.sim,
                                            cancelButtonText: $_CONFIG.language.nao,
                                            closeOnConfirm: true,
                                            closeOnCancel: true,
                                            html: true,
                                        },
                                        function(isConfirm) {
                                            if (isConfirm) {
                                                $.ajax({
                                                    dataType: "json",
                                                    url: "/pages/cadastros/alteraComandaDescontov2.php",
                                                    data: {
                                                        comcodigo: $("#idComanda").html(),
                                                        tipopagamento: $(
                                                            "#tipoPagamento" + idx + " option:selected"
                                                        ).val(),
                                                    },
                                                    success: function(result) {
                                                        if (result.data[0].erro == "0") {
                                                            $scope.atualizaDadosItens();
                                                            if (location.hash == "#/comandasabertas") {
                                                                $rootScope.$emit("atualizaDadosComanda", {});
                                                            }
                                                            toastr.success(result.data[0].resultado);
                                                        } else {
                                                            toastr.error(result.data[0].resultado);
                                                        }
                                                    },
                                                });
                                            }
                                        }
                                    );
                                }
                            }
                        }

                        if (
                            $("#tipoPagamento" + idx + " option:selected").text() ==
                            "Resgate de Pontos"
                        ) {
                            toastr.info(
                                "Para efetivar o resgate tenha certeza de inserir o TOKEN, caso tenha associado prossiga normalmente"
                            );
                        }
                        if ($("#tipoPagamento" + idx + " option:selected").val() == "") {
                            $("#divBandeiraPag" + idx).val("");
                            $("#divBandeiraPag" + idx).prop("disabled", true);
                        } else {
                            $scope.buscaTipoBandeira(this);
                        }
                    });

                    j++;
                }
            };

            // Remove Tipo de Pagamento
            $scope.removeTipoPagemento = function() {
                if (j == 1) {
                    toastr.error("A Comanda deve possuir ao menos um tipo de pagamento!");
                } else {
                    if ($("#TraCodigo1").val() != "") {
                        atualizaTransacao($("#TraCodigo1").val());
                        $("#linhaPagamento1").remove();
                        $("#parcelarCaixa").prop("disabled", false);
                        $("#codigoTransacao1").val("");
                        j = 1;
                        g = 0;
                    } else {
                        $("#linhaPagamento1").remove();
                        $("#parcelarCaixa").prop("disabled", false);
                        $("#codigoTransacao1").val("");
                        j = 1;
                        g = 0;
                    }
                }
            };

            $scope.atualizaTipoPagemento = function() {
                for (var i = j; i >= 0; i--) {
                    $("#linhaPagamento" + i).remove();
                    $("#parcelarCaixa").prop("disabled", false);
                    $("#codigoTransacao" + i).val("");
                }
                j = 0;
                g = 0;
                $scope.buscaTipoPagamento();
            };

            // Busca Tipo Bandeira
            $scope.buscaTipoBandeira = function(tipobandeira) {
                var idx = tipobandeira.dataset.idx;
                var html = "";
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    data: {
                        metodo: "buscaTipoBandeira",
                        id: $scope.idCliente,
                        tpacodigo: tipobandeira.value,
                    },
                    success: function(result) {
                        html += '<option value ="">Bandeira</option>';
                        var iscartao = 1;

                        if (result.result.length == 1) {
                            iscartao = result.result[0].TPa_Cartao;
                            for (var i = 0; i < result.result.length; i++) {
                                html +=
                                    "<option value =" +
                                    result.result[i].TBa_Codigo +
                                    " selected>" +
                                    result.result[i].TBa_Descricao +
                                    "</option>";
                            }
                        } else if (result.result.length > 1) {
                            for (var i = 0; i < result.result.length; i++) {
                                html +=
                                    "<option value =" +
                                    result.result[i].TBa_Codigo +
                                    ">" +
                                    result.result[i].TBa_Descricao +
                                    "</option>";
                            }
                        } else {
                            iscartao = 0;
                        }

                        if (result.result.length == "0") {
                            $("#divBandeiraPag" + idx).prop("disabled", true);
                        } else {
                            $("#divBandeiraPag" + idx).prop("disabled", false);
                        }
                        if (iscartao == 0) {
                            $("#divBandeiraPag" + idx).prop("disabled", true);
                            html = '<option value ="">Bandeira</option>';
                        }
                        $("#divBandeiraPag" + idx).html(html);
                        $("#divBandeiraPag" + idx).val("");

                        $compile($("#divBandeiraPag" + idx))($scope);
                    },
                });
            };

            //insere o codigo da transacao na comanda
            $scope.comandaCodigoTransacao = function(idx) {
                $("#idxCodigoTransac").val(idx);
                $("#codigoTransacao-modal").modal();
            };

            $scope.guardaCodigoTransac = function() {
                var idx = $("#idxCodigoTransac").val();
                $("#codigoTransacao" + idx).val($("#inputcodigo").val());
                $("#inputcodigo").val("");
                $("#codigoTransacao-modal").modal("hide");
            };

            // Editar item Comanda
            $scope.editarItemComanda = function(idx) {
                if (j == 1) {
                    var registroTabela = tabelaComItens.fnGetData(idx);

                    if (registroTabela.ProGorjeta == 0) {
                        limpaToken($("#divTokenCom"), $("#tokenCom"), $("#msgTokenCom"));
                        $("#comValor").val(registroTabela.Valor);
                        $("#comValorRestore").val(registroTabela.Valor);
                        $("#comValorHd").val(registroTabela.ValorUn);
                        $("#comValorHdOLD").val(registroTabela.ValorUn);
                        $("#comValSerHd").val(registroTabela.ValorUn);
                        $("#comCodItem").val(registroTabela.CodItem);
                        $("#comTipoItem").val(registroTabela.TipoItem);
                        $("#comCodSerPro").val(registroTabela.CodSerPro);
                        $("#comDesconto").val(
                            registroTabela.Desconto.replace("%", "")
                            .replace($_CONFIG.MOEDA, "")
                            .replace(" ", "")
                        );
                        $("#comQtde").val(registroTabela.Quantidade);
                        $("#comComissao").val(
                            parseFloat(registroTabela.Comissao).formatMoney(2, ",")
                        );
                        $("#comComissaoHd").val(registroTabela.ComissaoPadrao);
                        $("#comComissaoPrincipalHd").val(registroTabela.ComissaoPrincipal);
                        $("#itemNome").html(registroTabela.Item);
                        $("#itemValorOriginal").val(registroTabela.ValorOriginal);
                        if (registroTabela.Quantidade == 1) {
                            $("#comToken").prop("disabled", false);
                        } else {
                            $("#comToken").prop("disabled", true);
                        }

                        $("#tipoUnidadeAddonEdtComanda").html(registroTabela.TipoUnidade);

                        if (registroTabela.TUnCodigo != 1) {
                            $("#comQtde").attr("type", "text");
                            $("#comQtde").attr(
                                "onkeyup",
                                "formataValorDinheiro(this); calculaValor();"
                            );
                        } else {
                            $("#comQtde").attr("type", "number");
                            $("#comQtde").attr("onkeyup", "");
                        }

                        if (registroTabela.Combo != "") {
                            $("#comValorHd").prop("disabled", true);
                            $("#comQtde").prop("disabled", true);
                            $("#comComissao").prop("disabled", true);
                            $("#comToken").prop("disabled", true);
                            $("#btnValidarToken").prop("disabled", true);
                            $("#comParaUso").prop("disabled", true);
                        } else {
                            $("#comValorHd").prop("disabled", false);
                            $("#comQtde").prop("disabled", false);
                            $("#comToken").prop("disabled", false);
                            $("#btnValidarToken").prop("disabled", false);
                            $("#comParaUso").prop("disabled", false);
                            if ($scope.parValorShowComissao == 1) {
                                $("#comComissao").attr("disabled", true);
                            } else {
                                $("#comComissao").attr("disabled", false);
                            }
                        }
                        $("#listaServicoUsoEdt").hide();
                        if (registroTabela.TipoItem == "0") {
                            $("#comQtde").prop("disabled", false);
                            $("#comProValor").val(registroTabela.ProValor);
                            if (registroTabela.Venda == "0") {
                                $("#comParaUso").get(0).checked = true;
                                if (
                                    $scope.parDescontoProduto == "1" ||
                                    $scope.parDescontoProduto == "2"
                                ) {
                                    if ($("#listServicoComandaEdt").children().length > 0) {
                                        $("#listaServicoUsoEdt").show();
                                    }
                                }
                            } else {
                                $("#comParaUso").get(0).checked = false;
                            }
                        } else {
                            $("#comQtde").prop("disabled", true);
                        }

                        if (registroTabela.Cortesia == "1") {
                            $("#comCortesia").get(0).checked = true;
                        } else {
                            $("#comCortesia").get(0).checked = false;
                        }

                        if (registroTabela.TipoItem == "1") {
                            $("#comParaUsoTipoItem").hide();
                            $("#comAlteraDataAgendamento").show();
                        } else {
                            $("#comParaUsoTipoItem").show();
                            $("#comAlteraDataAgendamento").hide();
                        }

                        if (registroTabela.TipoDesconto != "") {
                            $("#tipoDesconto").val(registroTabela.TipoDesconto);
                        } else {
                            $("#tipoDesconto").val("-1");
                        }

                        $("#comanda-modal").modal("hide");
                        $("#comandaEdit-modal").modal("show");
                    } else {
                        $("#itemComandaGorjeta").val(registroTabela.CodItem);
                        $("#valorComandaGorjetaAltera").val(registroTabela.Valor);
                        $("#profissionalGorjetaAltera").val(
                            registroTabela.CodigoProfissionalComissao
                        );
                        $("#comandaAlteraGorjeta-modal").modal();
                        $("#listaServicoUsoEdt").hide();
                    }
                } else {
                    swal(
                        "Não é possivel alterar itens em uma comanda com mais de uma forma de pagamento",
                        "",
                        "warning"
                    );
                }
            };

            $("#comValorDesconto").keyup(function() {
                if ($("#comValorDesconto").val() > 100) {
                    $("#comValorDesconto").val(100);
                }
            });

            // Remove itens pacote comanda
            $scope.removePacoteItemComanda = function(codigo) {
                swal({
                        title: "Confirmar exclusão:",
                        text: "Deseja desassociar o pacote?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Sim",
                        cancelButtonText: "Não",
                        closeOnConfirm: true,
                    },
                    function() {
                        showLoader(true);
                        $.ajax({
                            dataType: "html",
                            url: "/pages/cadastros/removePacoteItemComanda.php",
                            data: {
                                ppdcodigo: codigo,
                            },
                            success: function(data) {
                                if (data == "0") {
                                    toastr.success("Pacote Desassociado com Sucesso.");
                                    $scope.atualizaDadosItens();
                                    if (location.hash == "#/comandasabertas") {
                                        $rootScope.$emit("atualizaDadosComanda", {});
                                    }
                                } else {
                                    toastr.error(data, "Falha ao Desassociado o Pacote.");
                                }
                                showLoader(false);
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                                showLoader(false);
                            },
                        });
                    }
                );
            };

            // Adicionar item Pacote comanda
            $scope.adicionarPacoteItemComanda = function(idx) {
                var hasPacote = 0;
                var hasAssinatura = 0;
                showLoader(true);
                if (j == 1) {
                    var registroTabela = tabelaComItens.fnGetData(idx);
                    $.ajax({
                        url: "/pages/cadastros/buscaPacotesPessoaCombo.php",
                        type: "POST",
                        dataType: "json",
                        async: false,
                        data: {
                            pescodigo: $("#codCliente").val(),
                            codigo: registroTabela.CodSerPro,
                            tipo: registroTabela.TipoItem,
                        },
                        success: function(data) {
                            if (data.result.length > 0) {
                                html = '<option value="-1">Selecione um Pacote</option>';
                                for (var i = 0; i < data.result.length; i++) {
                                    html +=
                                        "<option data-codigo='" +
                                        data.result[i].PTe_Codigo +
                                        "' data-cadastro='" +
                                        data.result[i].PPa_Dat_Cadastro +
                                        "' data-uso='" +
                                        data.result[i].PPa_Qtd_Usada +
                                        "' data-total='" +
                                        data.result[i].PPa_Qtd_Sessao +
                                        "' value='" +
                                        data.result[i].PPa_Codigo +
                                        "'>" +
                                        data.result[i].Pac_Descricao +
                                        "</option>";
                                }

                                $("#pacotesComandaCombo").html(html);
                                $("#comTipoItemPac").val(registroTabela.TipoItem);
                                $("#comCodSerProPac").val(registroTabela.CodSerPro);
                                $("#comCodItemPac").val(registroTabela.CodItem);
                                $("#itemNomePacote").html(registroTabela.Item);

                                hasPacote = 1;
                            }

                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });

                    $.ajax({
                        url: "/pages/cadastros/buscaAssinaturaPessoaItens.php",
                        type: "POST",
                        dataType: "json",
                        async: false,
                        data: {
                            pescodigocliente: $("#codCliente").val(),
                            sercodigo: registroTabela.CodSerPro,
                            dataagendamento: registroTabela.dataComanda,
                        },
                        success: function(data) {
                            if (data.data.length > 0) {
                                if (data.data[0].Disponivel == 1) {
                                    hasAssinatura = 1;
                                }

                                if (data.data[0].ISMulti == 1) {
                                    if (data.data[0].Disponiveis == 10000) {
                                        $("#titleUtilizacao").html(`Ilimitado`);
                                    } else {
                                        $("#titleUtilizacao").html(
                                            `${data.data[0].Usados}/${data.data[0].Disponiveis}`
                                        );
                                    }
                                } else {
                                    $("#titleUtilizacao").html(
                                        `${data.data[0].Usados}/${data.data[0].Disponiveis}`
                                    );
                                }
                                $("#titleVencimento").html(data.data[0].Vencimento);
                                $("#titleAssinatura").html(data.data[0].Descricao);
                                $("#AssCodigoAssocia").val(data.data[0].CodigoAssinatura);
                                $("#APFCodigoAssocia").val(data.data[0].CodigoFatura);
                                $("#CitCodigoAssocia").val(registroTabela.CodItem);
                                $("#IsMultiUnidade").val(data.data[0].ISMulti);
                            }
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                } else {
                    toastr.warning(
                        "Não é possivel alterar itens em uma comanda com mais de uma forma de pagamento"
                    );
                }

                if (hasPacote == 1 && hasAssinatura == 1) {
                    $("#comanda-modal").modal("hide");
                    $("#selectTipoAssociacao-modal").modal("show");
                } else if (hasPacote == 1 && hasAssinatura == 0) {
                    $("#comanda-modal").modal("hide");
                    $("#comandaPacote-modal").modal("show");
                } else if (hasPacote == 0 && hasAssinatura == 1) {
                    $("#comanda-modal").modal("hide");
                    $("#comandaAssinatura-modal").modal("show");
                } else {
                    toastr.error(
                        "Sem pacote ou assinatura para este Cliente com este Item."
                    );
                }
            };

            $scope.displayOptionPacote = function() {
                $("#selectTipoAssociacao-modal").modal("hide");
                $("#comandaPacote-modal").modal("show");
            };

            $scope.displayOptionAssinatura = function() {
                $("#selectTipoAssociacao-modal").modal("hide");
                $("#comandaAssinatura-modal").modal("show");
            };

            // Exclui itens Comanda
            $scope.excluirItemComanda = function(idx) {
                var tempagOnline = 0;
                var itenComanda = tabelaComItens.fnGetData();
                for (var k = 0; k < itenComanda.length; k++) {
                    if (itenComanda[k].PagamentoOnline == 1) {
                        tempagOnline = 1;
                    }
                }
                if (j == 2 && tempagOnline == 0) {
                    toastr.warning(
                        "Não é possivel alterar itens em uma comanda com mais de uma forma de pagamento"
                    );
                } else {
                    var registroTabela = tabelaComItens.fnGetData(idx);
                    if (registroTabela.ExistePacote == "1") {
                        toastr.error(
                            "Para excluir este item, desassocie o pacote.",
                            "Existe um pacote associado."
                        );
                    } else {
                        swal({
                                title: "Confirmar exclusão:",
                                text: "Deseja excluir o item " + registroTabela.Item,
                                type: "input",
                                inputPlaceholder: "Informe o Motivo da Exclusão",
                                showCancelButton: true,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "Sim",
                                cancelButtonText: "Não",
                                closeOnConfirm: false,
                            },
                            function(inputValue) {
                                if (inputValue === false) return false;
                                if (inputValue === "") {
                                    swal.showInputError("Especifique o motivo!");
                                    return false;
                                } else {
                                    showLoader(true);
                                    $.ajax({
                                        dataType: "html",
                                        url: "/pages/cadastros/removeItensComanda.php",
                                        data: {
                                            citcodigo: registroTabela.CodItem,
                                            motivo: inputValue,
                                        },
                                        success: function(data) {
                                            if (data == "0") {
                                                toastr.success("Item Excluido com Sucesso.");
                                                $scope.atualizaDadosItens();
                                                if (location.hash == "#/comandasabertas") {
                                                    $rootScope.$emit("atualizaDadosComanda", {});
                                                }

                                                if (location.hash == "#/agenda") {
                                                    $rootScope.$emit("BuscaAgenda", {});
                                                }
                                                if (location.hash == "#/relGerencialEstoque") {
                                                    $rootScope.$emit("atulizaRelEstoque", {});
                                                }
                                                swal.close();
                                            } else {
                                                swal("Falha ao Excluir o Item.", data, "error");
                                            }
                                            showLoader(false);
                                        },
                                        error: function(result) {
                                            swal("Falha na conexão.", "", "error");
                                            showLoader(false);
                                        },
                                    });
                                }
                            }
                        );
                    }
                }
            };

            // Busca Combo Produto
            $scope.buscaProdutoCombo = function() {
                try {
                    if ($("#comProduto").hasClass("select2-hidden-accessible")) {
                        $("#comProduto").select2("destroy");
                    }
                } catch (e) {
                    console.log("");
                } finally {
                    $("#formInsereItemComanda").each(function() {
                        this.reset();
                    });
                    $("#comQtdeInsert").prop("disabled", false);

                    if (
                        $("#TprTipoComanda").html() == 1 ||
                        $("#TprTipoComanda").html() == "" ||
                        $("#treAgendaCodigo").html() == 1
                    ) {
                        $.ajax({
                            dataType: "json",
                            url: "/pages/cadastros/buscaProdutosv3.php",
                            data: {
                                procodigo: "",
                                tipo: 2,
                            },
                            success: function(result) {
                                var combo = "";
                                combo +=
                                    '<option data-iscombo="0" value="-1" selected="true"  data-valor="0" data-comissao="0">Selecione um Produto</option>';
                                for (var i = 0; i < result.data.length; i++) {
                                    if (result.data[i].Pro_Disp_Venda != 1) {
                                        combo +=
                                            '<option data-iscombo="0" data-imagem="' +
                                            result.data[i].Pro_Figura +
                                            '" value =' +
                                            result.data[i].Pro_Codigo +
                                            ' data-valor="' +
                                            result.data[i].Pro_Valor +
                                            '" data-comissao="' +
                                            result.data[i].Pro_Comissao +
                                            '" data-qtdminima="' +
                                            result.data[i].StatusQtdMinima +
                                            '" data-tuncodigo="' +
                                            result.data[i].TUn_Codigo +
                                            '" data-tunabreviatura="' +
                                            result.data[i].TUn_Abreviatura +
                                            '">' +
                                            result.data[i].Pro_Descricao +
                                            "</option>";
                                    }
                                }

                                $.ajax({
                                    dataType: "json",
                                    url: "/pages/cadastros/buscaCombo.php",
                                    async: false,
                                    data: {
                                        tipo: 3,
                                    },
                                    success: function(result) {
                                        if (result.data.length > 0) {
                                            combo =
                                                '<optgroup label="Produto">' + combo + "</optgroup>";
                                            combo += '<optgroup label="Combos">';
                                            for (var j = 0; j < result.data.length; j++) {
                                                combo +=
                                                    '<option data-iscombo="1" data-imagem="' +
                                                    result.data[j].CBo_Imagem +
                                                    '" data-comissao="0" value =' +
                                                    result.data[j].CBo_Codigo +
                                                    ' data-valor="' +
                                                    result.data[j].CBo_Valor +
                                                    '" data-tuncodigo="1" data-tunabreviatura="un" >' +
                                                    result.data[j].CBo_Descricao +
                                                    "</option>";
                                            }
                                            combo += "</optgroup>";
                                        }
                                    },
                                });

                                $("#comProduto").html(combo);
                                $("#comProduto").select2({
                                    templateResult: thumbProduto,
                                });
                            },
                        });
                    } else {
                        $.ajax({
                            dataType: "json",
                            url: "/pages/cadastros/buscaProdutosProfissionais.php",
                            data: {},
                            success: function(result) {
                                var combo = "";
                                combo =
                                    '<option value="-1" selected="true">Selecione um Produto</option>';

                                for (var i = 0; i < result.data.length; i++) {
                                    var comissao = 0.0;
                                    if (result.data.geracomissaoprof == 1) {
                                        comissao = result.data[i].comissao;
                                    }

                                    combo +=
                                        '<option  data-iscombo="0" data-imagem="' +
                                        result.data[i].figura +
                                        '" value =' +
                                        result.data[i].procodigo +
                                        ' data-valor="' +
                                        result.data[i].valor +
                                        '" data-comissao="' +
                                        comissao +
                                        '" data-qtdminima="' +
                                        result.data[i].qtdminima +
                                        '" data-tuncodigo="' +
                                        result.data[i].TUn_Codigo +
                                        '"  data-tunabreviatura="' +
                                        result.data[i].TUn_Abreviatura +
                                        '">' +
                                        result.data[i].descricao +
                                        "</option>";
                                }
                                $("#comProduto").html(combo);
                                $("#comProduto").select2({
                                    templateResult: thumbProduto,
                                });
                            },
                        });
                    }

                    $("#comQtdeInsert").attr("type", "number");
                    $("#comQtdeInsert").attr("onkeyup", "");
                }
            };

            // Busca Select Serviço
            $scope.buscaServicoSelect = function() {
                $("#formInsereItemComandaSer").each(function() {
                    this.reset();
                });
                $.ajax({
                    dataType: "json",
                    // url: '/pages/cadastros/buscaServicoSelect.php',
                    url: "/pages/cadastros/buscaServicoSelectCombo.php",
                    success: function(result) {
                        var combo =
                            '<option value =""  data-valor="" data-tipopreco="">Selecione um Serviço</option>';
                        for (var i = 0; i < result.servicos.length; i++) {
                            combo +=
                                "<option value =" +
                                result.servicos[i].Ser_Codigo +
                                ' data-valor="' +
                                result.servicos[i].Ser_Valor +
                                '"  data-tipopreco="' +
                                result.servicos[i].Ser_Tip_Preco +
                                '" name="' +
                                result.servicos[i].Ser_Duplo +
                                '" data-tipoitem="' +
                                result.servicos[i].TipoItem +
                                '">' +
                                result.servicos[i].Ser_Descricao +
                                "</option>";
                        }
                        $("#comInsertServico").html(combo);
                        $("#comInsertServico").select2({
                            templateResult: thumbServico,
                        });
                    },
                });
            };

            $scope.buscaServicoSelect();

            // Busca Pessoa Conta
            $scope.buscaPessoaConta = function() {
                $scope.dadosClienteComanda = "";
                $("#pessoaConta").html("");
                $("#pessoaConta").hide();

                var pessoaConta = "";
                var pesCodigoCliente = $("#codCliente").val();

                if (pesCodigoCliente != "") {
                    $("#pessoaConta").show();
                    $.ajax({
                        dataType: "json",
                        url: localStorage.getItem("host"),
                        data: {
                            metodo: "buscaPessoaConta",
                            id: $scope.idCliente,
                            tipo: "5",
                            pescodigocliente: pesCodigoCliente,
                        },
                        success: function(result) {
                            if ($("#TprTipoComanda").html() == "3") {
                                var tipocomandaconta = "profissional";
                            } else {
                                var tipocomandaconta = "cliente";
                            }
                            if (result.result[0] != undefined) {
                                if (result.result[0].SaldoReal < 0.0) {
                                    pessoaConta +=
                                        "<label><span style='color:red'>Saldo na conta do " +
                                        tipocomandaconta +
                                        ": " +
                                        result.result[0].PCo_Saldo +
                                        "</label>&nbsp&nbsp<button ng-click='detalhesContaCliente()' class='btn btn-primary btn-xs'>Ver detalhes</button>&nbsp<button id='btnPagacomanda' class='btn btn-warning btn-xs' ng-click='pagaContaCliente(1," +
                                        result.result[0].SaldoReal +
                                        ")'>Pagar</button>";
                                } else if (result.result[0].SaldoReal > 0.0) {
                                    pessoaConta +=
                                        "<label><span style='color:green'>Saldo na conta do " +
                                        tipocomandaconta +
                                        ": " +
                                        result.result[0].PCo_Saldo +
                                        "</label >&nbsp&nbsp<button ng-click='detalhesContaCliente()' class='btn btn-primary btn-xs'>Ver detalhes</button>&nbsp<button id='btnPagacomanda' class='btn btn-warning btn-xs' ng-click='pagaContaCliente(2," +
                                        result.result[0].SaldoReal +
                                        ")'>Pagar</button>";
                                }
                            }
                            $("#pessoaConta").html(pessoaConta);
                            $compile($("#pessoaConta"))($scope);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                    $("#btnPagacomanda").prop("disabled", false);
                } else {
                    $("#pessoaConta").html("");
                    $("#pessoaConta").hide();
                }
            };

            // Mostra info Cliente
            $scope.mostraInfoClientes = function(codcliente) {
                if ($_CONFIG.HASACESSOINFOCLI == 1) {
                    var datafim = moment().locale("pt-br").format("L");
                    var dataini = moment().add(-90, "days").locale("pt-br").format("L");
                    $(".date.divDataIniAge").datepicker("update", dataini);
                    $(".date.divDataFimAge").datepicker("update", datafim);
                    $(".date.divDataIniCom").datepicker("update", dataini);
                    $(".date.divDataFimCom").datepicker("update", datafim);
                    $(".date.divDataIniPac").datepicker("update", dataini);
                    $(".date.divDataFimPac").datepicker("update", datafim);
                    $(".date.divDataIniPts").datepicker("update", dataini);
                    $(".date.divDataFimPts").datepicker("update", datafim);

                    if (codcliente == "") {
                        toastr.error(
                            "Para ver mais informações, associe um cliente.",
                            "Sem Cliente Associado."
                        );
                    } else {
                        showLoader(true);
                        $.ajax({
                            dataType: "json",
                            url: "/pages/cadastros/buscaClientesInformacoes.php",
                            data: {
                                pescodigo: codcliente,
                            },
                            success: function(data) {
                                $("#divBtnLGPD").hide();
                                var valores = data.clientes[0];
                                $("#cliNomeInfo").html(valores.Pes_Nome);
                                $("#cliCpfInfo").html(valores.Paf_Cpf);
                                $("#cliEmailInfo").html(valores.Paf_Email);
                                $("#cliCelularInfo").html(valores.Paf_Celular);
                                $("#cliTelefoneInfo").html(valores.Paf_Telefone);
                                $("#cliLoginInfo").html(valores.Usu_Login);
                                $("#cliSexoInfo").html(valores.Paf_Sexo);
                                $("#cliDataNascimentoInfo").html(valores.PAF_Dat_Nascimento);
                                $("#cliEnderecoInfo").html(valores.Paf_Endereco);
                                $("#cliBairroInfo").html(valores.Paf_Bairro);
                                $("#cliCidadeInfo").html(valores.Cid_Nome);
                                $("#cliEstadoInfo").html(valores.Est_Sigla);
                                $("#cliCepInfo").html(valores.Paf_CEP);
                                $("#cliCodigoInfo").html(valores.Usu_Codigo);
                                $("#cliObsInfo").html(valores.Paf_Observacao);
                                $("#cliPesCodigoInfo").val(valores.Pes_Codigo);
                                $("#cliDatCadastro").html(valores.Pes_Dat_Cadastro);

                                $("#nomePrint").html(valores.Pes_Nome);
                                $("#cpfPrint").html(valores.Paf_Cpf);
                                $("#emailPrint").html(valores.Paf_Email);
                                $("#celPrint").html(valores.Paf_Celular);
                                $("#telPrint").html(valores.Paf_Telefone);
                                $("#sexoPrint").html(valores.Paf_Sexo);
                                $("#datanascPrint").html(valores.PAF_Dat_Nascimento);
                                $("#endPrint").html(valores.Paf_Endereco);
                                $("#bairroPrint").html(valores.Paf_Bairro);
                                $("#cidPrint").html(valores.Cid_Nome);
                                $("#estPrint").html(valores.Est_Sigla);
                                $("#dataCadPrint").html(valores.Pes_Dat_Cadastro);

                                var htmlbotao = `<button class="btn btn-primary btn-xs" id="btnEmailLGPD" ng-click="enviaEmailClienteLGPD(${valores.Pes_Codigo})"><i class="fa fa-envelope"></i> Termos de Uso</button><a class="btn btn-info btn-xs" target="_blank" href="https://termosdeuso.s3-sa-east-1.amazonaws.com/TermoConsentimento/AppBarber/AppBarber-TermodeConsentimento.pdf">Ver Termo</a>`;
                                if (valores.Paf_Email != "" && valores.PAF_LGPD != 1) {
                                    $("#divBtnLGPD").html(htmlbotao);
                                    $("#divBtnLGPD").show();

                                    $compile($("#divBtnLGPD"))($scope);
                                } else {
                                    $("#divBtnLGPD").html("");
                                    $("#divBtnLGPD").hide();
                                }

                                if (valores.Paf_Imagem != "") {
                                    $("#cliImagemInfo").attr("src", valores.Paf_Imagem);
                                    $("#imgPrint").attr("src", valores.Paf_Imagem);
                                } else {
                                    $("#cliImagemInfo").attr("src", "/img/nopicture.png");
                                    $("#imgPrint").attr("src", "/img/nopicture.png");
                                }

                                $App.formatDateSort();
                                $scope.buscaCliAgendamento(
                                    $("#cliDatInicioAge").val(),
                                    $("#cliDatFimAge").val()
                                );
                                $scope.buscaCliComanda(
                                    $("#cliDatInicioCom").val(),
                                    $("#cliDatFimCom").val()
                                );
                                $scope.buscaCliPacote(
                                    $("#cliDatInicioPac").val(),
                                    $("#cliDatFimPac").val()
                                );
                                $("#servicoPront").val("");
                                $("#profPront").val("");
                                $("#cliDatInicioPron").val("");
                                $("#cliDatFimPron").val("");
                                $scope.buscaProntuarioCliente(codcliente);
                                $scope.buscaCliPonto(codcliente);
                                $scope.buscaPessoaContaInfoCli(codcliente);
                                if (valores.StatusPessoa == "*") {
                                    $(".btnAlteracaoCliente").hide();
                                } else {
                                    $(".btnAlteracaoCliente").show();
                                }
                                $("#infoCliente-modal").modal();
                                showLoader(false);
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                                showLoader(false);
                            },
                        });

                        $.ajax({
                            dataType: "html",
                            url: "/pages/cadastros/buscaClienteInfo.php",
                            method: "POST",
                            data: {
                                pesCodigo: codcliente,
                                tipo: 1,
                                dataIni: "",
                                dataFim: "",
                            },
                            dataType: "json",
                            success: function(data) {
                                $("#serDescricao").html(data.data[0].ServicoDescricao);
                                $("#serTotal").html(data.data[0].TotalServico);
                                $("#proNome").html(data.data[0].ProdutoDescricao);
                                $("#porTotal").html(data.data[0].TotalProduto);
                                $("#totalDias").html(data.data[0].DiasSemVir);
                                $("#totalGasto").html(data.data[0].GastosClientes);
                                if (data.data[0].UltimoAcessoCliente != "") {
                                    $("#ultimoAcessoCliente").html(
                                        data.data[0].UltimoAcessoCliente
                                    );
                                } else {
                                    $("#ultimoAcessoCliente").html(
                                        "Não possui usuário,<br> ou nunca acessou"
                                    );
                                }
                            },
                        });

                        $("#CliAgeInicio").html("");
                        $("#CliLastServico").html("");
                        $("#CliLastProf").html("");

                        $.ajax({
                            dataType: "html",
                            url: "/pages/cadastros/buscaClienteInfo.php",
                            method: "POST",
                            data: {
                                pesCodigo: codcliente,
                                tipo: 5,
                                dataIni: "",
                                dataFim: "",
                            },
                            dataType: "json",
                            success: function(data) {
                                $("#CliAgeInicio").html(data.data[0].Age_Dat_Inicio);
                                $("#CliLastServico").html(data.data[0].Ser_Descricao);
                                $("#CliLastProf").html(data.data[0].Pes_Nome);
                            },
                        });

                        // card dos pontos
                        $.ajax({
                            dataType: "html",
                            url: "/pages/relatorios/buscaProgramaFidelidade.php",
                            method: "POST",
                            data: {
                                selCliente: codcliente,
                                selTipo: 1,
                            },
                            dataType: "json",
                            success: function(data) {
                                if (data.data.length == 1) {
                                    $("#pontosClientes").html(data.data[0].TotalPontos);
                                } else {
                                    $("#pontosClientes").html(0);
                                }
                            },
                        });
                        $("#pesCodigoTokenInfo").val(codcliente);
                    }

                    $.ajax({
                        dataType: "json",
                        url: "/pages/cadastros/buscaServicoSelect.php",
                        success: function(result) {
                            var combo = "";
                            combo += "<option value=''>Nenhum</option>";
                            for (var i = 0; i < result.servicos.length; i++) {
                                combo +=
                                    "<option value =" +
                                    result.servicos[i].Ser_Codigo +
                                    ' data-valor="' +
                                    result.servicos[i].Ser_Valor +
                                    '" name="' +
                                    result.servicos[i].Ser_Duplo +
                                    '">' +
                                    result.servicos[i].Ser_Descricao +
                                    "</option>";
                            }
                            $("#servicoPront").html(combo);
                        },
                    });
                    $.ajax({
                        dataType: "json",
                        url: "pages/cadastros/buscaProfissionalSelect.php",
                        success: function(data) {
                            var profissional = "";
                            profissional +=
                                '<option  value="">' +
                                $_CONFIG.language.profissional +
                                "</option>";
                            for (var i = 0; i < data.profissionais.length; i++) {
                                var codigo = data.profissionais[i].Pes_Codigo;
                                var nome = data.profissionais[i].Pes_Nome;
                                profissional +=
                                    '<option  value="' + codigo + '">' + nome + "</option>";
                            }
                            $("#profPront").html(profissional);
                        },
                    });
                } else {
                    $("#infoCliente-modal").modal();
                }
            };

            $scope.detalhesContaCliente = function() {
                $App.formatDateSort();
                $("#contaClienteDeatalhes-modal").modal();
                if (typeof tabela != "undefined") {
                    tabela.api().destroy();
                }
                var codcliente = $("#codCliente").val();
                // if (location.hash == "#/pacotesVenda") {
                // 	codcliente =  $("#venCliente").val();
                // }
                tabela = $("#tbContaClienteDetalhes").dataTable({
                    ajax: {
                        url: "/pages/cadastros/buscaContaClientes.php",
                        method: "POST",
                        data: function(d) {
                            d.pescodigo = codcliente;
                        },
                    },
                    fnRowCallback: function(nRow, aData) {
                        var id = aData.PCo_Tipo;
                        var $nRow = $(nRow);
                        if (id == "D") {
                            $nRow
                                .map(function() {
                                    return $(this).css({
                                        color: "#F44336",
                                    });
                                })
                                .get();
                        } else {
                            $nRow
                                .map(function() {
                                    return $(this).css({
                                        color: "#1B5E20",
                                    });
                                })
                                .get();
                        }

                        return nRow;
                    },
                    dom: "Bfrtip",
                    buttons: [{
                            extend: "excelHtml5",
                            text: "Excel",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: "true",
                        },
                        {
                            extend: "pdfHtml5",
                            title: "sistema - Conta Cliente",
                            orientation: "landscape",
                            pageSize: "LEGAL",
                            exportOptions: {
                                columns: ":visible",
                            },
                        },
                    ],

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,

                    initComplete: function() {
                        var vlrTotal = this.fnGetData(this.fnGetNodes().length - 1);

                        $("#lblSaldo").show();
                        $("#btnCredito").show();
                        $("#btnDebito").show();

                        if (vlrTotal == null) {
                            $("#valorTotal").html("0,00");
                        } else {
                            $("#valorTotal").html(vlrTotal.Saldo);
                        }
                        resizeContent();
                    },
                    columnDefs: [{
                        targets: [0, 1, 7, 8, 9],
                        visible: false,
                        searchable: false,
                    }, ],
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                    columns: [{
                            data: "DT_RowId",
                        },
                        {
                            data: "PCo_Codigo",
                        },
                        {
                            data: "PCo_Descricao",
                        },
                        {
                            data: "PCo_Dat_Lancamento",
                            type: "moment-DD/MM/YYYY",
                        },
                        {
                            data: "PCo_Valor",
                        },
                        {
                            data: "PCo_TipoMov",
                        },
                        {
                            data: "Saldo",
                        },
                        {
                            data: "PCo_Tipo",
                        },
                        {
                            data: "PCo_Vlr_Real",
                        },
                        {
                            data: "Com_Codigo",
                        },
                    ],
                });
            };

            // Calcula Parcela
            $scope.calculaParcelas = function(valor) {
                valor = valor.replace(",", ".");
                valor = valor.replace($_CONFIG.MOEDA, "");
                var html = "";
                if (valor != "0.00") {
                    for (var i = 2; i <= 12; i++) {
                        var valorparcela = valor / i;
                        var valorparcelatext = parseFloat(valorparcela)
                            .formatMoney()
                            .replace(".", ",");
                        var option =
                            "<option value='" +
                            i +
                            "'>" +
                            i +
                            "x de " +
                            $_CONFIG.MOEDA +
                            valorparcelatext +
                            "</option>";
                        html += option;
                    }
                } else {
                    var option = "<option value=''>" + $_CONFIG.MOEDA + "0,00</option>";
                    html += option;
                }
                $("#selVezesParcela").html(html);
            };

            // Busca Itens Comanda
            $scope.buscaItensComanda = function(codigo) {
                $("#pessoaDetalhesAssinaturas").html("");
                $("#listServicoComanda").html("");
                $("#listServicoComandaEdt").html("");
                if (typeof tabelaComItens != "undefined") {
                    tabelaComItens.api().destroy();
                }
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaPessoa.php",
                    method: "POST",
                    data: {
                        tipo: 2,
                    },
                    success: function(result) {
                        if (result.buscaPessoa.length > 0) {
                            var valores = result.buscaPessoa[0];
                            var html = "";
                            $("#nomeSalao").html(valores.Nome);
                            html =
                                valores.Endereco +
                                ", " +
                                valores.Numero +
                                " - " +
                                valores.Bairro +
                                " | " +
                                valores.Cid_Nome +
                                "/" +
                                valores.Est_Sigla +
                                "<br>";
                            html += "Telefone: " + valores.Telefone + "<br>";
                            html += "Email: " + valores.Email + "<br>";
                            html += valores.CNPJ;
                            $("#infoSalao").html(html);
                            $("#enderecoEstabelecimento").show();
                        } else {
                            $("#enderecoEstabelecimento").hide();
                            $("#nomeSalao").html("");
                            $("#infoSalao").html("");
                        }
                    },
                });

                tabelaComItens = $("#tbComandaItens").dataTable({
                    ajax: "/pages/cadastros/buscaItensComanda.php?codigo=" + codigo,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                    bPaginate: false,
                    bLengthChange: false,
                    bFilter: false,
                    bSort: false,
                    bInfo: false,
                    bAutoWidth: false,
                    rowCallback: function(nRow, aData, index) {
                        if (aData.TipoItem == 1) {
                            $("#listServicoComanda").append(
                                `<option value="${aData.AgeCodigo}">${aData.Item} - Profissional: ${aData.Profissional}</option>`
                            );
                            $("#listServicoComandaEdt").append(
                                `<option value="${aData.AgeCodigo}">${aData.Item} - Profissional: ${aData.Profissional}</option>`
                            );
                        }
                        $.ajax({
                            url: "/pages/cadastros/buscaPacotesPessoaCombo.php",
                            type: "POST",
                            dataType: "json",
                            data: {
                                pescodigo: $("#codCliente").val(),
                                codigo: aData.CodSerPro,
                                tipo: aData.TipoItem,
                            },
                            success: function(data) {
                                if (data.result.length > 0) {
                                    for (var i = 0; i < nRow.children.length; i++) {
                                        if (
                                            nRow.children[i].className == " pacoteclass" &&
                                            nRow.children[i].className != "sorting_1" &&
                                            aData.ExistePacote != "1"
                                        ) {
                                            if (
                                                nRow.children[i].children[0].children[1].className !=
                                                "notpacote"
                                            ) {
                                                nRow.children[i].children[0].children[1].className =
                                                    "fa fa-exclamation";
                                                nRow.children[i].children[0].children[1].style.display =
                                                    "inline";
                                            }
                                        }
                                    }
                                } else {}
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                            },
                        });
                        return nRow;
                    },
                    initComplete: function() {
                        var vlrTotal = this.fnGetData(0);

                        if (vlrTotal != null) {
                            $("#valorTotalComanda").html(
                                $_CONFIG.MOEDA + vlrTotal.ValorTotal
                            );
                            $("#comValorTotal").html($_CONFIG.MOEDA + vlrTotal.ValorTotal);
                            $("#valorPagamento0").val(vlrTotal.ValorTotal);
                            $("#comValorPag").val(vlrTotal.ValorTotal);
                            $("#comCodSerPro").val(vlrTotal.CodSerPro);
                            $scope.typeCadComanda = vlrTotal.TprCadastro;
                            $("#comValorDesconto").val("");
                            $("#btnNovoTipo").show();

                            // CLIENTE_BUSCA_INFO
                            $.ajax({
                                dataType: "html",
                                url: "/pages/cadastros/CLIENTE_Busca_Info.php",
                                method: "POST",
                                data: {
                                    type: 1,
                                    person_code: vlrTotal.ClienteCodigo,
                                    client_code: "",
                                },
                                dataType: "json",
                                success: function(data) {
                                    if (data.data.error == false) {
                                        $scope.dadosClienteComanda = data.data.client[0];
                                        if ($scope.typeCadComanda == 1) {
                                            if (data.data.client[0].CIE_ID_Externo != "") {
                                                if (data.data.client[0].CIE_Cobranca == 1) {
                                                    $("#divCardButton").show();
                                                    $("#divPixButton").removeClass("col-md-offset-3");
                                                } else {
                                                    $("#divCardButton").hide();
                                                    $("#divPixButton").addClass("col-md-offset-3");
                                                }
                                            } else {
                                                $("#divCardButton").hide();
                                                $("#divPixButton").addClass("col-md-offset-3");
                                            }
                                        } else {
                                            $("#divCardButton").hide();
                                            $("#divPixButton").addClass("col-md-offset-3");
                                        }
                                        if (data.data.client[0].Plano != "") {
                                            var prefixo = "";

                                            if (data.data.client[0].TipoAssinautra != "") {
                                                prefixo = '<span class="badge bg-blue">R</span>';
                                            } else {
                                                prefixo = '<span class="badge bg-default">C</span>';
                                            }
                                            var detalhesAssinatura =
                                                prefixo +
                                                " " +
                                                data.data.client[0].Plano +
                                                " - " +
                                                data.data.client[0].StatusAssinatura;

                                            $("#pessoaDetalhesAssinaturas").html(detalhesAssinatura);
                                        }
                                    } else {
                                        $("#divCardButton").hide();
                                        $("#divPixButton").addClass("col-md-offset-3");
                                    }
                                },
                            });

                            $scope.calculaParcelas(vlrTotal.ValorTotal);

                            var itensComandaLoop = this.fnGetData();
                            var valorPagamentoOnline = 0.0;
                            var itensOnline = 0;

                            var valorPagamentoComanda = 0;
                            var completePayment = 0;
                            var isPix = 0;
                            var isPinPad = 0;
                            var isPinPadPix = 0;
                            for (
                                var loopItem = 0; loopItem < itensComandaLoop.length; loopItem++
                            ) {
                                if (itensComandaLoop[loopItem].PagamentoOnline == 1) {
                                    valorPagamentoOnline =
                                        valorPagamentoOnline +
                                        parseFloat(
                                            itensComandaLoop[loopItem].ValorUn.replace(",", ".")
                                        );
                                    itensOnline++;
                                }
                                valorPagamentoComanda = itensComandaLoop[loopItem].CPoValor;
                                completePayment = itensComandaLoop[loopItem].CPoPagamentoTotal;
                                isPix = itensComandaLoop[loopItem].isPix;
                                isPinPad = itensComandaLoop[loopItem].isPinPad;
                                isPinPadPix = itensComandaLoop[loopItem].isPinPadPix;
                            }

                            if (valorPagamentoOnline != 0) {
                                $("#btnCobrarCliente").hide();
                                for (
                                    var i = 0; i < $("#tipoPagamento0").get(0).options.length; i++
                                ) {
                                    if (isPinPad != 1) {
                                        if (isPinPadPix != 1) {
                                            if (
                                                $("#tipoPagamento0").get(0).options[i].dataset
                                                .pagamentoonline == "1" &&
                                                $("#tipoPagamento0").get(0).options[i].dataset
                                                .pagamentoonlineparcelado == ""
                                            ) {
                                                $("#tipoPagamento0").val(
                                                    $("#tipoPagamento0").get(0).options[i].value
                                                );
                                                $("#tipoPagamento0").prop("disabled", true);
                                                $("#valorPagamento0").val(valorPagamentoOnline);
                                                if (completePayment == 0) {
                                                    $("#valorPagamento0").val(valorPagamentoComanda);
                                                }
                                                $("#valorPagamento0").prop("disabled", true);
                                                $("#btnNovoTipo").hide();
                                            }
                                        } else {
                                            if (
                                                $("#tipoPagamento0").get(0).options[i].dataset
                                                .integracao == "3" &&
                                                $("#tipoPagamento0").get(0).options[i].dataset
                                                .pagamentoonline == "1" &&
                                                $("#tipoPagamento0").get(0).options[i].dataset
                                                .pagamentoonlineparcelado == "" &&
                                                $("#tipoPagamento0").get(0).options[i].text ==
                                                "Pix - PINPAD"
                                            ) {
                                                $("#tipoPagamento0").val(
                                                    $("#tipoPagamento0").get(0).options[i].value
                                                );
                                                $("#tipoPagamento0").prop("disabled", true);
                                                $("#valorPagamento0").val(valorPagamentoOnline);
                                                if (completePayment == 0) {
                                                    $("#valorPagamento0").val(valorPagamentoComanda);
                                                }
                                                $("#valorPagamento0").prop("disabled", true);
                                                $("#btnNovoTipo").hide();
                                            }
                                        }
                                    } else {
                                        if (
                                            $("#tipoPagamento0").get(0).options[i].dataset
                                            .integracao == "3" &&
                                            $("#tipoPagamento0").get(0).options[i].dataset
                                            .pagamentoonline == "1" &&
                                            $("#tipoPagamento0").get(0).options[i].dataset
                                            .pagamentoonlineparcelado == "" &&
                                            $("#tipoPagamento0").get(0).options[0].text ==
                                            "Crédito - PINPAD"
                                        ) {
                                            $("#tipoPagamento0").val(
                                                $("#tipoPagamento0").get(0).options[i].value
                                            );
                                            $("#tipoPagamento0").prop("disabled", true);
                                            $("#valorPagamento0").val(valorPagamentoOnline);
                                            if (completePayment == 0) {
                                                $("#valorPagamento0").val(valorPagamentoComanda);
                                            }
                                            $("#valorPagamento0").prop("disabled", true);
                                            $("#btnNovoTipo").hide();
                                        }
                                    }
                                }

                                if (
                                    (j == 1 && this.fnGetData().length > itensOnline) ||
                                    completePayment == 0
                                ) {
                                    $("#btnNovoTipo").click();
                                    $("#btnRemoveTipo1").remove();
                                    valor =
                                        parseFloat(vlrTotal.ValorTotal.replace(",", ".")) -
                                        parseFloat(valorPagamentoOnline);
                                    if (completePayment == 0) {
                                        valor =
                                            parseFloat(vlrTotal.ValorTotal.replace(",", ".")) -
                                            parseFloat(valorPagamentoComanda);
                                    }
                                    $("#valorPagamento1").val(valor);
                                }

                                $.ajax({
                                    dataType: "json",
                                    url: "/pages/cadastros/buscaTipoBandeira.php",
                                    method: "POST",
                                    data: {
                                        tipopagamento: $("#tipoPagamento0 option:selected").val(),
                                    },
                                    success: function(result) {
                                        var html = "";
                                        for (var i = 0; i < result.data.length; i++) {
                                            if (isPix == 1) {
                                                if (result.data[i].TBa_Tipo_Bandeira == "2") {
                                                    html +=
                                                        "<option value =" +
                                                        result.data[i].TBa_Codigo +
                                                        " >" +
                                                        result.data[i].TBa_Descricao +
                                                        "</option>";
                                                }
                                            } else if (isPinPad == 1) {
                                                if (result.data[i].TBa_Tipo_Bandeira == "4") {
                                                    html +=
                                                        "<option value =" +
                                                        result.data[i].TBa_Codigo +
                                                        " >" +
                                                        result.data[i].TBa_Descricao +
                                                        "</option>";
                                                }
                                            } else {
                                                if (result.data[i].TBa_Tipo_Bandeira != "2") {
                                                    html +=
                                                        "<option value =" +
                                                        result.data[i].TBa_Codigo +
                                                        " >" +
                                                        result.data[i].TBa_Descricao +
                                                        "</option>";
                                                }
                                            }
                                        }
                                        $("#divBandeiraPag0").html(html);
                                        $compile($("#divBandeiraPag0"))($scope);
                                    },
                                });

                                $("#divBandeiraPag0").prop("disabled", true);
                            } else {
                                $("#tipoPagamento0").prop("disabled", false);
                                $("#valorPagamento0").prop("disabled", false);
                                if ($scope.parContaDigital == 1) {
                                    if (
                                        parseFloat(vlrTotal.ValorTotal.replace(",", ".")) >= 1.0
                                    ) {
                                        if ($scope.parContaDigital == 1) {
                                            $("#btnCobrarCliente").show();
                                        }
                                    } else if (
                                        parseFloat(vlrTotal.ValorTotal.replace(",", ".")) < 1.0
                                    ) {
                                        $("#btnCobrarCliente").hide();
                                    }
                                }
                            }
                        } else {
                            $("#valorTotalComanda").html($_CONFIG.MOEDA + "0.00");
                            $("#comValorTotal").html("0.00");
                            $("#valorPagamento0").val("0.00");
                            $("#comValorPag").val("0.00");
                            $scope.calculaParcelas("0,00");
                        }

                        $('[data-toggle="popover"]').popover({
                            container: "body",
                        });
                        $compile($("#tbComandaItens"))($scope);
                        $("#tbComandaItens_paginate").click(function() {
                            $compile($("#tbComandaItens"))($scope);
                        });
                        $("#tbComandaItens_filter").change(function() {
                            $compile($("#tbComandaItens"))($scope);
                        });
                        $("#tbComandaItens_length").change(function() {
                            $compile($("#tbComandaItens"))($scope);
                        });
                    },

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,

                    columnDefs: [{
                        targets: [
                            0, 1, 2, 3, 5, 6, 9, 11, 12, 15, 16, 17, 18, 19, 21, 22,
                        ],
                        visible: false,
                        searchable: false,
                    }, ],
                    columns: [
                        /*0*/
                        {
                            data: "Codigo",
                        },
                        /*1*/
                        {
                            data: "CodItem",
                        },
                        /*2*/
                        {
                            data: "CodSerPro",
                        },
                        /*3*/
                        {
                            data: "TipoItem",
                        },
                        /*4*/
                        {
                            data: "ImgItem",
                        },
                        /*5*/
                        {
                            data: "Data",
                        },
                        /*6*/
                        {
                            data: "Usuario",
                        },
                        /*7*/
                        {
                            data: "Valor",
                        },
                        /*8*/
                        {
                            data: "ValorUn",
                        },
                        /*9*/
                        {
                            data: "Desconto",
                        },
                        /*10*/
                        {
                            data: "Quantidade",
                            render: function(data, style, row) {
                                return `${row.Quantidade} ${row.TipoUnidade}`;
                            },
                        },
                        /*11*/
                        {
                            data: "Comissao",
                        },
                        /*12*/
                        {
                            data: "ValorTotal",
                        },
                        /*13*/
                        {
                            data: "Item",
                        },
                        /*14*/
                        {
                            data: "Profissional",
                        },
                        /*15*/
                        {
                            data: "Cliente",
                        },
                        /*16*/
                        {
                            data: "TipoDesconto",
                        },
                        /*17*/
                        {
                            data: "ComissaoPadrao",
                        },
                        /*18*/
                        {
                            data: "ComissaoPrincipal",
                        },
                        /*19*/
                        {
                            data: "ExistePacote",
                        },
                        /*20*/
                        {
                            data: "Uso",
                        },
                        /*21*/
                        {
                            data: "Venda",
                        },
                        /*22*/
                        {
                            data: "ProValor",
                        },
                        /*23*/
                        {
                            data: "btnauxiliar",
                        },
                        /*24*/
                        {
                            data: "btnEditar",
                        },
                        /*25*/
                        {
                            data: "btnPacote",
                            class: "pacoteclass",
                        },
                        /*26*/
                        {
                            data: "btnExcluir",
                        },
                    ],
                });
            };

            // Atualiza Dados itens
            $scope.atualizaDadosItens = function() {
                tabelaComItens.api().ajax.reload(function(e) {
                    $("#listServicoComanda").html("");
                    $("#listServicoComandaEdt").html("");
                    var itens = tabelaComItens.fnGetData();
                    var atualizavalores = 0;
                    var valor = 0;

                    if (itens.length != 1) {
                        var numItemPagoonline = 0;
                        for (var i = 0; i < itens.length; i++) {
                            if (itens[i].PagamentoOnline == 1) {
                                numItemPagoonline++;
                                if (j == 1) {
                                    valor = valor + parseFloat(itens[i].Valor.replace(",", "."));
                                    valor = parseFloat(valor);
                                    $("#btnNovoTipo").click();
                                    $("#btnRemoveTipo1").remove();
                                    atualizavalores = 1;
                                } else {
                                    valor = valor + parseFloat(itens[i].Valor.replace(",", "."));
                                    valor = parseFloat(valor);
                                    atualizavalores = 1;
                                }
                            }
                            if (itens[i].CPoPagamentoTotal == 0) {
                                valor = itens[i].CPoValor;
                            }
                            if (itens[i].TipoItem == 1) {
                                $("#listServicoComanda").append(
                                    `<option value="${itens[i].AgeCodigo}">${itens[i].Item} - Profissional: ${itens[i].Profissional}</option>`
                                );
                                $("#listServicoComandaEdt").append(
                                    `<option value="${itens[i].AgeCodigo}">${itens[i].Item} - Profissional: ${itens[i].Profissional}</option>`
                                );
                            }
                        }
                        if (numItemPagoonline == itens.length) {
                            if (itens[i].CPoPagamentoTotal == 1) {
                                $("#btnInsereProdutoComanda").prop("disabled", false);
                                $("#btnInsereServicoComanda").prop("disabled", false);
                                $scope.removeTipoPagemento();
                            } else {
                                $("#btnInsereProdutoComanda").prop("disabled", true);
                                $("#btnInsereServicoComanda").prop("disabled", true);
                                atualizavalores = 1;
                                valor = itens[0].CPoValor;
                            }
                            $("#btnCobrarCliente").hide();
                        }
                        if (numItemPagoonline == 0) {
                            if (parseFloat(itens[0].ValorTotal.replace(",", ".")) >= 1.0) {
                                if ($scope.parContaDigital == 1) {
                                    $("#btnCobrarCliente").show();
                                }
                            } else {
                                $("#btnCobrarCliente").hide();
                            }
                        }
                    } else {
                        if (itens[0].PagamentoOnline == 1) {
                            if (itens[0].CPoPagamentoTotal == 1) {
                                $("#btnInsereProdutoComanda").prop("disabled", false);
                                $("#btnInsereServicoComanda").prop("disabled", false);
                                $scope.removeTipoPagemento();
                            } else {
                                $("#btnInsereProdutoComanda").prop("disabled", true);
                                $("#btnInsereServicoComanda").prop("disabled", true);
                                atualizavalores = 1;
                                valor = itens[0].CPoValor;
                            }
                            $("#btnCobrarCliente").hide();
                        } else {
                            if (parseFloat(itens[0].ValorTotal.replace(",", ".")) >= 1.0) {
                                if ($scope.parContaDigital == 1) {
                                    $("#btnCobrarCliente").show();
                                }
                            } else {
                                $("#btnCobrarCliente").hide();
                            }
                        }
                    }
                    var vlrTotal = e.data[0];

                    $("#valorTotalComanda").html($_CONFIG.MOEDA + vlrTotal.ValorTotal);
                    $("#comValorPag").val(vlrTotal.ValorTotal);
                    $("#comValorTotal").html($_CONFIG.MOEDA + vlrTotal.ValorTotal);
                    if (atualizavalores == 0) {
                        $("#valorPagamento0").val(vlrTotal.ValorTotal);
                        if (j == 2) {
                            $("#valorPagamento1").val(0.0);
                        }
                        $scope.calculaParcelas(vlrTotal.ValorTotal);
                        $compile($("#tbComandaItens"))($scope);
                        $("#tbComandaItens_paginate").click(function() {
                            $compile($("#tbComandaItens"))($scope);
                        });
                    } else {
                        $("#valorPagamento0").val(valor);
                        $("#valorPagamento1").val(
                            parseFloat(vlrTotal.ValorTotal.replace(",", ".")) - valor
                        );
                        $scope.calculaParcelas(vlrTotal.ValorTotal);
                        $compile($("#tbComandaItens"))($scope);
                        $("#tbComandaItens_paginate").click(function() {
                            $compile($("#tbComandaItens"))($scope);
                        });
                    }
                    $("#valorPagamento0").change();
                    if ($("#valorPagamento1").val() !== undefined) {
                        $("#valorPagamento1").change();
                    }
                });
            };

            // Busca ClienteAgendameno
            $scope.buscaCliAgendamento = function(dataini, datafim) {
                if (typeof tableCliAgendamento !== "undefined") {
                    tableCliAgendamento.destroy();
                }
                tableCliAgendamento = $("#tabelaClienteAgendamento").DataTable({
                    dom: 'T<"clear">lfrtip',
                    ajax: {
                        url: $("#tabelaClienteAgendamento").data("source"),
                        method: "POST",
                        data: function(d) {
                            d.tipo = 2;
                            d.pesCodigo = $("#cliPesCodigoInfo").val();
                            d.dataIni = dataini;
                            d.dataFim = datafim;
                        },
                    },
                    dom: "Blfrtip",
                    buttons: [{
                            extend: "excelHtml5",
                            text: "Excel",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: "true",
                        },
                        {
                            extend: "pdfHtml5",
                            title: $Options.sistema + " - Histórico de Agendamentos",
                            orientation: "landscape",
                            pageSize: "LEGAL",
                            exportOptions: {
                                columns: ":visible",
                            },
                        },
                        {
                            extend: "print",
                            text: "Imprimir",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: true,
                        },
                    ],

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,

                    columns: [{
                            data: "Ser_Descricao",
                        },
                        {
                            data: "Pes_Nome",
                        },
                        {
                            data: "Age_Dat_Inicio",
                            type: "moment-DD/MM/YYYY hh:mm",
                        },
                        {
                            data: "Usu_Nome",
                        },
                        {
                            data: "Age_Dat_Cadastro",
                            type: "moment-DD/MM/YYYY hh:mm",
                        },
                        {
                            data: "ASt_Descricao",
                        },
                        {
                            data: "Age_Valor",
                        },
                    ],
                    ordering: false,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                });
            };

            // Busca CliComanda
            $scope.buscaCliComanda = function(dataini, datafim) {
                if (typeof tabelaCliComanda !== "undefined") {
                    tabelaCliComanda.destroy();
                }
                tabelaCliComanda = $("#tabelaClienteComanda").DataTable({
                    dom: 'T<"clear">lfrtip',
                    ajax: {
                        url: $("#tabelaClienteComanda").data("source"),
                        method: "POST",
                        data: function(d) {
                            d.tipo = 3;
                            d.pesCodigo = $("#cliPesCodigoInfo").val();
                            d.dataIni = dataini;
                            d.dataFim = datafim;
                        },
                    },
                    dom: "Blfrtip",
                    buttons: [{
                            extend: "excelHtml5",
                            text: "Excel",
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5],
                            },
                            footer: "true",
                        },
                        {
                            extend: "pdfHtml5",
                            title: $Options.sistema + " - Histórioco de Comandas",
                            orientation: "landscape",
                            pageSize: "LEGAL",
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5],
                            },
                        },
                        {
                            extend: "print",
                            text: "Imprimir",
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5],
                            },
                            footer: true,
                        },
                    ],

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,

                    columns: [{
                            data: "Com_Codigo",
                        },
                        {
                            data: "Status",
                        },
                        {
                            data: "Usu_Nome",
                        },
                        {
                            data: "Com_Vlr_Total",
                        },
                        {
                            data: "Com_Vlr_Pagamento",
                        },
                        {
                            data: "Com_Observacao",
                        },
                        {
                            class: "abrecomanda-control",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-success btn-xs ">Ver Comanda</button>',
                        },
                    ],
                    ordering: false,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                });

                $("#tabelaClienteComanda tbody").on(
                    "click",
                    "td.abrecomanda-control",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaCliComanda.row(tr);
                        var data = row.data();
                        $scope.buscaItensComandaVer(data.Com_Codigo);
                        $("#nomeClienteComandaVer").html(data.Pes_Nome);
                        $("#idComandaVer").html(data.Com_Codigo);
                        if (data.CCE_Cod_Externo != "") {
                            $("#idComandaExternoVer").html("N˚: " + data.CCE_Cod_Externo);
                            $("#idComandaExternoVer").show();
                        } else {
                            $("#idComandaExternoVer").html("");
                            $("#idComandaExternoVer").hide();
                        }
                        $("#dataComandaVer").html(data.Com_Dat_Cadastro);
                        $("#vercomanda-modal").modal("show");
                    }
                );
            };

            // Busca CliPacote
            $scope.buscaCliPacote = function(dataini, datafim) {
                if (typeof tabelaCliPacote !== "undefined") {
                    $("#tabelaClientePacotes tbody").unbind("click");
                    tabelaCliPacote.destroy();
                    $("#tabelaClientePacotes tbody").unbind("click");
                }
                tabelaCliPacote = $("#tabelaClientePacotes").DataTable({
                    dom: 'T<"clear">lfrtip',
                    ajax: {
                        url: $("#tabelaClientePacotes").data("source"),
                        method: "POST",
                        data: function(d) {
                            d.tipo = 4;
                            d.pesCodigo = $("#cliPesCodigoInfo").val();
                            d.dataIni = dataini;
                            d.dataFim = datafim;
                        },
                    },
                    dom: "Blfrtip",
                    buttons: [{
                            extend: "excelHtml5",
                            text: "Excel",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: "true",
                        },
                        {
                            extend: "pdfHtml5",
                            title: $Options.sistema + " - Pacotes",
                            orientation: "landscape",
                            pageSize: "LEGAL",
                            exportOptions: {
                                columns: ":visible",
                            },
                        },
                        {
                            extend: "print",
                            text: "Imprimir",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: true,
                        },
                    ],

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,

                    columns: [{
                            data: "Pac_Descricao",
                        },
                        {
                            data: "PPa_Dat_Cadastro",
                            type: "moment-DD/MM/YYYY hh:mm",
                        },
                        {
                            data: "Utilizado",
                        },
                        {
                            data: "PPa_Vlr_Venda",
                        },
                        {
                            class: "verPacoteInfoCli",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-block btn-primary btn-xs"><i class="ion ion-android-list"></i>&nbspDetalhes</button>',
                        },
                    ],
                    ordering: false,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                });

                $("#tabelaClientePacotes tbody").on(
                    "click",
                    "td.verPacoteInfoCli",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaCliPacote.row(tr);
                        var data = row.data();
                        showLoader(true);
                        $scope.verDetalhesPacote(data.PPa_Codigo);
                        var valPercent = (data.PPa_Qtd_Usada / data.PPa_Qtd_Sessao) * 100;
                        $("#progPacote").css("width", valPercent + "%");
                        $("#pacdescricao").html(data.PPa_Descricao);
                        $("#pacdatcadastro").html(data.PPa_Dat_Cadastro);
                        $("#qtdConsumo").html(data.PPa_Qtd_Usada);
                        $("#qtdTotal").html(data.PPa_Qtd_Sessao);
                    }
                );
            };

            $scope.insereDesconto = function() {
                $("#descontoComanda-modal").modal();
                $("#insereDescontoComanda").prop("disabled", false);
            };

            $scope.buscaCliPonto = function(codigo) {
                if (typeof tabelaCliPonto !== "undefined") {
                    tabelaCliPonto.destroy();
                }
                tabelaCliPonto = $("#tableCliPontos").DataTable({
                    dom: 'T<"clear">lfrtip',
                    ajax: {
                        url: "/pages/relatorios/buscaProgramaFidelidade.php",
                        method: "POST",
                        data: function(d) {
                            d.selTipo = 1;
                            d.selCliente = codigo;
                        },
                    },

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,

                    columns: [{
                            data: "Nome",
                        },
                        {
                            data: "TotalPontos",
                        },
                    ],
                    ordering: false,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                });
            };

            // Busca ItensComandaVer
            $rootScope.$on("buscaItensComandaVer", function(event, codigo) {
                $scope.buscaItensComandaVer(codigo.any);
            });

            $scope.buscaItensComandaVer = function(codigo) {
                if (typeof tabelaComItensVer != "undefined") {
                    tabelaComItensVer.api().destroy();
                }
                var codigoClienteAssinatura = "";
                tabelaComItensVer = $("#tbComandaItensVer").dataTable({
                    ajax: "/pages/cadastros/buscaItensComanda.php?codigo=" + codigo,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                    bPaginate: false,
                    bLengthChange: false,
                    bFilter: false,
                    bSort: false,
                    bInfo: false,
                    bAutoWidth: false,
                    fnRowCallback: function(nRow, aData) {
                        var id = aData.Cortesia;

                        if (id == 1) {
                            nRow.children[8].innerHTML = "Sim";
                        } else {
                            nRow.children[8].innerHTML = "Não";
                        }
                    },
                    initComplete: function() {
                        var vlrTotal = this.fnGetData(0);
                        $("#valorTotalComandaVer").html(
                            $_CONFIG.MOEDA + vlrTotal.ValorTotal
                        );
                        if (vlrTotal.comandaVlrPagamento != "") {
                            $("#valorPagoComandaVer").html(
                                $_CONFIG.MOEDA + vlrTotal.comandaVlrPagamento
                            );
                            $("#vlrPagoVer").css("display", "block");
                        } else {
                            $("#vlrPagoVer").css("display", "none");
                            $("#valorPagoComandaVer").html("");
                        }
                        $("#nomeClienteComandaVer").html(vlrTotal.Cliente);
                        codigoClienteAssinatura = vlrTotal.ClienteCodigo;
                        $("#idComandaVer").html(vlrTotal.Codigo);
                        $("#dataComandaVer").html(vlrTotal.dataComanda);
                        $("#comValorPagVer").val(vlrTotal.ValorTotal);
                        $("#pagamentoComandaVer").html(
                            vlrTotal.tipoPagamento.replace("/", "<br>")
                        );
                    },
                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,
                    columnDefs: [{
                        targets: [0, 1, 2, 3, 5, 6, 11, 12],
                        visible: false,
                        searchable: false,
                    }, ],
                    columns: [{
                            data: "Codigo",
                        },
                        {
                            data: "CodItem",
                        },
                        {
                            data: "CodSerPro",
                        },
                        {
                            data: "TipoItem",
                        },
                        {
                            data: "ImgItem",
                        },
                        {
                            data: "Data",
                        },
                        {
                            data: "Usuario",
                        },
                        {
                            data: "Valor",
                        },
                        {
                            data: "ValorUn",
                        },
                        {
                            data: "Desconto",
                        },
                        {
                            data: "Quantidade",
                        },
                        {
                            data: "Comissao",
                        },
                        {
                            data: "ValorTotal",
                        },
                        {
                            data: "Item",
                        },
                        {
                            data: "Profissional",
                        },
                        {
                            data: "Cliente",
                        },
                        {
                            data: "Cortesia",
                        },
                        {
                            data: null,
                            defaultContent: "",
                            render: function(data, t, row) {
                                if (row.ExistePacote == "1") {
                                    return "Pacote";
                                } else if (row.asscodigo != "") {
                                    return "Clube de Assintura";
                                }
                            },
                        },
                    ],
                });
            };

            //Seleciona novo cliente
            $scope.selecionaNovoCliente = function(pesCodigo) {
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    data: {
                        metodo: "buscaClientes",
                        id: $scope.idCliente,
                    },
                    success: function(data) {
                        clientesNomesComanda.length = 0;
                        var html =
                            '<option data-usucodigo="" data-imagem="" value="0" selected>Sem Cadastro</option>';
                        for (var i = 0; i < data.clientes.length; i++) {
                            var codigo = data.clientes[i].Pes_Codigo;
                            var nome = data.clientes[i].Pes_Nome;
                            var foto = data.clientes[i].Paf_Imagem;
                            var usucod = data.clientes[i].Usu_Codigo;
                            var celular = "";
                            if (data.clientes[i].Paf_Celular != "") {
                                celular = " - " + data.clientes[i].Paf_Celular;
                            }
                            html +=
                                '<option data-usucodigo="' +
                                usucod +
                                '" data-imagem="' +
                                foto +
                                '" value="' +
                                codigo +
                                '">' +
                                nome +
                                "" +
                                celular +
                                "</option>";
                        }
                        $("#comCliente").html(html);

                        setTimeout(function() {
                            $("#comCliente").val(pesCodigo);
                            $("#comCliente").change();
                        }, 1000);
                    },
                });
            };

            $scope.geraDescontoComanda = function() {
                if ($("#comValorDesconto").val() == "") {
                    toastr.error("Informe o desconto");
                } else {
                    if ($("#senhaDesconto").html() == "1") {
                        var statesdemo = {
                            state0: {
                                title: "Insira a senha ",
                                html: '<input class="form-control" type="password" name="password" id="password" value=""></label>',
                                buttons: {
                                    Ok: 1,
                                },
                                submit: function(e, v, m, f) {
                                    e.preventDefault();
                                    if (f.password != null) {
                                        $.ajax({
                                            dataType: "json",
                                            method: "POST",
                                            url: "/php/verificaSenhaDesconto.php",
                                            data: {
                                                password: f.password,
                                            },
                                            success: function(data) {
                                                if (data.erro == "0") {
                                                    $.ajax({
                                                        type: "POST",
                                                        url: "/pages/cadastros/alteraComandaDesconto.php",
                                                        data: {
                                                            comanda: $("#idComanda").html(),
                                                            desconto: $("#comValorDesconto").val(),
                                                            senhaDesconto: data.p,
                                                        },
                                                        dataType: "json",
                                                        success: function(result) {
                                                            showLoader(true);
                                                            if (result.data[0].erro == "0") {
                                                                $scope.atualizaDadosItens();
                                                                if (location.hash == "#/comandasabertas") {
                                                                    $rootScope.$emit("atualizaDadosComanda", {});
                                                                }
                                                                toastr.success(result.data[0].resultado);
                                                                $("#descontoComanda-modal").modal("hide");
                                                                $("#comValorDesconto").val("");
                                                            } else {
                                                                toastr.error(result.data[0].resultado);
                                                            }
                                                            showLoader(false);
                                                            $("#comValor").attr("disabled", true);
                                                        },
                                                        error: function(result) {
                                                            toastr.error("Falha na conexão.");
                                                            showLoader(false);
                                                            $("#comValor").attr("disabled", true);
                                                        },
                                                    });
                                                    $.prompt.close();
                                                } else {
                                                    toastr.error(data.resultado);
                                                }
                                            },
                                            error: function(data) {
                                                toastr.error("Falha de conexão");
                                            },
                                        });
                                    }
                                },
                            },
                        };
                        $.prompt(statesdemo);
                    } else {
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/alteraComandaDesconto.php",
                            data: {
                                comanda: $("#idComanda").html(),
                                desconto: $("#comValorDesconto").val(),
                            },
                            dataType: "json",
                            success: function(result) {
                                showLoader(true);
                                if (result.data[0].erro == "0") {
                                    $scope.atualizaDadosItens();
                                    if (location.hash == "#/comandasabertas") {
                                        $rootScope.$emit("atualizaDadosComanda", {});
                                    }
                                    toastr.success(result.data[0].resultado);
                                    $("#descontoComanda-modal").modal("hide");
                                    $("#comValorDesconto").val("");
                                } else {
                                    toastr.error(result.data[0].resultado);
                                }
                                showLoader(false);
                                $("#comValor").attr("disabled", true);
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                                showLoader(false);
                                $("#comValor").attr("disabled", true);
                            },
                        });
                    }
                }
            };

            $scope.atualizatabelaProntuario = function() {
                tabelaProntuario.ajax.reload();
            };

            //Monta o prontuario do cliente
            $rootScope.$on("buscaClienteProntuario", function(pescodigo) {
                $scope.buscaProntuarioCliente(pescodigo);
            });

            $scope.buscaProntuarioCliente = function(PescodigoCliente) {
                $("#pescodigoProntuario").val(PescodigoCliente);
                if (typeof tabelaProntuario != "undefined") {
                    $("#tableProntuario tbody").unbind("click");
                    tabelaProntuario.destroy();
                    $("#tableProntuario tbody").unbind("click");
                }
                tabelaProntuario = $("#tableProntuario").DataTable({
                    ajax: {
                        url: "/pages/cadastros/buscaAgendamentoProntuariov2.php",
                        method: "POST",
                        data: {
                            pescodigocliente: PescodigoCliente,
                            tipo: 1,
                            agecodigo: "",
                            dataini: $("#cliDatInicioPron").val(),
                            datafim: $("#cliDatFimPron").val(),
                            pescodigoprofissional: $("#profPront").val(),
                            sercodigo: $("#servicoPront").val(),
                        },
                    },
                    columnDefs: [{
                        targets: [3, 9],
                        visible: false,
                        searchable: false,
                    }, ],
                    fnRowCallback: function(nRow, aData) {
                        var $nRow = $(nRow);
                        var id = aData.TemProntuario;
                        switch (id) {
                            case "0":
                                $nRow.map(function() {}).get();
                                nRow.children[5].style.display = "none";
                                nRow.children[6].style.display = "none";
                                nRow.children[8].style.display = "none";
                                break;
                            default:
                                $nRow.map(function() {}).get();
                                nRow.children[4].style.display = "none";
                                nRow.children[7].style.display = "none";
                                break;
                        }
                    },

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,

                    columns: [
                        /*0*/
                        {
                            class: "details-control",
                            orderable: false,
                            data: null,
                            defaultContent: "",
                        },
                        /*1*/
                        {
                            data: "Age_Dat_Inicio",
                            type: "moment-DD/MM/YYYY hh:mm",
                        },
                        /*2*/
                        {
                            data: "Ser_Descricao",
                        },
                        /*3*/
                        {
                            data: "ADe_Codigo",
                        },
                        /*4*/
                        {
                            data: "Profissional",
                        },
                        /*5*/
                        {
                            class: "adicionar",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-info btn-block btn-xs"><i class="fa fa-plus"></i>&nbspNovo</button>',
                        },
                        /*6*/
                        {
                            class: "editar",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-block btn-success btn-xs"><i class="fa fa-pencil"></i>&nbspEditar</button>',
                        },
                        /*7*/
                        {
                            class: "remover",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-danger btn-block btn-xs"><i class="fa fa-trash"></i>&nbspExcluir</button>',
                        },
                        /*8*/
                        {
                            data: null,
                            defaultContent: "",
                        },
                        /*9*/
                        {
                            data: "Age_Codigo",
                        },
                        /*10*/
                        {
                            class: "imprimir",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn bg-teal-dark btn-block btn-xs"><i class="fa fa-print"></i></button>',
                        },
                    ],
                    ordering: false,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                });

                $("#tableProntuario tbody").on(
                    "click",
                    "td.details-control",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaProntuario.row(tr);
                        if (row.child.isShown()) {
                            row.child.hide();
                            tr.removeClass("shown");
                        } else {
                            row.child($scope.formatDetails(row.data())).show();
                            tr.addClass("shown");
                            $compile($("#tableProntuario"))($scope);
                        }
                    }
                );

                $("#tableProntuario tbody").on("click", "td.adicionar", function() {
                    var tr = $(this).closest("tr");
                    var row = tabelaProntuario.row(tr);
                    var agendamentoprontcodigo = row.data().Age_Codigo;

                    $("#codigoAgendamento").val(agendamentoprontcodigo);
                    $("#codigoAgendamentoImagem").val(agendamentoprontcodigo);
                    $scope.numImagemProntuario = 0;
                    $("#imagemProntuario0").attr(
                        "src",
                        "https://d3verit7xckkza.cloudfront.net/imgsystem/pront_sem_imagem.png"
                    );
                    $("#imagemProntuario1").attr(
                        "src",
                        "https://d3verit7xckkza.cloudfront.net/imgsystem/pront_sem_imagem.png"
                    );
                    $("#imagemProntuario2").attr(
                        "src",
                        "https://d3verit7xckkza.cloudfront.net/imgsystem/pront_sem_imagem.png"
                    );
                    $("#insereProntuario-modal").modal();
                    $("#divDetalhes").show();
                });

                $("#tableProntuario tbody").on("click", "td.editar", function() {
                    var tr = $(this).closest("tr");
                    var row = tabelaProntuario.row(tr);
                    $scope.numImagemProntuario = 0;
                    $("#AgeCodigoBuscaImagem").val(row.data().Age_Codigo);
                    $("#ageMaterialEdt").val(row.data().ADe_Material);
                    $("#ageDetalhesEdt").val(
                        row.data().ADe_Detalhes.replaceAll("__", "\r\n")
                    );
                    $("#ageCorteEdt").val(row.data().ADe_Corte);
                    $("#codigoAgendamentoImagemEdit").val(row.data().Age_Codigo);
                    $("#AdeCodgioAltera").val(row.data().ADe_Codigo);
                    $("#AdeCodgioAlteraImg").val(row.data().ADe_Codigo);
                    $scope.buscaImagemProntuarioAlteracao(row.data().Age_Codigo);
                    $("#EditaProntuario-modal").modal();
                });

                $("#tableProntuario tbody").on("click", "td.imprimir", function() {
                    var tr = $(this).closest("tr");
                    var row = tabelaProntuario.row(tr);

                    $("#printMaterial").html(row.data().ADe_Material);
                    $("#printObs").html(row.data().ADe_Detalhes.replaceAll("__", "<br>"));
                    $("#printPro").html(row.data().ADe_Corte);
                    $("#printData").html(row.data().Age_Dat_Inicio);
                    $("#printServico").html(row.data().Ser_Descricao);
                    $("#printProfissional").html(row.data().Profissional);
                    setTimeout(function() {
                        $scope.imprimirProntuario();
                    }, 300);
                });

                $("#tableProntuario tbody").on("click", "td.remover", function() {
                    var tr = $(this).closest("tr");
                    var row = tabelaProntuario.row(tr);
                    swal({
                            title: "Deseja realmente excluir este prontuário?",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "Sim",
                            cancelButtonText: "Não",
                            closeOnConfirm: true,
                        },
                        function() {
                            showLoader(true);
                            $.ajax({
                                dataType: "json",
                                method: "POST",
                                url: "/pages/cadastros/removeAgendamentoProntuario.php",
                                data: {
                                    adeCodigo: row.data().ADe_Codigo,
                                    tipo: 2,
                                },
                                success: function(result) {
                                    if (result.data[0].erro == "0") {
                                        toastr.success(result.data[0].resultado);
                                    } else {
                                        toastr.error(result.data[0].resultado);
                                    }
                                    $scope.buscaProntuarioCliente(row.data().Pes_Codigo);
                                    showLoader(false);
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                    showLoader(false);
                                },
                            });
                        }
                    );
                });

                $scope.formatDetails = function(d) {
                    $scope.buscaImagemProntuario(d.Age_Codigo);
                    var documentoline = "";
                    if (d.ADe_Codigo != "") {
                        documentoline =
                            "<tr>" +
                            '<td class="col-md-12"></td>' +
                            '<td id="tddocumento"><buttom class="btn btn-xs btn-primary pull-left" ng-click="listDocumento(' +
                            PescodigoCliente +
                            "," +
                            d.Pes_Codigo_Profissional +
                            "," +
                            d.Age_Codigo +
                            ",null,null," +
                            d.ADe_Codigo +
                            ')">Documentos</buttom></td>' +
                            "</tr>";
                    }
                    return (
                        '<table cellpadding="5" class="table table-striped" cellspacing="0" border="0" style="border: 1px solid #e0e0d1;display:block;" >' +
                        "<tr >" +
                        '<td style="text-align:justify;"><strong>Detalhes:</strong>&nbsp&nbsp&nbsp&nbsp&nbsp' +
                        d.ADe_Detalhes.replaceAll("__", "<br>") +
                        "</td>" +
                        "<td ></td>" +
                        "</tr>" +
                        "<tr>" +
                        "<td ><strong>Material Utiliazado:</strong>&nbsp&nbsp&nbsp&nbsp&nbsp" +
                        d.ADe_Material +
                        "</td>" +
                        "<td></td>" +
                        "</tr>" +
                        "<tr>" +
                        "<td ><strong>Tipo de Corte:</strong> &nbsp&nbsp&nbsp&nbsp&nbsp" +
                        d.ADe_Corte +
                        "</td>" +
                        "<td></td>" +
                        "</tr>" +
                        "<tr>" +
                        "<td><strong>Imagens do agendamento: </strong></td>" +
                        "<td></td>" +
                        "</tr>" +
                        "<tr>" +
                        '<td id="imgPront" class="col-md-12"></td>' +
                        "<td></td>" +
                        "</tr>" +
                        documentoline +
                        "</table>"
                    );
                };

                $scope.buscaImagemProntuario = function(codigo) {
                    var PescodigoCliente = "";
                    if (location.hash == "#/agenda") {
                        PescodigoCliente = $("#lblPesCodigo").html();
                    } else if (location.hash == "#/clientes") {
                        PescodigoCliente = $("#cliPesCodigoInfo").val();
                    }
                    var htmlimg = "";
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaAgendamentoProntuario.php",
                        data: {
                            pescodigo: PescodigoCliente,
                            tipo: "2",
                            dataini: "",
                            datafim: "",
                            agecodigo: codigo,
                        },
                        dataType: "json",
                        success: function(result) {
                            for (var i = 0; i < result.data.length; i++) {
                                htmlimg +=
                                    "<div class='col-sm-2 margin' ng-click='ampliaImagem(&quot;" +
                                    result.data[i].AIm_Imagem +
                                    "&quot;)'><img  src='" +
                                    result.data[i].AIm_Imagem +
                                    "'  name=" + [i] +
                                    "  id=" + [i] +
                                    "  width='80' style='cursor:pointer;'><label>" +
                                    result.data[i].AIm_Legenda +
                                    "</label></div>";
                            }
                            $("#imgPront").html(htmlimg);
                            $compile($("#imgPront"))($scope);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                };
            };

            $scope.buscaProntuarioDocumento = function(pescodigo, adecodigo) {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaPessoaDocumento.php",
                    data: {
                        cliente: pescodigo,
                        tipo: "2",
                        adecodigo: adecodigo,
                    },
                    dataType: "json",
                    success: function(result) {
                        return "foo";
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });
            };

            // Busca as imagens que podem ser alteradas no prontuario
            $scope.buscaImagemProntuarioAlteracao = function(codigo) {
                $("#divimgagealt").html("");
                var PescodigoCliente = "";
                if (location.hash == "#/agenda") {
                    PescodigoCliente = $("#lblPesCodigo").html();
                } else if (location.hash == "#/clientes") {
                    PescodigoCliente = $("#cliPesCodigoInfo").val();
                }
                var htmlimgalt = "";
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaAgendamentoProntuario.php",
                    data: {
                        pescodigo: PescodigoCliente,
                        tipo: "2",
                        dataini: "",
                        datafim: "",
                        agecodigo: codigo,
                    },
                    dataType: "json",
                    success: function(result) {
                        var nonimage = 3 - result.data.length;
                        htmlimgalt +=
                            '<form id="formAlteraImagemAgendamento" enctype="multipart/form-data">';
                        htmlimgalt +=
                            '<input id="AimCodigoAltera" name="AimCodigoAltera" hidden>';
                        htmlimgalt += `<input type="file" style="display:none;" name="imgAgeAlter" id="imgAgeAlter" accept="image/*" onChange='readURL2(this,$("#formAlteraImagemAgendamento"));'>`;
                        for (var i = 0; i < result.data.length; i++) {
                            htmlimgalt += `<div  class="col-md-4 mouse-over" ng-click="alteraProntuarioImagem(${result.data[i].AIm_Codigo})"><a class="pointer"><img  src="${result.data[i].AIm_Imagem}" width="75%" ></div></a>`;
                        }
                        htmlimgalt += "</form>";
                        htmlimgalt +=
                            '<form id="formInsereImagemAgendamentoEDT" enctype="multipart/form-data">';
                        htmlimgalt += `<input type="hidden" id="codigoAgendamentoImagemEdit" name="codigoAgendamentoImagem" value="${codigo}">`;
                        htmlimgalt += `<input type="file" style="display:none;" name="aimImagem" id="aimImagemEdt" accept="image/*" onChange='readURL2(this,$("#formInsereImagemAgendamentoEDT"));'>`;

                        for (var i = 0; i < nonimage; i++) {
                            htmlimgalt += `<div  class="col-md-4 " ng-click="insereImagemProntuarioEdita()"><a class="pointer"><img   src="https://d3verit7xckkza.cloudfront.net/imgsystem/pront_sem_imagem.png" width="75%" ></a></div>`;
                        }
                        htmlimgalt += "</form>";

                        $("#divimgagealt").html(htmlimgalt);
                        $compile($("#divimgagealt"))($scope);

                        $("#formInsereImagemAgendamentoEDT").submit(function(event) {
                            event.preventDefault();
                            showLoader(true);
                            formInsereImgedt = $(this);
                            var dados = new FormData(this);
                            dados.append("blob", mBlob);
                            dados.delete("aimImagem");
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereAgendamentoProntuarioImagem.php",
                                data: dados,
                                dataType: "json",
                                processData: false,
                                contentType: false,
                                success: function(result) {
                                    if (result.result[0].erro == "0") {
                                        toastr.success(result.result[0].resultado, "");
                                        formInsereImgedt.each(function() {
                                            this.reset();
                                        });
                                        $scope.buscaImagemProntuarioAlteracao(
                                            $("#AgeCodigoBuscaImagem").val()
                                        );
                                    } else {
                                        toastr.error(result.result[0].resultado);
                                    }
                                    showLoader(false);
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                    showLoader(false);
                                },
                            });

                            return true;
                        });

                        //altera imgens do prontuario
                        $("#formAlteraImagemAgendamento").submit(function(event) {
                            event.preventDefault();
                            showLoader(true);
                            var dados = new FormData(this);
                            dados.append("blob", mBlob);
                            dados.delete("imgAgeAlter");
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/alteraAgendamentoProntuarioImagem.php",
                                data: dados,
                                dataType: "json",
                                processData: false,
                                contentType: false,
                                success: function(result) {
                                    if (result.result[0].erro == "0") {
                                        $scope.atualizatabelaProntuario();
                                        toastr.success(result.result[0].resultado);
                                        $scope.buscaImagemProntuarioAlteracao(
                                            $("#AgeCodigoBuscaImagem").val()
                                        );
                                    } else {
                                        toastr.error(result.result[0].resultado);
                                    }
                                    showLoader(false);
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                    showLoader(false);
                                },
                            });
                            return true;
                        });
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });
            };

            $scope.buscaImagemProntuarioImprecao = function(codigo) {
                var PescodigoCliente = "";
                if (location.hash == "#/agenda") {
                    PescodigoCliente = $("#lblPesCodigo").html();
                } else if (location.hash == "#/clientes") {
                    PescodigoCliente = $("#cliPesCodigoInfo").val();
                }
                var htmlimgalt = "";
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaAgendamentoProntuario.php",
                    data: {
                        pescodigo: PescodigoCliente,
                        tipo: "2",
                        dataini: "",
                        datafim: "",
                        agecodigo: codigo,
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.data.length <= 0) {
                            htmlimgalt +=
                                "<div  class='col-sm-12 margin'><label>Não existem imagens para este agendamento</label></div>";
                        } else {
                            for (var i = 0; i < result.data.length; i++) {
                                htmlimgalt +=
                                    "<div class='col-sm-6 col-sm-offset-3 margin' ><img  src='" +
                                    result.data[i].AIm_Imagem +
                                    "'  name=" + [i] +
                                    "  id=" + [i] +
                                    "  width='400' ><label>" +
                                    result.data[i].AIm_Legenda +
                                    "</label></div>";
                            }
                        }
                        $("#imagensPrint").html(htmlimgalt);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });
            };

            //Seta codigos para a alteração da imagem do prontuario
            $scope.alteraProntuarioImagem = function(codigo, legenda) {
                $("#AimCodigoAltera").val(codigo);
                $("#aimLegendaedt").val(legenda);
                $("#imgAgeAlter").click();
            };
            $scope.insereImagemProntuarioEdita = function() {
                $("#aimImagemEdt").click();
            };

            //Amplia imagens do prontuario
            $scope.ampliaImagem = function(imgsrc) {
                $("#ampliaImagem-modal").modal();
                $("#imagemProntuario").prop("src", imgsrc);
            };
            // Seta data atual para os relatorios
            $scope.dataAtual = function() {
                var dataini = moment().locale("pt-br").format("L");
                var datafim = moment().locale("pt-br").format("L");
                $(".date.divDataIni").datepicker("update", dataini);
                $(".date.divDataFim").datepicker("update", datafim);
            };

            //Busca combo de profissionais do header agenda
            $rootScope.$on("buscaProfissionalHeaderAgenda", function() {
                $scope.buscaProfissionaisHeaderAgenda();
            });

            $scope.buscaProfissionaisHeaderAgenda = function() {
                var html = "";
                $.ajax({
                    dataType: "json",
                    async: false,
                    url: "/pages/cadastros/buscaProfissionalHeader.php",
                    success: function(data) {
                        for (var i = 0; i < data.profissionais.length; i++) {
                            var codigo = data.profissionais[i].Pes_Codigo;
                            var nome = data.profissionais[i].Pes_Apelido;
                            html += '<option  value="' + codigo + '">' + nome + '</option>';
                        }
                        $("#users_menu").html(html);
                        $('#users_menu').multiselect("destroy");
                        // $('#users_menu').selectpicker({
                        // 	"liveSearch": true,
                        // 	"liveSearchPlaceholder": "Filtrar",
                        // 	"noneSelectedText": "Nenhum Profissional Selecionado",
                        // 	"maxOptions": 20,
                        // 	"mobile": isMobile,
                        // 	"width": "fit",
                        // 	"selectedTextFormat": "count > 5",
                        // 	"countSelectedText": "{0} profissionais selecionados",
                        // 	"maxOptionsText": ["Máximo de 20 Profissionais", "Máximo de 20 Profissionais"]
                        // });

                        $('#users_menu').multiselect({
                            enableFiltering: true,
                            filterPlaceholder: 'Procurar...',
                            buttonText: function(options, select) {
                                if (options.length === 0) {
                                    return 'Nenhum Profissional Selecionado ...';
                                } else if (options.length > 5) {
                                    return options.length + ' profissionais Selecionados';
                                } else {
                                    var labels = [];
                                    options.each(function() {
                                        if ($(this).attr('label') !== undefined) {
                                            labels.push($(this).attr('label'));
                                        } else {
                                            labels.push($(this).html());
                                        }
                                    });
                                    return labels.join(', ') + '';
                                }
                            }
                        });

                        if (getStorage("profissionais_" + $_CONFIG.CODESTABELECIMENTO) == null) {
                            if (getStorage("profissionais") == null) {
                                $('#users_menu').multiselect('select', $("#users_menu").get(0).options[0].value);
                            } else {
                                $('#users_menu').multiselect('select', getStorage("profissionais").split(","));
                                if ($('#users_menu').multiselect('select') == null) {
                                    $('#users_menu').multiselect('select', $("#users_menu").get(0).options[0].value);
                                }
                            }
                        } else {
                            $('#users_menu').multiselect('select', getStorage("profissionais_" + $_CONFIG.CODESTABELECIMENTO).split(","));
                            if ($('#users_menu').multiselect('select') == null) {
                                $('#users_menu').multiselect('select', $("#users_menu").get(0).options[0].value);
                            }
                        }

                    }
                });
            }
            $scope.buscaProfissionaisHeaderAgenda();

            $scope.infos = new Array();
            $scope.buscaCatalagoProduto = function() {
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaProdutos.php",
                    method: "POST",
                    data: {
                        tipo: 1,
                    },
                    success: function(result) {
                        var half1 = "";
                        var half2 = "";

                        if (result.data.length % 2 == 1) {
                            half2 = result.data.length / 2 + 0.5;
                            half1 = result.data.length / 2 - 0.5;
                        } else {
                            half1 = result.data.length / 2;
                            half2 = result.data.length / 2;
                        }
                        $scope.infos.produtos = [];
                        $scope.infos.produtos2 = [];
                        $scope.infos.produtos3 = [];
                        for (var i = 0; i < result.data.length; i++) {
                            $scope.infos.produtos3.push(result.data[i]);
                            if (i < half2) {
                                $scope.infos.produtos.push(result.data[i]);
                            } else {
                                $scope.infos.produtos2.push(result.data[i]);
                            }
                        }
                    },
                });

                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaServicoSelect.php",
                    method: "POST",
                    data: {
                        tipo: 1,
                    },
                    success: function(result) {
                        var half1 = "";
                        var half2 = "";
                        if (result.servicos.length % 2 == 1) {
                            half2 = result.servicos.length / 2 + 0.5;
                            half1 = result.servicos.length / 2 - 0.5;
                        } else {
                            half1 = result.servicos.length / 2;
                            half2 = result.servicos.length / 2;
                        }
                        $scope.infos.servico = [];
                        $scope.infos.servico2 = [];
                        $scope.infos.servico3 = [];
                        for (var i = 0; i < result.servicos.length; i++) {
                            $scope.infos.servico3.push(result.servicos[i]);
                            if (i < half2) {
                                $scope.infos.servico.push(result.servicos[i]);
                            } else {
                                $scope.infos.servico2.push(result.servicos[i]);
                            }
                        }
                    },
                });
            };

            $scope.buscaCatalagoProduto();
            $scope.catalogo = function() {
                $("#catalogoProduto-modal").modal();
                $scope.buscaCatalagoProduto();
            };

            $("#cadastrarComanda-modal").on("shown.bs.modal", function(e) {
                if (!$scope.manyClients) {
                    $scope.buscaInfoCombos();
                }
            });

            $("#comanda-modal").on("show.bs.modal", function(e) {
                $("#btnInsereProdutoComanda").prop("disabled", false);
                $("#btnInsereServicoComanda").prop("disabled", false);
                $("#btnCobrarCliente").prop("disabled", false);
            });

            $("#comanda-modal").on("hidden.bs.modal", function(e) {
                $("#comValorRecebido").val("");
                $("#comValorTroco").val("");
            });

            // ComInsertServiço

            // Parcelar Caixa
            $("#parcelarCaixa").change(function() {
                if ($("#tipoPagamento1 option:selected").val() !== undefined) {
                    toastr.warning(
                        "Não é possível parcelar comandas com mais de um tipo de pagamento"
                    );
                    $("#parcelarCaixa").prop("checked", false);
                    $("#trParcelar").hide();
                    $("#trParcelarPer").hide();
                }
            });

            // Botão novo tipo de Pagamento
            var g = 0;
            $("#btnNovoTipo").click(function() {
                valorCompletoComanda = 0.0;
                var valor = 0;
                $scope.novoTipoPagamento();

                var valorComandaReal = $("#valorTotalComanda")
                    .html()
                    .replace($_CONFIG.MOEDA, "")
                    .replace(",", ".");
                valorComandaReal = parseFloat(valorComandaReal).toFixed(2);

                var listaIten = tabelaComItens.fnGetData();
                for (var i = 0; i < listaIten.length; i++) {
                    if (listaIten[i].PagamentoOnline == 1) {
                        valor = valor + parseFloat(listaIten[i].Valor);

                        valor = parseFloat(valor);
                    }
                    if (listaIten[i].CPoPagamentoTotal == 0) {
                        valor = listaIten[i].CPoValor;
                    }
                }

                if (g < 1) {
                    if (valor == 0) {
                        valorCompletoComanda = $("#valorPagamento0")
                            .val()
                            .replace($_CONFIG.MOEDA, "")
                            .replace(",", ".");
                        valorCompletoComanda = parseFloat(valorCompletoComanda).toFixed(2);
                        if (
                            parseFloat(valorCompletoComanda) >= parseFloat(valorComandaReal)
                        ) {
                            $("#valorPagamento0").val((valorCompletoComanda / 2).toFixed(2));
                            $("#valorPagamento1").val((valorCompletoComanda / 2).toFixed(2));
                            $("#valorPagamento1").focus();
                            $("#valorPagamento0").focus();
                            $("#btnInsereProdutoComanda").prop("disabled", true);
                            $("#btnInsereServicoComanda").prop("disabled", true);
                            $("#btnCobrarCliente").prop("disabled", true);
                        } else {
                            $("#valorPagamento1").val(
                                (valorComandaReal - valorCompletoComanda).toFixed(2)
                            );
                            $("#valorPagamento1").focus().change();
                            $("#btnInsereProdutoComanda").prop("disabled", true);
                            $("#btnInsereServicoComanda").prop("disabled", true);
                            $("#btnCobrarCliente").prop("disabled", true);
                            valorCompletoComanda = valorComandaReal;
                        }
                    } else {
                        valorCompletoComanda = $("#valorTotalComanda")
                            .html()
                            .replace($_CONFIG.MOEDA, "")
                            .replace(",", ".");
                        valorCompletoComanda = parseFloat(valorCompletoComanda).toFixed(2);

                        $("#valorPagamento0").val(parseFloat(valor).toFixed(2));
                        $("#valorPagamento1").val(
                            (valorCompletoComanda - valor).toFixed(2)
                        );
                        $("#valorPagamento1").focus();
                        $("#valorPagamento0").focus();
                        $("#btnInsereProdutoComanda").prop("disabled", true);
                        $("#btnInsereServicoComanda").prop("disabled", true);
                        $("#btnCobrarCliente").prop("disabled", true);
                    }

                    g++;
                }
            });

            // Botão finalizar comanda
            $("#btnFinalizarComanda").click(function() {
                $("#btnFinalizarComanda").prop("disabled", true);

                const hasSenhaCaixaContaCli = $("#senhaInserecaixa").html();
                var pagamentoComanda = parseFloat(
                    $("#comValorTotal")
                    .html()
                    .replace($_CONFIG.MOEDA, "")
                    .replace(",", ".")
                );
                var valorTotalComanda = parseFloat(
                    $("#valorTotalComanda")
                    .html()
                    .replace($_CONFIG.MOEDA, "")
                    .replace(",", ".")
                );

                var mensagemContaCliente = "";
                var tituloContaCliente = "";
                var insereContaCliente = 0;
                var insereCaixinha = 0;
                var displayContaCliente = 0;
                var displayCaixinha = 0;
                var inverteMensagem = 0;
                var insereCaixa = 1;
                var tipopessoacomanda = "cliente";
                var erro = 1;
                var triggerStone = [];
                if ($("#TprTipoComanda").html() == "3") {
                    tipopessoacomanda = "profissional";
                }

                if (
                    $("#tipoPagamento0 option:selected").val() === undefined ||
                    $("#tipoPagamento0 option:selected").val() == ""
                ) {
                    toastr.error("Selecione um Tipo de Pagamento.");
                    $("#btnFinalizarComanda").prop("disabled", false);
                    erro = 1;
                } else {
                    if (
                        $("#tipoPagamento1 option:selected").val() !== undefined &&
                        $("#tipoPagamento1 option:selected").val() == ""
                    ) {
                        toastr.error("Selecione o Segundo Tipo de Pagamento.");
                        $("#btnFinalizarComanda").prop("disabled", false);
                        erro = 1;
                    } else {
                        if (pagamentoComanda != valorTotalComanda) {
                            if (
                                $("#nomeClienteComanda").html() == "" ||
                                $("#nomeClienteComanda").html() == "Sem Cadastro"
                            ) {
                                mensagemContaCliente =
                                    "<h4>Valor de pagamento é diferente do valor da comanda e não tem cliente associado.<br><br>Deseja prosseguir mesmo assim?</h4>";
                                tituloContaCliente = "<strong>Atenção</strong>";
                                displayContaCliente = 1;
                                inverteMensagem = 1;
                            } else if (pagamentoComanda < valorTotalComanda) {
                                mensagemContaCliente =
                                    "<h4>Valor de pagamento é menor que o valor da comanda.<br><br>Deseja adicionar o saldo como <strong>débito</strong> do " +
                                    tipopessoacomanda +
                                    "?</h4>";
                                tituloContaCliente =
                                    "<strong>Conta do " + tipopessoacomanda + "</strong>";
                                displayContaCliente = 1;
                            } else if (pagamentoComanda > valorTotalComanda) {
                                mensagemContaCliente =
                                    "<h4>Valor de pagamento é maior que o valor da comanda.<br><br>Deseja adicionar o saldo como <strong>crédito</strong> do " +
                                    tipopessoacomanda +
                                    "?</h4>";
                                tituloContaCliente =
                                    "<strong>Conta do " + tipopessoacomanda + "</strong>";
                                displayContaCliente = 1;

                                if ($scope.caixinha == 1) {
                                    displayCaixinha = 1;
                                } else {
                                    displayCaixinha = 0;
                                }
                            }
                        }
                        erro = 0;
                    }
                }

                if (erro == 0) {
                    var proceedComanda = new Promise((resolve, reject) => {
                        if (displayContaCliente == 1) {
                            bootbox.dialog({
                                message: mensagemContaCliente,
                                title: tituloContaCliente,
                                onEscape: function() {
                                    $("#btnFinalizarComanda").prop("disabled", false);
                                },
                                onHide: function() {
                                    $("#btnFinalizarComanda").prop("disabled", false);
                                },
                                buttons: {
                                    success: {
                                        label: "Sim",
                                        className: "btn-success",
                                        callback: function() {
                                            if (hasSenhaCaixaContaCli /*&& inverteMensagem == 1*/ ) {
                                                var statesdemo = {
                                                    state0: {
                                                        title: "Insira a senha ",
                                                        html: '<input class="form-control" type="password" name="password" id="password" value=""></label>',
                                                        buttons: {
                                                            Ok: 1,
                                                        },
                                                        submit: function(e, v, m, f) {
                                                            e.preventDefault();
                                                            if (f.password != null) {
                                                                $.ajax({
                                                                    dataType: "json",
                                                                    method: "POST",
                                                                    url: "/php/verificaSenhaCaixa.php",
                                                                    data: {
                                                                        password: f.password,
                                                                    },
                                                                    success: function(data) {
                                                                        if (data.erro == "0") {
                                                                            insereContaCliente = 1;
                                                                            insereCaixinha = 0;
                                                                            resolve({
                                                                                contacli: insereContaCliente,
                                                                                caixinha: insereCaixinha,
                                                                            });
                                                                            $.prompt.close();
                                                                        } else {
                                                                            toastr.error(data.resultado);
                                                                            $("#btnFinalizarComanda").prop(
                                                                                "disabled",
                                                                                false
                                                                            );
                                                                        }
                                                                    },
                                                                    error: function(data) {
                                                                        toastr.error(data.resultado);
                                                                        $("#btnFinalizarComanda").prop(
                                                                            "disabled",
                                                                            false
                                                                        );
                                                                    },
                                                                });
                                                            }
                                                        },
                                                    },
                                                };
                                                $.prompt(statesdemo);
                                            } else {
                                                insereContaCliente = 1;
                                                insereCaixinha = 0;
                                                resolve({
                                                    contacli: insereContaCliente,
                                                    caixinha: insereCaixinha,
                                                });
                                            }
                                        },
                                    },
                                    danger: {
                                        label: "Não",
                                        className: "btn-danger",
                                        callback: function() {
                                            if (hasSenhaCaixaContaCli /*&& inverteMensagem == 0*/ ) {
                                                var statesdemo = {
                                                    state0: {
                                                        title: "Insira a senha ",
                                                        html: '<input class="form-control" type="password" name="password" id="password" value=""></label>',
                                                        buttons: {
                                                            Ok: 1,
                                                        },
                                                        submit: function(e, v, m, f) {
                                                            e.preventDefault();
                                                            if (f.password != null) {
                                                                $.ajax({
                                                                    dataType: "json",
                                                                    method: "POST",
                                                                    url: "/php/verificaSenhaCaixa.php",
                                                                    data: {
                                                                        password: f.password,
                                                                    },
                                                                    success: function(data) {
                                                                        if (data.erro == "0") {
                                                                            insereContaCliente = 0;
                                                                            if (displayCaixinha == 1) {
                                                                                swal({
                                                                                        title: "Caixinha",
                                                                                        text: "<h4>Deseja inserir esse valor no caixinha?</h4>",
                                                                                        type: "warning",
                                                                                        showCancelButton: true,
                                                                                        confirmButtonColor: "#DD6B55",
                                                                                        confirmButtonText: $_CONFIG.language.sim,
                                                                                        cancelButtonText: $_CONFIG.language.nao,
                                                                                        closeOnConfirm: true,
                                                                                        closeOnCancel: true,
                                                                                        html: true,
                                                                                    },
                                                                                    function(isConfirm) {
                                                                                        if (isConfirm) {
                                                                                            insereCaixinha = 1;
                                                                                        }
                                                                                        resolve({
                                                                                            contacli: insereContaCliente,
                                                                                            caixinha: insereCaixinha,
                                                                                        });
                                                                                    }
                                                                                );
                                                                            } else {
                                                                                resolve({
                                                                                    contacli: insereContaCliente,
                                                                                    caixinha: insereCaixinha,
                                                                                });
                                                                            }
                                                                            $.prompt.close();
                                                                        } else {
                                                                            toastr.error(data.resultado);
                                                                            $("#btnFinalizarComanda").prop(
                                                                                "disabled",
                                                                                false
                                                                            );
                                                                        }
                                                                    },
                                                                    error: function(data) {
                                                                        toastr.error("Falha de conexão");
                                                                        $("#btnFinalizarComanda").prop(
                                                                            "disabled",
                                                                            false
                                                                        );
                                                                    },
                                                                });
                                                            }
                                                        },
                                                    },
                                                };
                                                $.prompt(statesdemo);
                                            } else {
                                                if (inverteMensagem == 0) {
                                                    insereContaCliente = 0;
                                                    insereCaixinha = 0;
                                                    if (displayCaixinha == 1) {
                                                        swal({
                                                                title: "Caixinha",
                                                                text: "<h4>Deseja inserir esse valor no caixinha?</h4>",
                                                                type: "warning",
                                                                showCancelButton: true,
                                                                confirmButtonColor: "#DD6B55",
                                                                confirmButtonText: $_CONFIG.language.sim,
                                                                cancelButtonText: $_CONFIG.language.nao,
                                                                closeOnConfirm: true,
                                                                closeOnCancel: true,
                                                                html: true,
                                                            },
                                                            function(isConfirm) {
                                                                if (isConfirm) {
                                                                    insereCaixinha = 1;
                                                                }
                                                                resolve({
                                                                    contacli: insereContaCliente,
                                                                    caixinha: insereCaixinha,
                                                                });
                                                            }
                                                        );
                                                    } else {
                                                        resolve({
                                                            contacli: insereContaCliente,
                                                            caixinha: insereCaixinha,
                                                        });
                                                    }
                                                } else {
                                                    $("#btnFinalizarComanda").prop("disabled", false);
                                                }
                                            }
                                        },
                                    },
                                    main: {
                                        label: "Cancelar",
                                        className: "btn-primary",
                                        callback: function() {
                                            $("#btnFinalizarComanda").prop("disabled", false);
                                        },
                                    },
                                },
                            });
                        } else {
                            resolve({
                                contacli: insereContaCliente,
                                caixinha: insereCaixinha,
                            });
                        }
                    });

                    var proceedComandaCaixa = new Promise((resolve, reject) => {
                        if ($("#insereCaixa").get(0).checked) {
                            insereCaixa = 1;
                            resolve({
                                inserecaixa: insereCaixa,
                            });
                        } else {
                            if (hasSenhaCaixaContaCli == 1) {
                                var statesdemo = {
                                    state0: {
                                        title: "Insira a senha ",
                                        html: '<input class="form-control" type="password" name="password" id="password" value=""></label>',
                                        buttons: {
                                            Ok: 1,
                                        },
                                        submit: function(e, v, m, f) {
                                            e.preventDefault();
                                            if (f.password != null) {
                                                $.ajax({
                                                    dataType: "json",
                                                    method: "POST",
                                                    url: "/php/verificaSenhaCaixa.php",
                                                    data: {
                                                        password: f.password,
                                                    },
                                                    success: function(data) {
                                                        if (data.erro == "0") {
                                                            insereCaixa = 0;
                                                            resolve({
                                                                inserecaixa: insereCaixa,
                                                            });
                                                            $.prompt.close();
                                                        } else {
                                                            toastr.error(data.resultado);
                                                            $("#btnFinalizarComanda").prop("disabled", false);
                                                        }
                                                    },
                                                    error: function(data) {
                                                        toastr.error("Falha de conexão");
                                                        $("#btnFinalizarComanda").prop("disabled", false);
                                                    },
                                                });
                                            }
                                        },
                                    },
                                };
                                $.prompt(statesdemo);
                            } else {
                                insereCaixa = 0;
                                resolve({
                                    inserecaixa: insereCaixa,
                                });
                            }
                        }
                    });

                    proceedComanda.then((infoCliCaixinha) => {
                        proceedComandaCaixa.then((infoCaixa) => {
                            if (
                                ($scope.parnota == 1 && $scope.parnfse == 1) ||
                                ($scope.parnota == 1 && $scope.parnfe == 1)
                            ) {
                                closeComanda(infoCaixa.inserecaixa, infoCliCaixinha, true);
                            } else {
                                closeComanda(infoCaixa.inserecaixa, infoCliCaixinha, false);
                            }
                        });
                    });
                }
            });

            // Pacote Comandas Com
            $("#pacotesComandaCombo").change(function() {
                verificaConsumoPacote();
            });

            // Hide ComandaPacotes-Modal
            $("#comandaPacote-modal").on("hide.bs.modal", function() {
                $("#pacotesComandaCombo").val("-1").trigger("change");
            });

            // Produto change
            $("#comProduto").change(function() {
                $("#tipoUnidadeAddonComanda").html(
                    $("#comProduto option:selected").get(0).dataset.tunabreviatura
                );
                if ($("#comProduto option:selected").get(0).dataset.tuncodigo != 1) {
                    $("#comQtdeInsert").attr("type", "text");
                    $("#comQtdeInsert").attr(
                        "onkeyup",
                        "formataValorDinheiro(this); calculaValorInsert();"
                    );
                } else {
                    $("#comQtdeInsert").attr("type", "number");
                    $("#comQtdeInsert").attr("onkeyup", "");
                }
                if ($("#comProduto option:selected").get(0).dataset.iscombo == 0) {
                    $.ajax({
                        dataType: "json",
                        method: "POST",
                        url: "/pages/cadastros/buscaPessoaProduto.php",
                        data: {
                            procodigo: $("#comProduto option:selected").val(),
                            tipo: 2,
                        },
                        success: function(data) {
                            var html2 = "";
                            html2 +=
                                '<option value="" data-comissao="0">Profissional</option>';
                            for (var i = 0; i < data.data.length; i++) {
                                var codigo = data.data[i].Pes_Codigo;
                                var apelido = data.data[i].Pes_Apelido;
                                var comissao = data.data[i].comissao;
                                html2 +=
                                    '<option value="' +
                                    codigo +
                                    '" data-comissao="' +
                                    comissao +
                                    '">' +
                                    apelido +
                                    "</option>";
                            }
                            $("#comProfissionalComissao").html(html2);
                        },
                    });

                    var mensagem = $("#comProduto option:selected").get(0).dataset
                        .qtdminima;
                    if (mensagem != "") {
                        toastr.warning(mensagem);
                    }
                    $("#comValorHdInsert").attr("disabled", false);
                    $("#comQtdeInsert").attr("disabled", false);
                    $("#comTokenInsert").attr("disabled", false);
                    $("#btnValidarTokenInsert").attr("disabled", false);
                    $("#comParaUsoInsert").attr("disabled", false);
                    if ($scope.parValorShowComissao == 1) {
                        $("#comProComissao").attr("disabled", true);
                    } else {
                        $("#comProComissao").attr("disabled", false);
                    }
                } else {
                    $("#comValorHdInsert").attr("disabled", true);
                    $("#comQtdeInsert").attr("disabled", true);
                    $("#comTokenInsert").attr("disabled", true);
                    $("#comProComissao").attr("disabled", true);
                    $("#btnValidarTokenInsert").attr("disabled", true);
                    $("#comParaUsoInsert").attr("disabled", true);
                }
            });

            // Informações do cliente
            $("#iconInfoCliente").click(function(event) {
                $scope.mostraInfoClientes($("#codCliente").val());
            });

            // Destroy scope
            $scope.$on("$destroy", function() {
                $("#btnFinalizarComanda").unbind("click");
                $("#btnNovoTipo").unbind("click");
                $("#iconInfoCliente").unbind("click");
                $("#formInsereItemComanda").unbind("submit");
                $("#formInsereItemComandaSer").unbind("submit");
                $("#formAlteraItemPacote").unbind("submit");
                $("#formCadastroComanda").unbind("subimit");
            });

            // Campo comissao Profissional
            $("#comProComissao").on("keyup", function(e) {
                formataValorDinheiro(this);
            });

            $("#btnCliPacote").click(function() {
                $scope.buscaCliPacote(
                    $("#cliDatInicioPac").val(),
                    $("#cliDatFimPac").val()
                );
            });

            $("#btnCliAgendamento").click(function() {
                $scope.buscaCliAgendamento(
                    $("#cliDatInicioAge").val(),
                    $("#cliDatFimAge").val()
                );
            });

            $("#btnCliComanda").click(function() {
                $scope.buscaCliComanda(
                    $("#cliDatInicioCom").val(),
                    $("#cliDatFimCom").val()
                );
            });

            $scope.avancaTab = function() {
                var $active = $(".cliente .nav-tabs li.active");
                $scope.nextTab($active);
            };

            $scope.retornaTab = function() {
                var $active = $(".cliente .nav-tabs li.active");
                $scope.prevTab($active);
            };

            $scope.nextTab = function(elem) {
                $(elem).next().find('a[data-toggle="tab"]').click();
            };

            $scope.prevTab = function(elem) {
                $(elem).prev().find('a[data-toggle="tab"]').click();
            };

            $scope.firstTab = function() {
                $('#infoCliente-modal a[data-toggle="tab"]:first').click();
            };

            /*--------Submits---------*/

            // Cadastrar Comanda
            $("#formCadastroComanda").submit(function(event) {
                if (
                    $("#comTipoManual").val() == 1 &&
                    $("#comProfissional").val() == ""
                ) {
                    toastr.warning("Informe o Profissional");
                } else {
                    showLoader(true);
                    event.preventDefault();
                    formCadastro = $(this);
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/insereComandasv2.php",
                        data: new FormData(this),
                        dataType: "json",
                        processData: false,
                        contentType: false,
                        success: function(result) {
                            if (result.result[0].erro == "0") {
                                toastr.success(result.result[0].resultado);
                                $("#nomeClienteComanda").html(result.result[0].NomeCliente);
                                $("#idComanda").html(result.result[0].ComCodigo);
                                $("#numComanda").html(result.result[0].ComCodigo);
                                $("#numComandaProd").html(result.result[0].ComCodigo);
                                $("#dataComanda").html(result.result[0].DataComanda);
                                $("#edtComCartao").val(result.result[0].CodigoExterno);
                                $("#codCliente").val(result.result[0].Cliente);
                                $("#TprTipoComanda").html(result.result[0].TPRCodigo);
                                $("#infoPontosCli").hide();

                                if (result.result[0].TPRCodigo == 3) {
                                    $("#labelTipoClienteComanda").html("Profissional: ");
                                    $("#iconInfoCliente").hide();
                                    $("#btnAssociaClienteComanda").hide();
                                } else {
                                    $("#labelTipoClienteComanda").html("Cliente: ");
                                    $("#iconInfoCliente").show();
                                    if (result.result[0].NomeCliente != "") {
                                        $("#btnAssociaClienteComanda").hide();
                                        $("#infoPontosCli").show();

                                        $.ajax({
                                            dataType: "html",
                                            url: "/pages/relatorios/buscaProgramaFidelidade.php",
                                            method: "POST",
                                            data: {
                                                selCliente: result.result[0].Cliente,
                                                selTipo: 1,
                                            },
                                            dataType: "json",
                                            success: function(data) {
                                                if (data.data.length == 1) {
                                                    $("#stringPontosCli").html(data.data[0].TotalPontos);
                                                } else {
                                                    $("#stringPontosCli").html(0);
                                                }
                                            },
                                        });
                                    } else {
                                        $("#btnAssociaClienteComanda").show();
                                        $("#nomeClienteComanda").html("Sem Cadastro");
                                    }
                                }
                                $("#comanda-modal").modal("show");

                                $scope.buscaPessoaConta();

                                var PromissePagamento = new Promise((resolve, reject) => {
                                    resolve($scope.atualizaTipoPagemento());
                                });
                                PromissePagamento.then(() => {
                                    $scope.buscaItensComanda(result.result[0].ComCodigo);
                                });

                                if (location.hash == "#/agenda") {
                                    $rootScope.$emit("BuscaAgenda", {});
                                }

                                $("#cadastrarComanda-modal").modal("hide");

                                $("#comCliente").val("0").trigger("change");

                                formCadastro.each(function() {
                                    this.reset();
                                });

                                $("#comTipoManual").val(0);
                                $("#comTipoManual").change();
                                $(".date.DataComandaAbre").datepicker(
                                    "update",
                                    dataabrecomanda
                                );
                            } else {
                                toastr.error(result.result[0].resultado);
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                }

                return true;
            });

            $("#comQtde").keyup(function() {
                if ($("#comQtde").val() > 1 && $("#comToken").val() == "") {
                    $("#comToken").prop("disabled", true);
                } else {
                    $("#comToken").prop("disabled", false);
                }
                if ($("#comQtde").val() == 0 || $("#comQtde").val() == "") {
                    $("#comQtde").val(1);
                }
            });

            $("#comQtde").change(function() {
                if ($("#comQtde").val() > 1 && $("#comToken").val() == "") {
                    $("#comToken").prop("disabled", true);
                } else {
                    $("#comToken").prop("disabled", false);
                }
                if ($("#comQtde").val() == 0 || $("#comQtde").val() == "") {
                    $("#comQtde").val(1);
                }
            });

            $("#comToken").keyup(function() {
                if ($("#comToken").val() != "") {
                    $("#comQtde").val(1).change();
                    $("#comQtde").prop("disabled", true);
                } else {
                    $("#comQtde").prop("disabled", false);
                }
            });

            $("#comQtdeInsert").keyup(function() {
                if ($("#comQtdeInsert").val() > 1 && $("#comTokenInsert").val() == "") {
                    $("#comTokenInsert").prop("disabled", true);
                } else {
                    $("#comTokenInsert").prop("disabled", false);
                }
            });
            $("#comQtdeInsert").change(function() {
                if ($("#comQtdeInsert").val() > 1 && $("#comTokenInsert").val() == "") {
                    $("#comTokenInsert").prop("disabled", true);
                } else {
                    $("#comTokenInsert").prop("disabled", false);
                }
            });

            $("#comTokenInsert").keyup(function() {
                if ($("#comTokenInsert").val() != "") {
                    $("#comQtdeInsert").val(1);
                    $("#comQtdeInsert").prop("disabled", true);
                } else {
                    $("#comQtdeInsert").prop("disabled", false);
                }
            });

            // Insere itens Comanda
            $("#formInsereItemComanda").submit(function(event) {
                $("#comQtdeInsert").prop("disabled", false);
                $("#comTokenInsert").prop("disabled", false);
                event.preventDefault();
                if ($("#comProduto").val() != "-1") {
                    if (
                        $("#comQtdeInsert").val() != "0" &&
                        $("#comQtdeInsert").val() != "" &&
                        $("#comQtdeInsert").val() > 0 &&
                        $("#comQtdeInsert").val() != "e"
                    ) {
                        if (
                            $("#comTokenInsert").val() != "" ||
                            $("#comValorHdInsertOLD").val() == $("#comValorHdInsert").val() ||
                            $("#comParaUsoInsert").is(":checked") ||
                            $("#comCortesiaInsert").is(":checked")
                        ) {
                            if ($("#TprTipoComanda").html() == 3) {
                                if ($scope.geracomissaoprof == 1) {
                                    if (
                                        $("#comProComissao").val() != "0.00" &&
                                        $("#comProfissionalComissao").val() == "" &&
                                        $("#comProComissao").val() != "0,00" &&
                                        $("#comProfissionalComissao").val() == ""
                                    ) {
                                        toastr.error(
                                            "Insira o Profissional que irá receber a comissão."
                                        );
                                        return false;
                                    }
                                }
                            } else {
                                if (
                                    $("#comProComissao").val() != "0.00" &&
                                    $("#comProfissionalComissao").val() == "" &&
                                    $("#comProComissao").val() != "0,00" &&
                                    $("#comProfissionalComissao").val() == ""
                                ) {
                                    toastr.error(
                                        "Insira o Profissional que irá receber a comissão."
                                    );
                                    return false;
                                }
                            }
                            if ($("#divTokenComInsert").hasClass("has-error")) {
                                $("#comCortesia").prop("disabled", false);
                                toastr.error("Token Inválido.");
                            } else if (
                                $("#comTokenInsert").val() != "" &&
                                !$("#divTokenComInsert").hasClass("has-success")
                            ) {
                                toastr.error("Token não validado, tentando novamente...");
                                $("#comToken").keyup();
                            } else if (
                                $("#tipoDescontoInsert").val() == "-1" &&
                                $("#comDesconto").val() != ""
                            ) {
                                toastr.error("Insira o tipo de desconto.");
                            } else {
                                var valorAgendamento = "";

                                if ($("#comParaUsoInsert").is(":checked")) {
                                    valorAgendamento = $("#listServicoComanda").val();
                                }
                                if ($("#comTokenInsert").val().length < 5) {
                                    $("#comTokenInsert").val("");
                                }

                                $("#comValorInsert").attr("disabled", false);

                                if (
                                    $("#comProduto option:selected").get(0).dataset.iscombo == 1
                                ) {
                                    $("#comProComissao").val("");
                                }
                                formInsereItemComanda = $(this);
                                showLoader(true);
                                $.ajax({
                                    type: "POST",
                                    url: "/pages/cadastros/insereComandaItensV4.php",
                                    data: {
                                        comcodigo: $("#comCodigoInsert").val(),
                                        procodigo: $("#comProduto").val(),
                                        valor: $("#comValorInsert").val().replace(",", "."),
                                        valorunitario: $("#comValorHdInsert")
                                            .val()
                                            .replace(",", "."),
                                        cittoken: $("#comTokenInsert").val(),
                                        citvenda: Number($("#comParaUsoInsert").is(":checked")),
                                        citcomissaoproduto: $("#comProComissao").val(),
                                        pescodigoprocomissao: $("#comProfissionalComissao").val(),
                                        citcortesia: Number($("#comCortesiaInsert").is(":checked")),
                                        iscombo: $("#comProduto option:selected").get(0).dataset
                                            .iscombo,
                                        qtd: $("#comQtdeInsert").val(),
                                        agecodigovinculo: valorAgendamento,
                                        checksenha: 0,
                                    },
                                    dataType: "json",

                                    success: function(result) {
                                        if (result.result[0].erro == "0") {
                                            if ($("#insereProdutoOrigem").val() == 1) {
                                                $scope.atualizaDadosItens();
                                            }
                                            if (location.hash == "#/comandasabertas") {
                                                $rootScope.$emit("atualizaDadosComanda", {});
                                            }
                                            if (location.hash == "#/filaDeEspera") {
                                                $rootScope.$emit("atualizaDadosFila", {});
                                            }
                                            toastr.success(result.result[0].resultado);

                                            $("#btnValidarTokenInsert").prop("disabled", false);

                                            $("#comandaInsert-modal").modal("hide");
                                            if ($("#insereProdutoOrigem").val() == 1) {
                                                $("#comanda-modal").modal("show");
                                            }
                                            formInsereItemComanda.each(function() {
                                                this.reset();
                                            });

                                            $("#comValorHdInsert").attr("disabled", false);
                                            $("#comQtdeInsert").attr("disabled", false);
                                            $("#comTokenInsert").attr("disabled", false);
                                            $("#btnValidarTokenInsert").attr("disabled", false);
                                            $("#comParaUsoInsert").attr("disabled", false);
                                            if ($scope.parValorShowComissao == 1) {
                                                $("#comProComissao").attr("disabled", true);
                                            } else {
                                                $("#comProComissao").attr("disabled", false);
                                            }
                                        } else {
                                            if (result.result[0].erro != "2") {
                                                toastr.error(result.result[0].resultado);
                                            } else {
                                                //swal(result.result[0].resultado, "", "error");
                                                /*-----------------------------------------------------------------------------------------------------------------------------*/

                                                swal({
                                                        title: "Não será possível inserir o produto na comanda!",
                                                        text: "O total de lançamentos desse produto em comandas em aberto execederá o seu saldo em estoque. Confira o relatório <b>Produtos em comandas abertas</b> para mais detalhes.",
                                                        type: "warning",
                                                        showCancelButton: true,
                                                        confirmButtonColor: "#7ddd54",
                                                        cancelButtonColor: "#679bef",
                                                        confirmButtonText: "Ver relatório",
                                                        cancelButtonText: "Ok",
                                                        closeOnConfirm: false,
                                                        closeOnCancel: true,
                                                        html: true,
                                                    },
                                                    function(isConfirm) {
                                                        if (isConfirm) {
                                                            swal.close();
                                                            $("#comandaInsert-modal").modal("hide");
                                                            $state.go("relGerencialEstoque");
                                                        }
                                                    }
                                                );

                                                /*-----------------------------------------------------------------------------------------------------------------------------*/
                                            }
                                            if (
                                                $("#comProduto option:selected").get(0).dataset
                                                .iscombo == 1
                                            ) {
                                                $("#comQtdeInsert").prop("disabled", true);
                                                $("#comTokenInsert").prop("disabled", true);
                                                $("#comValorInsert").attr("disabled", true);
                                            }
                                        }
                                        showLoader(false);
                                        if (
                                            $("#comProduto option:selected").get(0).dataset.iscombo ==
                                            0
                                        ) {
                                            $("#comValorInsert").attr("disabled", true);
                                        }
                                    },
                                    error: function(result) {
                                        toastr.error("Falha na conexão.");
                                        showLoader(false);
                                        if (
                                            $("#comProduto option:selected").get(0).dataset.iscombo ==
                                            0
                                        ) {
                                            $("#comValorInsert").attr("disabled", true);
                                        }
                                    },
                                });

                                return true;
                            }
                        } else {
                            if ($("#senhaDesconto").html() == "1") {
                                var statesdemo = {
                                    state0: {
                                        title: "Insira a senha ",
                                        html: '<input class="form-control" type="password" name="password" id="password" value=""></label>',
                                        buttons: {
                                            Ok: 1,
                                        },
                                        submit: function(e, v, m, f) {
                                            e.preventDefault();
                                            if (f.password != null) {
                                                showLoader(true);

                                                if ($("#TprTipoComanda").html() == 3) {
                                                    if ($scope.geracomissaoprof == 1) {
                                                        if (
                                                            $("#comProComissao").val() != "0.00" &&
                                                            $("#comProfissionalComissao").val() == "" &&
                                                            $("#comProComissao").val() != "0,00" &&
                                                            $("#comProfissionalComissao").val() == ""
                                                        ) {
                                                            toastr.error(
                                                                "Insira o Profissional que irá receber a comissão."
                                                            );
                                                            showLoader(false);
                                                            $.prompt.close();
                                                            return false;
                                                        }
                                                    }
                                                } else {
                                                    if (
                                                        $("#comProComissao").val() != "0.00" &&
                                                        $("#comProfissionalComissao").val() == "" &&
                                                        $("#comProComissao").val() != "0,00" &&
                                                        $("#comProfissionalComissao").val() == ""
                                                    ) {
                                                        toastr.error(
                                                            "Insira o Profissional que irá receber a comissão."
                                                        );
                                                        showLoader(false);
                                                        $.prompt.close();
                                                        return false;
                                                    }
                                                }

                                                if ($("#divTokenComInsert").hasClass("has-error")) {
                                                    $("#comCortesia").prop("disabled", false);
                                                    showLoader(false);
                                                    $.prompt.close();
                                                    toastr.error("Token Inválido.");
                                                } else if (
                                                    $("#comTokenInsert").val() != "" &&
                                                    !$("#divTokenComInsert").hasClass("has-success")
                                                ) {
                                                    toastr.error(
                                                        "Token não validado, tentando novamente..."
                                                    );
                                                    showLoader(false);
                                                    $.prompt.close();
                                                    $("#comToken").keyup();
                                                } else if (
                                                    $("#tipoDescontoInsert").val() == "-1" &&
                                                    $("#comDesconto").val() != ""
                                                ) {
                                                    showLoader(false);
                                                    $.prompt.close();
                                                    toastr.error("Insira o tipo de desconto.");
                                                } else {
                                                    if ($("#comTokenInsert").val().length < 5) {
                                                        $("#comTokenInsert").val("");
                                                    }

                                                    $("#comValorInsert").attr("disabled", false);
                                                    formInsereItemComanda = $(this);
                                                    showLoader(true);
                                                    if (
                                                        $("#comProduto option:selected").get(0).dataset
                                                        .iscombo == 1
                                                    ) {
                                                        $("#comProComissao").val("");
                                                    }
                                                    $.ajax({
                                                        type: "POST",
                                                        url: "/pages/cadastros/insereComandaItensV4.php",
                                                        data: {
                                                            comcodigo: $("#comCodigoInsert").val(),
                                                            procodigo: $("#comProduto").val(),
                                                            valor: $("#comValorInsert")
                                                                .val()
                                                                .replace(",", "."),
                                                            valorunitario: $("#comValorHdInsert")
                                                                .val()
                                                                .replace(",", "."),
                                                            cittoken: $("#comTokenInsert").val(),
                                                            citvenda: Number(
                                                                $("#comParaUsoInsert").is(":checked")
                                                            ),
                                                            citcomissaoproduto: $("#comProComissao").val(),
                                                            pescodigoprocomissao: $(
                                                                "#comProfissionalComissao"
                                                            ).val(),
                                                            citcortesia: Number(
                                                                $("#comCortesiaInsert").is(":checked")
                                                            ),
                                                            iscombo: $("#comProduto option:selected").get(0)
                                                                .dataset.iscombo,
                                                            qtd: $("#comQtdeInsert").val(),
                                                            senhaitens: MD5(f.password),

                                                            checksenha: 1,
                                                        },
                                                        dataType: "json",

                                                        success: function(result) {
                                                            if (result.result[0].erro == "0") {
                                                                if ($("#insereProdutoOrigem").val() == 1) {
                                                                    $scope.atualizaDadosItens();
                                                                }
                                                                if (location.hash == "#/comandasabertas") {
                                                                    $rootScope.$emit("atualizaDadosComanda", {});
                                                                }
                                                                if (location.hash == "#/filaDeEspera") {
                                                                    $rootScope.$emit("atualizaDadosFila", {});
                                                                }
                                                                toastr.success(result.result[0].resultado);

                                                                $("#btnValidarTokenInsert").prop(
                                                                    "disabled",
                                                                    false
                                                                );

                                                                $("#comandaInsert-modal").modal("hide");
                                                                if ($("#insereProdutoOrigem").val() == 1) {
                                                                    $("#comanda-modal").modal("show");
                                                                }
                                                                formInsereItemComanda.each(function() {
                                                                    $("#formInsereItemComanda")[0].reset();
                                                                });

                                                                $("#comValorHdInsert").attr("disabled", false);
                                                                $("#comQtdeInsert").attr("disabled", false);
                                                                $("#comTokenInsert").attr("disabled", false);
                                                                $("#btnValidarTokenInsert").attr(
                                                                    "disabled",
                                                                    false
                                                                );
                                                                $("#comParaUsoInsert").attr("disabled", false);
                                                                if ($scope.parValorShowComissao == 1) {
                                                                    $("#comProComissao").attr("disabled", true);
                                                                } else {
                                                                    $("#comProComissao").attr("disabled", false);
                                                                }
                                                            } else {
                                                                //toastr.error(result.result[0].resultado);

                                                                if (result.result[0].erro != "2") {
                                                                    toastr.error(result.result[0].resultado);
                                                                } else {
                                                                    //swal(result.result[0].resultado, "", "error");
                                                                    /*-----------------------------------------------------------------------------------------------------------------------------*/

                                                                    swal({
                                                                            title: "Não será possível inserir o produto na comanda!",
                                                                            text: "O total de lançamentos desse produto em comandas em aberto execederá o seu saldo em estoque. Confira o relatório <b>Produtos em comandas abertas</b> para mais detalhes.",
                                                                            type: "warning",
                                                                            showCancelButton: true,
                                                                            confirmButtonColor: "#7ddd54",
                                                                            cancelButtonColor: "#679bef",
                                                                            confirmButtonText: "Ver relatório",
                                                                            cancelButtonText: "Ok",
                                                                            closeOnConfirm: false,
                                                                            closeOnCancel: true,
                                                                            html: true,
                                                                        },
                                                                        function(isConfirm) {
                                                                            if (isConfirm) {
                                                                                swal.close();
                                                                                $("#comandaInsert-modal").modal("hide");
                                                                                $state.go("relGerencialEstoque");
                                                                            }
                                                                        }
                                                                    );

                                                                    /*-----------------------------------------------------------------------------------------------------------------------------*/
                                                                }
                                                                if (
                                                                    $("#comProduto option:selected").get(0)
                                                                    .dataset.iscombo == 1
                                                                ) {
                                                                    $("#comQtdeInsert").prop("disabled", true);
                                                                    $("#comTokenInsert").prop("disabled", true);
                                                                    $("#comValorInsert").attr("disabled", true);
                                                                }
                                                            }
                                                            showLoader(false);
                                                            if (
                                                                $("#comProduto option:selected").get(0).dataset
                                                                .iscombo == 0
                                                            ) {
                                                                $("#comValorInsert").attr("disabled", true);
                                                            }
                                                        },
                                                        error: function(result) {
                                                            toastr.error("Falha na conexão.");
                                                            showLoader(false);
                                                            if (
                                                                $("#comProduto option:selected").get(0).dataset
                                                                .iscombo == 0
                                                            ) {
                                                                $("#comValorInsert").attr("disabled", true);
                                                            }
                                                        },
                                                    });
                                                    $.prompt.close();
                                                    return true;
                                                }
                                            }
                                        },
                                    },
                                };
                            } else {
                                if ($("#TprTipoComanda").html() == 3) {
                                    if ($scope.geracomissaoprof == 1) {
                                        if (
                                            $("#comProComissao").val() != "0.00" &&
                                            $("#comProfissionalComissao").val() == "" &&
                                            $("#comProComissao").val() != "0,00" &&
                                            $("#comProfissionalComissao").val() == ""
                                        ) {
                                            toastr.error(
                                                "Insira o Profissional que irá receber a comissão."
                                            );
                                            return false;
                                        }
                                    }
                                } else {
                                    if (
                                        $("#comProComissao").val() != "0.00" &&
                                        $("#comProfissionalComissao").val() == "" &&
                                        $("#comProComissao").val() != "0,00" &&
                                        $("#comProfissionalComissao").val() == ""
                                    ) {
                                        toastr.error(
                                            "Insira o Profissional que irá receber a comissão."
                                        );
                                        return false;
                                    }
                                }
                                if ($("#divTokenComInsert").hasClass("has-error")) {
                                    $("#comCortesia").prop("disabled", false);
                                    toastr.error("Token Inválido.");
                                } else if (
                                    $("#comTokenInsert").val() != "" &&
                                    !$("#divTokenComInsert").hasClass("has-success")
                                ) {
                                    toastr.error("Token não validado, tentando novamente...");
                                    $("#comToken").keyup();
                                } else if (
                                    $("#tipoDescontoInsert").val() == "-1" &&
                                    $("#comDesconto").val() != ""
                                ) {
                                    toastr.error("Insira o tipo de desconto.");
                                } else {
                                    if ($("#comTokenInsert").val().length < 5) {
                                        $("#comTokenInsert").val("");
                                    }

                                    $("#comValorInsert").attr("disabled", false);
                                    formInsereItemComanda = $(this);
                                    if (
                                        $("#comProduto option:selected").get(0).dataset.iscombo == 1
                                    ) {
                                        $("#comProComissao").val("");
                                    }

                                    showLoader(true);
                                    $.ajax({
                                        type: "POST",
                                        url: "/pages/cadastros/insereComandaItensv2.php",
                                        data: {
                                            comcodigo: $("#comCodigoInsert").val(),
                                            procodigo: $("#comProduto").val(),
                                            valor: $("#comValorInsert").val().replace(",", "."),
                                            valorunitario: $("#comValorHdInsert")
                                                .val()
                                                .replace(",", "."),
                                            cittoken: $("#comTokenInsert").val(),
                                            citvenda: Number($("#comParaUsoInsert").is(":checked")),
                                            citcomissaoproduto: $("#comProComissao").val(),
                                            pescodigoprocomissao: $("#comProfissionalComissao").val(),
                                            citcortesia: Number(
                                                $("#comCortesiaInsert").is(":checked")
                                            ),
                                            iscombo: $("#comProduto option:selected").get(0).dataset
                                                .iscombo,
                                            qtd: $("#comQtdeInsert").val(),
                                        },
                                        dataType: "json",

                                        success: function(result) {
                                            if (result.result[0].erro == "0") {
                                                if ($("#insereProdutoOrigem").val() == 1) {
                                                    $scope.atualizaDadosItens();
                                                }
                                                if (location.hash == "#/comandasabertas") {
                                                    $rootScope.$emit("atualizaDadosComanda", {});
                                                }
                                                if (location.hash == "#/filaDeEspera") {
                                                    $rootScope.$emit("atualizaDadosFila", {});
                                                }
                                                toastr.success(result.result[0].resultado);

                                                $("#btnValidarTokenInsert").prop("disabled", false);

                                                $("#comandaInsert-modal").modal("hide");
                                                if ($("#insereProdutoOrigem").val() == 1) {
                                                    $("#comanda-modal").modal("show");
                                                }
                                                formInsereItemComanda.each(function() {
                                                    this.reset();
                                                });

                                                $("#comValorHdInsert").attr("disabled", false);
                                                $("#comQtdeInsert").attr("disabled", false);
                                                $("#comTokenInsert").attr("disabled", false);
                                                $("#btnValidarTokenInsert").attr("disabled", false);
                                                $("#comParaUsoInsert").attr("disabled", false);
                                                if ($scope.parValorShowComissao == 1) {
                                                    $("#comProComissao").attr("disabled", true);
                                                } else {
                                                    $("#comProComissao").attr("disabled", false);
                                                }
                                            } else {
                                                toastr.error(result.result[0].resultado);
                                                if (
                                                    $("#comProduto option:selected").get(0).dataset
                                                    .iscombo == 1
                                                ) {
                                                    $("#comQtdeInsert").prop("disabled", true);
                                                    $("#comTokenInsert").prop("disabled", true);
                                                    $("#comValorInsert").attr("disabled", true);
                                                }
                                            }
                                            showLoader(false);
                                            if (
                                                $("#comProduto option:selected").get(0).dataset
                                                .iscombo == 0
                                            ) {
                                                $("#comValorInsert").attr("disabled", true);
                                            }
                                        },
                                        error: function(result) {
                                            toastr.error("Falha na conexão.");
                                            showLoader(false);
                                            if (
                                                $("#comProduto option:selected").get(0).dataset
                                                .iscombo == 0
                                            ) {
                                                $("#comValorInsert").attr("disabled", true);
                                            }
                                        },
                                    });
                                    return true;
                                }
                            }
                            $.prompt(statesdemo);
                        }
                    } else {
                        toastr.error("Informe a Quantidade.");
                    }
                } else {
                    toastr.error("Informe o produto.");
                }
            });

            $("#btnFechaItemComanda").click(function() {
                $("#comandaInsert-modal").modal("hide");
                $("#comanda-modal").modal("show");
                $("#comCortesiaInsert").prop("disabled", false);
                limpaToken(
                    $("#divTokenComInsert"),
                    $("#tokenComInsert"),
                    $("#msgTokenComInsert")
                );
            });
            $("#btnFechaItemComandaSer").click(function() {
                $("#comandaInsertSer-modal").modal("hide");
                $("#comanda-modal").modal("show");
            });
            // Insere intens comandas serviço
            $("#formInsereItemComandaSer").submit(function(event) {
                event.preventDefault();
                $("#btnInsereItemComandaSer").attr("disabled", true);

                formInsereItemComanda = $(this);
                showLoader(true);
                dataInsere = new FormData(this);
                dataInicio = formataData($("#comDataIni").val());
                dataInsere.append("dataInicio", dataInicio);

                showLoader(false);

                $.ajax({
                    dataType: "json",
                    type: "POST",
                    url: "/pages/cadastros/insereAgendamentoEncaixev3.php",
                    data: {
                        item: $("#comInsertServico").val(),
                        tipoitem: $("#comInsertServico option:selected").get(0).dataset
                            .tipoitem,
                        profissional: $("#comInsertProfissional").val(),
                        cliente: $("#comClienteInsertSer").val(),
                        ageorigem: 2,
                        observacao: "",
                        comcodigo: $("#comCodigoInsertSer").val(),
                        dia: $("#comDataIni").val(),
                        hora: $("#comHoraIni").val(),
                    },
                    success: function(data) {
                        if (data.data[0].erro == "0") {
                            if (location.hash == "#/comandasabertas") {
                                $rootScope.$emit("atualizaDadosComanda", {});
                            }
                            toastr.success(data.data[0].resultado);

                            $("#comandaInsertSer-modal").modal("hide");
                            if ($("#insereServicoOrigem").val() == 1) {
                                $scope.atualizaDadosItens();
                                $("#comanda-modal").modal("show");
                            } else {
                                $rootScope.$emit("BuscaAgenda", {});
                            }
                            if (location.hash == "#/filaDeEspera") {
                                $rootScope.$emit("atualizaDadosFila", {});
                            }

                            formInsereItemComanda.each(function() {
                                this.reset();
                            });
                            $("#btnInsereItemComandaSer").attr("disabled", false);
                        } else {
                            toastr.error(data.data[0].resultado);
                        }
                        showLoader(false);
                        $("#btnInsereItemComandaSer").attr("disabled", false);
                        $("#comValorInsert").attr("disabled", true);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                        $("#btnInsereItemComandaSer").attr("disabled", false);
                        $("#comValorInsert").attr("disabled", true);
                    },
                });

                // $.ajax({
                // 	type: "POST",
                // 	url: "/pages/cadastros/insereItensComandaSer.php",
                // 	data: dataInsere,
                // 	dataType: "json",
                // 	processData: false,
                // 	contentType: false,
                // 	success: function (result) {
                // 		if (result.result[0].erro == "0") {
                // 			if (location.hash == "#/comandasabertas") {
                // 				$rootScope.$emit("atualizaDadosComanda", {});
                // 			}
                // 			toastr.success(result.result[0].resultado);

                // 			$("#comandaInsertSer-modal").modal("hide");
                // 			if ($("#insereServicoOrigem").val() == 1) {
                // 				$scope.atualizaDadosItens();
                // 				$("#comanda-modal").modal("show");
                // 			} else {
                // 				$rootScope.$emit("BuscaAgenda", {});
                // 			}
                // 			if (location.hash == "#/filaDeEspera") {
                // 				$rootScope.$emit("atualizaDadosFila", {});

                // 			}

                // 			formInsereItemComanda.each(function () {
                // 				this.reset();
                // 			});
                // 			$("#btnInsereItemComandaSer").attr('disabled', false);
                // 		} else {
                // 			toastr.error(result.result[0].resultado);
                // 		}
                // 		showLoader(false);
                // 		$("#btnInsereItemComandaSer").attr('disabled', false);
                // 		$("#comValorInsert").attr("disabled", true);
                // 	},
                // 	error: function (result) {
                // 		toastr.error("Falha na conexão.");
                // 		showLoader(false);
                // 		$("#btnInsereItemComandaSer").attr('disabled', false);
                // 		$("#comValorInsert").attr("disabled", true);
                // 	}
                // });
                return true;
            });

            //Altera itens Comanda
            $("#formAlteraItemComanda").submit(function(event) {
                event.preventDefault();
                $("#comToken").prop("disabled", false);
                if ($("#divTokenCom").hasClass("has-error")) {
                    $("#comCortesia").prop("disabled", false);
                    toastr.error("Token Inválido.");
                } else if (
                    $("#comToken").val() != "" &&
                    !$("#divTokenCom").hasClass("has-success")
                ) {
                    toastr.error("Token não validado, tentando novamente...");
                    $("#comToken").keyup();
                } else if (
                    $("#tipoDesconto").val() == "-1" &&
                    $("#comDesconto").val() != ""
                ) {
                    toastr.error("Insira o tipo de desconto.");
                } else {
                    if ($("#comToken").val().length < 5) {
                        $("#comToken").val("");
                    }

                    $("#comValor").attr("disabled", false);
                    $("#comQtde").attr("disabled", false);
                    $("#comComissao").prop("disabled", false);
                    $("#comToken").prop("disabled", false);
                    $("#comParaUso").prop("disabled", false);
                    $("#comCortesia").prop("disabled", false);

                    $("#comValorHd").prop("disabled", false);

                    formAlteraItemComanda = $(this);
                    var needSenha = 0;
                    dataInsere = new FormData(this);
                    dataInsere.append(
                        "comissao",
                        $("#comComissao").maskMoney("unmasked")[0].toFixed(2)
                    );
                    var valorAgendamento = "";

                    if ($("#comParaUso").is(":checked")) {
                        valorAgendamento = $("#listServicoComandaEdt").val();
                    }

                    if (
                        $("#comToken").val() != "" ||
                        $("#comValorHd").val() == $("#comValorHdOLD").val() ||
                        $("#comParaUso").is(":checked") ||
                        $("#comCortesia").is(":checked")
                    ) {
                        showLoader(true);
                        needSenha = 0;
                        dataInsere.append("needSenha", needSenha);
                        dataInsere.append("agendamentoProduto", valorAgendamento);

                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/alteraItensComandav3.php",
                            data: dataInsere,
                            dataType: "json",
                            processData: false,
                            contentType: false,
                            success: function(result) {
                                if (result.result[0].erro == "0") {
                                    $scope.atualizaDadosItens();
                                    if (location.hash == "#/comandasabertas") {
                                        $rootScope.$emit("atualizaDadosComanda", {});
                                    }
                                    toastr.success(result.result[0].resultado);

                                    $("#comandaEdit-modal").modal("hide");
                                    $("#comanda-modal").modal("show");

                                    formAlteraItemComanda.each(function() {
                                        this.reset();
                                    });

                                    limpaToken(
                                        $("#divTokenCom"),
                                        $("#tokenCom"),
                                        $("#msgTokenCom")
                                    );
                                } else {
                                    toastr.error(result.result[0].resultado);
                                }
                                showLoader(false);
                                $("#comValor").attr("disabled", true);
                                $("#btnValidarToken").attr("disabled", false);
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                                showLoader(false);
                                $("#comValor").attr("disabled", true);
                            },
                        });
                        return true;
                    } else {
                        needSenha = 1;
                        if ($("#senhaDesconto").html() == "1") {
                            var statesdemo = {
                                state0: {
                                    title: "Insira a senha ",
                                    html: '<input class="form-control" type="password" name="password" id="password" value=""></label>',
                                    buttons: {
                                        Ok: 1,
                                    },
                                    submit: function(e, v, m, f) {
                                        e.preventDefault();
                                        if (f.password != null) {
                                            showLoader(true);
                                            dataInsere.append("senhaitens", MD5(f.password));
                                            dataInsere.append("needSenha", needSenha);
                                            dataInsere.append("agendamentoProduto", valorAgendamento);
                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/alteraItensComandav3.php",
                                                data: dataInsere,
                                                dataType: "json",
                                                processData: false,
                                                contentType: false,
                                                success: function(result) {
                                                    if (result.result[0].erro == "0") {
                                                        $scope.atualizaDadosItens();
                                                        if (location.hash == "#/comandasabertas") {
                                                            $rootScope.$emit("atualizaDadosComanda", {});
                                                        }
                                                        toastr.success(result.result[0].resultado);

                                                        $("#comandaEdit-modal").modal("hide");
                                                        $("#comanda-modal").modal("show");

                                                        formAlteraItemComanda.each(function() {
                                                            this.reset();
                                                        });

                                                        limpaToken(
                                                            $("#divTokenCom"),
                                                            $("#tokenCom"),
                                                            $("#msgTokenCom")
                                                        );
                                                    } else {
                                                        toastr.error(result.result[0].resultado);
                                                    }
                                                    showLoader(false);
                                                    $("#comValor").attr("disabled", true);
                                                },
                                                error: function(result) {
                                                    toastr.error("Falha na conexão.");
                                                    showLoader(false);
                                                    $("#comValor").attr("disabled", true);
                                                },
                                            });
                                            $.prompt.close();
                                            return true;
                                        }
                                    },
                                },
                            };
                            $.prompt(statesdemo);
                        } else {
                            needSenha = 0;
                            showLoader(true);
                            dataInsere.append("needSenha", needSenha);
                            dataInsere.append("agendamentoProduto", valorAgendamento);
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/alteraItensComandav3.php",
                                data: dataInsere,
                                dataType: "json",
                                processData: false,
                                contentType: false,
                                success: function(result) {
                                    if (result.result[0].erro == "0") {
                                        $scope.atualizaDadosItens();
                                        if (location.hash == "#/comandasabertas") {
                                            $rootScope.$emit("atualizaDadosComanda", {});
                                        }
                                        toastr.success(result.result[0].resultado);

                                        $("#comandaEdit-modal").modal("hide");
                                        $("#comanda-modal").modal("show");

                                        formAlteraItemComanda.each(function() {
                                            this.reset();
                                        });

                                        limpaToken(
                                            $("#divTokenCom"),
                                            $("#tokenCom"),
                                            $("#msgTokenCom")
                                        );
                                    } else {
                                        toastr.error(result.result[0].resultado);
                                    }
                                    showLoader(false);
                                    $("#comValor").attr("disabled", true);
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                    showLoader(false);
                                    $("#comValor").attr("disabled", true);
                                },
                            });
                            return true;
                        }
                    }
                }
            });

            //Altera itens Pacote
            $("#formAlteraItemPacote").submit(function(event) {
                event.preventDefault();
                showLoader(true);

                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/inserePessoaPacoteDetalhesv2.php",
                    data: {
                        ppacodigo: $("#pacotesComandaCombo").val(),
                        itemcodigo: $("#pacotesComandaCombo option:selected").get(0).dataset
                            .codigo,
                        pescodigo: $("#codCliente").val(),
                        citcodigo: $("#comCodItemPac").val(),
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.data[0].erro == "0") {
                            $scope.atualizaDadosItens();
                            if (location.hash == "#/comandasabertas") {
                                $rootScope.$emit("atualizaDadosComanda", {});
                            }
                            toastr.success(result.data[0].resultado);

                            $("#comandaPacote-modal").modal("hide");
                            $("#comanda-modal").modal("show");
                        } else {
                            toastr.error(result.data[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });

                return true;
            });

            $scope.insereAgendamentoClube = function() {
                if ($("#IsMultiUnidade").val() == 0) {
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/insereAgendamentoClube.php",
                        data: {
                            citcodigo: $("#CitCodigoAssocia").val(),
                            apfcodigo: $("#APFCodigoAssocia").val(),
                            asscodigo: $("#AssCodigoAssocia").val(),
                        },
                        dataType: "json",
                        success: function(result) {
                            if (result.data[0].erro == "0") {
                                $scope.atualizaDadosItens();
                                toastr.success(result.data[0].resultado);

                                $("#comandaAssinatura-modal").modal("hide");
                                $("#comanda-modal").modal("show");
                            } else {
                                toastr.error(result.data[0].resultado);
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                } else {
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/AGENDAMENTO_PLANO_ASSINATURA_Vincula.php",
                        data: {
                            invoice_item_code: $("#CitCodigoAssocia").val(),
                            client_subscription_finantial_code: $("#APFCodigoAssocia").val(),
                        },
                        dataType: "json",
                        success: function(data) {
                            if (data.data.error == false) {
                                if (data.data.subscription_plan[0].error == 0) {
                                    $scope.atualizaDadosItens();
                                    toastr.success(data.data.subscription_plan[0].result);

                                    $("#comandaAssinatura-modal").modal("hide");
                                    $("#comanda-modal").modal("show");
                                } else {
                                    toastr.error(data.data.subscription_plan.result);
                                }
                            } else {
                                toastr.error(data.data.message);
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                }
            };

            $("#cliEmail2").keyup(function() {
                $("#cliLoginId2").val($("#cliEmail2").val());
            });

            //Insere cliente (Comanda)
            $("#formCadastroClienteComanda").submit(function(event) {
                if ($("#cliLoginId2").val() != "" && $("#cliEmail2").val() == "") {
                    toastr.error(
                        "Por favor, insira um e-mail para o cliente receber os dados de acesso.",
                        "Insira um E-mail"
                    );
                    return true;
                } else {
                    event.preventDefault();
                    formCadastro = $(this);
                    showLoader(true);
                    dataInsere = new FormData(this);
                    dataInsere.append("apelido", $("#cliApelido").html());
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/insereClientes.php",
                        data: dataInsere,
                        dataType: "json",
                        processData: false,
                        contentType: false,
                        success: function(result) {
                            if (result.insereCliente[0].erro == "0") {
                                $scope.cliLogin = "";
                                toastr.success(result.insereCliente[0].resultado);
                                $("#cadastrarClienteComanda-modal").modal("hide");
                                pescodigo = result.insereCliente[0].pescodigo;
                                $rootScope.$broadcast("AgendabuscaClientes", {
                                    any: pescodigo,
                                });

                                if (hasManyClients) {
                                    var codigo = result.insereCliente[0].pescodigo;
                                    var nome = $("#cliNomeComanda").val();
                                    var celular = $("#cliCelularComanda").val();
                                    if (celular != "") {
                                        celular = " - " + $("#cliCelularComanda").val();
                                    }
                                    $("#comCliente").append(
                                        '<option data-usucodigo="" data-imagem="" value="' +
                                        codigo +
                                        '">' +
                                        nome +
                                        "" +
                                        celular +
                                        "</option>"
                                    );
                                    $("#cliente_menu").append(
                                        '<option data-usucodigo="" data-imagem="" value="' +
                                        codigo +
                                        '">' +
                                        nome +
                                        "" +
                                        celular +
                                        "</option>"
                                    );
                                    $("#cliente_menu2").append(
                                        '<option data-usucodigo="" data-imagem="" value="' +
                                        codigo +
                                        '">' +
                                        nome +
                                        "" +
                                        celular +
                                        "</option>"
                                    );
                                    $("#comCliente").val(codigo).trigger("change");
                                    $("#cliente_menu").val(codigo).trigger("change");
                                    $("#cliente_menu2").val(codigo).trigger("change");
                                    if (location.hash == "#/filaDeEspera") {
                                        $rootScope.$emit("buscaclientefila", {});

                                        setTimeout(function() {
                                            $("#pesCodigoCliente").val(codigo).trigger("change");
                                        }, 2000);
                                    }
                                    if (location.hash == "#/assinantes") {
                                        $rootScope.$emit("buscaClienteAssinatura", {});
                                    }
                                } else {
                                    $scope.selecionaNovoCliente(
                                        result.insereCliente[0].pescodigo
                                    );
                                    if (location.hash == "#/filaDeEspera") {
                                        $rootScope.$emit("buscaclientefila", {});

                                        setTimeout(function() {
                                            $("#pesCodigoCliente")
                                                .val(result.insereCliente[0].pescodigo)
                                                .trigger("change");
                                        }, 2000);
                                    }
                                    if (location.hash == "#/assinantes") {
                                        $rootScope.$emit("buscaClienteAssinatura", {});
                                        setTimeout(() => {
                                            $("#AssCliente")
                                                .val(result.insereCliente[0].pescodigo)
                                                .change();
                                            $("#AssClienteVinculo")
                                                .val(result.insereCliente[0].pescodigo)
                                                .change();
                                        }, 2000);
                                    }
                                }

                                formCadastro.each(function() {
                                    this.reset();
                                });
                                $("#cliLoginId2").val("");
                            } else {
                                toastr.error(result.insereCliente[0].resultado);
                            }

                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                    return true;
                }
            });

            // Insere prontuario
            $("#formInsereDetalhesAgendamento").submit(function(event) {
                event.preventDefault();
                showLoader(true);
                formInsereDet = $(this);
                var dados = new FormData(this);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereAgendamentoProntuario.php",
                    data: dados,
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: function(result) {
                        if (result.result[0].erro == "0") {
                            toastr.success(result.result[0].resultado);
                            formInsereDet.each(function() {
                                this.reset();
                            });
                            $("#insereProntuario-modal").modal("hide");
                            $scope.atualizatabelaProntuario();
                        } else {
                            toastr.error(result.result[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });
                return true;
            });

            //insere imagens do prontuario
            $("#formInsereImagemAgendamento").submit(function(event) {
                event.preventDefault();
                showLoader(true);
                formInsereImg = $(this);
                var dados = new FormData(this);
                dados.append("blob", mBlob);
                dados.delete("aimImagem");
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereAgendamentoProntuarioImagem.php",
                    data: dados,
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: function(result) {
                        if (result.result[0].erro == "0") {
                            toastr.success(result.result[0].resultado);
                            $scope.atualizatabelaProntuario();
                            formInsereImg.each(function() {
                                this.reset();
                            });
                        } else {
                            toastr.error(result.result[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });
                return true;
            });

            // altera prontuario
            $("#formAlteraDetalhesAgendamento").submit(function(event) {
                event.preventDefault();
                if ($("#AdeCodgioAltera").val() != "") {
                    showLoader(true);
                    var dados = new FormData(this);

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/alteraAgendamentoProntuario.php",
                        data: dados,
                        dataType: "json",
                        processData: false,
                        contentType: false,
                        success: function(result) {
                            if (result.result[0].erro == "0") {
                                $scope.atualizatabelaProntuario();
                                toastr.success(result.result[0].resultado);
                            } else {
                                toastr.error(result.result[0].resultado);
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                    return true;
                } else {
                    showLoader(true);
                    formInsereDet = $(this);
                    var dados = new FormData(this);
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/insereAgendamentoProntuario.php",
                        data: {
                            codigoAgendamento: $("#AgeCodigoBuscaImagem").val(),
                            ageMaterial: $("#ageMaterialEdt").val(),
                            ageDetalhes: $("#ageDetalhesEdt").val(),
                            ageCorte: $("#ageCorteEdt").val(),
                        },
                        dataType: "json",
                        success: function(result) {
                            if (result.result[0].erro == "0") {
                                toastr.success(result.result[0].resultado);
                                $scope.atualizatabelaProntuario();
                                $("#EditaProntuario-modal").modal("hide");
                            } else {
                                toastr.error(result.result[0].resultado);
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                    return true;
                }
            });

            /*--------Mascaras--------*/

            $translate("mascaras.telefone").then(function(value) {
                if (value != "") {
                    $("#cliTelefone").mask(value);
                    $("#cliTelefoneComanda").mask(value);
                }
            });

            $("#msgEnviarSms").change(function(event) {
                $scope.sendSms = this.checked;
                if (this.checked) {
                    $("#msgDescricao").attr("maxlength", $scope.textMax);
                    $scope.countCharMsg();
                    $("#divSaldoSmsMsg").show();
                    $("#charNumMsg").show();
                } else {
                    $("#msgDescricao").removeAttr("maxlength");
                    $("#divSaldoSmsMsg").hide();
                    $("#charNumMsg").hide();
                    $("#divDescNot").removeClass("has-error");
                }
            });

            $("#msgDescricao").keyup(function() {
                $scope.countCharMsg();
            });

            $scope.countCharMsg = function(text) {
                if ($scope.sendSms) {
                    var text_length = $("#msgDescricao").val().length;
                    if (text_length > $scope.textMax) {
                        $("#divDescMsg").addClass("has-error");
                    } else {
                        $("#divDescMsg").removeClass("has-error");
                    }
                    $("#charTextMsg").html(text_length + " caracteres");
                }
            };

            $scope.buscaSaldoSMSMsg = function() {
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    data: {
                        metodo: "buscaPessoaSMS",
                        tipo: 1,
                        id: $scope.idCliente,
                    },
                    success: function(data) {
                        if (data.result.length > 0) {
                            $("#lblSaldoSMSMsg").html(data.result[0].Saldo);
                        }
                    },
                });
            };
            buscaEstados($_CONFIG.PAIS);

            function buscaEstados(pais) {
                var html = "<option value='-1'>Estado</option>";
                for (var i = 0; i < $_CONFIG.LISTA_ESTADO.length; i++) {
                    if (pais != "2") {
                        html +=
                            "<option id='" +
                            $_CONFIG.LISTA_ESTADO[i].Est_Sigla +
                            "' value='" +
                            $_CONFIG.LISTA_ESTADO[i].Est_Codigo +
                            "'> " +
                            $_CONFIG.LISTA_ESTADO[i].Est_Nome +
                            "</option>";
                    } else {
                        html +=
                            "<option id='" +
                            $_CONFIG.LISTA_ESTADO[i].Est_Nome.replace(" ", "").toLowerCase() +
                            "' value='" +
                            $_CONFIG.LISTA_ESTADO[i].Est_Codigo +
                            "'> " +
                            $_CONFIG.LISTA_ESTADO[i].Est_Nome +
                            "</option>";
                    }
                }

                $("#cliEstado").html(html);
                $("#cliEstadoEdt").html(html);
                $("#cliCupomUF").html(html);
            }
            $("#cliEstado").change(function() {
                var estado = this.value;
                $("#cliCidade").empty();
                if (estado === -1) {
                    $("#cliCidade").attr("disabled", true);
                } else {
                    $.ajax({
                        dataType: "html",
                        url: "/pages/cadastros/buscaCidades.php",
                        method: "POST",
                        data: {
                            estCodigo: estado,
                        },
                        success: function(data) {
                            $("#cliCidade").append(data);
                            $("#cliCidade").attr("disabled", false);
                        },
                    });
                }
            });

            $scope.geraComandaInfo = function() {
                $scope.isereComandaInfoCliente($("#cliPesCodigoInfo").val());
            };

            $scope.isereComandaInfoCliente = function(codigocliente) {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereComandas.php",
                    data: {
                        comObs: "Comanda aberta pela info do Cliente.",
                        comNumCartao: "",
                        comTipoManual: 0,
                        comCliente: codigocliente,
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.result[0].erro == "0") {
                            $("#nomeClienteComanda").html(result.result[0].NomeCliente);
                            $("#idComanda").html(result.result[0].ComCodigo);
                            $("#numComanda").html(result.result[0].ComCodigo);
                            $("#numComandaProd").html(result.result[0].ComCodigo);
                            $("#dataComanda").html(result.result[0].DataComanda);
                            $("#edtComCartao").val(result.result[0].CodigoExterno);
                            $("#codCliente").val(result.result[0].Cliente);
                            if (result.result[0].TPRCodigo == 3) {
                                $("#comandaProfissionalAviso").show();
                            } else {
                                $("#comandaProfissionalAviso").hide();
                            }
                            $("#comanda-modal").modal("show");
                            $("#infoCliente-modal").modal("hide");

                            $scope.buscaPessoaConta();

                            var PromissePagamento = new Promise((resolve, reject) => {
                                resolve($scope.atualizaTipoPagemento());
                            });
                            PromissePagamento.then(() => {
                                $scope.buscaItensComanda(result.result[0].ComCodigo);
                            });
                        } else {}
                        showLoader(false);
                    },
                    error: function(result) {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    },
                });
            };

            $scope.pagaContaCliente = function(tipo, valor) {
                var comanda = 0.0;
                comanda = parseFloat(
                    $("#valorPagamento0")
                    .val()
                    .replace(",", ".")
                    .replace($_CONFIG.MOEDA, "")
                );
                if (tipo == 1) {
                    $("#valorPagamento0").val((comanda - valor).toFixed(2));
                } else {
                    var val = valor - comanda;
                    if (val >= 0) {
                        $("#valorPagamento0").val((0).toFixed(2));
                    } else {
                        $("#valorPagamento0").val((comanda - valor).toFixed(2));
                    }
                }
                $("#valorPagamento0").focus();
                $("#valorPagamento0").change();
                $("#btnPagacomanda").prop("disabled", true);
            };

            $scope.rotateImage = function(degree) {
                $("#imagemCutAll").cropper("rotate", degree);
            };

            $scope.saveImageCrop = function() {
                var formimagem = $("#formid").val();
                if ($("#imagemCutAll").cropper("getData").width <= 800) {
                    logoEmpresa = $("#imagemCutAll")
                        .cropper("getCroppedCanvas")
                        .toDataURL();
                    $("#imagemCutAll")
                        .cropper("getCroppedCanvas")
                        .toBlob(function(blob) {
                            mBlob = blob;
                            if (
                                formimagem == "#formAlteraImagem" ||
                                formimagem == "#formInsereImagem"
                            ) {
                                $(formimagem).submit();
                            }
                            mImage = $("#imagemCutAll")
                                .cropper("getCroppedCanvas")
                                .toDataURL("image/jpeg");
                            $("#cortaImagemAll-modal").modal("hide");
                        });
                } else {
                    logoEmpresa = $("#imagemCutAll")
                        .cropper("getCroppedCanvas", {
                            width: 600,
                        })
                        .toDataURL();
                    $("#imagemCutAll")
                        .cropper("getCroppedCanvas", {
                            width: 800,
                        })
                        .toBlob(function(blob) {
                            mBlob = blob;
                            if (
                                formimagem == "#formAlteraImagem" ||
                                formimagem == "#formInsereImagem"
                            ) {
                                $(formimagem).submit();
                            }
                            mImage = $("#imagemCutAll")
                                .cropper("getCroppedCanvas")
                                .toDataURL("image/jpeg");
                            $("#cortaImagemAll-modal").modal("hide");
                        });
                }
            };

            $("#btnCompraSms").click(function() {
                swal({
                        title: "Confirmar :",
                        text: "Deseja realmente ir até a compra de sms, os campos preenchidos serão perdidos",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Sim",
                        cancelButtonText: "Não",
                        closeOnConfirm: true,
                    },
                    function() {
                        var url = location.href;
                        url = url.split("#/")[0];
                        url = url + "#/sms";
                        window.location.href = url;
                        $("#cadastrarmsg-modal").modal("hide");
                    }
                );
            });

            $scope.bucaClienteAssociacao = function() {
                if (hasManyClients) {
                    $("#buscaClienteAssociaComanda").select2({
                        ajax: {
                            url: localStorage.getItem("host"),
                            dataType: "json",
                            delay: 250,
                            data: function(params) {
                                return {
                                    nome: params.term,
                                    metodo: "buscaClientes_v4",
                                    tipo: 5,
                                    id: $_CONFIG.ID,
                                };
                            },
                            processResults: function(data, params) {
                                return {
                                    results: data.result,
                                };
                            },
                            cache: true,
                        },
                        placeholder: "Sem Cadastro",
                        escapeMarkup: function(markup) {
                            return markup;
                        }, // let our custom formatter work
                        minimumInputLength: 3,
                        templateResult: thumbClienteName,
                        templateSelection: formatRepoSelection,
                    });
                } else {
                    $.ajax({
                        dataType: "json",
                        url: localStorage.getItem("host"),
                        data: {
                            metodo: "buscaClientes_v3",
                            id: $_CONFIG.ID,
                            tipo: 2,
                        },
                        success: function(data) {
                            clientesNomesComanda.length = 0;
                            var html =
                                '<option data-usucodigo="" data-imagem="" value="0" selected>Sem Cadastro</option>';
                            for (var i = 0; i < data.result.length; i++) {
                                var codigo = data.result[i].Pes_Codigo;
                                var nome = data.result[i].Pes_Nome;
                                var foto = data.result[i].Paf_Imagem;
                                var usucod = data.result[i].Usu_Codigo;
                                var celular = data.result[i].Paf_Celular;
                                html +=
                                    '<option data-usucodigo="' +
                                    usucod +
                                    '" data-imagem="' +
                                    foto +
                                    '" value="' +
                                    codigo +
                                    '">' +
                                    nome +
                                    " - " +
                                    celular +
                                    "</option>";
                                clientesNomesComanda.push(nome);
                            }
                            $("#buscaClienteAssociaComanda").html(html);
                            if (data.result.length > 800) {
                                $("#buscaClienteAssociaComanda").select2({
                                    minimumInputLength: 3,
                                });
                                $scope.manyClients = true;
                            } else {
                                $("#buscaClienteAssociaComanda").select2();
                                $scope.manyClients = false;
                            }
                            $("#buscaClienteAssociaComanda").val("0").trigger("change");
                        },
                    });
                }
            };

            $scope.associaClienteComanda = function() {
                $("#associaClienteComanda-modal").modal("show");

                $("#associaComCodigo").val($("#idComanda").html());
                $scope.bucaClienteAssociacao();
            };

            $("#formAssociaClienteComanda").submit(function(event) {
                event.preventDefault();
                showLoader(true);
                formAssocia = $(this);
                var dados = new FormData(this);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/atualizaClienteComanda.php",
                    data: dados,
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: function(result) {
                        if (result.result[0].erro == "0") {
                            toastr.success(result.result[0].resultado, "");
                            formAssocia.each(function() {
                                this.reset();
                            });
                            $scope.atualizaComandaCliente(result.result[0].comcodigo);
                            $("#associaClienteComanda").modal("hide");
                        } else {
                            toastr.error(result.result[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });

                return true;
            });

            $scope.atualizaComandaCliente = function(comcodigo) {
                $.ajax({
                    dataType: "json",
                    method: "POST",
                    url: "pages/cadastros/atualizaComandaCliente.php",
                    data: {
                        comcodigo: comcodigo,
                    },
                    success: function(data) {
                        $("#nomeClienteComanda").html(data.result[0].Cliente);

                        $("#labelTipoClienteComanda").html("Cliente: ");
                        $("#iconInfoCliente").show();
                        $("#TprTipoComanda").html(data.result[0].TPR_Codigo);

                        $("#codCliente").val(data.result[0].CodCliente);

                        $("#btnAssociaClienteComanda").hide();
                        $("#associaClienteComanda-modal").modal("hide");
                        $scope.buscaItensComanda(comcodigo);
                        $scope.buscaPessoaConta();
                        if (location.hash == "#/comandasabertas") {
                            $rootScope.$emit("atualizaDadosComanda", {});
                        }
                        if (location.hash == "#/filaDeEspera") {
                            $rootScope.$emit("atualizaDadosFila", {});
                        }
                        if (location.hash == "#/agenda") {
                            $rootScope.$emit("BuscaAgenda", {});
                        }
                    },
                });
            };
            $("#infoMensagemStatusCliente").click(function() {
                $(this).attr(
                    "data-content",
                    '<div><i class="fa fa-circle text-success"></i> <i class="fa fa-arrow-right"></i>&nbspTem Usuário e está conectado no app; </div><br><div><i class="fa fa-circle text-danger"></i> <i class="fa fa-arrow-right"></i>&nbspTem usuário do app e não está conectado;</div><br><div>Sem ícone <i class="fa fa-arrow-right"></i>&nbspNão tem Usuário do App ou não baixou o app</div>'
                );
                $(this).popover("show");
            });

            $scope.infoshowGeraToken = function() {
                $("#geratokenCliente-modal").modal("show");
                $("#infoCliente-modal").modal("hide");
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaListaPontoItens.php",
                    method: "POST",
                    success: function(data) {
                        if (data.buscaListaPontosItens.length > 0) {
                            var html = "<option value=''>Nenhum Selecionado</option>";
                            for (var i = 0; i < data.buscaListaPontosItens.length; i++) {
                                html +=
                                    "<option value='" +
                                    data.buscaListaPontosItens[i].PIt_Codigo +
                                    "'> " +
                                    data.buscaListaPontosItens[i].Descricao +
                                    "</option>";
                            }
                        }
                        $("#itemTokemInfo").html(html);
                    },
                });
            };

            $scope.resgataTokenInfo = function() {
                showLoader(true);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaListaPontosResgate.php",
                    data: {
                        pitcodigo: $("#itemTokemInfo").val(),
                        pescodigo: $("#pesCodigoTokenInfo").val(),
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.data[0].erro == "0") {
                            $("#resultadoTokenInfo").html(result.data[0].resultado);
                            $("#tokenIdInfo").html(result.data[0].token);
                            $("#tokenIdinfocliinput").val(result.data[0].token);
                            $("#geratokenCliente-modal").modal("hide");
                            $("#showTokenClienteInfo-modal").modal("show");
                        } else {
                            toastr.error(result.data[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error($_CONFIG.language.errors.falha_conexao);
                        showLoader(false);
                    },
                });
            };

            $scope.goToAnamnese = function() {
                $state.go("anamnese", {
                    codigo: $("#cliPesCodigoInfo").val(),
                });
                $("#infoCliente-modal").modal("hide");
            };

            $scope.buscaInfoCombos();
            $scope.buscaSaldoSMSMsg();

            $scope.imprimirProntuario = function() {
                PrintElem("Prontuário", "#prontuarioImprimir");
            };

            function PrintElem(title, elem) {
                Popup(title, $(elem).html());
            }

            function Popup(title, data) {
                var mywindow = window.open(
                    "",
                    "Imprimir prontuário",
                    "height=600,width=800"
                );
                mywindow.document.write("<html><head><title>" + title + "</title>");
                mywindow.document.write(
                    '<link rel="stylesheet" href="/css/print.css"/>'
                );
                mywindow.document.write(
                    '<link rel="stylesheet" href="css/bootstrap.css"/>'
                );
                mywindow.document.write(
                    '</head><body onload="window.print();window.close();">'
                );
                mywindow.document.write(data);
                mywindow.document.write("</body></html>");
                mywindow.document.close();
                mywindow.focus();
                return true;
            }

            $scope.buscaTipoCategoriaGeral = function() {
                var tipccategoria = "";
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaTipoCategoria.php",
                    dataType: "json",

                    success: function(result) {
                        tipccategoria += "<option value=''>Nenhuma</option>";
                        for (var i = 0; i < result.result.length; i++) {
                            tipccategoria +=
                                "<option value='" +
                                result.result[i].TCT_Codigo +
                                "'>" +
                                result.result[i].TCT_Descricao +
                                "</option>";
                        }
                        $("#tipocategoria").html(tipccategoria);
                    },
                    error: function(result) {
                        tipccategoria +=
                            "<option value=''>Nenhuma opção disponível</option>";
                        $("#tipocategoria").html(tipccategoria);
                    },
                });
            };
            $scope.buscaTipoCategoriaGeral();

            $scope.buscaCategoriaGeral = function(tipo, elem) {
                var htmlcategoria = "";
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaCategoria.php",
                    dataType: "json",
                    data: {
                        tipo: tipo,
                    },

                    success: function(result) {
                        htmlcategoria += "<option value=''>Nenhuma</option>";
                        for (var i = 0; i < result.data.length; i++) {
                            htmlcategoria +=
                                "<option value=" +
                                result.data[i].TCa_Codigo +
                                ">" +
                                result.data[i].TCa_Descricao +
                                "</option>";
                        }
                        htmlcategoria += "<br>";

                        $("#" + elem).html(htmlcategoria);
                    },
                    error: function(result) {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    },
                });
            };

            $scope.buscaCategoriaProfissionalGeral = function() {
                $("#spCategoria").multiselect("destroy");
                var categorias = "";
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaCategoria.php",
                    dataType: "json",
                    data: {
                        tipo: 1,
                    },

                    success: function(result) {
                        for (var i = 0; i < result.data.length; i++) {
                            categorias +=
                                "<option value='" +
                                result.data[i].TCa_Codigo +
                                "'>" +
                                result.data[i].TCa_Descricao +
                                "</option>";
                        }
                        $("#spCategoria").html(categorias);
                        $("#spCategoria").multiselect({
                            buttonText: function(options, select) {
                                if (options.length === 0) {
                                    return "Categorias";
                                } else if (options.length > 3) {
                                    return $_CONFIG.language.mais_categorias_selecionada;
                                } else {
                                    var labels = [];
                                    options.each(function() {
                                        if ($(this).attr("label") !== undefined) {
                                            labels.push($(this).attr("label"));
                                        } else {
                                            labels.push($(this).html());
                                        }
                                    });
                                    return labels.join(", ") + "";
                                }
                            },
                            buttonWidth: "100%",
                        });
                    },
                    error: function(result) {
                        $("#spCategoria").multiselect();
                    },
                });
            };

            $scope.cadastrarCategoriaGeral = function(tipo) {
                $("#cadastrarcategoria-modal").modal();
                $("#tipocategoria").val(tipo);
            };

            $("#formCategoria").submit(function(event) {
                event.preventDefault();
                formCategoria = $(this);
                dataForm = new FormData(this);
                showLoader(true);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereCategoria.php",
                    data: dataForm,
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: function(result) {
                        if (result.data[0].erro == "0") {
                            if (location.hash == "#/categorias") {
                                $rootScope.$emit("atualizaDadosCategoria", {});
                            }
                            if (location.hash == "#/servicos") {
                                $scope.buscaCategoriaGeral(2, "serCategoria");
                                $scope.buscaCategoriaGeral(2, "serCategoriaEdt");
                                setTimeout(function() {
                                    $("#serCategoria").val(result.data[0].codigocategoria);
                                    $("#serCategoriaEdt").val(result.data[0].codigocategoria);
                                }, 1000);
                            }
                            if (location.hash == "#/estoque") {
                                $scope.buscaCategoriaGeral(3, "proCategoria");
                                $scope.buscaCategoriaGeral(3, "proCategoriaEdt");
                                setTimeout(function() {
                                    $("#proCategoria").val(result.data[0].codigocategoria);
                                    $("#proCategoriaEdt").val(result.data[0].codigocategoria);
                                }, 1000);
                            }
                            if (location.hash == "#/profissionais") {
                                $scope.buscaCategoriaProfissionalGeral();
                            }
                            toastr.success(result.data[0].resultado);
                            $("#cadastrarcategoria-modal").modal("hide");
                            formCategoria.each(function() {
                                this.reset();
                            });
                        } else {
                            toastr.error(result.data[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });

                return true;
            });

            $scope.verpreviewmensagem = function() {
                if ($scope.sistemaName == "AppBarber") {
                    $("#logopushbarber").show();
                    $("#logopushbeleza").hide();
                } else {
                    $("#logopushbarber").hide();
                    $("#logopushbeleza").show();
                }
                $("#previewmensagem-modal").modal();
            };

            $scope.buscaDocumentoSelect = function() {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaDocumento.php",
                    data: {
                        tipo: 1,
                    },
                    dataType: "json",

                    success: function(result) {
                        var html = "<option value=''> Documento</option>";
                        for (var i = 0; i < result.data.length; i++) {
                            html +=
                                "<option value='" +
                                result.data[i].Doc_Codigo +
                                "'>" +
                                result.data[i].Doc_Titulo +
                                "</option>";
                        }
                        $("#documentoSelect").html(html);
                        $("#documentoSelectProfissional").html(html);
                    },
                    error: function(result) {
                        $("#documentoSelect").html("<option value=''> Documento</option>");
                        $("#documentoSelectProfissional").html(
                            "<option value=''> Documento</option>"
                        );
                        showLoader(false);
                    },
                });
            };

            $scope.novoDocumentoCliente = function(
                cliente,
                profissional,
                agendamento,
                servico,
                assinatura,
                adecodigo
            ) {
                $("#divCorpoDocumento").hide();
                $("#corpoDocumentoCliente").data("wysihtml5").editor.setValue("");
                $("#pesCodigoClienteDocumento").val(cliente);
                $("#pesCodigoProfissionalDocumento").val(profissional);
                $("#ageCodigoDocumento").val(agendamento);
                $("#serCodigoDocumento").val(servico);
                $("#assCodigoDocumento").val(assinatura);
                $("#adeCodigoDocumento").val(adecodigo);
                $scope.buscaDocumentoSelect();

                $("#novodocumentocliente-modal").modal();
            };

            $scope.novoDocumentoProfissional = function(profissional) {
                $("#divCorpoDocumentoProfissional").hide();
                $("#corpoDocumentoProfissional").data("wysihtml5").editor.setValue("");

                $("#codigoProfissionalDocumento").val(profissional);

                $scope.buscaDocumentoSelect();

                $("#novodocumentoprofissional-modal").modal();
            };

            $scope.listDocumento = function(
                cliente,
                profissional,
                agendamento,
                servico,
                assinatura,
                adecodigo
            ) {
                if (typeof tabelaDocumentosPront != "undefined") {
                    $("#tabelaListaDocumentos tbody").unbind("click");
                    tabelaDocumentosPront.destroy();
                }
                tabelaDocumentosPront = $("#tabelaListaDocumentos").DataTable({
                    dom: 'T<"clear">lfrtip',
                    ajax: {
                        url: "/pages/cadastros/buscaPessoaDocumento.php",
                        method: "POST",
                        data: function(d) {
                            d.tipo = 2;
                            d.cliente = cliente;
                            d.adecodigo = adecodigo;
                        },
                    },
                    scrollX: isPortrait,
                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,
                    columns: [{
                            data: "Doc_Titulo",
                        },
                        {
                            data: "PDo_Dat_Cadastro",
                            type: "moment-DD/MM/YYYY hh:mm",
                        },
                        {
                            class: "viewDocumento",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-success btn-xs"><i class="fa fa-search"></i></button>',
                        },
                        {
                            class: "printDocumento",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn bg-teal-dark btn-xs"><i class="fa fa-print"></i></button>',
                        },
                        {
                            class: "pdfDocumento",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn bg-teal-dark btn-xs"><i class="fa fa-file-pdf-o"></i></button>',
                        },
                        {
                            class: "removeDocumentoProntuario",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>',
                        },
                    ],
                    order: [1, "asc"],
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                });

                $("#tabelaListaDocumentos tbody").on(
                    "click",
                    "td.viewDocumento",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaDocumentosPront.row(tr);
                        var data = row.data();
                        $("#tituloDocumentoView").html(data.Doc_Titulo);
                        $("#corpoDocumentoView").html(data.PDo_Corpo);
                        $("#viewdocumentocliente-modal").modal();
                    }
                );

                $("#tabelaListaDocumentos tbody").on(
                    "click",
                    "td.printDocumento",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaDocumentosPront.row(tr);
                        var data = row.data();
                        Popup(data.Doc_Titulo, data.PDo_Corpo);
                    }
                );
                $("#tabelaListaDocumentos tbody").on(
                    "click",
                    "td.pdfDocumento",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaDocumentosPront.row(tr);
                        var data = row.data();
                        $scope.salvaPdfHtml(data.Doc_Titulo, data.PDo_Corpo);
                    }
                );

                $("#tabelaListaDocumentos tbody").on(
                    "click",
                    "td.removeDocumentoProntuario",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaDocumentosPront.row(tr);
                        var data = row.data();
                        swal({
                                title: "Excluir",
                                text: "Deseja realmente excluir este documento?",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "Sim",
                                cancelButtonText: "Não",
                            },
                            function(Confirmou) {
                                if (Confirmou) {
                                    $.ajax({
                                        type: "POST",
                                        url: "/pages/cadastros/removePessoaDocumento.php",
                                        data: {
                                            pdocodigo: data.PDo_Codigo,
                                        },
                                        dataType: "json",
                                        success: function(result) {
                                            tabelaDocumentosPront.ajax.reload();
                                            toastr.success(result.data[0].resultado);
                                        },
                                        error: function(result) {},
                                    });
                                }
                            }
                        );
                    }
                );

                var buttonnovodocumento =
                    '<button id="btnNovoDocumentoProntuario" class="btn bg-teal-dark" ng-click="novoDocumentoCliente(' +
                    cliente +
                    "," +
                    profissional +
                    "," +
                    agendamento +
                    "," +
                    servico +
                    "," +
                    assinatura +
                    "," +
                    adecodigo +
                    ')"><i class="fa fa-plus"></i> Documento</button>';
                $("#divBtnNovoDocumento").html(buttonnovodocumento);
                $("#listaDocumentos-modal").modal();
                $compile($("#divBtnNovoDocumento"))($scope);
            };

            $("#documentoSelect").change(function() {
                if ($(this).val() != "") {
                    $("#divCorpoDocumento").show();
                    $("#btnPrintDocumento").unbind("click");
                    $("#btndpfDocumento").unbind("click");
                    $(this).prop("disabled", true);
                    $("#corpoDocumentoCliente").data("wysihtml5").editor.setValue("");
                    showLoader(true);

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaDocumento.php",
                        data: {
                            tipo: 2,
                            doccodigo: $(this).val(),
                        },
                        dataType: "json",

                        success: function(result) {
                            if (result.data[0] != undefined && result.data[0] != "") {
                                setTimeout(function() {
                                    $("#documentoSelect").prop("disabled", false);
                                }, 1500);

                                $.ajax({
                                    type: "POST",
                                    url: "/pages/cadastros/replaceDocumento.php",
                                    data: {
                                        pesCodigoCliente: $("#pesCodigoClienteDocumento").val(),
                                        corpoDocumento: result.data[0].Doc_Corpo,
                                        pesCodigoProfissional: $(
                                            "#pesCodigoProfissionalDocumento"
                                        ).val(),
                                        ageCodigo: $("#ageCodigoDocumento").val(),
                                        serCodigo: $("#serCodigoDocumento").val(),
                                        assCodigo: $("#assCodigoDocumento").val(),
                                    },
                                    dataType: "json",

                                    success: function(result) {
                                        $("#corpoDocumentoCliente")
                                            .data("wysihtml5")
                                            .editor.setValue(result.data);
                                        $compile($("#btnPrintDocumento"))($scope);
                                        $compile($("#btndpfDocumento"))($scope);
                                        showLoader(false);
                                    },

                                    error: function(result) {
                                        showLoader(false);

                                        toastr.error("Falha na conexão.");
                                    },
                                });
                            } else {
                                $("#corpoDocumentoCliente")
                                    .data("wysihtml5")
                                    .editor.setValue("");
                            }
                        },
                        error: function(result) {
                            $("#corpoDocumentoCliente").data("wysihtml5").editor.setValue("");
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                } else {
                    $("#divCorpoDocumento").hide();
                    $("#corpoDocumentoCliente").data("wysihtml5").editor.setValue("");
                }
            });

            $("#documentoSelectProfissional").change(function() {
                if ($(this).val() != "") {
                    $("#divCorpoDocumentoProfissional").show();
                    $(this).prop("disabled", true);
                    $("#corpoDocumentoProfissional")
                        .data("wysihtml5")
                        .editor.setValue("");
                    $("#btnPrintDocumentoProfissional").unbind("click");
                    $("#btndpfDocumentoProfissional").unbind("click");
                    showLoader(true);

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaDocumento.php",
                        data: {
                            tipo: 2,
                            doccodigo: $(this).val(),
                        },
                        dataType: "json",

                        success: function(result) {
                            if (result.data[0] != undefined && result.data[0] != "") {
                                setTimeout(function() {
                                    $("#documentoSelectProfissional").prop("disabled", false);
                                }, 1500);

                                $.ajax({
                                    type: "POST",
                                    url: "/pages/cadastros/replaceDocumento.php",
                                    data: {
                                        pesCodigoCliente: "",
                                        corpoDocumento: result.data[0].Doc_Corpo,
                                        pesCodigoProfissional: $(
                                            "#codigoProfissionalDocumento"
                                        ).val(),
                                        ageCodigo: "",
                                        serCodigo: "",
                                        assCodigo: "",
                                    },
                                    dataType: "json",

                                    success: function(result) {
                                        $("#corpoDocumentoProfissional")
                                            .data("wysihtml5")
                                            .editor.setValue(result.data);
                                        $compile($("#btnPrintDocumentoProfissional"))($scope);
                                        $compile($("#btndpfDocumentoProfissional"))($scope);
                                        showLoader(false);
                                    },

                                    error: function(result) {
                                        showLoader(false);

                                        toastr.error("Falha na conexão.");
                                    },
                                });
                            } else {
                                $("#corpoDocumentoCliente")
                                    .data("wysihtml5")
                                    .editor.setValue("");
                            }
                        },
                        error: function(result) {
                            $("#corpoDocumentoCliente").data("wysihtml5").editor.setValue("");
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                } else {
                    $("#divCorpoDocumento").hide();
                    $("#corpoDocumentoCliente").data("wysihtml5").editor.setValue("");
                }
            });

            $scope.printDocumento = function() {
                Popup("Documento", $("#corpoDocumentoCliente").val());
            };

            $scope.pdfDocumento = function() {
                $scope.salvaPdfHtml("Documento", $("#corpoDocumentoCliente").val());
            };

            $scope.printDocumentoProfissional = function() {
                Popup("Documento", $("#corpoDocumentoProfissional").val());
            };

            $scope.pdfDocumentoProfissional = function() {
                $scope.salvaPdfHtml(
                    "Documento",
                    $("#corpoDocumentoProfissional").val()
                );
            };

            $scope.printCatalogoProduto = function() {
                Popup("Produtos", $("#catProduto").html());
            };

            $scope.printCatalogoServico = function() {
                Popup("Serviços", $("#catServico").html());
            };

            $("#formCliDocumento").submit(function(event) {
                event.preventDefault();
                formDocumento = $(this);
                showLoader(true);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/inserePessoaDocumento.php",
                    data: new FormData(this),
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: function(result) {
                        if (result.data.erro == undefined) {
                            toastr.success(result.data[0].resultado);
                            $("#novodocumentocliente-modal").modal("hide");
                            showLoader(false);
                            tabelaDocumentosPront.ajax.reload();
                        } else {
                            toastr.error(result.data.resultado);
                            showLoader(false);
                        }
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });

                return true;
            });

            $("#formProDocumento").submit(function(event) {
                event.preventDefault();
                formDocumento = $(this);
                showLoader(true);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/inserePessoaDocumento.php",
                    data: {
                        pesCodigoClienteDocumento: $("#codigoProfissionalDocumento").val(),
                        documentoSelect: $("#documentoSelectProfissional").val(),
                        corpoDocumentoCliente: $("#corpoDocumentoProfissional").val(),
                        adeCodigoDocumento: "",
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.data.erro == undefined) {
                            toastr.success(result.data[0].resultado);
                            $("#novodocumentoprofissional-modal").modal("hide");
                            showLoader(false);
                        } else {
                            toastr.error(result.data.resultado);
                            showLoader(false);
                        }
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });

                return true;
            });

            $("#btnImprimeDocumento").click(function() {
                var titulo = $("#tituloDocumentoView").html();
                var corpo = $("#corpoDocumentoView").html();
                var assinatura = $("#assinaturaDocumentoView").html();

                var conteudoCompleto = corpo;
                if (assinatura && assinatura.trim() !== '') {
                    conteudoCompleto += '<div style="margin-top: 20px; text-align: center;">' + assinatura + '</div>';
                }

                Popup(titulo, conteudoCompleto);
            });

            $("#btnPDFDocumento").click(function() {
                var titulo = $("#tituloDocumentoView").html();
                var corpo = $("#corpoDocumentoView").html();

                var imgAssinatura = $("#assinaturaDocumentoView").find("img");

                if (imgAssinatura.length > 0 && imgAssinatura.attr("src")) {
                    var img = new Image();
                    img.crossOrigin = "Anonymous";

                    img.onload = function() {
                        var canvas = document.createElement("canvas");
                        canvas.width = img.width;
                        canvas.height = img.height;
                        var ctx = canvas.getContext("2d");
                        ctx.drawImage(img, 0, 0);

                        try {
                            var base64Image = canvas.toDataURL("image/png");
                            var conteudoComImagem = corpo +
                                `<div style="margin-top: 20px; text-align: center;">
                  <label><strong>Assinatura</strong></label><br>
                  <img src="${base64Image}" style="width:300px; border: 1px solid #ddd; padding: 5px;">
                </div>`;
                            $scope.salvaPdfHtml(titulo, conteudoComImagem);
                        } catch (e) {
                            console.error("Erro ao converter imagem para base64:", e);
                            $scope.salvaPdfHtml(titulo, corpo);
                        }
                    };

                    img.onerror = function() {
                        console.error("Erro ao carregar imagem de assinatura");
                        $scope.salvaPdfHtml(titulo, corpo);
                    };

                    img.src = imgAssinatura.attr("src") +
                        (imgAssinatura.attr("src").includes("?") ? "&" : "?") +
                        "t=" + new Date().getTime();
                } else {
                    $scope.salvaPdfHtml(titulo, corpo);
                }
            });

            $scope.salvaPdf = function(titulo, elem) {
                showLoader(true);
                var element = elem;
                var opt = {
                    margin: [15, 15],
                    filename: `${titulo}.pdf`,
                    image: {
                        type: "jpeg",
                        quality: 0.98,
                    },
                    html2canvas: {
                        scale: 2,
                        letterRendering: true,
                    },
                    jsPDF: {
                        unit: "pt",
                        format: "letter",
                        orientation: "portrait",
                    },
                    pagebreak: {
                        mode: ["avoid-all", "css", "legacy"],
                    },
                };

                html2pdf().set(opt).from(element).save();
                showLoader(false);
            };

            $scope.salvaPdfHtml = function(titulo, html) {
                showLoader(true);
                var element = html;
                var opt = {
                    margin: [15, 15],
                    filename: `${titulo}.pdf`,
                    image: {
                        type: "jpeg",
                        quality: 0.98,
                    },
                    html2canvas: {
                        scale: 2,
                        letterRendering: true,
                    },
                    jsPDF: {
                        unit: "pt",
                        format: "letter",
                        orientation: "portrait",
                    },
                    pagebreak: {
                        mode: ["avoid-all", "css", "legacy"],
                    },
                };

                html2pdf().set(opt).from(element).save();
                showLoader(false);
            };

            $scope.addAuxiliar = function(
                codigo,
                sercodigo,
                pescodigoauxiliar,
                porcentagemauxiliar
            ) {
                $.ajax({
                    dataType: "json",
                    url: "pages/cadastros/buscaProfissionalSelect.php",
                    success: function(data) {
                        var profissional = "";
                        profissional +=
                            '<option  value="">' +
                            $_CONFIG.language.profissional +
                            "</option>";
                        for (var i = 0; i < data.profissionais.length; i++) {
                            var codigo = data.profissionais[i].Pes_Codigo;
                            var nome = data.profissionais[i].Pes_Nome;
                            profissional +=
                                '<option  value="' + codigo + '">' + nome + "</option>";
                        }
                        $("#PesAuxiliar").html(profissional);

                        if (pescodigoauxiliar != undefined && pescodigoauxiliar != "") {
                            $("#removeAuxiliarComanda").show();
                            $("#PesAuxiliar").val(pescodigoauxiliar);
                        } else {
                            $("#removeAuxiliarComanda").hide();
                            $("#PesAuxiliar").val("");
                        }
                    },
                });

                if (porcentagemauxiliar != undefined && porcentagemauxiliar != "") {
                    $("#PorAuxiliar").val(porcentagemauxiliar);
                } else {
                    $("#PorAuxiliar").val("");
                    $.ajax({
                        dataType: "json",
                        url: "pages/cadastros/buscaServicoAuxiliar.php",
                        data: {
                            sercodigo: sercodigo,
                        },
                        dataType: "json",
                        success: function(data) {
                            if (data.data.length > 0) {
                                $("#PorAuxiliar")
                                    .val(data.data[0].SAu_Comissao.replace(".", ""))
                                    .keyup();
                            } else {
                                $("#PorAuxiliar").val("");
                            }
                        },
                        error: function(data) {
                            $("#PorAuxiliar").val("");
                        },
                    });
                }
                $("#CitCodigoAuxiliar").val(codigo);
                $("#auxiliar-modal").modal();
            };

            $scope.salvaAuxiliar = function() {
                if ($("#PesAuxiliar").val() == "") {
                    toastr.error("Selecione um profissional");
                } else if ($("#PorAuxiliar").val() == "") {
                    toastr.error("Informe a porcentagem de comissão a ser recebida");
                } else {
                    showLoader(true);
                    $.ajax({
                        dataType: "json",
                        method: "POST",
                        url: "pages/cadastros/atualizaComandaAuxiliar.php",
                        data: {
                            citCodigo: $("#CitCodigoAuxiliar").val(),
                            profissional: $("#PesAuxiliar").val(),
                            comissao: $("#PorAuxiliar").val(),
                            tipo: 1,
                        },
                        success: function(data) {
                            if (data.data[0].erro == "0") {
                                toastr.success(data.data[0].resultado);
                                $scope.buscaItensComanda(data.data[0].comcodigo);
                                $("#auxiliar-modal").modal("hide");
                                showLoader(false);
                            } else {
                                toastr.error(data.data[0].resultado);
                                showLoader(false);
                            }
                        },
                        error: function(data) {
                            toastr.success("Falha de conexão");
                            showLoader(false);
                        },
                    });
                }
            };

            $scope.removeAuxiliar = function() {
                if ($("#CitCodigoAuxiliar").val() == "") {
                    toastr.error("Informe o codigo do item");
                } else {
                    showLoader(true);
                    $.ajax({
                        dataType: "json",
                        method: "POST",
                        url: "pages/cadastros/atualizaComandaAuxiliar.php",
                        data: {
                            citCodigo: $("#CitCodigoAuxiliar").val(),
                            tipo: 2,
                        },
                        success: function(data) {
                            if (data.data[0].erro == "0") {
                                toastr.success(data.data[0].resultado);
                                $scope.buscaItensComanda(data.data[0].comcodigo);
                                $("#auxiliar-modal").modal("hide");
                                showLoader(false);
                            } else {
                                toastr.error(data.data[0].resultado);
                                showLoader(false);
                            }
                        },
                        error: function(data) {
                            toastr.success("Falha de conexão");
                            showLoader(false);
                        },
                    });
                }
            };

            $("#PorAuxiliar").on("change", function() {
                valor = parseFloat($(this).val().replace(",", "."));
                if (valor > 100) {
                    $("#PorAuxiliar").val("100.00");
                } else if ($(this).val() < 0) {
                    $("#PorAuxiliar").val("0");
                }
            });

            $scope.displaydetalhespontos = function() {
                $("#movPontos-modal").modal();
                $scope.buscaClienteMovPonto();
            };

            $scope.buscaClienteMovPonto = function() {
                showLoader(true);
                if (typeof tabelaMovCliPts !== "undefined") {
                    tabelaMovCliPts.destroy();
                }

                $App.formatDateSort();
                tabelaMovCliPts = $("#tabelaMovPtsCliente").DataTable({
                    ajax: {
                        url: "/pages/relatorios/buscaProgramaFidelidade.php",
                        type: "POST",
                        data: function(d) {
                            d.edtDataIni = $("#cliDatInicioPonto").val();
                            d.edtDataFim = $("#cliDatFimPonto").val();
                            d.selTipo = 2;
                            d.selCliente = $("#cliPesCodigoInfo").val();
                        },
                    },
                    dom: "Blfrtip",
                    scrollX: isPortrait,

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,
                    columnDefs: [{
                        targets: [7],
                        visible: false,
                        searchable: false,
                    }, ],
                    buttons: [{
                            extend: "colvis",
                            collectionLayout: "fixed two-column",
                            text: "Colunas",
                        },
                        {
                            extend: "excelHtml5",
                            text: "Excel",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: "true",
                        },
                        {
                            extend: "pdfHtml5",
                            title: sSistema + " - Programa Fidelidade - Movimentações",
                            orientation: "landscape",
                            pageSize: "LEGAL",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: true,
                        },
                        {
                            extend: "print",
                            text: "Imprimir",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: true,
                        },
                    ],
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                    columns: [{
                            data: "Nome",
                        },
                        {
                            data: "DataIni",
                            type: "moment-DD/MM/YYYY hh:mm",
                        },
                        {
                            data: "DataExp",
                            type: "moment-DD/MM/YYYY hh:mm",
                        },
                        {
                            data: "TotalPontos",
                        },
                        {
                            data: "TipoPonto",
                        },
                        {
                            data: "Item",
                        },
                        {
                            data: "Token",
                        },
                        {
                            data: "Observacao",
                        },
                    ],
                });

                showLoader(false);
            };

            $scope.buscaPessoaContaInfoCli = function(cliente) {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaPessoaContaCliente.php",
                    data: {
                        tipo: 1,
                        pescodigo: cliente,
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.data[0] != undefined) {
                            if (result.data[0].erro == undefined) {
                                if (result.data[0].PCo_Saldo != undefined) {
                                    $("#saldoContaCli").html(result.data[0].PCo_Saldo);
                                } else {
                                    $("#saldoContaCli").html($_CONFIG.MOEDA + " 0,00");
                                }
                            } else {
                                $("#saldoContaCli").html("");
                            }
                        } else {
                            $("#saldoContaCli").html($_CONFIG.MOEDA + " 0,00");
                        }
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });
            };

            $scope.showDetailsContaCliente = function() {
                if (typeof tabelaClienteContaInfo != "undefined") {
                    tabelaClienteContaInfo.destroy();
                }
                $App.formatDateSort();
                tabelaClienteContaInfo = $("#tbContaClienteInfo").DataTable({
                    ajax: {
                        url: "/pages/cadastros/buscaContaClientes.php",
                        method: "POST",
                        data: function(d) {
                            d.pescodigo = $("#cliPesCodigoInfo").val();
                        },
                    },
                    fnRowCallback: function(nRow, aData) {
                        var id = aData.PCo_Tipo; // ID is returned by the server as part of the data
                        var Comanda = aData.Com_Codigo; // ID is returned by the server as part of the data
                        var $nRow = $(nRow); // cache the row wrapped up in jQuery
                        if (id == "D") {
                            $nRow
                                .map(function() {
                                    return $(this).css({
                                        color: "#F44336",
                                    });
                                })
                                .get();
                        } else {
                            $nRow
                                .map(function() {
                                    return $(this).css({
                                        color: "#1B5E20",
                                    });
                                })
                                .get();
                        }

                        if (aData.Saldo == null) {
                            $("#valorTotalContaCli").html($_CONFIG.MOEDA + "0,00");
                        } else {
                            $("#valorTotalContaCli").html(aData.Saldo);
                        }

                        switch (Comanda) {
                            case "":
                                $nRow.map(function() {}).get();
                                nRow.children[4].children[0].disabled = "true";
                                nRow.children[4].children[0].className =
                                    "btn btn-secondary btn-xs";
                                nRow.children[4].className = "";
                                break;
                            default:
                                $nRow.map(function() {}).get();

                                break;
                        }

                        return nRow;
                    },
                    dom: "Bfrtip",
                    buttons: [{
                            extend: "excelHtml5",
                            text: "Excel",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: "true",
                        },
                        {
                            extend: "pdfHtml5",
                            title: $Options.sistema + " - Conta Cliente",
                            orientation: "landscape",
                            pageSize: "LEGAL",
                            exportOptions: {
                                columns: ":visible",
                            },
                            footer: true,
                        },
                    ],
                    initComplete: function() {
                        var vlrTotal = this.fnGetData(0);

                        $("#lblSaldoContaCli").show();
                        $("#btnCreditoContaCli").show();
                        $("#btnDebitoContaCli").show();

                        if (vlrTotal == null) {
                            $("#valorTotalContaCli").html("0,00");
                        } else {
                            $("#valorTotalContaCli").html(vlrTotal.Saldo);
                        }

                        resizeContent();
                    },

                    stateSaveCallback: function(settings, data) {
                        data.order = [];
                        localStorage.setItem(
                            "DataTables_" + settings.sInstance,
                            JSON.stringify(data)
                        );
                    },
                    stateLoadCallback: function(settings) {
                        return JSON.parse(
                            localStorage.getItem("DataTables_" + settings.sInstance)
                        );
                    },
                    stateSave: true,
                    columnDefs: [{
                        targets: [0, 1, 6, 7, 8, 9, 11, 12],
                        visible: false,
                        searchable: false,
                    }, ],
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                    columns: [{
                            data: "DT_RowId",
                        },
                        {
                            data: "PCo_Codigo",
                        },
                        {
                            data: "PCo_Descricao",
                        },
                        {
                            data: "PCo_Dat_Lancamento",
                            type: "moment-DD/MM/YYYY",
                        },
                        {
                            data: "PCo_Valor",
                        },
                        {
                            data: "PCo_TipoMov",
                        },
                        {
                            data: "Saldo",
                        },
                        {
                            data: "PCo_Tipo",
                        },
                        {
                            data: "PCo_Vlr_Real",
                        },
                        {
                            data: "Com_Codigo",
                        },
                        {
                            class: "abrecomanda-control",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-success btn-xs " id="abreComandaContaCliente">Ver Comanda</button>',
                        },
                        {
                            data: "Pes_Nome",
                        },
                        {
                            data: "Com_Dat_Cadastro",
                        },
                        {
                            data: "PCa_Faturado",
                        },
                        {
                            data: "DataFaturado",
                        },
                    ],
                    destroy: true,
                });
                $("#tbContaClienteInfo tbody").on(
                    "click",
                    "td.abrecomanda-control",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelaClienteContaInfo.row(tr);
                        var data = row.data();
                        $scope.buscaItensComandaVer(data.Com_Codigo);
                        $("#nomeClienteComandaVer").html(data.Pes_Nome);
                        $("#idComandaVer").html(data.Com_Codigo);
                        $("#dataComandaVer").html(data.Com_Dat_Cadastro);
                        $("#vercomanda-modal").modal("show");
                    }
                );

                var imagem = "../../img/nopicture.png";

                if ($("#cliImagemInfo").prop("src") != "") {
                    $("#cliImagemInfoConta").prop("src", $("#cliImagemInfo").prop("src"));
                } else {
                    $("#cliImagemInfoConta").prop("src", imagem);
                }
                $("#cliNomeInfoConta").html($("#cliNomeInfo").html());
                $("#cliEmailInfoConta").html($("#cliEmailInfo").html());
                $("#cliTelefoneInfoConta").html($("#cliCelularInfo").html());
                $scope.insereCaixaContaCli();
                $("#clienteContaDetalhes-modal").modal();
            };

            $scope.insereCaixaContaCli = function() {
                $(".divNumParcelasModal").hide();
                $("#parceladoContaCliModal").val(0);
                if ($("#insereCaixaContaCli").val() == 1) {
                    $("#divPagamentoContaCli").show();
                    $(".divParceladoModal").show();
                    $scope.TipoPagamentoContaCliente();
                } else {
                    $(".divParceladoModal").hide();
                    $("#divPagamentoContaCli").hide();
                }
            };
            $("#insereCaixaContaCli").change(() => {
                $scope.insereCaixaContaCli();
            });

            $scope.TipoPagamentoContaCliente = function() {
                var tipopagamentocc = "";
                $scope.tiposPagamento = $_CONFIG.LISTA_PAGAMAENTO;
                tipopagamentocc +=
                    "<option value='' selected>Tipo de Pagamento</option>";
                for (var i = 0; i < $scope.tiposPagamento.length; i++) {
                    tipopagamentocc +=
                        "<option value='" +
                        $scope.tiposPagamento[i].TPa_Codigo +
                        "'>" +
                        $scope.tiposPagamento[i].TPa_Descricao +
                        "</option>";
                }

                $("#tipoPagamentoContaCli").html(tipopagamentocc);
                $("#tipoBandeiraContaCli").html(
                    "<option value=''>Sem Bandeira</option>"
                );
                $("#tipoBandeiraContaCli").prop("disabled", true);
            };

            $("#tipoPagamentoContaCli").change(function() {
                if ($("#tipoPagamentoContaCli").val() == "") {
                    $("#tipoBandeiraContaCli").html(
                        "<option value=''>Sem Bandeira</option>"
                    );
                    $("#tipoBandeiraContaCli").prop("disabled", true);
                } else {
                    $("#tipoBandeiraContaCli").prop("disabled", false);
                    $scope.buscaBandeiraContaCliente();
                }
            });

            $scope.buscaBandeiraContaCliente = function() {
                var tipobandeiracc = "";
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaTipoBandeira.php",
                    data: {
                        tipopagamento: $("#tipoPagamentoContaCli option:selected").val(),
                    },
                    dataType: "json",
                    success: function(result) {
                        $("#tipoBandeiraContaCli").val("");
                        if ($("#tipoPagamentoContaCli option:selected").val() == "") {
                            tipobandeiracc += "<option value=''>Sem Bandeira</option>";
                        }

                        if (result.data.length == 0) {
                            tipobandeiracc += "<option value=''>Sem Bandeira</option>";
                            $("#tipoBandeiraContaCli").prop("disabled", true);
                        } else {
                            for (var i = 0; i < result.data.length; i++) {
                                tipobandeiracc +=
                                    "<option value='" +
                                    result.data[i].TBa_Codigo +
                                    "'>" +
                                    result.data[i].TBa_Descricao +
                                    "</option>";
                            }
                            $("#tipoBandeiraContaCli").prop("disabled", false);
                        }

                        $("#tipoBandeiraContaCli").html(tipobandeiracc);
                    },
                    error: function(result) {},
                });
            };

            $scope.verificaSenhaContaCli = function() {
                if ($("#senhaInserecaixacontacli").html() == "1") {
                    if ($("#insereCaixaContaCli").val() != 1) {
                        var statesdemo = {
                            state0: {
                                title: "Insira a senha ",
                                html: '<input class="form-control" type="password" name="password" id="password" value=""></label>',
                                buttons: {
                                    Ok: 1,
                                },
                                zIndex: 99999,
                                submit: function(e, v, m, f) {
                                    e.preventDefault();
                                    if (f.password != null) {
                                        $.ajax({
                                            dataType: "json",
                                            method: "POST",
                                            url: "/php/verificaSenhaCaixa.php",
                                            data: {
                                                password: f.password,
                                            },
                                            success: function(data) {
                                                if (data.erro == "0") {
                                                    $scope.insereContaClienteCredito(0);
                                                    $.prompt.close();
                                                } else {
                                                    toastr.error(data.resultado);
                                                }
                                            },
                                            error: function(data) {
                                                toastr.error("Falha de conexão");
                                            },
                                        });
                                    }
                                },
                            },
                        };

                        $.prompt(statesdemo);
                    } else {
                        if ($("#tipoPagamentoContaCli").val() != "") {
                            $scope.insereContaClienteCredito(1);
                        } else {
                            toastr.error("Insira uma forma de pagamento");
                        }
                    }
                } else {
                    if ($("#insereCaixaContaCli").val() == 1) {
                        $scope.insereContaClienteCredito(1);
                    } else {
                        $scope.insereContaClienteCredito(0);
                    }
                }
            };

            $scope.insereContaClienteCredito = function(inserecaixa) {
                if ($("#cliPesCodigoInfo").val() == "") {
                    toastr.error("Informe um Cliente.");
                } else if ($("#ContaCliDescEnt").val() == "") {
                    toastr.error("Informe a Descrição.");
                } else if ($("#ContaCliValorEnt").val() == "") {
                    toastr.error("Informe o Valor.");
                } else if ($("#ContaCliDataEnt").val() == "") {
                    toastr.error("Informe a data.");
                } else {
                    showLoader(true);
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/insereContaCliente_v6.php",
                        dataType: "json",
                        data: {
                            valor: $("#ContaCliValorEnt").maskMoney("unmasked")[0],
                            tipo: 1,
                            pescodigocliente: $("#cliPesCodigoInfo").val(),
                            inserecaixa: inserecaixa,
                            tpacodigo: $("#tipoPagamentoContaCli").val(),
                            tbacodigo: $("#tipoBandeiraContaCli").val(),
                            datalancamento: $("#ContaCliDataEnt").val(),
                            descricao: $("#ContaCliDescEnt").val(),
                            parceladoContaCli: $("#parceladoContaCliModal").val(),
                            numParcelasContaCli: $("#numParcelasContaCliModal").val(),
                            periodicidadeContaCli: $("#periodicidadeContaCliModal").val(),
                        },
                        success: function(result) {
                            if (result.data[0].erro == "0") {
                                toastr.success(result.data[0].resultado);
                                $("#creditocontacli-modal").modal("hide");
                                $("#insereCaixaContaCli").val(0);
                                $scope.insereCaixaContaCli();
                                $("#ContaCliDescEnt").val("");
                                $("#ContaCliValorEnt").val(0);
                                $("#ContaCliValorEnt").focus();
                                $("#tbContaClienteInfo").dataTable().api().ajax.reload();
                                $scope.buscaPessoaContaInfoCli($("#cliPesCodigoInfo").val());
                            } else {
                                toastr.error(result.data[0].resultado);
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                }
            };

            $("#formDebitoContaCliente").submit(function(event) {
                if ($("#cliPesCodigoInfo").val() == "") {
                    toastr.error("Informe um Cliente.");
                    return false;
                } else if ($("#ContaCliDescSai").val() == "") {
                    toastr.error("Informe a Descrição.");
                } else if ($("#ContaCliValorSai").val() == "") {
                    toastr.error("Informe o Valor.");
                } else if ($("#ContaCliDataSai").val() == "") {
                    toastr.error("Informe a data.");
                } else {
                    event.preventDefault();
                    formCadastroDebitoCli = $(this);
                    dataForm = new FormData(this);
                    dataForm.append(
                        "valor",
                        $("#ContaCliValorSai").maskMoney("unmasked")[0]
                    );
                    dataForm.append("tipo", "0");
                    dataForm.append("pescodigo", $("#cliPesCodigoInfo").val());
                    showLoader(true);

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/insereContaCliente.php",
                        data: dataForm,
                        dataType: "json",
                        processData: false,
                        contentType: false,
                        success: function(result) {
                            if (result.result[0].erro == "0") {
                                toastr.success(result.result[0].resultado);
                                $("#debitocontacli-modal").modal("hide");
                                formCadastroDebitoCli.each(function() {
                                    this.reset();
                                });
                                $("#tbContaClienteInfo").dataTable().api().ajax.reload();
                                $scope.buscaPessoaContaInfoCli($("#cliPesCodigoInfo").val());
                            } else {
                                toastr.error(result.result[0].resultado);
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });

                    return true;
                }
            });

            $("#creditocontacli-modal").on("hidden.bs.modal", function(e) {
                $("#ContaCliValorEnt").val("");
                $("#ContaCliDescEnt").val("");

                $(".date.dataInContaCli").datepicker("update", dataabrecomanda);
                $("#insereCaixaContaCli").attr("checked", false);
                $scope.insereCaixaContaCli();
            });

            $("#debitocontacli-modal").on("hidden.bs.modal", function(e) {
                $("#ContaCliValorSai").val("");
                $("#ContaCliDescSai").val("");
                $("#ContaCliDataSai").val("");
            });

            $("#btnEnviaWhatsCliente").click(function() {
                $scope.sendWhatsCliente($("#cliCelularInfo").html());
            });

            $scope.sendWhatsCliente = function(celular) {
                var celular =
                    $_CONFIG.language.mascaras.codigopais.replace("+", "") +
                    celular
                    .replace("(", "")
                    .replace(")", "")
                    .replace(" ", "")
                    .replace("-", "");

                sendWhatsReminder(celular, "");
            };

            $scope.isUndefined = function(value) {
                if (value == undefined) {
                    return "";
                } else {
                    return value;
                }
            };

            $scope.mascaratelefonepaisatual = "";
            var listapais = [];
            if (localStorage.getItem("listaPaisTelefone") != null) {
                listapais = localStorage.getItem("listaPaisTelefone").split(",");
            }

            $scope.geraComboPaisTelefone = function(
                idfield,
                dialcode,
                ddi = undefined
            ) {
                var initpais = "br";

                if (ddi != undefined && ddi != "") {
                    $.ajax({
                        url: "./pages/cadastros/listaPaisDDI.json",
                        dataType: "json",
                        async: false,
                        success: function(data) {
                            initpais = data[ddi];
                        },
                    });
                } else {
                    if ($_CONFIG.PAIS == 2) {
                        initpais = "pt";
                    } else if ($_CONFIG.PAIS == 10) {
                        initpais = "py";
                    } else if ($_CONFIG.PAIS == 11) {
                        initpais = "bo";
                    } else if ($_CONFIG.PAIS == 4) {
                        initpais = "us";
                    } else {
                        initpais = "br";
                    }
                }
                if (foo != undefined) {
                    foo.destroy();
                }

                this[idfield + "selector"] = document.querySelector("#" + idfield);

                if (listapais == "" || listapais == undefined) {
                    listapais = ["br", "pt", "py", "bo", "us"];
                }

                var foo = (this[idfield + "config"] = window.intlTelInput(
                    this[idfield + "selector"], {
                        initialCountry: initpais,
                        preferredCountries: listapais,
                        autoPlaceholder: "aggressive",
                        utilsScript: "./js/utilsintelinput.js",
                    }
                ));

                this[idfield + "selector"].addEventListener(
                    "open:countrydropdown",
                    function() {
                        var mascara = this.placeholder;
                        mascara = mascara
                            .replaceAll("1", "0")
                            .replaceAll("2", "0")
                            .replaceAll("3", "0")
                            .replaceAll("4", "0")
                            .replaceAll("5", "0")
                            .replaceAll("6", "0")
                            .replaceAll("7", "0")
                            .replaceAll("8", "0")
                            .replaceAll("9", "0");
                        $scope.mascaratelefonepaisatual = mascara;
                        $("#" + idfield).unmask();
                    }
                );

                this[idfield + "selector"].addEventListener(
                    "close:countrydropdown",
                    function() {
                        var mascara = this.placeholder;

                        mascara = mascara
                            .replaceAll("1", "0")
                            .replaceAll("2", "0")
                            .replaceAll("3", "0")
                            .replaceAll("4", "0")
                            .replaceAll("5", "0")
                            .replaceAll("6", "0")
                            .replaceAll("7", "0")
                            .replaceAll("8", "0")
                            .replaceAll("9", "0");
                        if (mascara == $scope.mascaratelefonepaisatual) {
                            if ($scope.mascaratelefonepaisatual != "") {
                                $("#" + idfield).mask($scope.mascaratelefonepaisatual);
                                $("#" + dialcode).val(foo.getSelectedCountryData().dialCode);
                            } else {
                                $("#" + idfield).unmask();
                            }
                        }
                    }
                );

                this[idfield + "selector"].addEventListener(
                    "countrychange",
                    function() {
                        var index = listapais.indexOf(foo.getSelectedCountryData().iso2);
                        if (index != -1) {
                            listapais.splice(index, 1);
                        }
                        listapais.push(foo.getSelectedCountryData().iso2);

                        localStorage.setItem("listaPaisTelefone", listapais);
                        var mascara = this.placeholder;

                        mascara = mascara
                            .replaceAll("1", "0")
                            .replaceAll("2", "0")
                            .replaceAll("3", "0")
                            .replaceAll("4", "0")
                            .replaceAll("5", "0")
                            .replaceAll("6", "0")
                            .replaceAll("7", "0")
                            .replaceAll("8", "0")
                            .replaceAll("9", "0");
                        $scope.mascaratelefonepaisatual = mascara;
                        if ($scope.mascaratelefonepaisatual != "") {
                            $("#" + idfield).mask($scope.mascaratelefonepaisatual);
                            $("#" + dialcode).val(foo.getSelectedCountryData().dialCode);
                        } else {
                            $("#" + idfield).unmask();
                        }
                    }
                );

                setTimeout(function() {
                    foo._triggerCountryChange();
                    $("#" + idfield).mask(
                        $("#" + idfield)[0]
                        .placeholder.replaceAll("1", "0")
                        .replaceAll("2", "0")
                        .replaceAll("3", "0")
                        .replaceAll("4", "0")
                        .replaceAll("5", "0")
                        .replaceAll("6", "0")
                        .replaceAll("7", "0")
                        .replaceAll("8", "0")
                        .replaceAll("9", "0")
                    );
                    $("#" + dialcode).val(foo.getSelectedCountryData().dialCode);
                }, 1500);
            };

            $scope.emiteSemCliente = 1;
            $scope.emiteSemCPF = 1;
            $scope.emiteSemEndereco = 1;

            $scope.generateCupom = function(comanda, cliente, geraaproser = 0) {
                $("#cliCupomNome").val("");
                $("#cliCupomNomeProd").val("");
                $("#cliCupomEmail").val("");
                $("#cliCupomEmailProd").val("");
                $("#tipoPessoaNota").val("F");
                $("#tipoPessoaEmitProd").val("F");
                $("#cliCupomCPF").val("");
                $("#cliCupomCPFProd").val("");
                $("#cliCupomCEP").val("");
                $("#cliCupomCEPProd").val("");
                $("#cliCupomUF").val("");
                $("#cliCupomUFProd").val("");
                $("#cliCupomCidade").val("");
                $("#cliCupomCidadeProd").val("");
                $("#cliCupomBairro").val("");
                $("#cliCupomBairroProd").val("");
                $("#cliCupomLogradouro").val("");
                $("#cliCupomLogradouroProd").val("");
                $("#cliCupomNumero").val("");
                $("#cliCupomNumeroProd").val("");
                $("#cliCupomComplemento").val("");
                $("#cliCupomComplementoProd").val("");
                $("#cliCupomTelefoneProd").val("");
                showLoader(true);
                // geraproser
                // 0 - gera pros dois
                // 1 - gera só serviço
                // 2 - gera só produto
                $("#numComanda").html(comanda);
                $("#numComandaProd").html(comanda);
                $("#cliCupomObs").val("");
                $("#valorComissaoDisplay").val("");

                var valorPis = 0;
                var valorInss = 0;
                var valorCofins = 0;
                var valorIr = 0;
                var valorServicos = 0;
                var valorComissao = 0;
                var valorProduto = 0;
                var descricaoServicos = "";
                var citvalorProduto = 0;
                var numeroServico = 0;
                var numeroProduto = 0;
                var erroProduto = 0;
                var obsParceiro = "";
                var obsOriginal = "";

                $("#usaEndereco").val(0).change();
                $("#usaEnderecoProd").val(0).change();

                $.ajax({
                    dataType: "json",
                    method: "POST",
                    url: "/pages/cadastros/buscaComandaItens.php",
                    async: false,
                    data: {
                        codigo: $("#numComanda").html(),
                    },
                    success: function(data) {
                        $scope.itensComandaNota = data.data;
                        for (var a = 0; a < $scope.itensComandaNota.length; a++) {
                            if ($scope.itensComandaNota[a].Ser_Codigo != "") {
                                if ($scope.parnfapacote == 1) {
                                    if ($scope.itensComandaNota[a].PPD_Codigo == "") {
                                        numeroServico++;
                                    }
                                } else {
                                    numeroServico++;
                                }
                            } else if (
                                $scope.itensComandaNota[a].CIt_Venda == 1 &&
                                $scope.itensComandaNota[a].Pro_Gorjeta != 1 &&
                                $scope.itensComandaNota[a].PPD_Codigo == ""
                            ) {
                                numeroProduto++;
                            }
                        }
                    },
                    error: function(data) {
                        $scope.itensComandaNota = "";
                    },
                });

                if (numeroServico > 0 && (geraaproser == 0 || geraaproser == 1)) {
                    $scope.arrayMetadados = [];
                    if ($scope.parnfse == 1) {
                        for (var i = 0; i < $scope.itensComandaNota.length; i++) {
                            if ($scope.itensComandaNota[i].Ser_Codigo != "") {
                                if (i != 0) {
                                    descricaoServicos += "; ";
                                }

                                var citvalor = parseFloat(
                                    $scope.itensComandaNota[i].CIt_Valor.replace(",", ".")
                                );
                                var valorcomissaodesconto = parseFloat(
                                    $scope.itensComandaNota[i].CIt_Comissao_Principal.replace(
                                        ",",
                                        "."
                                    )
                                );

                                if ($scope.parnfapacote == 1) {
                                    if ($scope.itensComandaNota[i].PPD_Codigo != "") {
                                        citvalor = 0;
                                    }
                                }

                                if ($("#empresaCST").val() != "") {
                                    $.ajax({
                                        dataType: "json",
                                        method: "POST",
                                        url: "/pages/cadastros/buscaServicoSerCodigo.php",
                                        async: false,
                                        data: {
                                            sercodigo: $scope.itensComandaNota[i].Ser_Codigo,
                                        },
                                        success: function(result) {
                                            for (var j = 0; j < result.servicos.length; j++) {
                                                valorPis =
                                                    valorPis +
                                                    (citvalor * result.servicos[j].Ser_Pis) / 100;
                                                valorInss =
                                                    valorInss +
                                                    (citvalor * result.servicos[j].Ser_Inss) / 100;
                                                valorCofins =
                                                    valorCofins +
                                                    (citvalor * result.servicos[j].Ser_Cofins) / 100;
                                                valorIr =
                                                    valorIr +
                                                    (citvalor * result.servicos[j].Ser_Ir) / 100;
                                            }
                                            $("#valorPis").html(valorPis);
                                            $("#valorInss").html(valorInss);
                                            $("#valorCofins").html(valorCofins);
                                            $("#valorClss").html(valorClss);
                                            $("#valorIr").html(valorIr);
                                        },
                                        error: function(result) {
                                            console.log(result);
                                        },
                                    });
                                    $("#divCSTEmpresa").show();
                                } else {
                                    $("#divCSTEmpresa").hide();
                                }
                                $("#valorPis").html(valorPis);
                                $("#valorInss").html(valorInss);
                                $("#valorCofins").html(valorCofins);
                                $("#valorClss").html(valorClss);
                                $("#valorIr").html(valorIr);
                                descricaoServicos += `${$scope.itensComandaNota[i].Ser_Descricao}  ${$scope.itensComandaNota[i].CIt_Valor}`;
                                valorServicos = valorServicos + citvalor;
                                console.log($scope.parnfdescontoparceiro);
                                if ($scope.parnfdescontoparceiro == 1) {
                                    var pesCodigoParceiro =
                                        $scope.itensComandaNota[i].Pes_Codigo_Destino;
                                    if (
                                        pesCodigoParceiro != "" &&
                                        pesCodigoParceiro != undefined
                                    ) {
                                        $.ajax({
                                            type: "POST",
                                            url: "/pages/cadastros/buscaPessoav2.php",
                                            async: false,
                                            data: {
                                                tipo: 2,
                                                pescodigo: pesCodigoParceiro,
                                            },
                                            dataType: "json",
                                            success: function(result) {
                                                if (result.data.length != 0) {
                                                    if (
                                                        result.data[0].PAF_CPF != "" &&
                                                        result.data[0].PNa_Codigo != ""
                                                    ) {
                                                        var cnpjParceiro = result.data[0].PAF_CPF;
                                                        $.ajax({
                                                            type: "POST",
                                                            url: "/pages/cadastros/buscaPessoaNaturezav2.php",
                                                            async: false,
                                                            data: {
                                                                tipo: "1",
                                                                pescodigo: pesCodigoParceiro,
                                                            },
                                                            dataType: "json",
                                                            success: function(result) {
                                                                var valorcomissaodesconto = parseFloat(
                                                                    $scope.itensComandaNota[
                                                                        i
                                                                    ].CIt_Comissao_Principal.replace(",", ".")
                                                                );
                                                                valorComissao =
                                                                    valorComissao + valorcomissaodesconto;
                                                                var profissional = "";
                                                                if ($scope.arrayMetadados.length > 0) {
                                                                    for (
                                                                        let j = 0; j < $scope.arrayMetadados.length; j++
                                                                    ) {
                                                                        if (
                                                                            $scope.arrayMetadados[j][0] ==
                                                                            pesCodigoParceiro
                                                                        ) {
                                                                            $scope.arrayMetadados[j][3] =
                                                                                $scope.arrayMetadados[j][3] +
                                                                                parseFloat(
                                                                                    valorcomissaodesconto.toFixed(2)
                                                                                );
                                                                            break;
                                                                        } else {
                                                                            if (
                                                                                j ==
                                                                                $scope.arrayMetadados.length - 1
                                                                            ) {
                                                                                $scope.arrayMetadados.push([
                                                                                    pesCodigoParceiro,
                                                                                    result.data[0].Pes_Nome,
                                                                                    cnpjParceiro,
                                                                                    parseFloat(
                                                                                        valorcomissaodesconto.toFixed(2)
                                                                                    ),
                                                                                    result.data[0].Codigo,
                                                                                ]);
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                } else {
                                                                    $scope.arrayMetadados.push([
                                                                        pesCodigoParceiro,
                                                                        result.data[0].Pes_Nome,
                                                                        cnpjParceiro,
                                                                        parseFloat(
                                                                            valorcomissaodesconto.toFixed(2)
                                                                        ),
                                                                        result.data[0].Codigo,
                                                                    ]);
                                                                }
                                                                if ($scope.nomeProfissionalNota == 1) {
                                                                    profissional = `${result.data[0].Pes_Nome},`;
                                                                }
                                                                if (
                                                                    cnpjParceiro.replace(/\D/g, "").length >= 14
                                                                ) {
                                                                    obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                    2
                                  )} de cota-parte profissional parceiro ${profissional} CNPJ ${cnpjParceiro}, emitida no código: ${
                                    result.data[0].Codigo
                                  };\n`;
                                                                    if (
                                                                        $_CONFIG.CODESTABELECIMENTO == 17169048 ||
                                                                        $_CONFIG.CODESTABELECIMENTO == 90 ||
                                                                        $_CONFIG.CODESTABELECIMENTO == 17774557 ||
                                                                        $_CONFIG.CODESTABELECIMENTO == 20657910
                                                                    ) {
                                                                        descricaoServicos += ` - R$ ${valorcomissaodesconto.toFixed(
                                      2
                                    )} de cota-parte profissional parceiro ${profissional} CNPJ ${cnpjParceiro}, emitida no código: ${
                                      result.data[0].Codigo
                                    }\n`;
                                                                    }
                                                                } else {
                                                                    obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                    2
                                  )} de cota-parte profissional parceiro ${profissional} CPF ${cnpjParceiro}, emitida no código: ${
                                    result.data[0].Codigo
                                  };\n`;
                                                                    if (
                                                                        $_CONFIG.CODESTABELECIMENTO == 17169048 ||
                                                                        $_CONFIG.CODESTABELECIMENTO == 90 ||
                                                                        $_CONFIG.CODESTABELECIMENTO == 17774557 ||
                                                                        $_CONFIG.CODESTABELECIMENTO == 20657910
                                                                    ) {
                                                                        descricaoServicos += ` - R$ ${valorcomissaodesconto.toFixed(
                                      2
                                    )} de cota-parte profissional parceiro ${profissional} CPF ${cnpjParceiro}, emitida no código: ${
                                      result.data[0].Codigo
                                    }\n`;
                                                                    }
                                                                }
                                                            },
                                                            error: function(result) {
                                                                toastr.error("Falha na conexão.");
                                                            },
                                                        });
                                                    }
                                                }
                                            },
                                            error: function(result) {
                                                toastr.error("Falha na conexão.");
                                            },
                                        });
                                    }
                                }
                            }
                        }
                    }
                }

                if (numeroProduto > 0 && (geraaproser == 0 || geraaproser == 2)) {
                    if ($scope.parnfe == 1) {
                        var itensArray = [];
                        var htmlProdNota = "";
                        for (var k = 0; k < $scope.itensComandaNota.length; k++) {
                            if (
                                $scope.itensComandaNota[k].Ser_Codigo == "" &&
                                $scope.itensComandaNota[k].CIt_Venda == 1 &&
                                ($scope.itensComandaNota[k].Pro_Gorjeta == 0 ||
                                    $scope.itensComandaNota[k].Pro_Gorjeta == "")
                            ) {
                                citvalorProduto = parseFloat(
                                    $scope.itensComandaNota[k].CIt_Valor.replace(",", ".")
                                );
                                $.ajax({
                                    dataType: "json",
                                    method: "POST",
                                    url: "/pages/cadastros/buscaProdutosv2.php",
                                    async: false,
                                    data: {
                                        procodigo: $scope.itensComandaNota[k].Pro_Codigo,
                                    },
                                    success: function(result) {
                                        if (
                                            result.data[0].Pro_Cfop == "" ||
                                            result.data[0].Pro_ICMS == "" ||
                                            result.data[0].Pro_Ncm == ""
                                        ) {
                                            erroProduto = 1;
                                            numeroProduto = 0;
                                            k = $scope.itensComandaNota.length;
                                        } else {
                                            htmlProdNota += `<tr>
														<td>
															${result.data[0].Pro_Descricao}
														</td>
														<td>
															${$scope.itensComandaNota[k].CIt_Quantidade}
														</td>
														<td>
															${$scope.itensComandaNota[k].CIt_Vlr_Unitario}
														</td>
														<td>
															<select id="proCfopLista${$scope.itensComandaNota[k].Pro_Codigo}${k}" >
																<option value="${result.data[0].Pro_Cfop}" data-produto="${result.data[0].Pro_Codigo}">${result.data[0].Pro_Cfop}</option>
																<option value="${result.data[0].Pro_Cfop_Secundario}" data-produto="${result.data[0].Pro_Codigo}">${result.data[0].Pro_Cfop_Secundario}</option>
															</select>
														</td>
													</tr>`;

                                            $scope.createChangeCfop.push(
                                                `proCfopLista${$scope.itensComandaNota[k].Pro_Codigo}${k}`
                                            );

                                            if (result.data[0].Pro_CEST == "") {
                                                itensArray.push({
                                                    valorUnitario: $scope.itensComandaNota[k].CIt_Vlr_Unitario,
                                                    quantidade: $scope.itensComandaNota[k].CIt_Quantidade,
                                                    unidadeMedida: "UN",
                                                    cfop: result.data[0].Pro_Cfop,
                                                    descricao: result.data[0].Pro_Descricao,
                                                    ncm: result.data[0].Pro_Ncm,
                                                    codigo: result.data[0].Pro_Codigo,
                                                    ean: result.data[0].Pro_Codigo_Barras,
                                                    eanTributavel: result.data[0].Pro_Codigo_Barras,
                                                    impostos: {
                                                        icms: {
                                                            situacaoTributaria: result.data[0].Pro_ICMS,
                                                            origem: 0,
                                                        },
                                                        pis: {
                                                            situacaoTributaria: result.data[0].Pro_Pis,
                                                        },
                                                        cofins: {
                                                            situacaoTributaria: result.data[0].Pro_Cofins,
                                                        },
                                                    },
                                                });
                                            } else {
                                                itensArray.push({
                                                    valorUnitario: $scope.itensComandaNota[k].CIt_Vlr_Unitario,
                                                    quantidade: $scope.itensComandaNota[k].CIt_Quantidade,
                                                    unidadeMedida: "UN",
                                                    cfop: result.data[0].Pro_Cfop,
                                                    descricao: result.data[0].Pro_Descricao,
                                                    ncm: result.data[0].Pro_Ncm,
                                                    codigo: result.data[0].Pro_Codigo,
                                                    cest: result.data[0].Pro_CEST,
                                                    ean: result.data[0].Pro_Codigo_Barras,
                                                    eanTributavel: result.data[0].Pro_Codigo_Barras,
                                                    impostos: {
                                                        icms: {
                                                            situacaoTributaria: result.data[0].Pro_ICMS,
                                                            origem: 0,
                                                        },
                                                        pis: {
                                                            situacaoTributaria: result.data[0].Pro_Pis,
                                                        },
                                                        cofins: {
                                                            situacaoTributaria: result.data[0].Pro_Cofins,
                                                        },
                                                    },
                                                });
                                            }
                                        }
                                    },
                                    error: function(result) {
                                        console.log(result);
                                    },
                                });
                                valorProduto = valorProduto + citvalorProduto;
                            }
                        }

                        $scope.produtosNota = JSON.stringify(itensArray);
                        $("#tableItensNfProduto").html(htmlProdNota);
                        $("#valorCupomProd").html(valorProduto);
                        $("#valorCupomDisplayProd").val(
                            `${$_CONFIG.MOEDA} ${valorProduto.toFixed(2).replace(",", ".")}`
                        );

                        for (var l = 0; l < $scope.createChangeCfop.length; l++) {
                            $(`#${$scope.createChangeCfop[l]}`).change(function() {
                                var procodigoloop = $(this).get(0)[0].dataset.produto;
                                for (var m = 0; m < itensArray.length; m++) {
                                    if (itensArray[m].codigo == procodigoloop) {
                                        itensArray[m].cfop = this.value;
                                        $scope.produtosNota = JSON.stringify(itensArray);
                                    }
                                }
                            });
                        }
                    }
                }

                var html = "<option value=''>Estado</option>";
                for (var i = 0; i < $_CONFIG.LISTA_ESTADO.length; i++) {
                    html +=
                        "<option value='" +
                        $_CONFIG.LISTA_ESTADO[i].Est_Sigla +
                        "'> " +
                        $_CONFIG.LISTA_ESTADO[i].Est_Sigla +
                        "</option>";
                }

                $("#cliCupomUF").html(html);
                $("#cliCupomUFProd").html(html);
                $("#veiculoTranspoteNotaProd").html(html);
                $("#transporteNotaProd").val("SemOcorrenciaDeTransporte").change();

                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaPessoa.php",
                    data: {
                        tipo: 1,
                    },
                    dataType: "json",
                    success: function(result) {
                        $scope.dadosEmpresaNota = result.buscaPessoa[0];
                        $("#empresaCNAE").val(result.buscaPessoa[0].CNAE);
                        // $("#empresaCodigoNF").val(result.buscaPessoa[0].CodigoNF);
                        //$("#empresaCodigoNFProd").val(result.buscaPessoa[0].CodigoNF);
                        var codigoempresahtml = `<option value="${result.buscaPessoa[0].CodigoNF}">${result.buscaPessoa[0].CNPJ}</option>`;
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaPessoaEnotas.php",
                            dataType: "json",
                            async: false,
                            success: function(result) {
                                if (result.data.length > 0) {
                                    for (var i = 0; i < result.data.length; i++) {
                                        codigoempresahtml += `<option value="${result.data[i].PEn_Codigo_GW}">${result.data[i].PEn_CNPJ}</option>`;
                                    }
                                }
                            },
                            error: function(result) {},
                        });

                        $("#empresaCodigoNF").html(codigoempresahtml);
                        $("#empresaCodigoNFProd").html(codigoempresahtml);
                        $("#cidCodigoEmpresaNotaProduto").val(
                            result.buscaPessoa[0].Cid_Codigo
                        );
                        $scope.emiteSemCliente =
                            result.buscaPessoa[0].Cid_Emissao_SemCliente;
                        $scope.emiteSemCPF = result.buscaPessoa[0].Cid_Emissao_SemCPF;
                        $scope.emiteSemEndereco =
                            result.buscaPessoa[0].Cid_Emissao_SemEndereco;
                        $("#empresaCST").val(result.buscaPessoa[0].CST);

                        if ($scope.emiteSemCliente == 0) {
                            $("#nomeObrigatorio").show();
                            $("#nomeObrigatorioProd").show();
                        } else {
                            $("#nomeObrigatorio").hide();
                            $("#nomeObrigatorioProd").hide();
                        }

                        if ($scope.emiteSemCPF == 0) {
                            $("#CPFObrigatorio").show();
                            $("#CPFObrigatorioProd").show();
                        } else {
                            $("#CPFObrigatorio").hide();
                            $("#CPFObrigatorioProd").hide();
                        }

                        if ($scope.emiteSemEndereco == 0) {
                            $("#EstadoObrigatorio").show();
                            $("#EstadoObrigatorioProd").show();
                            $("#CidadeObrigatorio").show();
                            $("#CidadeObrigatorioProd").show();
                            $("#CepObrigatorio").show();
                            $("#CepObrigatorioProd").show();
                            $("#BairroObrigatorio").show();
                            $("#BairroObrigatorioProd").show();
                            $("#LogradouroObrigatorio").show();
                            $("#LogradouroObrigatorioProd").show();
                            $("#NumeroObrigatorio").show();
                            $("#NumeroObrigatorioProd").show();
                        } else {
                            $("#EstadoObrigatorio").hide();
                            $("#EstadoObrigatorioProd").hide();
                            $("#CidadeObrigatorio").hide();
                            $("#CidadeObrigatorioProd").hide();
                            $("#CepObrigatorio").hide();
                            $("#CepObrigatorioProd").hide();
                            $("#BairroObrigatorio").hide();
                            $("#BairroObrigatorioProd").hide();
                            $("#LogradouroObrigatorio").hide();
                            $("#LogradouroObrigatorioProd").hide();
                            $("#NumeroObrigatorio").hide();
                            $("#NumeroObrigatorioProd").hide();
                        }

                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaPessoaNatureza.php",
                            data: {
                                tipo: "1",
                            },
                            dataType: "json",
                            success: function(result) {
                                var naturezalista = "";
                                for (var i = 0; i < result.data.length; i++) {
                                    if (i == 0) {
                                        naturezalista += `<option selected value='${result.data[i].Nat_Codigo_Externo}' data-nbs='${result.data[i].Nat_NBS}' data-itemlista='${result.data[i].PNa_Codigo_Municipal_Servico}' data-aliquota='${result.data[i].PNa_Aliquota}' data-federal='${result.data[i].Nat_IBPTFederal}' data-estadual='${result.data[i].Nat_IBPTEstadual}' data-municipal='${result.data[i].Nat_IBPTMunicipal}'>${result.data[i].Nat_Descricao}</option>`;
                                        $("#oldValueNatureza").val(
                                            result.data[i].Nat_Codigo_Externo
                                        );
                                    } else {
                                        naturezalista += `<option value='${result.data[i].Nat_Codigo_Externo}'  data-nbs='${result.data[i].Nat_NBS}' data-itemlista='${result.data[i].PNa_Codigo_Municipal_Servico}' data-aliquota='${result.data[i].PNa_Aliquota}' data-federal='${result.data[i].Nat_IBPTFederal}' data-estadual='${result.data[i].Nat_IBPTEstadual}' data-municipal='${result.data[i].Nat_IBPTMunicipal}'>${result.data[i].Nat_Descricao}</option>`;
                                    }
                                }
                                $("#servicoNatureza").unbind("change");
                                $("#servicoNatureza").html(naturezalista);

                                $("#servicoNatureza").on("change", function() {
                                    if (
                                        $("#servicoNatureza option:selected").get(0).dataset
                                        .federal != "" &&
                                        $("#servicoNatureza option:selected").get(0).dataset
                                        .municipal != ""
                                    ) {
                                        var valoritem = parseFloat(
                                            $("#valorCupom")
                                            .html()
                                            .replace($_CONFIG.MOEDA, "")
                                            .replace(",", ".")
                                        );

                                        var federal =
                                            (valoritem *
                                                $("#servicoNatureza option:selected").get(0).dataset
                                                .federal) /
                                            100;
                                        var estadual =
                                            (valoritem *
                                                $("#servicoNatureza option:selected").get(0).dataset
                                                .estadual) /
                                            100;
                                        var municipal =
                                            (valoritem *
                                                $("#servicoNatureza option:selected").get(0).dataset
                                                .municipal) /
                                            100;

                                        var preinfoOrigem = `Valor aproximado dos impostos: \nR$ ${federal.toFixed(
                      2
                    )} Federal, R$ ${estadual.toFixed(
                      2
                    )} Estadual, R$ ${municipal.toFixed(
                      2
                    )} Municipal Fonte: IBPT/FECOMERCIO\n\n`;

                                        $("#cliCupomObs").val(`${preinfoOrigem} ${obsOriginal}`);
                                    }
                                    $("#cliCupomObs").val(
                                        $("#cliCupomObs")
                                        .val()
                                        .replaceAll(
                                            $("#oldValueNatureza").val(),
                                            $("#servicoNatureza option:selected").val()
                                        )
                                    );
                                    $("#oldValueNatureza").val(
                                        $("#servicoNatureza option:selected").val()
                                    );
                                });
                                setTimeout(function() {
                                    $("#servicoNatureza").trigger("change");
                                }, 1000);
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                            },
                        });

                        var infoOrigem = "";
                        var infoProcon = "";
                        $("#valorCupom").html(valorServicos);

                        if ($scope.dadosEmpresaNota.Pes_Codigo == 189886) {
                            infoOrigem =
                                "Fonte: IBPT/FECOMERCIO RJ - 18.1.A Resolução CGSN Nº 137, de 04 de Dezembro de 2017.\n";
                        } else if (
                            $scope.dadosEmpresaNota.Pes_Codigo == 8866546 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 12690404 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 320798 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 7007706 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 3224558 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 13329906 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 1034072 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 20271388 ||
                            $scope.dadosEmpresaNota.Pes_Codigo == 20657910
                        ) {
                            infoOrigem =
                                "EMISSAO DE NOTA CONFORME RESOLUCAO CGSN N. 140, DE 22 DE MAIO DE 2018\n";
                        } else if ($scope.dadosEmpresaNota.Pes_Codigo == 17774557) {
                            infoOrigem =
                                "Serviço prestado sob regime de parceria nos termos da Lei nº 13.352/2016\n";
                        }

                        if ($scope.dadosEmpresaNota.Cid_Codigo != "") {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/buscaCidadeProcon.php",
                                async: false,
                                data: {
                                    cidcodigo: $scope.dadosEmpresaNota.Cid_Codigo,
                                },
                                dataType: "json",
                                success: function(result) {
                                    if (result.data.length > 0) {
                                        infoProcon = `TELEFONE DO PROCON: ${result.data[0].CPo_Telefone} \n ENDERECO DO PROCON: ${result.data[0].CPo_Endereco}`;
                                    }
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                },
                            });
                        }
                        $("#valorCupomDisplay").val(
                            `${$_CONFIG.MOEDA} ${valorServicos.toFixed(2).replace(",", ".")}`
                        );
                        if ($_CONFIG.CODESTABELECIMENTO == 20657910) {
                            descricaoServicos =
                                descricaoServicos +
                                "\nEMISSAO DE NOTA CONFORME RESOLUCAO CGSN N. 140, DE 22 DE MAIO DE 2018";
                        }
                        $("#servicosPrestados").html(descricaoServicos);
                        $("#servicosPrestadosDisplay").val(descricaoServicos);
                        if ($scope.parnfdescontoparceiro == 1) {
                            if ($scope.parDescriaoSalaoParceiro == 1) {
                                $("#valorComissaoDisplay").val(0.0);
                            } else {
                                $("#valorComissaoDisplay").val(valorComissao.toFixed(2));
                            }

                            if (obsParceiro != "") {
                                let jsonmetadata = "";
                                $("#cliCupomMetadata").val(``);
                                if ($scope.arrayMetadados.length > 0) {
                                    setTimeout(() => {
                                        if (
                                            $scope.dadosEmpresaNota.Pes_Codigo == 1315052 ||
                                            $scope.dadosEmpresaNota.Pes_Codigo == 5386498 ||
                                            $scope.dadosEmpresaNota.Pes_Codigo == 18835846 ||
                                            $scope.dadosEmpresaNota.Pes_Codigo == 1033225 ||
                                            $scope.dadosEmpresaNota.Pes_Codigo == 5768816
                                        ) {
                                            for (let j = 0; j < $scope.arrayMetadados.length; j++) {
                                                jsonmetadata =
                                                    jsonmetadata +
                                                    `{"cnpj": "${
                            $scope.arrayMetadados[j][2]
                          }","razaoSocial": "${
                            $scope.arrayMetadados[j][1]
                          }","valorServico": ${parseFloat(
                            $scope.arrayMetadados[j][3].toFixed(2)
                          )},"codigoServicoParceiro": "${
                            $scope.arrayMetadados[j][4]
                          }"}`;
                                                if (j != $scope.arrayMetadados.length - 1) {
                                                    jsonmetadata = jsonmetadata + ",";
                                                }
                                            }
                                            $("#cliCupomMetadata").val(
                                                `{"profissionaisParceiros": [${jsonmetadata}], "regimeEspecialTributacao": 3}`
                                            );
                                        } else if ($scope.dadosEmpresaNota.Pes_Codigo == 14724552) {
                                            for (let j = 0; j < $scope.arrayMetadados.length; j++) {
                                                jsonmetadata =
                                                    jsonmetadata +
                                                    `{"codigoServicoMunicipio": "${
                            $scope.arrayMetadados[j][4]
                          }","descricao": "Parceiro ${
                            $scope.arrayMetadados[j][1]
                          } CNPJ ${
                            $scope.arrayMetadados[j][2]
                          }","valorUnitario": "${parseFloat(
                            $scope.arrayMetadados[j][3].toFixed(2)
                          )}","quantidade": 1,"valorDesconto":0,"tributavel":"2","tipoDeducao":"P","cnae":"${$(
                            "#empresaCNAE"
                          ).val()}"}`;
                                                if (j != $scope.arrayMetadados.length - 1) {
                                                    jsonmetadata = jsonmetadata + ",";
                                                }
                                            }
                                            if (jsonmetadata != "") {
                                                jsonmetadata =
                                                    jsonmetadata +
                                                    `,{"codigoServicoMunicipio": "${$(
                            "#servicoNatureza"
                          ).val()}","descricao": "${$(
                            "#servicosPrestados"
                          ).html()}","valorUnitario": "${(
                            valorServicos - valorComissao
                          ).toFixed(
                            2
                          )}","quantidade": 1,"valorDesconto":0,"tributavel":"1","cnae":"${$(
                            "#empresaCNAE"
                          ).val()}"}`;
                                            } else {
                                                jsonmetadata =
                                                    jsonmetadata +
                                                    `{"codigoServicoMunicipio": "${$(
                            "#servicoNatureza"
                          ).val()}","descricao": "${$(
                            "#servicosPrestados"
                          ).html()}","valorUnitario": "${(
                            valorServicos - valorComissao
                          ).toFixed(
                            2
                          )}","quantidade": 1,"valorDesconto":0,"tributavel":"1","cnae":"${$(
                            "#empresaCNAE"
                          ).val()}"}`;
                                            }
                                            $("#cliCupomMetadata").val(
                                                `{"itens": [${jsonmetadata}]}`
                                            );
                                        }
                                    }, 1000);
                                }

                                $("#cliCupomObs").val(
                                    `${infoOrigem}R$ ${(valorServicos - valorComissao).toFixed(
                    2
                  )} de cota-parte do salão parceiro: ${
                    $scope.dadosEmpresaNota.CNPJ
                  }\n${obsParceiro} \n\n\n ${infoProcon}`
                                );
                            } else {
                                $("#cliCupomObs").val(`${infoOrigem}\n\n\n ${infoProcon}`);
                                $("#cliCupomMetadata").val("");
                            }
                        } else {
                            $("#valorComissaoDisplay").val(0.0);
                            $("#cliCupomObs").val(`${infoOrigem} \n\n\n ${infoProcon}`);
                        }

                        obsOriginal = $("#cliCupomObs").val();
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                    },
                });

                if (cliente != "") {
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoav2.php",
                        data: {
                            tipo: 1,
                            pescodigo: cliente,
                        },
                        dataType: "json",
                        success: function(result) {
                            if (result.data.length > 0) {
                                $scope.dadosClienteNota = result.data[0];
                                $("#cliCupomNome").val(result.data[0].Pes_Nome);
                                $("#cliCupomNomeProd").val(result.data[0].Pes_Nome);
                                $("#cliCupomEmail").val(result.data[0].PAF_Email);
                                $("#cliCupomEmailProd").val(result.data[0].PAF_Email);
                                if (result.data[0].PAF_CPF.length <= 14) {
                                    $("#tipoPessoaNota").val("F");
                                } else {
                                    $("#tipoPessoaNota").val("J");
                                }
                                if (result.data[0].PAF_CPF.length <= 14) {
                                    $("#tipoPessoaEmitProd").val("F");
                                } else {
                                    $("#tipoPessoaEmitProd").val("J");
                                }
                                $("#cliCupomCPF").val(result.data[0].PAF_CPF);
                                $("#cliCupomCPFProd").val(result.data[0].PAF_CPF);
                                $("#cliCupomCEP").val(result.data[0].PAF_CEP);
                                $("#cliCupomCEPProd").val(result.data[0].PAF_CEP);
                                $("#cliCupomUF").val(result.data[0].Est_Sigla);
                                $("#cliCupomUFProd").val(result.data[0].Est_Sigla);
                                $("#cliCupomCidade").val(result.data[0].Cid_Nome);
                                $("#cliCupomCidadeProd").val(result.data[0].Cid_Nome);
                                $("#cliCupomBairro").val(result.data[0].PAF_Bairro);
                                $("#cliCupomBairroProd").val(result.data[0].PAF_Bairro);
                                $("#cliCupomLogradouro").val(result.data[0].PAF_Endereco);
                                $("#cliCupomLogradouroProd").val(result.data[0].PAF_Endereco);
                                $("#cliCupomNumero").val(result.data[0].PAF_Numero);
                                $("#cliCupomNumeroProd").val(result.data[0].PAF_Numero);
                                $("#cliCupomComplemento").val(result.data[0].PAF_Complemento);
                                $("#cliCupomComplementoProd").val(
                                    result.data[0].PAF_Complemento
                                );
                                $("#cliCupomTelefoneProd").val(result.data[0].PAF_Celular);
                            }
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                        },
                    });
                }

                setTimeout(() => {
                    if ($scope.parEnderecoNota == 1) {
                        $("#usaEndereco").val(1).change();
                    }
                    showLoader(false);
                }, 1000);

                if (
                    numeroServico > 0 &&
                    (geraaproser == 0 || geraaproser == 1) &&
                    $scope.parnfse == 1
                ) {
                    // if ($_CONFIG.CODESTABELECIMENTO == 9319370 && $scope.parnfce == 1) {
                    // criaNotaConsumidor(comanda, cliente, 0);
                    //} else {
                    $("#generateCupon-modal").modal();
                    //}
                }

                if (
                    numeroProduto > 0 &&
                    (geraaproser == 0 || geraaproser == 2) &&
                    $scope.parnfe == 1
                ) {
                    if ($scope.parnfce == 1) {
                        criaNotaConsumidor(comanda, cliente, 1);
                    } else {
                        $("#generateCuponProduto-modal").modal();
                    }
                }
                if (erroProduto == 1) {
                    toastr.warning(
                        'Favor, antes de fazer a emissão dos produtos, preencha todos os dados referentes emissão em "Cadastros > Produtos"'
                    );
                }
            };

            $("#transporteNotaProd").on("change", function() {
                if ($("#transporteNotaProd").val() != "SemOcorrenciaDeTransporte") {
                    $(".divDadosTransporte").show();
                } else {
                    $(".divDadosTransporte").hide();
                }
            });

            function FormataStringData(data) {
                var dia = data.split("/")[0];
                var mes = data.split("/")[1];
                var ano = data.split("/")[2];

                return ano + "-" + ("0" + mes).slice(-2) + "-" + ("0" + dia).slice(-2);
            }

            $scope.criaCupom = function() {
                showLoader(true);
                var timegerado = new Date().getTime();
                var proceedNota = 1;
                var msgerro = "";

                var datacompetencia = "";

                if ($("#dataCompetencia").val() != "") {
                    var dataString = new Date(
                        FormataStringData($("#dataCompetencia").val())
                    ).toISOString();
                    datacompetencia = dataString;
                }

                if ($scope.emiteSemEndereco == undefined) {
                    $scope.emiteSemEndereco = 1;
                } else if ($scope.emiteSemEndereco == 0) {
                    if (
                        $("#cliCupomUF").val() == "" ||
                        $("#cliCupomUF").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o estado do cliente.";
                    } else if (
                        $("#cliCupomCidade").val() == "" ||
                        $("#cliCupomCidade").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe a cidade do cliente.";
                    } else if (
                        $("#cliCupomCEP").val() == "" ||
                        $("#cliCupomCEP").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o CEP do cliente.";
                    } else if (
                        $("#cliCupomBairro").val() == "" ||
                        $("#cliCupomBairro").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o bairro do cliente.";
                    } else if (
                        $("#cliCupomLogradouro").val() == "" ||
                        $("#cliCupomLogradouro").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o logradouro do cliente.";
                    } else if (
                        $("#cliCupomNumero").val() == "" ||
                        $("#cliCupomNumero").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o numero do endereço do cliente.";
                    }
                }

                if ($scope.emiteSemCPF == undefined) {
                    $scope.emiteSemCPF = 1;
                } else if ($scope.emiteSemCPF == 0) {
                    if (
                        $("#cliCupomCPF").val() == "" ||
                        $("#cliCupomCPF").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o CPF do tomador do serviço. Favor informe o CPF do cliente.";
                    }
                }

                if ($scope.emiteSemCliente == undefined) {
                    $scope.emiteSemCliente = 1;
                } else if ($scope.emiteSemCliente == 0) {
                    if (
                        $("#cliCupomNome").val() == "" ||
                        $("#cliCupomNome").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o nome do tomador do serviço. Favor informe o nome do cliente.";
                    }
                }

                if (
                    $("#enviaCupomEmail").val() == "1" &&
                    $("#cliCupomEmail").val() == ""
                ) {
                    proceedNota = 0;
                    msgerro = "Informe um e-mail pra o envio a emissão.";
                }

                if (proceedNota == 1) {
                    if ($("#servicoNatureza option:selected").get(0) != undefined) {
                        if (
                            $("#empresaCodigoNF").val() != "" &&
                            $("#empresaCodigoNF").val() != undefined
                        ) {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereNotaFiscal.php",
                                data: {
                                    comcodigo: $("#numComanda").html(),
                                    idEmpresa: $("#empresaCodigoNF").val(),
                                    idExternoNota: $("#numComanda").html() + "_" + timegerado,
                                    enviarEmail: $("#enviaCupomEmail").val(),
                                    nomeCliente: $("#cliCupomNome").val(),
                                    emailCliente: $("#cliCupomEmail").val(),
                                    cpfCliente: $("#cliCupomCPF").val(),
                                    logradouroCliente: $("#cliCupomLogradouro").val(),
                                    numeroCliente: $("#cliCupomNumero").val(),
                                    complementoCliente: $("#cliCupomComplemento").val(),
                                    bairroCliente: $("#cliCupomBairro").val(),
                                    cepCliente: $("#cliCupomCEP").val(),
                                    ufCliente: $("#cliCupomUF").val(),
                                    cidadeCliente: $("#cliCupomCidade").val(),
                                    descricaoServico: $("#servicosPrestados").html(),
                                    aliquotaIss: parseFloat(
                                        $("#servicoNatureza option:selected").get(0).dataset
                                        .aliquota
                                    ),
                                    itemServico: $("#servicoNatureza option:selected").get(0)
                                        .dataset.itemlista,
                                    cnae: $("#empresaCNAE").val(),
                                    codigoServico: $("#servicoNatureza").val(),
                                    valorTotal: parseFloat(
                                        $("#valorCupom")
                                        .html()
                                        .replace($_CONFIG.MOEDA, "")
                                        .replace(",", ".")
                                    ),
                                    timegerado: timegerado,
                                    valorClss: parseFloat(
                                        $("#valorClss").html().replace(",", ".")
                                    ),
                                    valorPis: parseFloat($("#valorPis").html().replace(",", ".")),
                                    valorCofins: parseFloat(
                                        $("#valorCofins").html().replace(",", ".")
                                    ),
                                    valorInss: parseFloat(
                                        $("#valorInss").html().replace(",", ".")
                                    ),
                                    valorIr: parseFloat($("#valorIr").html().replace(",", ".")),
                                    observacao: $("#cliCupomObs").val(),
                                    deducoes: $("#valorComissaoDisplay").val(),
                                    tipoPessoa: $("#tipoPessoaNota").val(),
                                    ie: $("#cliCupomIE").val(),
                                    im: $("#cliCupomIM").val(),
                                    datacompetencia: datacompetencia,
                                    descricaocidadeservico: $(
                                        "#servicoNatureza option:selected"
                                    ).get(0).text,
                                    metadados: $("#cliCupomMetadata").val(),
                                    codigoNBS: $("#servicoNatureza option:selected").get(0)
                                        .dataset.nbs,
                                },
                                dataType: "json",
                                success: function(result) {
                                    showLoader(false);
                                    if (result.data[0].erro == 1) {
                                        toastr.warning(result.data[0].resultado);
                                    } else {
                                        toastr.warning(result.resultNota.erronf);
                                        if (
                                            result.resultNota.nfid == "" ||
                                            result.resultNota.nfid == undefined
                                        ) {
                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/removeComandaNotaFiscal.php",
                                                data: {
                                                    cnfcodigoexterno: $("#numComanda").html() + "_" + timegerado,
                                                },
                                                dataType: "json",
                                                success: function(data) {
                                                    if (data.data.erro != undefined) {
                                                        toastr.error(data.data.resultado);
                                                    } else {
                                                        if (data.data[0].erro == "0") {
                                                            toastr.success(data.data[0].resultado);
                                                        } else {
                                                            toastr.error(data.data[0].resultado);
                                                        }
                                                    }
                                                },
                                                error: function(result) {
                                                    toastr.error("Falha na conexão.");
                                                },
                                            });
                                        }
                                        $("#generateCupon-modal").modal("hide");
                                    }
                                    if (location.hash == "#/emissoes") {
                                        $rootScope.$emit("buscaRelatorioEmissao", {});
                                    }
                                },
                                error: function(result) {
                                    showLoader(false);
                                    toastr.error("Falha na conexão.");
                                },
                            });
                        } else {
                            showLoader(false);
                            toastr.error("Informe o ID da empresa");
                        }
                    } else {
                        showLoader(false);
                        toastr.error("Selecione o Serviço");
                    }
                } else {
                    showLoader(false);
                    toastr.error(msgerro);
                }
            };

            $scope.criaCupomProd = function() {
                showLoader(true);
                var timegerado = new Date().getTime();
                var proceedNota = 1;
                var msgerro = "";

                if (
                    $("#cliCupomUFProd").val() == "" ||
                    $("#cliCupomUFProd").val() == undefined
                ) {
                    proceedNota = 0;
                    msgerro =
                        "Endereço é obrigatório para nota de produtos. Favor informe o estado do cliente.";
                } else if (
                    $("#cliCupomCidadeProd").val() == "" ||
                    $("#cliCupomCidadeProd").val() == undefined
                ) {
                    proceedNota = 0;
                    msgerro =
                        "Endereço é obrigatório para nota de produtos. Favor informe a cidade do cliente.";
                } else if (
                    $("#cliCupomCEPProd").val() == "" ||
                    $("#cliCupomCEPProd").val() == undefined
                ) {
                    proceedNota = 0;
                    msgerro =
                        "Endereço é obrigatório para nota de produtos. Favor informe o CEP do cliente.";
                } else if (
                    $("#cliCupomBairroProd").val() == "" ||
                    $("#cliCupomBairroProd").val() == undefined
                ) {
                    proceedNota = 0;
                    msgerro =
                        "Endereço é obrigatório para nota de produtos. Favor informe o bairro do cliente.";
                } else if (
                    $("#cliCupomLogradouroProd").val() == "" ||
                    $("#cliCupomLogradouroProd").val() == undefined
                ) {
                    proceedNota = 0;
                    msgerro =
                        "Endereço é obrigatório para nota de produtos. Favor informe o logradouro do cliente.";
                } else if (
                    $("#cliCupomNumeroProd").val() == "" ||
                    $("#cliCupomNumeroProd").val() == undefined
                ) {
                    proceedNota = 0;
                    msgerro =
                        "Endereço é obrigatório para nota de produtos. Favor informe o numero do endereço do cliente.";
                }

                if (
                    $("#cliCupomCPFProd").val() == "" ||
                    $("#cliCupomCPFProd").val() == undefined
                ) {
                    proceedNota = 0;
                    msgerro =
                        "Sua cidade exige o CPF do tomador do serviço. Favor informe o CPF do cliente.";
                }

                if ($scope.emiteSemCliente == undefined) {
                    $scope.emiteSemCliente = 1;
                } else if ($scope.emiteSemCliente == 0) {
                    if (
                        $("#cliCupomNomeProd").val() == "" ||
                        $("#cliCupomNomeProd").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o nome do tomador do serviço. Favor informe o nome do cliente.";
                    }
                }

                if (
                    $("#enviaCupomEmailProd").val() == "1" &&
                    $("#cliCupomEmailProd").val() == ""
                ) {
                    proceedNota = 0;
                    msgerro = "Informe um e-mail pra o envio a emissão.";
                }

                if (proceedNota == 1) {
                    var infoProcon = "";
                    if ($("#cidCodigoEmpresaNotaProduto").val() != "") {
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaCidadeProcon.php",
                            async: false,
                            data: {
                                cidcodigo: $("#cidCodigoEmpresaNotaProduto").val(),
                            },
                            dataType: "json",
                            success: function(result) {
                                if (result.data.length > 0) {
                                    infoProcon = `TELEFONE DO PROCON: ${result.data[0].CPo_Telefone} \n ENDERECO DO PROCON: ${result.data[0].CPo_Endereco}`;
                                }
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                            },
                        });
                    }

                    $.ajax({
                        dataType: "json",
                        url: localStorage.getItem("host"),
                        async: false,
                        data: {
                            metodo: "buscaComanda",
                            id: $_CONFIG.ID,
                            comcodigo: $("#numComandaProd").html(),
                            tipo: 6,
                        },
                        success: function(data) {
                            if (data.result[0].TPa_Descricao != "") {
                                $scope.tpapagamento = data.result[0].TPa_Descricao;
                                if (data.result[0].TBa_Descricao != "") {
                                    $scope.tbapagamento = data.result[0].TBa_Descricao;
                                }
                            }
                        },
                        error: function() {
                            swal("Falha na conexão.", "", "error");
                        },
                    });

                    if ($scope.tpapagamento != "") {
                        $scope.arrPagamento = [];
                        var descricaoPagamento = "";
                        $scope.valorPagamentoNota = parseFloat(
                            $("#valorCupomDisplayProd")
                            .val()
                            .replace($_CONFIG.MOEDA, "")
                            .replace(" ", "")
                        );
                        var pushPagamento = "";
                        if (
                            $scope.tpapagamento == "Dinheiro" ||
                            $scope.tpapagamento == "dinheiro"
                        ) {
                            pushPagamento = "Dinheiro";
                        } else if (
                            $scope.tpapagamento == "Cartão de Crédito" ||
                            $scope.tpapagamento == "cartão de crédito"
                        ) {
                            pushPagamento = "CartaoDeCredito";
                        } else if (
                            $scope.tpapagamento == "Cartão de Débito" ||
                            $scope.tpapagamento == "cartão de débito"
                        ) {
                            pushPagamento = "CartaoDeDebito";
                        } else if (
                            $scope.tpapagamento == "Cheque" ||
                            $scope.tpapagamento == "cheque"
                        ) {
                            pushPagamento = "Cheque";
                        } else if (
                            $scope.tpapagamento == "Boleto" ||
                            $scope.tpapagamento == "boleto"
                        ) {
                            pushPagamento = "BoletoBancario";
                        } else if (
                            $scope.tpapagamento == "PIX" ||
                            $scope.tpapagamento == "pix" ||
                            $scope.tpapagamento == "Pix"
                        ) {
                            pushPagamento = "PagamentoInstantaneoPix";
                        } else if (
                            $scope.tpapagamento == "Resgate de Pontos" ||
                            $scope.tpapagamento == "resgate de pontos"
                        ) {
                            pushPagamento = "ProgramaFidelidadeCashbackCarteiraVirtual";
                        } else {
                            descricaoPagamento = $scope.tpapagamento;
                            pushPagamento = "Outros";
                        }

                        if (descricaoPagamento != "") {
                            $scope.arrPagamento.push({
                                tipo: pushPagamento,
                                valor: $scope.valorPagamentoNota,
                                descricao: descricaoPagamento,
                            });
                        } else {
                            if (
                                pushPagamento == "CartaoDeCredito" ||
                                pushPagamento == "CartaoDeDebito"
                            ) {
                                $scope.arrPagamento.push({
                                    tipo: pushPagamento,
                                    valor: $scope.valorPagamentoNota,
                                    credenciadoraCartao: {
                                        tipoIntegracaoPagamento: "NaoIntegradoAoSistemaDeGestao",
                                    },
                                });
                            } else {
                                $scope.arrPagamento.push({
                                    tipo: pushPagamento,
                                    valor: $scope.valorPagamentoNota,
                                });
                            }
                        }
                    } else {
                        $scope.arrPagamento.push({
                            tipo: "Dinheiro",
                            valor: $scope.valorPagamentoNota,
                        });
                    }

                    if (
                        $("#empresaCodigoNFProd").val() != "" &&
                        $("#empresaCodigoNFProd").val() != undefined
                    ) {
                        if (infoProcon != "") {
                            var infoaddnota = `${$("#cliCupomAdInfo").val()} \n${infoProcon}`;
                        } else {
                            var infoaddnota = $("#cliCupomAdInfo").val();
                        }
                        if ($("#transporteNotaProd").val() == "SemOcorrenciaDeTransporte") {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereNotaFiscalProdutos.php",
                                data: {
                                    comcodigo: $("#numComandaProd").html(),
                                    idEmpresa: $("#empresaCodigoNFProd").val(),
                                    idExternoNota: $("#numComandaProd").html() + "_" + timegerado,
                                    enviarEmail: $("#enviaCupomEmailProd").val(),
                                    nomeCliente: $("#cliCupomNomeProd").val(),
                                    telefoneCliente: $("#cliCupomTelefoneProd").val(),
                                    emailCliente: $("#cliCupomEmailProd").val(),
                                    cpfCliente: $("#cliCupomCPFProd").val(),
                                    logradouroCliente: $("#cliCupomLogradouroProd").val(),
                                    numeroCliente: $("#cliCupomNumeroProd").val(),
                                    complementoCliente: $("#cliCupomComplementoProd").val(),
                                    bairroCliente: $("#cliCupomBairroProd").val(),
                                    cepCliente: $("#cliCupomCEPProd").val(),
                                    ufCliente: $("#cliCupomUFProd").val(),
                                    cidadeCliente: $("#cliCupomCidadeProd").val(),
                                    item: $scope.produtosNota,
                                    timegerado: timegerado,
                                    tipoemissao: 1,
                                    pagamento: JSON.stringify($scope.arrPagamento),
                                    tipoPessoaEmitProd: $("#tipoPessoaEmitProd").val(),
                                    ie: $("#cliCupomIEProd").val(),
                                    im: $("#cliCupomIMProd").val(),
                                    informacaoAdicional: infoaddnota,
                                    natureza: $("#naturezaNotaProduto").val(),
                                    /*,datacompetencia: datacompetenciaprod*/
                                },
                                dataType: "json",
                                success: function(result) {
                                    showLoader(false);
                                    if (result.data[0].erro == 1) {
                                        toastr.warning(result.data[0].resultado);
                                    } else {
                                        toastr.warning(result.resultNota.erronf);
                                        if (
                                            result.resultNota.nfid == "" ||
                                            result.resultNota.nfid == undefined
                                        ) {
                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/removeComandaNotaFiscal.php",
                                                data: {
                                                    cnfcodigoexterno: $("#numComandaProd").html() + "_" + timegerado,
                                                },
                                                dataType: "json",
                                                success: function(data) {
                                                    if (data.data.erro != undefined) {
                                                        toastr.error(data.data.resultado);
                                                    } else {
                                                        if (data.data[0].erro == "0") {
                                                            toastr.success(data.data[0].resultado);
                                                        } else {
                                                            toastr.error(data.data[0].resultado);
                                                        }
                                                    }
                                                },
                                                error: function(result) {
                                                    toastr.error("Falha na conexão.");
                                                },
                                            });
                                        }
                                        $("#generateCuponProduto-modal").modal("hide");
                                    }
                                },
                                error: function(result) {
                                    showLoader(false);
                                    toastr.error("Falha na conexão.");
                                },
                            });
                        } else {
                            /*---------------------------------------------------------------------*/

                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereNotaFiscalProdutosv2.php",
                                data: {
                                    comcodigo: $("#numComandaProd").html(),
                                    idEmpresa: $("#empresaCodigoNFProd").val(),
                                    idExternoNota: $("#numComandaProd").html() + "_" + timegerado,
                                    enviarEmail: $("#enviaCupomEmailProd").val(),
                                    nomeCliente: $("#cliCupomNomeProd").val(),
                                    telefoneCliente: $("#cliCupomTelefoneProd").val(),
                                    emailCliente: $("#cliCupomEmailProd").val(),
                                    cpfCliente: $("#cliCupomCPFProd").val(),
                                    logradouroCliente: $("#cliCupomLogradouroProd").val(),
                                    numeroCliente: $("#cliCupomNumeroProd").val(),
                                    complementoCliente: $("#cliCupomComplementoProd").val(),
                                    bairroCliente: $("#cliCupomBairroProd").val(),
                                    cepCliente: $("#cliCupomCEPProd").val(),
                                    ufCliente: $("#cliCupomUFProd").val(),
                                    cidadeCliente: $("#cliCupomCidadeProd").val(),
                                    item: $scope.produtosNota,
                                    timegerado: timegerado,
                                    tipoemissao: 1,
                                    pagamento: JSON.stringify($scope.arrPagamento),
                                    tipoPessoaEmitProd: $("#tipoPessoaEmitProd").val(),
                                    ie: $("#cliCupomIEProd").val(),
                                    im: $("#cliCupomIMProd").val(),
                                    informacaoAdicional: infoaddnota,
                                    natureza: $("#naturezaNotaProduto").val(),
                                    modalidadeTransporte: $("#transporteNotaProd").val(),
                                    usarDadosEmitente: "",
                                    tipoPessoaTransportadora: $(
                                        "#transportadoraNotaProd option:selected"
                                    ).get(0).dataset.tipopessoa,
                                    cpfcnpjTransportadora: $(
                                        "#transportadoraNotaProd option:selected"
                                    ).get(0).dataset.cnpj,
                                    nomeTransportadora: $("#transportadoraNotaProd ").val(),
                                    ieTransportadora: $(
                                        "#transportadoraNotaProd option:selected"
                                    ).get(0).dataset.ie,
                                    enderecoTransportadora: $(
                                        "#transportadoraNotaProd option:selected"
                                    ).get(0).dataset.endereco,
                                    ufTransportadora: $(
                                        "#transportadoraNotaProd option:selected"
                                    ).get(0).dataset.uf,
                                    cidadeTransportadora: $(
                                        "#transportadoraNotaProd option:selected"
                                    ).get(0).dataset.cidade,
                                    veiculoPlaca: $("#placaVeiculoTranspoteNotaProd").val(),
                                    veiculoUF: $("#veiculoTranspoteNotaProd").val(),
                                    qtdVolume: $("#qtdTransporteNota").val(),
                                    especieVolume: $("#especieTransporteNotaProd").val(),
                                    marcaVolume: $("#marcaTransporteNotaProd").val(),
                                    numeracaoVolume: $("#numeracaoTransporteNotaProd").val(),
                                    pesoBrutoVomume: $("#pesoBrutoNotaProd").val(),
                                    pesoLiqVolume: $("#pesoLiquidoNotaProd").val(),
                                },
                                dataType: "json",
                                success: function(result) {
                                    showLoader(false);
                                    if (result.data[0].erro == 1) {
                                        toastr.warning(result.data[0].resultado);
                                    } else {
                                        toastr.warning(result.resultNota.erronf);
                                        if (
                                            result.resultNota.nfid == "" ||
                                            result.resultNota.nfid == undefined
                                        ) {
                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/removeComandaNotaFiscal.php",
                                                data: {
                                                    cnfcodigoexterno: $("#numComandaProd").html() + "_" + timegerado,
                                                },
                                                dataType: "json",
                                                success: function(data) {
                                                    if (data.data.erro != undefined) {
                                                        toastr.error(data.data.resultado);
                                                    } else {
                                                        if (data.data[0].erro == "0") {
                                                            toastr.success(data.data[0].resultado);
                                                        } else {
                                                            toastr.error(data.data[0].resultado);
                                                        }
                                                    }
                                                },
                                                error: function(result) {
                                                    toastr.error("Falha na conexão.");
                                                },
                                            });
                                        }
                                        $("#generateCuponProduto-modal").modal("hide");
                                    }
                                },
                                error: function(result) {
                                    showLoader(false);
                                    toastr.error("Falha na conexão.");
                                },
                            });

                            /*---------------------------------------------------------------------*/
                        }
                    } else {
                        showLoader(false);
                        toastr.error("Informe o ID da empresa");
                    }
                } else {
                    showLoader(false);
                    toastr.error(msgerro);
                }
            };

            $scope.lang = $_CONFIG.language.mascaras.lang;

            $scope.diplayGorjeta = function() {
                $("#comandaInsereGorjeta-modal").modal();
            };

            $scope.insereComandaGorjeta = function() {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    method: "POST",
                    url: "/pages/cadastros/insereComandaGorjeta.php",
                    data: {
                        profissional: $("#profissionalGorjeta").val(),
                        valor: $("#valorComandaGorjeta").val(),
                        comcodigo: $("#idComanda").html(),
                    },
                    success: function(data) {
                        if (data.data.erro != undefined) {
                            toastr.error(data.data.resultado);
                        } else {
                            if (data.data[0].erro == "0") {
                                toastr.success(data.data[0].resultado);
                                $scope.atualizaDadosItens();
                                if (location.hash == "#/comandasabertas") {
                                    $rootScope.$emit("atualizaDadosComanda", {});
                                }
                                $("#comandaInsereGorjeta-modal").modal("hide");
                                $("#valorComandaGorjeta").val("");
                                $("#profissionalGorjeta").val("");
                            } else {
                                toastr.error(data.data[0].resultado);
                            }
                        }
                        showLoader(false);
                    },
                });
            };

            $scope.alteraComandaGorjeta = function() {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    method: "POST",
                    url: "/pages/cadastros/alteraComandaGorjeta.php",
                    data: {
                        profissional: $("#profissionalGorjetaAltera").val(),
                        valor: $("#valorComandaGorjetaAltera").val(),
                        citcodigo: $("#itemComandaGorjeta").val(),
                    },
                    success: function(data) {
                        if (data.data.erro != undefined) {
                            toastr.error(data.data.resultado);
                        } else {
                            if (data.data[0].erro == "0") {
                                toastr.success(data.data[0].resultado);
                                $scope.atualizaDadosItens();
                                if (location.hash == "#/comandasabertas") {
                                    $rootScope.$emit("atualizaDadosComanda", {});
                                }
                                $("#comandaAlteraGorjeta-modal").modal("hide");
                                $("#valorComandaGorjetaAltera").val("");
                                $("#profissionalGorjetaAltera").val("");
                            } else {
                                toastr.error(data.data[0].resultado);
                            }
                        }
                        showLoader(false);
                    },
                });
            };

            $scope.edtImgProntuario = function() {
                $("#aimImagemInsere").click();
            };

            $("#cortaImagemAll-modal").on("hidden.bs.modal", function(e) {
                if ($scope.numImagemProntuario <= 2) {
                    if (mBlob != undefined && mBlob != "") {
                        if (($("#insereProntuario-modal").data("bs.modal") || {}).isShown) {
                            $("#imagemProntuario" + $scope.numImagemProntuario).attr(
                                "src",
                                mImage
                            );
                            $("#formInsereImagemAgendamento").submit();
                            $scope.numImagemProntuario++;
                        }
                        if (($("#EditaProntuario-modal").data("bs.modal") || {}).isShown) {
                            if ($("#formid").val() == "#formAlteraImagemAgendamento") {
                                $("#formAlteraImagemAgendamento").submit();
                            } else {
                                $("#formInsereImagemAgendamentoEDT").submit();
                            }
                        }
                    }
                    $("#imagemCutAll").resize();
                    $("#imagemCutAll").cropper("reset");
                }
            });

            $("#formEditarClienteAgenda").submit(function(event) {
                event.preventDefault();
                showLoader(true);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/alteraClientes.php",
                    data: new FormData(this),
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: function(result) {
                        if (result.alteraCliente[0].erro == "0") {
                            /*if ($("#cliSenhaAgenda").val() != "") {
						$.ajax({
							type: "POST",
							url: "/pages/cadastros/alteraSenha.php",
							data: {
								tipo: 2,
								usuCodigo: $('#usucodigoalteracao').val(),
								pesCodigoAlt: $('#cliCodigoEdtAgenda').val(),
								senhaAlt: $("#cliSenhaAgenda").val(),
							},
							dataType: "json",
							success: function (result) {
								if (result.result[0].erro == "0") {
									toastr.success(result.result[0].resultado);

								} else {
									toastr.error(result.result[0].resultado);
								}
								showLoader(false);
							},
							error: function (result) {
								toastr.error($_CONFIG.language.errors.falha_conexao);
								showLoader(false);
							}
						});

					}*/
                            toastr.success(result.alteraCliente[0].resultado);
                            $("#editarClienteAgenda-modal").modal("hide");
                            if (location.hash == "#/agenda") {
                                $rootScope.$emit("BuscaAgenda", {});
                            } else {
                                $("#infoCliente-modal").modal("hide");
                                setTimeout(function() {
                                    $scope.mostraInfoClientes($("#cliCodigoEdtAgenda").val());
                                    if (location.hash == "#/clientes") {
                                        $rootScope.$emit("AtualizaListaCliente", {});
                                    }
                                }, 500);
                            }
                        } else {
                            toastr.error(result.alteraCliente[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error($_CONFIG.language.errors.falha_conexao);
                        showLoader(false);
                    },
                });

                return true;
            });

            $scope.editarClienteInfo = function() {
                $.ajax({
                    method: "POST",
                    dataType: "json",
                    url: "/pages/cadastros/buscaClienteAlteraAgenda.php",
                    data: {
                        cliente: $("#cliPesCodigoInfo").val(),
                    },
                    success: function(data) {
                        $("#cliSenhaAgenda").val("");
                        $("#cliNomeEdtAgenda").val(data.result[0].Pes_Nome);
                        $("#cliCpfEdtAgenda").val(data.result[0].Paf_Cpf);
                        $("#cliEmailEdtAgenda").val(data.result[0].Paf_Email);
                        $("#cliEmailEdtAgenda").change();
                        $("#cliCelularEdtAgenda").val(data.result[0].Paf_Celular);
                        $("#cliTelefoneEdtAgenda").val(data.result[0].Paf_Telefone);
                        $("#cliEnderecoEdtAgenda").val(data.result[0].Paf_Endereco);
                        $("#cliSexoEdtAgenda").val(data.result[0].Paf_Sexo);
                        $("#cliDataNascimentoEdtAgenda").val(
                            data.result[0].PAF_Dat_Nascimento
                        );
                        $("#usucodigoalteracao").val(data.result[0].Usu_Codigo);
                        if (data.result[0].Usu_Codigo == "") {
                            $("#possuiusu").hide();
                            $("#npossuiusu").show();
                        } else {
                            $("#npossuiusu").hide();
                            $("#possuiusu").show();
                        }
                        $("#cliEstadoEdtAgenda").val(data.result[0].Est_Sigla);
                        $("#cliCepEdtAgenda").val(data.result[0].Paf_CEP);
                        $("#cliCodigoEdtAgenda").val(data.result[0].Pes_Codigo);
                        $("#cliEstadoEdtAgenda").val(data.result[0].Est_Codigo);
                        $("#pesCodigoAltAgenda").val(data.result[0].Pes_Codigo);
                        $("#cliObservacaoEdtAgenda").val(data.result[0].Paf_Observacao);
                        $("#cliNumeroEdtAgenda").val(data.result[0].Paf_Numero);
                        $("#cliComplementoEdtAgenda").val(data.result[0].Paf_Complemento);
                        $("#cliBairroEdtAgenda").val(data.result[0].Paf_Bairro);
                        $("#cliOndeAgenda").val(data.result[0].PAF_Com_Soube);
                        $("#cliRGEdtAgenda").val(data.result[0].Paf_RG);
                        $("#cliDialCodeEdtAgenda").val(data.result[0].DDI);
                        $scope.geraComboPaisTelefone(
                            "cliCelularEdtAgenda",
                            "cliDialCodeEdtAgenda",
                            data.result[0].DDI
                        );
                        $.ajax({
                            dataType: "html",
                            url: "/pages/cadastros/buscaCidades.php",
                            method: "POST",
                            data: {
                                estCodigo: data.result[0].Est_Codigo,
                            },
                            success: function(result) {
                                $("#cliCidadeEdtAgenda").append(result);
                                $("#cliCidadeEdtAgenda").attr("disabled", false);
                                $("#cliCidadeEdtAgenda").val(data.result[0].Cid_Codigo);
                            },
                        });
                    },
                    error: function(result) {},
                });
                $('[data-toggle="popover"]').popover({
                    container: "body",
                });
                $("#editarClienteAgenda-modal").modal();
            };
            $("#cadastrarClienteComanda-modal").on("show.bs.modal", function(e) {
                $scope.geraComboPaisTelefone("cliCelularComanda", "cliDialCodeComanda");
            });

            $scope.runBuscaProntuarioCliente = function() {
                $scope.buscaProntuarioCliente($("#pescodigoProntuario").val());
            };

            $scope.limpaDataPront = function() {
                $("#cliDatInicioPron").val("");
                $("#cliDatFimPron").val("");
            };

            $scope.geraReciboVale = function(data) {
                $("#valorReciboVale").html(data.FCM_Valor);
                $("#dataReciboVale").html(data.FCM_Dat_Cadastro);
                $("#nomeReciboVale").html(data.Pes_Nome);
                var valor = data.FCM_Valor;
                valor = valor.replace($_CONFIG.MOEDA, "");
                $("#valorExtensoReciboVale").html(valor.extenso(true).toUpperCase());
                $("#reciboVale-modal").modal();
                $scope.buscaEmpresaInformacoesRecibo();
            };

            $scope.buscaEmpresaInformacoesRecibo = function() {
                var cidData = "";
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaEmpresaInfo.php",
                    method: "POST",
                    async: false,
                    dataType: "json",
                    success: function(result) {
                        cidData =
                            result.buscaPessoa[0].Cid_Nome +
                            " (" +
                            result.buscaPessoa[0].Est_Sigla +
                            ")";
                    },
                });
                var data = new Date();

                var mes = "";
                var dia = "";
                if (data.getDate() < 10) {
                    dia = "0" + data.getDate();
                } else {
                    dia = data.getDate();
                }
                if (data.getMonth() == 0) {
                    mes = "Janeiro";
                } else if (data.getMonth() == 1) {
                    mes = "Fevereiro";
                } else if (data.getMonth() == 2) {
                    mes = "Março";
                } else if (data.getMonth() == 3) {
                    mes = "Abril";
                } else if (data.getMonth() == 4) {
                    mes = "Maio";
                } else if (data.getMonth() == 5) {
                    mes = "Junho";
                } else if (data.getMonth() == 6) {
                    mes = "Julho";
                } else if (data.getMonth() == 7) {
                    mes = "Agosto";
                } else if (data.getMonth() == 8) {
                    mes = "Setembro";
                } else if (data.getMonth() == 9) {
                    mes = "Outubro";
                } else if (data.getMonth() == 10) {
                    mes = "Novembro";
                } else if (data.getMonth() == 11) {
                    mes = "Dezembro";
                }
                $("#dataLocalReciboVale").html(
                    cidData + ", " + dia + " de " + mes + " de " + data.getFullYear()
                );
            };

            $scope.imorimeReciboVale = function() {
                PrintElem("Recibo Vale", "#reciboValeImprimir");
            };

            $("#usaEndereco").change(() => {
                if ($("#usaEndereco").val() == 0) {
                    $("#cliCupomCEP").val($scope.dadosClienteNota.Paf_CEP);
                    $("#cliCupomUF").val($scope.dadosClienteNota.Est_Sigla);
                    $("#cliCupomCidade").val($scope.dadosClienteNota.Cid_Nome);
                    $("#cliCupomBairro").val($scope.dadosClienteNota.Paf_Bairro);
                    $("#cliCupomLogradouro").val($scope.dadosClienteNota.Paf_Endereco);
                    $("#cliCupomNumero").val($scope.dadosClienteNota.Paf_Numero);
                    $("#cliCupomComplemento").val(
                        $scope.dadosClienteNota.Paf_Complemento
                    );
                } else {
                    $("#cliCupomCEP").val($scope.dadosEmpresaNota.CEP);
                    $("#cliCupomUF").val($scope.dadosEmpresaNota.Estado);
                    $("#cliCupomCidade").val($scope.dadosEmpresaNota.Cidade);
                    $("#cliCupomBairro").val($scope.dadosEmpresaNota.Bairro);
                    $("#cliCupomLogradouro").val($scope.dadosEmpresaNota.Endereco);
                    $("#cliCupomNumero").val($scope.dadosEmpresaNota.Numero);
                    $("#cliCupomComplemento").val($scope.dadosEmpresaNota.Complemento);
                }
            });

            $("#usaEnderecoProd").change(() => {
                if ($("#usaEnderecoProd").val() == 0) {
                    $("#cliCupomCEPProd").val($scope.dadosClienteNota.Paf_CEP);
                    $("#cliCupomUFProd").val($scope.dadosClienteNota.Est_Sigla);
                    $("#cliCupomCidadeProd").val($scope.dadosClienteNota.Cid_Nome);
                    $("#cliCupomBairroProd").val($scope.dadosClienteNota.Paf_Bairro);
                    $("#cliCupomLogradouroProd").val(
                        $scope.dadosClienteNota.Paf_Endereco
                    );
                    $("#cliCupomNumeroProd").val($scope.dadosClienteNota.Paf_Numero);
                    $("#cliCupomComplementoProd").val(
                        $scope.dadosClienteNota.Paf_Complemento
                    );
                    $("#cliCupomTelefoneProd").val($scope.dadosClienteNota.Paf_Celular);
                } else {
                    $("#cliCupomCEPProd").val($scope.dadosEmpresaNota.CEP);
                    $("#cliCupomUFProd").val($scope.dadosEmpresaNota.Estado);
                    $("#cliCupomCidadeProd").val($scope.dadosEmpresaNota.Cidade);
                    $("#cliCupomBairroProd").val($scope.dadosEmpresaNota.Bairro);
                    $("#cliCupomLogradouroProd").val($scope.dadosEmpresaNota.Endereco);
                    $("#cliCupomNumeroProd").val($scope.dadosEmpresaNota.Numero);
                    $("#cliCupomComplementoProd").val(
                        $scope.dadosEmpresaNota.Complemento
                    );
                    $("#cliCupomTelefoneProd").val($scope.dadosEmpresaNota.Telefone);
                }
            });

            $scope.emiteSemClientePacote = 0;
            $scope.emiteSemCPFPacote = 0;
            $scope.emiteSemEnderecoPacote = 0;

            $scope.generateCupomPacote = function(
                ppacodigo,
                cliente,
                geraaproser = 0,
                geraparteparceiro = ""
            ) {
                if ($scope.parnfapacote == 1 && $scope.parnota == 1) {
                    $("#ppaCodigoNotaPacote").val(ppacodigo);
                    $("#ppaCodigoNotaPacoteProduto").val(ppacodigo);
                    $scope.itensPacoteNota = "";

                    var valorPis = 0;
                    var valorInss = 0;
                    var valorCofins = 0;
                    var valorIr = 0;
                    var valorServicos = 0;
                    var valorProduto = 0;
                    var valorComissao = 0;
                    var descricaoServicos = "";
                    var citvalorProduto = 0;
                    var numeroServicoPacote = 0;
                    var numeroProdutoPacote = 0;
                    var erroProduto = 0;
                    var obsParceiro = "";
                    var obsOriginal = "";

                    var valorComissaoPacoteVenda = 0;
                    var obsComissaoPacoteVenda = "";

                    if ($scope.parEnderecoNota == 0) {
                        $("#usaEnderecoNotaPacote").val(0).change();
                    } else {
                        $("#usaEnderecoNotaPacote").val(1).change();
                    }
                    $("#usaEnderecoNotaPacoteProd").val(0).change();

                    if (geraparteparceiro != 1) {
                        $.ajax({
                            method: "POST",
                            dataType: "json",
                            url: "/pages/cadastros/buscaPessoaPacoteItens.php",
                            async: false,
                            data: {
                                ppacodigo: ppacodigo,
                                tipo: 1,
                            },
                            success: function(data) {
                                $scope.itensPacoteNota = data.data;
                                for (var a = 0; a < $scope.itensPacoteNota.length; a++) {
                                    if ($scope.itensPacoteNota[a].Ser_Codigo != "") {
                                        numeroServicoPacote++;
                                    } else if ($scope.itensPacoteNota[a].Pro_Codigo != "") {
                                        numeroProdutoPacote++;
                                    }
                                }

                                if (
                                    $scope.itensPacoteNota[0].PPa_Comissao != "" &&
                                    $scope.itensPacoteNota[0].PPa_Comissao > 0.0
                                ) {
                                    valorComissaoPacoteVenda = parseFloat(
                                        $scope.itensPacoteNota[0].PPa_Comissao
                                    );

                                    var profissionalcom = "";
                                    var cnpjParceirovenda = $scope.itensPacoteNota[0].PAF_CPF;
                                    if ($scope.nomeProfissionalNota == 1) {
                                        profissionalcom = `${$scope.itensPacoteNota[0].Pes_Nome},`;
                                    }

                                    if (cnpjParceirovenda.replace(/\D/g, "").length >= 14) {
                                        obsParceiro += `R$ ${valorComissaoPacoteVenda.toFixed(
                      2
                    )} de cota-parte profissional parceiro ${profissionalcom} CNPJ ${cnpjParceirovenda}, emitida no código: ${
                      $scope.itensPacoteNota[0].Codigo_Emissao
                    };\n`;
                                    } else {
                                        obsParceiro += `R$ ${valorComissaoPacoteVenda.toFixed(
                      2
                    )} de cota-parte profissional parceiro ${profissionalcom} CPF ${cnpjParceirovenda}, emitida no código: ${
                      $scope.itensPacoteNota[0].Codigo_Emissao
                    };\n`;
                                    }
                                }
                                $(".nomePacoteEmissao").html(
                                    $scope.itensPacoteNota[0].Pac_Descricao
                                );
                            },
                            error: function(result) {},
                        });
                    } else {
                        $.ajax({
                            method: "POST",
                            dataType: "json",
                            url: "/pages/cadastros/buscaPessoaPacoteItens.php",
                            async: false,
                            data: {
                                ppacodigo: ppacodigo,
                                tipo: 3,
                            },
                            success: function(data) {
                                $scope.itensPacoteNota = data.data;
                                for (var a = 0; a < $scope.itensPacoteNota.length; a++) {
                                    if ($scope.itensPacoteNota[a].Ser_Codigo != "") {
                                        numeroServicoPacote++;
                                    } else if ($scope.itensPacoteNota[a].Pro_Codigo != "") {
                                        numeroProdutoPacote++;
                                    }
                                }

                                if (
                                    $scope.itensPacoteNota[0].PPa_Comissao != "" &&
                                    $scope.itensPacoteNota[0].PPa_Comissao > 0.0
                                ) {
                                    valorComissaoPacoteVenda = parseFloat(
                                        $scope.itensPacoteNota[0].PPa_Comissao
                                    );

                                    var profissionalcom = "";
                                    var cnpjParceirovenda =
                                        $scope.itensPacoteNota[0].PAF_CPF_prof;
                                    if ($scope.nomeProfissionalNota == 1) {
                                        profissionalcom = `${$scope.itensPacoteNota[0].Pes_Nome_prof},`;
                                    }

                                    if (cnpjParceirovenda.replace(/\D/g, "").length >= 14) {
                                        obsParceiro += `R$ ${valorComissaoPacoteVenda.toFixed(
                      2
                    )} de cota-parte profissional parceiro ${profissionalcom} CNPJ ${cnpjParceirovenda}, emitida no código: ${
                      $scope.itensPacoteNota[0].Codigo_Emissao
                    };\n`;
                                    } else {
                                        obsParceiro += `R$ ${valorComissaoPacoteVenda.toFixed(
                      2
                    )} de cota-parte profissional parceiro ${profissionalcom} CPF ${cnpjParceirovenda}, emitida no código: ${
                      $scope.itensPacoteNota[0].Codigo_Emissao
                    };\n`;
                                    }
                                }
                                $(".nomePacoteEmissao").html(
                                    $scope.itensPacoteNota[0].Pac_Descricao
                                );
                            },
                            error: function(result) {},
                        });
                    }

                    if (
                        numeroServicoPacote > 0 &&
                        (geraaproser == 0 || geraaproser == 1)
                    ) {
                        if ($scope.parnfse == 1) {
                            for (var i = 0; i < $scope.itensPacoteNota.length; i++) {
                                if ($scope.itensPacoteNota[i].Ser_Codigo != "") {
                                    if (i != 0) {
                                        if (numeroServicoPacote > 1) {
                                            descricaoServicos += ", ";
                                        }
                                    }
                                    var citvalor =
                                        $scope.itensPacoteNota[i].PTe_Quantidade *
                                        parseFloat(
                                            $scope.itensPacoteNota[i].PTe_Valor.replace(",", ".")
                                        );
                                    if ($("#empresaCSTNotaPacote").val() != "") {
                                        $.ajax({
                                            dataType: "json",
                                            method: "POST",
                                            url: "/pages/cadastros/buscaServicoSerCodigo.php",
                                            async: false,
                                            data: {
                                                sercodigo: $scope.itensPacoteNota[i].Ser_Codigo,
                                            },
                                            success: function(result) {
                                                for (var j = 0; j < result.servicos.length; j++) {
                                                    valorPis =
                                                        valorPis +
                                                        (citvalor * result.servicos[j].Ser_Pis) / 100;
                                                    valorInss =
                                                        valorInss +
                                                        (citvalor * result.servicos[j].Ser_Inss) / 100;
                                                    valorCofins =
                                                        valorCofins +
                                                        (citvalor * result.servicos[j].Ser_Cofins) / 100;
                                                    valorIr =
                                                        valorIr +
                                                        (citvalor * result.servicos[j].Ser_Ir) / 100;
                                                }
                                                $("#valorPisNotaPacote").html(valorPis);
                                                $("#valorInssNotaPacote").html(valorInss);
                                                $("#valorCofinsNotaPacote").html(valorCofins);
                                                $("#valorClssNotaPacote").html(valorClss);
                                                $("#valorIrNotaPacote").html(valorIr);
                                            },
                                            error: function(result) {
                                                console.log(result);
                                            },
                                        });
                                        $("#divCSTEmpresaNotaPacote").show();
                                    } else {
                                        $("#divCSTEmpresaNotaPacote").hide();
                                    }
                                    $("#valorPisNotaPacote").html(valorPis);
                                    $("#valorInssNotaPacote").html(valorInss);
                                    $("#valorCofinsNotaPacote").html(valorCofins);
                                    $("#valorClssNotaPacote").html(0);
                                    $("#valorIrNotaPacote").html(valorIr);
                                    descricaoServicos += `${$scope.itensPacoteNota[i].Ser_Descricao} QTD: ${$scope.itensPacoteNota[i].PTe_Quantidade}`;
                                    valorServicos = valorServicos + citvalor;

                                    /*----------------------------------------------------------------------------------------------------------------------------------------------------*/

                                    if ($scope.parnfdescontoparceiro == 1) {
                                        var pesCodigoParceiro =
                                            $scope.itensPacoteNota[i].Pes_Codigo;
                                        if (
                                            pesCodigoParceiro != "" &&
                                            pesCodigoParceiro != undefined
                                        ) {
                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/buscaPessoav2.php",
                                                async: false,
                                                data: {
                                                    tipo: 2,
                                                    pescodigo: pesCodigoParceiro,
                                                },
                                                dataType: "json",
                                                success: function(result) {
                                                    if (result.data.length != 0) {
                                                        if (
                                                            result.data[0].PAF_CPF != "" &&
                                                            result.data[0].PNa_Codigo != ""
                                                        ) {
                                                            var cnpjParceiro = result.data[0].PAF_CPF;
                                                            $.ajax({
                                                                type: "POST",
                                                                url: "/pages/cadastros/buscaPessoaNaturezav2.php",
                                                                async: false,
                                                                data: {
                                                                    tipo: "1",
                                                                    pescodigo: pesCodigoParceiro,
                                                                },
                                                                dataType: "json",
                                                                success: function(result) {
                                                                    var valorcomissaodesconto = parseFloat(
                                                                        $scope.itensPacoteNota[i].Comissao.replace(
                                                                            ",",
                                                                            "."
                                                                        )
                                                                    );
                                                                    valorComissao =
                                                                        valorComissao + valorcomissaodesconto;
                                                                    var profissional = "";
                                                                    if ($scope.nomeProfissionalNota == 1) {
                                                                        profissional = `${result.data[0].Pes_Nome},`;
                                                                    }

                                                                    if (
                                                                        cnpjParceiro.replace(/\D/g, "").length >= 14
                                                                    ) {
                                                                        obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                      2
                                    )} de cota-parte profissional parceiro ${profissional} CNPJ ${cnpjParceiro}, emitida no código: ${
                                      result.data[0].Codigo
                                    };\n`;
                                                                    } else {
                                                                        obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                      2
                                    )} de cota-parte profissional parceiro ${profissional} CPF ${cnpjParceiro}, emitida no código: ${
                                      result.data[0].Codigo
                                    };\n`;
                                                                    }
                                                                },
                                                                error: function(result) {
                                                                    toastr.error("Falha na conexão.");
                                                                },
                                                            });
                                                        }
                                                    }
                                                },
                                                error: function(result) {
                                                    toastr.error("Falha na conexão.");
                                                },
                                            });
                                        }
                                    }

                                    /*----------------------------------------------------------------------------------------------------------------------------------------------------*/
                                }
                            }
                            valorComissao = valorComissao + valorComissaoPacoteVenda;
                            $("#valorCupomNotaPacote").html(valorServicos);
                            $("#valorCupomDisplayNotaPacote").val(
                                `${$_CONFIG.MOEDA} ${valorServicos
                  .toFixed(2)
                  .replace(",", ".")}`
                            );
                            $("#servicosPrestadosNotaPacote").html(descricaoServicos);
                            $("#servicosPrestadosDisplayNotaPacote").val(descricaoServicos);
                        }
                    }

                    if (
                        numeroProdutoPacote > 0 &&
                        (geraaproser == 0 || geraaproser == 2)
                    ) {
                        if ($scope.parnfe == 1) {
                            var itensArray = [];
                            var htmlProdNota = "";
                            for (var k = 0; k < $scope.itensPacoteNota.length; k++) {
                                if (
                                    $scope.itensPacoteNota[k].Ser_Codigo == "" &&
                                    $scope.itensPacoteNota[k].Pro_Codigo != ""
                                ) {
                                    citvalorProduto =
                                        $scope.itensPacoteNota[k].PTe_Quantidade *
                                        parseFloat(
                                            $scope.itensPacoteNota[k].PTe_Valor.replace(",", ".")
                                        );
                                    $.ajax({
                                        dataType: "json",
                                        method: "POST",
                                        url: "/pages/cadastros/buscaProdutosv2.php",
                                        async: false,
                                        data: {
                                            procodigo: $scope.itensPacoteNota[k].Pro_Codigo,
                                        },
                                        success: function(result) {
                                            if (
                                                result.data[0].Pro_Cfop == "" ||
                                                result.data[0].Pro_ICMS == "" ||
                                                result.data[0].Pro_Ncm == ""
                                            ) {
                                                erroProduto = 1;
                                                numeroProdutoPacote = 0;
                                                k = $scope.itensPacoteNota.length;
                                            } else {
                                                htmlProdNota += `<tr>
																<td>
																	${result.data[0].Pro_Descricao}
																</td>
																<td>
																	${$scope.itensPacoteNota[k].PTe_Quantidade}
																</td>
																<td>
																	${$scope.itensPacoteNota[k].PTe_Valor}
																</td>
															</tr>`;

                                                if (result.data[0].Pro_CEST == "") {
                                                    itensArray.push({
                                                        valorUnitario: $scope.itensPacoteNota[k].PTe_Valor,
                                                        quantidade: $scope.itensPacoteNota[k].PTe_Quantidade,
                                                        unidadeMedida: "UN",
                                                        cfop: result.data[0].Pro_Cfop,
                                                        descricao: result.data[0].Pro_Descricao,
                                                        ncm: result.data[0].Pro_Ncm,
                                                        codigo: result.data[0].Pro_Codigo,
                                                        ean: result.data[0].Pro_Codigo_Barras,
                                                        eanTributavel: result.data[0].Pro_Codigo_Barras,
                                                        impostos: {
                                                            icms: {
                                                                situacaoTributaria: result.data[0].Pro_ICMS,
                                                                origem: 0,
                                                            },
                                                            pis: {
                                                                situacaoTributaria: result.data[0].Pro_Pis,
                                                            },
                                                            cofins: {
                                                                situacaoTributaria: result.data[0].Pro_Cofins,
                                                            },
                                                        },
                                                    });
                                                } else {
                                                    itensArray.push({
                                                        valorUnitario: $scope.itensPacoteNota[k].PTe_Valor,
                                                        quantidade: $scope.itensPacoteNota[k].PTe_Quantidade,
                                                        unidadeMedida: "UN",
                                                        cfop: result.data[0].Pro_Cfop,
                                                        descricao: result.data[0].Pro_Descricao,
                                                        ncm: result.data[0].Pro_Ncm,
                                                        codigo: result.data[0].Pro_Codigo,
                                                        ean: result.data[0].Pro_Codigo_Barras,
                                                        eanTributavel: result.data[0].Pro_Codigo_Barras,
                                                        cest: result.data[0].Pro_CEST,
                                                        impostos: {
                                                            icms: {
                                                                situacaoTributaria: result.data[0].Pro_ICMS,
                                                                origem: 0,
                                                            },
                                                            pis: {
                                                                situacaoTributaria: result.data[0].Pro_Pis,
                                                            },
                                                            cofins: {
                                                                situacaoTributaria: result.data[0].Pro_Cofins,
                                                            },
                                                        },
                                                    });
                                                }
                                            }
                                        },
                                        error: function(result) {
                                            console.log(result);
                                        },
                                    });
                                    valorProduto = valorProduto + citvalorProduto;
                                }
                            }

                            $scope.produtosNotaPacote = JSON.stringify(itensArray);
                            $("#tableItensNfProdutoNotaPacote").html(htmlProdNota);
                            $("#valorCupomProdNotaPacote").html(valorProduto);
                            $("#valorCupomDisplayProdNotaPacote").val(
                                `${$_CONFIG.MOEDA} ${valorProduto.toFixed(2).replace(",", ".")}`
                            );
                        }
                    }

                    var html = "<option value=''>Estado</option>";
                    for (var i = 0; i < $_CONFIG.LISTA_ESTADO.length; i++) {
                        html +=
                            "<option value='" +
                            $_CONFIG.LISTA_ESTADO[i].Est_Sigla +
                            "'> " +
                            $_CONFIG.LISTA_ESTADO[i].Est_Sigla +
                            "</option>";
                    }

                    $("#cliCupomUFNotaPacote").html(html);
                    $("#cliCupomUFProdNotaPacote").html(html);

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoa.php",
                        data: {
                            tipo: 1,
                        },
                        dataType: "json",
                        success: function(result) {
                            $scope.dadosEmpresaNotaPacote = result.buscaPessoa[0];
                            $("#empresaCNAENotaPacote").val(result.buscaPessoa[0].CNAE);
                            // $("#empresaCodigoNFNotaPacote").val(result.buscaPessoa[0].CodigoNF);
                            // $("#empresaCodigoNFProdNotaPacote").val(result.buscaPessoa[0].CodigoNF);

                            var codigoempresahtml = `<option value="${result.buscaPessoa[0].CodigoNF}">${result.buscaPessoa[0].CNPJ}</option>`;
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/buscaPessoaEnotas.php",
                                dataType: "json",
                                async: false,
                                success: function(result) {
                                    if (result.data.length > 0) {
                                        for (var i = 0; i < result.data.length; i++) {
                                            codigoempresahtml += `<option value="${result.data[i].PEn_Codigo_GW}">${result.data[i].PEn_CNPJ}</option>`;
                                        }
                                    }
                                },
                                error: function(result) {},
                            });

                            $("#empresaCodigoNFNotaPacote").html(codigoempresahtml);
                            $("#empresaCodigoNFProdNotaPacote").html(codigoempresahtml);

                            $("#cidCodigoNotaProdutoPacote").val(
                                result.buscaPessoa[0].Cid_Codigo
                            );
                            $scope.emiteSemClientePacote =
                                result.buscaPessoa[0].Cid_Emissao_SemCliente;
                            $scope.emiteSemCPFPacote =
                                result.buscaPessoa[0].Cid_Emissao_SemCPF;
                            $scope.emiteSemEnderecoPacote =
                                result.buscaPessoa[0].Cid_Emissao_SemEndereco;
                            $("#empresaCSTNotaPacote").val(result.buscaPessoa[0].CST);

                            if ($scope.emiteSemCliente == 0) {
                                $("#nomeObrigatorioNotaPacote").show();
                                $("#nomeObrigatorioProdNotaPacote").show();
                            } else {
                                $("#nomeObrigatorioNotaPacote").hide();
                                $("#nomeObrigatorioProdNotaPacote").hide();
                            }

                            if ($scope.emiteSemCPF == 0) {
                                $("#CPFObrigatorioNotaPacote").show();
                                $("#CPFObrigatorioProdNotaPacote").show();
                            } else {
                                $("#CPFObrigatorioNotaPacote").hide();
                                $("#CPFObrigatorioProdNotaPacote").hide();
                            }

                            if ($scope.emiteSemEndereco == 0) {
                                $("#EstadoObrigatorioNotaPacote").show();
                                $("#CidadeObrigatorioNotaPacote").show();
                                $("#CepObrigatorioNotaPacote").show();
                                $("#BairroObrigatorioNotaPacote").show();
                                $("#NumeroObrigatorioNotaPacote").show();
                                $("#LogradouroObrigatorioNotaPacote").show();

                                $("#EstadoObrigatorioProdNotaPacote").show();
                                $("#CidadeObrigatorioProdNotaPacote").show();
                                $("#CepObrigatorioProdNotaPacote").show();
                                $("#BairroObrigatorioProdNotaPacote").show();
                                $("#LogradouroObrigatorioProdNotaPacote").show();
                                $("#NumeroObrigatorioProdNotaPacote").show();
                            } else {
                                $("#EstadoObrigatorioNotaPacote").hide();
                                $("#CidadeObrigatorioNotaPacote").hide();
                                $("#CepObrigatorioNotaPacote").hide();
                                $("#BairroObrigatorioNotaPacote").hide();
                                $("#LogradouroObrigatorioNotaPacote").hide();
                                $("#NumeroObrigatorioNotaPacote").hide();

                                $("#EstadoObrigatorioProdNotaPacote").hide();
                                $("#CidadeObrigatorioProdNotaPacote").hide();
                                $("#CepObrigatorioProdNotaPacote").hide();
                                $("#BairroObrigatorioProdNotaPacote").hide();
                                $("#LogradouroObrigatorioProdNotaPacote").hide();
                                $("#NumeroObrigatorioProdNotaPacote").hide();
                            }

                            var infoOrigem = "";
                            var infoProcon = "";
                            $("#valorCupomNotaPacote").html(valorServicos);
                            if ($scope.dadosEmpresaNota.Pes_Codigo == 189886) {
                                infoOrigem =
                                    "Fonte: IBPT/FECOMERCIO RJ - 18.1.A Resolução CGSN Nº 137, de 04 de Dezembro de 2017.\n";
                            } else if (
                                $scope.dadosEmpresaNota.Pes_Codigo == 8866546 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 12690404 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 320798 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 7007706 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 3224558 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 13329906 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 1034072 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 20271388 ||
                                $scope.dadosEmpresaNota.Pes_Codigo == 20657910
                            ) {
                                infoOrigem =
                                    "EMISSAO DE NOTA CONFORME RESOLUCAO CGSN N. 140, DE 22 DE MAIO DE 2018\n";
                            } else if ($scope.dadosEmpresaNota.Pes_Codigo == 17774557) {
                                infoOrigem =
                                    "Serviço prestado sob regime de parceria nos termos da Lei nº 13.352/2016\n";
                            }

                            if ($scope.dadosEmpresaNota.Cid_Codigo != "") {
                                $.ajax({
                                    type: "POST",
                                    url: "/pages/cadastros/buscaCidadeProcon.php",
                                    async: false,
                                    data: {
                                        cidcodigo: $scope.dadosEmpresaNota.Cid_Codigo,
                                    },
                                    dataType: "json",
                                    success: function(result) {
                                        if (result.data.length > 0) {
                                            infoProcon = `TELEFONE DO PROCON: ${result.data[0].CPo_Telefone} \n ENDERECO DO PROCON: ${result.data[0].CPo_Endereco}`;
                                        }
                                    },
                                    error: function(result) {
                                        toastr.error("Falha na conexão.");
                                    },
                                });
                            }

                            if ($scope.parnfdescontoparceiro == 1) {
                                if ($scope.parDescriaoSalaoParceiro == 1) {
                                    $("#valorComissaoDisplayNotaPacote").val(0.0);
                                } else {
                                    $("#valorComissaoDisplayNotaPacote").val(
                                        valorComissao.toFixed(2)
                                    );
                                }
                                if (obsParceiro != "") {
                                    $("#cliCupomObsNotaPacote").val(
                                        `${infoOrigem}R$ ${(valorServicos - valorComissao).toFixed(
                      2
                    )} de cota-parte do salão parceiro: ${
                      $scope.dadosEmpresaNotaPacote.CNPJ
                    }\n${obsParceiro} \n\n\n ${infoProcon}`
                                    );
                                } else {
                                    $("#cliCupomObsNotaPacote").val(
                                        `${infoOrigem}\n\n\n ${infoProcon}`
                                    );
                                }
                            } else {
                                $("#valorCupomDisplayNotaPacote").val(0.0);
                                $("#cliCupomObsNotaPacote").val(
                                    `${infoOrigem} \n\n\n ${infoProcon}`
                                );
                            }
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                        },
                    });

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoaNatureza.php",
                        data: {
                            tipo: "1",
                        },
                        dataType: "json",
                        success: function(result) {
                            var naturezalista = "";
                            for (var i = 0; i < result.data.length; i++) {
                                naturezalista += `<option value='${result.data[i].Nat_Codigo_Externo}'  data-nbs='${result.data[i].Nat_NBS}' data-itemlista='${result.data[i].PNa_Codigo_Municipal_Servico}' data-aliquota='${result.data[i].PNa_Aliquota}'>${result.data[i].Nat_Descricao}</option>`;
                            }
                            $("#servicoNaturezaNotaPacote").html(naturezalista);
                            $("#servicoNaturezaNotaPacote").select2();
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                        },
                    });

                    if (cliente != "") {
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaClienteAlteraAgenda.php",
                            data: {
                                cliente: cliente,
                            },
                            dataType: "json",
                            success: function(result) {
                                $scope.dadosClienteNotaPacote = result.result[0];
                                $("#cliCupomNomeNotaPacote").val(result.result[0].Pes_Nome);
                                $("#cliCupomEmailNotaPacote").val(result.result[0].Paf_Email);
                                $("#cliCupomCPFNotaPacote").val(result.result[0].Paf_Cpf);
                                $("#cliCupomCEPNotaPacote").val(result.result[0].Paf_CEP);
                                $("#cliCupomUFNotaPacote").val(result.result[0].Est_Sigla);
                                $("#cliCupomCidadeNotaPacote").val(result.result[0].Cid_Nome);
                                $("#cliCupomBairroNotaPacote").val(result.result[0].Paf_Bairro);
                                $("#cliCupomLogradouroNotaPacote").val(
                                    result.result[0].Paf_Endereco
                                );
                                $("#cliCupomNumeroNotaPacote").val(result.result[0].Paf_Numero);
                                $("#cliCupomComplementoNotaPacote").val(
                                    result.result[0].Paf_Complemento
                                );
                                $("#cliCupomNomeProdNotaPacote").val(result.result[0].Pes_Nome);
                                $("#cliCupomEmailProdNotaPacote").val(
                                    result.result[0].Paf_Email
                                );
                                $("#cliCupomCPFProdNotaPacote").val(result.result[0].Paf_Cpf);
                                $("#cliCupomCEPProdNotaPacote").val(result.result[0].Paf_CEP);
                                $("#cliCupomUFProdNotaPacote").val(result.result[0].Est_Sigla);
                                $("#cliCupomCidadeProdNotaPacote").val(
                                    result.result[0].Cid_Nome
                                );
                                $("#cliCupomBairroProdNotaPacote").val(
                                    result.result[0].Paf_Bairro
                                );
                                $("#cliCupomLogradouroProdNotaPacote").val(
                                    result.result[0].Paf_Endereco
                                );
                                $("#cliCupomNumeroProdNotaPacote").val(
                                    result.result[0].Paf_Numero
                                );
                                $("#cliCupomComplementoProdNotaPacote").val(
                                    result.result[0].Paf_Complemento
                                );
                                $("#cliCupomTelefoneProdNotaPacote").val(
                                    result.result[0].Paf_Celular
                                );
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                            },
                        });
                    }

                    if (
                        numeroServicoPacote > 0 &&
                        (geraaproser == 0 || geraaproser == 1) &&
                        $scope.parnfse == 1
                    ) {
                        $("#generateCupomServicoPacote-modal").modal();
                    }

                    if (
                        numeroProdutoPacote > 0 &&
                        (geraaproser == 0 || geraaproser == 2) &&
                        $scope.parnfe == 1
                    ) {
                        if ($scope.parnfce == 1) {
                            criaNotaConsumidor(ppacodigo, cliente, 1, 1);
                        } else {
                            $("#generateCuponProdutoPacote-modal").modal();
                        }
                    }
                    if (erroProduto == 1) {
                        toastr.warning(
                            'Favor, antes de fazer a emissão dos produtos, preencha todos os dados referentes emissão em "Cadastros > Produtos"'
                        );
                    }
                }
            };

            $("#usaEnderecoNotaPacote").change(() => {
                if ($("#usaEnderecoNotaPacote").val() == 0) {
                    $("#cliCupomCEPNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_CEP
                    );
                    $("#cliCupomUFNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Est_Sigla
                    );
                    $("#cliCupomCidadeNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Cid_Nome
                    );
                    $("#cliCupomBairroNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Bairro
                    );
                    $("#cliCupomLogradouroNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Endereco
                    );
                    $("#cliCupomNumeroNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Numero
                    );
                    $("#cliCupomComplementoNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Complemento
                    );
                } else {
                    $("#cliCupomCEPNotaPacote").val($scope.dadosEmpresaNotaPacote.CEP);
                    $("#cliCupomUFNotaPacote").val($scope.dadosEmpresaNotaPacote.Estado);
                    $("#cliCupomCidadeNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Cidade
                    );
                    $("#cliCupomBairroNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Bairro
                    );
                    $("#cliCupomLogradouroNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Endereco
                    );
                    $("#cliCupomNumeroNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Numero
                    );
                    $("#cliCupomComplementoNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Complemento
                    );
                }
            });

            $("#usaEnderecoProdNotaPacote").change(() => {
                if ($("#usaEnderecoProdNotaPacote").val() == 0) {
                    $("#cliCupomCEPProdNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_CEP
                    );
                    $("#cliCupomUFProdNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Est_Sigla
                    );
                    $("#cliCupomCidadeProdNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Cid_Nome
                    );
                    $("#cliCupomBairroProdNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Bairro
                    );
                    $("#cliCupomLogradouroProdNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Endereco
                    );
                    $("#cliCupomNumeroProdNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Numero
                    );
                    $("#cliCupomComplementoProdNotaPacote").val(
                        $scope.dadosClienteNotaPacote.Paf_Complemento
                    );
                } else {
                    $("#cliCupomCEPProdNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.CEP
                    );
                    $("#cliCupomUFProdNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Estado
                    );
                    $("#cliCupomCidadeProdNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Cidade
                    );
                    $("#cliCupomBairroProdNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Bairro
                    );
                    $("#cliCupomLogradouroProdNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Endereco
                    );
                    $("#cliCupomNumeroProdNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Numero
                    );
                    $("#cliCupomComplementoProdNotaPacote").val(
                        $scope.dadosEmpresaNotaPacote.Complemento
                    );
                }
            });

            $("#usaEnderecoNotaAssinatura").change(() => {
                if ($("#usaEnderecoNotaAssinatura").val() == 0) {
                    $("#cliCupomCEPNotaAssinatura").val(
                        $scope.dadosClienteNotaAssinatura.Paf_CEP
                    );
                    $("#cliCupomUFNotaAssinatura").val(
                        $scope.dadosClienteNotaAssinatura.Est_Sigla
                    );
                    $("#cliCupomCidadeNotaAssinatura").val(
                        $scope.dadosClienteNotaAssinatura.Cid_Nome
                    );
                    $("#cliCupomBairroNotaAssinatura").val(
                        $scope.dadosClienteNotaAssinatura.Paf_Bairro
                    );
                    $("#cliCupomLogradouroNotaAssinatura").val(
                        $scope.dadosClienteNotaAssinatura.Paf_Endereco
                    );
                    $("#cliCupomNumeroNotaAssinatura").val(
                        $scope.dadosClienteNotaAssinatura.Paf_Numero
                    );
                    $("#cliCupomComplementoNotaAssinatura").val(
                        $scope.dadosClienteNotaAssinatura.Paf_Complemento
                    );
                } else {
                    $("#cliCupomCEPNotaAssinatura").val(
                        $scope.dadosEmpresaNotaAssinatura.CEP
                    );
                    $("#cliCupomUFNotaAssinatura").val(
                        $scope.dadosEmpresaNotaAssinatura.Estado
                    );
                    $("#cliCupomCidadeNotaAssinatura").val(
                        $scope.dadosEmpresaNotaAssinatura.Cidade
                    );
                    $("#cliCupomBairroNotaAssinatura").val(
                        $scope.dadosEmpresaNotaAssinatura.Bairro
                    );
                    $("#cliCupomLogradouroNotaAssinatura").val(
                        $scope.dadosEmpresaNotaAssinatura.Endereco
                    );
                    $("#cliCupomNumeroNotaAssinatura").val(
                        $scope.dadosEmpresaNotaAssinatura.Numero
                    );
                    $("#cliCupomComplementoNotaAssinatura").val(
                        $scope.dadosEmpresaNotaAssinatura.Complemento
                    );
                }
            });

            $scope.criaCupomNotaPacote = function() {
                showLoader(true);
                var timegerado = new Date().getTime();
                var proceedNota = 1;
                var msgerro = "";

                if ($scope.emiteSemEnderecoPacote == undefined) {
                    $scope.emiteSemEnderecoPacote = 1;
                } else if ($scope.emiteSemEnderecoPacote == 0) {
                    if (
                        $("#cliCupomUFNotaPacote").val() == "" ||
                        $("#cliCupomUFNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o estado do cliente.";
                    } else if (
                        $("#cliCupomCidadeNotaPacote").val() == "" ||
                        $("#cliCupomCidadeNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe a cidade do cliente.";
                    } else if (
                        $("#cliCupomCEPNotaPacote").val() == "" ||
                        $("#cliCupomCEPNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o CEP do cliente.";
                    } else if (
                        $("#cliCupomBairroNotaPacote").val() == "" ||
                        $("#cliCupomBairroNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o bairro do cliente.";
                    } else if (
                        $("#cliCupomLogradouroNotaPacote").val() == "" ||
                        $("#cliCupomLogradouroNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o logradouro do cliente.";
                    } else if (
                        $("#cliCupomNumeroNotaPacote").val() == "" ||
                        $("#cliCupomNumeroNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o numero do endereço do cliente.";
                    }
                }

                if ($scope.emiteSemCPFPacote == undefined) {
                    $scope.emiteSemCPFPacote = 1;
                } else if ($scope.emiteSemCPFPacote == 0) {
                    if (
                        $("#cliCupomCPFNotaPacote").val() == "" ||
                        $("#cliCupomCPFNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o CPF do tomador do serviço. Favor informe o CPF do cliente.";
                    }
                }

                if ($scope.emiteSemClientePacote == undefined) {
                    $scope.emiteSemClientePacote = 1;
                } else if ($scope.emiteSemClientePacote == 0) {
                    if (
                        $("#cliCupomNomeNotaPacote").val() == "" ||
                        $("#cliCupomNomeNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o nome do tomador do serviço. Favor informe o nome do cliente.";
                    }
                }

                if (
                    $("#enviaCupomEmailNotaPacote").val() == "1" &&
                    $("#cliCupomEmailNotaPacote").val() == ""
                ) {
                    proceedNota = 0;
                    msgerro = "Informe um e-mail pra o envio a emissão.";
                }

                if (proceedNota == 1) {
                    if (
                        $("#servicoNaturezaNotaPacote option:selected").get(0) != undefined
                    ) {
                        if (
                            $("#empresaCodigoNFNotaPacote").val() != "" &&
                            $("#empresaCodigoNFNotaPacote").val() != undefined
                        ) {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereNotaFiscalPacote.php",
                                data: {
                                    ppacodigo: $("#ppaCodigoNotaPacote").val(),
                                    idEmpresa: $("#empresaCodigoNFNotaPacote").val(),
                                    idExternoNota: $("#ppaCodigoNotaPacote").val() + "_" + timegerado,
                                    enviarEmail: $("#enviaCupomEmailNotaPacote").val(),
                                    nomeCliente: $("#cliCupomNomeNotaPacote").val(),
                                    emailCliente: $("#cliCupomEmailNotaPacote").val(),
                                    cpfCliente: $("#cliCupomCPFNotaPacote").val(),
                                    logradouroCliente: $("#cliCupomLogradouroNotaPacote").val(),
                                    numeroCliente: $("#cliCupomNumeroNotaPacote").val(),
                                    complementoCliente: $("#cliCupomComplementoNotaPacote").val(),
                                    bairroCliente: $("#cliCupomBairroNotaPacote").val(),
                                    cepCliente: $("#cliCupomCEPNotaPacote").val(),
                                    ufCliente: $("#cliCupomUFNotaPacote").val(),
                                    cidadeCliente: $("#cliCupomCidadeNotaPacote").val(),
                                    descricaoServico: $("#servicosPrestadosNotaPacote").html(),
                                    aliquotaIss: parseFloat(
                                        $("#servicoNaturezaNotaPacote option:selected").get(0)
                                        .dataset.aliquota
                                    ),
                                    itemServico: $(
                                        "#servicoNaturezaNotaPacote option:selected"
                                    ).get(0).dataset.itemlista,
                                    cnae: $("#empresaCNAENotaPacote").val(),
                                    codigoServico: $("#servicoNaturezaNotaPacote").val(),
                                    valorTotal: parseFloat(
                                        $("#valorCupomNotaPacote")
                                        .html()
                                        .replace($_CONFIG.MOEDA, "")
                                        .replace(",", ".")
                                    ),
                                    timegerado: timegerado,
                                    valorClss: parseFloat(
                                        $("#valorClssNotaPacote").html().replace(",", ".")
                                    ),
                                    valorPis: parseFloat(
                                        $("#valorPisNotaPacote").html().replace(",", ".")
                                    ),
                                    valorCofins: parseFloat(
                                        $("#valorCofinsNotaPacote").html().replace(",", ".")
                                    ),
                                    valorInss: parseFloat(
                                        $("#valorInssNotaPacote").html().replace(",", ".")
                                    ),
                                    valorIr: parseFloat(
                                        $("#valorIrNotaPacote").html().replace(",", ".")
                                    ),
                                    observacao: $("#cliCupomObsNotaPacote").val(),
                                    tipoPessoaNotaPacote: $("#tipoPessoaNotaPacote").val(),
                                    deducoes: parseFloat(
                                        $("#valorComissaoDisplayNotaPacote").val().replace(",", ".")
                                    ),
                                    descricaocidadeservico: $(
                                        "#servicoNaturezaNotaPacote option:selected"
                                    ).get(0).text,
                                    metadados: "",
                                    codigoNBS: $(
                                        "#servicoNaturezaNotaPacote option:selected"
                                    ).get(0).dataset.nbs,
                                },
                                dataType: "json",
                                success: function(result) {
                                    showLoader(false);
                                    if (result.data[0].erro == 1) {
                                        toastr.warning(result.data[0].resultado);
                                    } else {
                                        toastr.warning(result.resultNota.erronf);
                                        if (
                                            result.resultNota.nfid == "" ||
                                            result.resultNota.nfid == undefined
                                        ) {
                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/removePacoteNotaFiscal.php",
                                                data: {
                                                    pnfcodigoexterno: $("#ppaCodigoNotaPacote").val() + "_" + timegerado,
                                                },
                                                dataType: "json",
                                                success: function(data) {
                                                    if (data.data.erro != undefined) {
                                                        toastr.error(data.data.resultado);
                                                    } else {
                                                        if (data.data[0].erro == "0") {
                                                            toastr.success(data.data[0].resultado);
                                                        } else {
                                                            toastr.error(data.data[0].resultado);
                                                        }
                                                    }
                                                },
                                                error: function(result) {
                                                    toastr.error("Falha na conexão.");
                                                },
                                            });
                                        }
                                        $("#generateCupomServicoPacote-modal").modal("hide");
                                    }
                                },
                                error: function(result) {
                                    showLoader(false);
                                    toastr.error("Falha na conexão.");
                                },
                            });
                        } else {
                            showLoader(false);
                            toastr.error("Informe o ID da empresa");
                        }
                    } else {
                        showLoader(false);
                        toastr.error("Selecione o Serviço");
                    }
                } else {
                    showLoader(false);
                    toastr.error(msgerro);
                }
            };

            $scope.criaCupomProdPacote = function() {
                showLoader(true);
                var timegerado = new Date().getTime();
                var proceedNota = 1;
                var msgerro = "";

                if ($scope.emiteSemEnderecoPacote == undefined) {
                    $scope.emiteSemEnderecoPacote = 1;
                } else if ($scope.emiteSemEnderecoPacote == 0) {
                    if (
                        $("#cliCupomUFProdNotaPacote").val() == "" ||
                        $("#cliCupomUFProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o estado do cliente.";
                    } else if (
                        $("#cliCupomCidadeProdNotaPacote").val() == "" ||
                        $("#cliCupomCidadeProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe a cidade do cliente.";
                    } else if (
                        $("#cliCupomCEPProdNotaPacote").val() == "" ||
                        $("#cliCupomCEPProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o CEP do cliente.";
                    } else if (
                        $("#cliCupomBairroProdNotaPacote").val() == "" ||
                        $("#cliCupomBairroProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o bairro do cliente.";
                    } else if (
                        $("#cliCupomLogradouroProdNotaPacote").val() == "" ||
                        $("#cliCupomLogradouroProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o logradouro do cliente.";
                    } else if (
                        $("#cliCupomNumeroProdNotaPacote").val() == "" ||
                        $("#cliCupomNumeroProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o numero do endereço do cliente.";
                    }
                }

                if ($scope.emiteSemCPFPacote == undefined) {
                    $scope.emiteSemCPFPacote = 1;
                } else if ($scope.emiteSemCPFPacote == 0) {
                    if (
                        $("#cliCupomCPFProdNotaPacote").val() == "" ||
                        $("#cliCupomCPFProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o CPF do tomador do serviço. Favor informe o CPF do cliente.";
                    }
                }

                if ($scope.emiteSemClientePacote == undefined) {
                    $scope.emiteSemClientePacote = 1;
                } else if ($scope.emiteSemClientePacote == 0) {
                    if (
                        $("#cliCupomNomeProdNotaPacote").val() == "" ||
                        $("#cliCupomNomeProdNotaPacote").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o nome do tomador do serviço. Favor informe o nome do cliente.";
                    }
                }

                if (
                    $("#enviaCupomEmailProdNotaPacote").val() == "1" &&
                    $("#cliCupomEmailProdNotaPacote").val() == ""
                ) {
                    proceedNota = 0;
                    msgerro = "Informe um e-mail pra o envio a emissão.";
                }

                if (proceedNota == 1) {
                    var infoProcon = "";
                    if ($("#cidCodigoNotaProdutoPacote").val() != "") {
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaCidadeProcon.php",
                            async: false,
                            data: {
                                cidcodigo: $("#cidCodigoEmpresaNotaProduto").val(),
                            },
                            dataType: "json",
                            success: function(result) {
                                if (result.data.length > 0) {
                                    infoProcon = `TELEFONE DO PROCON: ${result.data[0].CPo_Telefone} \n ENDERECO DO PROCON: ${result.data[0].CPo_Endereco}`;
                                }
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                            },
                        });
                    }

                    $.ajax({
                        dataType: "json",
                        url: "/pages/cadastros/buscaPessoaPacoteDetalhesv2.php",
                        async: false,
                        data: {
                            tipo: 2,
                            ppacodigo: $("#ppaCodigoNotaPacoteProduto").val(),
                        },
                        success: function(data) {
                            if (data.data[0].TPa_Descricao != "") {
                                $scope.tpapagamentopacote = data.data[0].TPa_Descricao;
                                if (data.data[0].TBa_Descricao != "") {
                                    $scope.tbapagamentopacote = data.data[0].TBa_Descricao;
                                }
                            }
                        },
                        error: function() {
                            swal("Falha na conexão.", "", "error");
                        },
                    });

                    if ($scope.tpapagamentopacote != "") {
                        $scope.arrPagamentopacote = [];
                        var descricaoPagamentopacote = "";
                        $scope.valorPagamentoNotapacote = parseFloat(
                            $("#valorCupomDisplayProdNotaPacote")
                            .val()
                            .replace($_CONFIG.MOEDA, "")
                            .replace(" ", "")
                        );
                        var pushPagamentopacote = "";
                        if (
                            $scope.tpapagamentopacote == "Dinheiro" ||
                            $scope.tpapagamentopacote == "dinheiro"
                        ) {
                            pushPagamentopacote = "Dinheiro";
                        } else if (
                            $scope.tpapagamentopacote == "Cartão de Crédito" ||
                            $scope.tpapagamentopacote == "cartão de crédito"
                        ) {
                            pushPagamentopacote = "CartaoDeCredito";
                        } else if (
                            $scope.tpapagamentopacote == "Cartão de Débito" ||
                            $scope.tpapagamentopacote == "cartão de débito"
                        ) {
                            pushPagamentopacote = "CartaoDeDebito";
                        } else if (
                            $scope.tpapagamentopacote == "Cheque" ||
                            $scope.tpapagamentopacote == "cheque"
                        ) {
                            pushPagamentopacote = "Cheque";
                        } else if (
                            $scope.tpapagamentopacote == "Boleto" ||
                            $scope.tpapagamentopacote == "boleto"
                        ) {
                            pushPagamentopacote = "BoletoBancario";
                        } else if (
                            $scope.tpapagamentopacote == "PIX" ||
                            $scope.tpapagamentopacote == "pix" ||
                            $scope.tpapagamentopacote == "Pix"
                        ) {
                            pushPagamentopacote = "PagamentoInstantaneoPix";
                        } else if (
                            $scope.tpapagamentopacote == "Resgate de Pontos" ||
                            $scope.tpapagamentopacote == "resgate de pontos"
                        ) {
                            pushPagamentopacote = "ProgramaFidelidadeCashbackCarteiraVirtual";
                        } else {
                            descricaoPagamentopacote = $scope.tpapagamentopacote;
                            pushPagamentopacote = "Outros";
                        }

                        if (descricaoPagamentopacote != "") {
                            $scope.arrPagamentopacote.push({
                                tipo: pushPagamentopacote,
                                valor: $scope.valorPagamentoNotapacote,
                                descricao: descricaoPagamentopacote,
                            });
                        } else {
                            if (
                                pushPagamentopacote == "CartaoDeCredito" ||
                                pushPagamentopacote == "CartaoDeDebito"
                            ) {
                                $scope.arrPagamentopacote.push({
                                    tipo: pushPagamentopacote,
                                    valor: $scope.valorPagamentoNotapacote,
                                    credenciadoraCartao: {
                                        tipoIntegracaoPagamento: "NaoIntegradoAoSistemaDeGestao",
                                    },
                                });
                            } else {
                                $scope.arrPagamentopacote.push({
                                    tipo: pushPagamentopacote,
                                    valor: $scope.valorPagamentoNotapacote,
                                });
                            }
                        }
                    } else {
                        $scope.arrPagamentopacote.push({
                            tipo: "Dinheiro",
                            valor: $scope.valorPagamentoNotapacote,
                        });
                    }

                    if (
                        $("#empresaCodigoNFProdNotaPacote").val() != "" &&
                        $("#empresaCodigoNFProdNotaPacote").val() != undefined
                    ) {
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/insereNotaFiscalPacoteProduto.php",
                            data: {
                                ppacodigo: $("#ppaCodigoNotaPacoteProduto").val(),
                                idEmpresa: $("#empresaCodigoNFProdNotaPacote").val(),
                                idExternoNota: $("#ppaCodigoNotaPacoteProduto").val() + "_" + timegerado,
                                enviarEmail: $("#enviaCupomEmailProdNotaPacote").val(),
                                nomeCliente: $("#cliCupomNomeProdNotaPacote").val(),
                                telefoneCliente: $("#cliCupomTelefoneProdNotaPacote").val(),
                                emailCliente: $("#cliCupomEmailProdNotaPacote").val(),
                                cpfCliente: $("#cliCupomCPFProdNotaPacote").val(),
                                logradouroCliente: $("#cliCupomLogradouroProdNotaPacote").val(),
                                numeroCliente: $("#cliCupomNumeroProdNotaPacote").val(),
                                complementoCliente: $(
                                    "#cliCupomComplementoProdNotaPacote"
                                ).val(),
                                bairroCliente: $("#cliCupomBairroProdNotaPacote").val(),
                                cepCliente: $("#cliCupomCEPProdNotaPacote").val(),
                                ufCliente: $("#cliCupomUFProdNotaPacote").val(),
                                cidadeCliente: $("#cliCupomCidadeProdNotaPacote").val(),
                                item: $scope.produtosNotaPacote,
                                timegerado: timegerado,
                                tipoemissao: 1,
                                pagamento: JSON.stringify($scope.arrPagamentopacote),
                                informacaoAdicional: infoProcon,
                                natureza: $("#naturezaNotaProdutoPacote").val(),
                            },
                            dataType: "json",
                            success: function(result) {
                                showLoader(false);
                                if (result.data[0].erro == 1) {
                                    toastr.warning(result.data[0].resultado);
                                } else {
                                    toastr.warning(result.resultNota.erronf);
                                    if (
                                        result.resultNota.nfid == "" ||
                                        result.resultNota.nfid == undefined
                                    ) {
                                        $.ajax({
                                            type: "POST",
                                            url: "/pages/cadastros/removePacoteNotaFiscal.php",
                                            data: {
                                                pnfcodigoexterno: $("#ppaCodigoNotaPacote").val() + "_" + timegerado,
                                            },
                                            dataType: "json",
                                            success: function(data) {
                                                if (data.data.erro != undefined) {
                                                    toastr.error(data.data.resultado);
                                                } else {
                                                    if (data.data[0].erro == "0") {
                                                        toastr.success(data.data[0].resultado);
                                                    } else {
                                                        toastr.error(data.data[0].resultado);
                                                    }
                                                }
                                            },
                                            error: function(result) {
                                                toastr.error("Falha na conexão.");
                                            },
                                        });
                                    }
                                    $("#generateCuponProdutoPacote-modal").modal("hide");
                                }
                            },
                            error: function(result) {
                                showLoader(false);
                                toastr.error("Falha na conexão.");
                            },
                        });
                    } else {
                        showLoader(false);
                        toastr.error("Informe o ID da empresa");
                    }
                } else {
                    showLoader(false);
                    toastr.error(msgerro);
                }
            };

            $scope.displayModalJornada = function() {
                $("#divTabelaJornada").hide();
                $("#divBotaoMaisJornada").hide();
                $("#addHorarioJornada").prop("disabled", true);
                $.ajax({
                    dataType: "json",
                    url: "pages/cadastros/buscaProfissionalSelect.php",
                    success: function(data) {
                        var profissional = "";
                        profissional +=
                            '<option  value="">' +
                            $_CONFIG.language.profissional +
                            "</option>";
                        for (var i = 0; i < data.profissionais.length; i++) {
                            var codigo = data.profissionais[i].Pes_Codigo;
                            var nome = data.profissionais[i].Pes_Nome;
                            profissional +=
                                '<option  value="' + codigo + '">' + nome + "</option>";
                        }
                        $("#profissionalJornadaSelect").html(profissional);
                    },
                });

                var stepTimePicker = "";

                if ($_CONFIG.TEMPOPADRAO == "40") {
                    stepTimePicker = "20";
                } else if ($_CONFIG.TEMPOPADRAO == "45") {
                    stepTimePicker = "15";
                } else {
                    stepTimePicker = $_CONFIG.TEMPOPADRAO;
                }

                $(".timepicker").timepicker({
                    timeFormat: "H:i",
                    maxTime: "23",
                    minTime: "01",
                    forceRoundTime: true,
                    step: parseInt(stepTimePicker),
                });

                $("#jornadaProfissional-modal").modal();
            };

            $scope.buscaPessoaJornadaLista = function() {
                if ($("#profissionalJornadaSelect").val() == "") {
                    $("#addHorarioJornada").prop("disabled", true);
                } else {
                    $("#addHorarioJornada").prop("disabled", false);
                }

                if ($("#profissionalJornadaSelect").val() != "") {
                    $("#divTabelaJornada").show();
                    $("#divBotaoMaisJornada").show();
                    $("#pesCodigoJornadaInsere").val(
                        $("#profissionalJornadaSelect").val()
                    );
                    $("#pesCodigoJornada").val($("#profissionalJornadaSelect").val());

                    if (typeof tabelaListaJornada != "undefined") {
                        tabelaListaJornada.destroy();
                        $("#tabelaJornadaProfissional tbody").unbind("click");
                    }
                    tabelaListaJornada = $("#tabelaJornadaProfissional").DataTable({
                        ajax: {
                            url: "/pages/cadastros/buscaPessoaJornada.php",
                            method: "POST",
                            data: function(d) {
                                d.pescodigo = $("#profissionalJornadaSelect").val();
                            },
                        },
                        lengthMenu: [10],
                        scrollX: isPortrait,

                        stateSaveCallback: function(settings, data) {
                            data.order = [];
                            localStorage.setItem(
                                "DataTables_" + settings.sInstance,
                                JSON.stringify(data)
                            );
                        },
                        stateLoadCallback: function(settings) {
                            return JSON.parse(
                                localStorage.getItem("DataTables_" + settings.sInstance)
                            );
                        },
                        stateSave: true,
                        fnRowCallback: function(nRow, aData) {
                            var $nRow = $(nRow);
                            var dia = aData.PJo_Dia;

                            switch (dia) {
                                case "1":
                                    $nRow.find("td.Dia").html("Domingo");
                                    break;
                                case "2":
                                    $nRow.find("td.Dia").html("Segunda-Feira");
                                    break;
                                case "3":
                                    $nRow.find("td.Dia").html("Terça-Feira");
                                    break;
                                case "4":
                                    $nRow.find("td.Dia").html("Quarta-Feira");
                                    break;
                                case "5":
                                    $nRow.find("td.Dia").html("Quinta-Feira");
                                    break;
                                case "6":
                                    $nRow.find("td.Dia").html("Sexta-Feira");
                                    break;
                                case "7":
                                    $nRow.find("td.Dia").html("Sábado");
                                    break;
                            }
                        },

                        columns: [{
                                data: "PJo_Dia",
                                title: "Dia",
                                class: "Dia jornadamobile",
                                width: "15%",
                            },
                            {
                                data: "PJo_Hor_Ini1",
                                title: "Hora inicio 1",
                                class: "jornadamobile",
                                width: "10%",
                            },
                            {
                                data: "PJo_Hor_Fim1",
                                title: "Hora fim 1",
                                class: "jornadamobile",
                                width: "10%",
                            },
                            {
                                data: "PJo_Hor_Ini2",
                                title: "Hora inicio 2",
                                class: "jornadamobile",
                                width: "10%",
                            },
                            {
                                data: "PJo_Hor_Fim2",
                                title: "Hora fim 2",
                                class: "jornadamobile",
                                width: "10%",
                            },
                            {
                                title: "Editar",
                                class: "editarJornada-control",
                                orderable: false,
                                data: null,
                                defaultContent: '<button class="btn btn-success btn-xs " style="margin:auto"> <i class="fa fa-pencil"></i></button>',
                                width: "5%",
                            },
                            {
                                title: "Remover",
                                class: "removerJornada-control",
                                orderable: false,
                                data: null,
                                defaultContent: '<button class="btn btn-danger btn-xs " style="margin:auto"> <i class="fa fa-trash"></i></button>',
                                width: "5%",
                            },
                        ],
                        ordering: false,
                        language: {
                            url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                        },
                    });
                    $("#tabelaJornadaProfissional tbody").on(
                        "click",
                        "td.editarJornada-control",
                        function() {
                            var tr = $(this).closest("tr");
                            var row = tabelaListaJornada.row(tr);
                            var data = row.data();
                            $("#pesCodigoJornada").val(data.Pes_Codigo);
                            $("#jornadaDiaSemana").val(data.PJo_Dia);
                            $("#jornadaHoraIni1").val(data.PJo_Hor_Ini1);
                            $("#jornadaHoraFim1").val(data.PJo_Hor_Fim1);
                            $("#jornadaHoraIni2").val(data.PJo_Hor_Ini2);
                            $("#jornadaHoraFim2").val(data.PJo_Hor_Fim2);
                            $("#editarJornadaProfissional-modal").modal();
                        }
                    );

                    if (isMobile) {
                        $("#tabelaJornadaProfissional tbody").on(
                            "click",
                            "td.jornadamobile",
                            function() {
                                var row = tabelaListaJornada.row($(this));
                                var data = row.data();
                                $("#pesCodigoJornada").val(data.Pes_Codigo);
                                $("#jornadaDiaSemana").val(data.PJo_Dia);
                                $("#jornadaHoraIni1").val(data.PJo_Hor_Ini1);
                                $("#jornadaHoraFim1").val(data.PJo_Hor_Fim1);
                                $("#jornadaHoraIni2").val(data.PJo_Hor_Ini2);
                                $("#jornadaHoraFim2").val(data.PJo_Hor_Fim2);
                                $("#editarJornadaProfissional-modal").modal();
                            }
                        );
                    }

                    $("#tabelaJornadaProfissional tbody").on(
                        "click",
                        "td.removerJornada-control",
                        function() {
                            var tr = $(this).closest("tr");
                            var row = tabelaListaJornada.row(tr);
                            var data = row.data();
                            swal({
                                    title: $_CONFIG.language.mensagens.excluir_titulo,
                                    text: $_CONFIG.language.mensagens.excluir_jornada,
                                    type: "warning",
                                    showCancelButton: true,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: $_CONFIG.language.sim,
                                    cancelButtonText: $_CONFIG.language.nao,
                                },
                                function() {
                                    showLoader(true);
                                    $.ajax({
                                        dataType: "html",
                                        url: "/pages/cadastros/removeProfissionalJornada.php",
                                        data: {
                                            pescodigo: data.Pes_Codigo,
                                            dia: data.PJo_Dia,
                                        },
                                        success: (data) => {
                                            if (data == "0") {
                                                toastr.success("Jornada Excluida com Sucesso.");
                                                tabelaListaJornada.ajax.reload();
                                            } else {
                                                toastr.error(
                                                    data,
                                                    $_CONFIG.language.mensagens.falha_excluir
                                                );
                                            }
                                            showLoader(false);
                                        },
                                        error: () => {
                                            toastr.error($_CONFIG.language.errors.falha_conexao);
                                            showLoader(false);
                                        },
                                    });
                                }
                            );
                        }
                    );
                } else {
                    toastr.warning("Selecione um profissional");
                }
            };

            $scope.novoHorarioTrabalho = function() {
                $("#jornadaHoraIni1Insere").val("");
                $("#jornadaHoraFim1Insere").val("");
                $("#jornadaHoraIni2Insere").val("");
                $("#jornadaHoraFim2Insere").val("");
                $("#jornadaDiaSemanaInsere").val(1);

                $("#cadastrarJornadaProfissional-modal").modal();
            };

            $scope.InsereJornadaProfissional = function() {
                $("#jornadaDiaSemana").prop("disabled", false);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereProfissionalJornada.php",
                    dataType: "json",
                    data: {
                        pjProfissional: $("#pesCodigoJornadaInsere").val(),
                        pjHoraIni1: $("#jornadaHoraIni1Insere").val(),
                        pjHoraFim1: $("#jornadaHoraFim1Insere").val(),
                        pjDiaSemana: [$("#jornadaDiaSemanaInsere").val()],
                        pjHoraIni2: $("#jornadaHoraIni2Insere").val(),
                        pjHoraFim2: $("#jornadaHoraFim2Insere").val(),
                    },
                    success: function(result) {
                        if (result.insereProfissionalJornada[0].erro == 1) {
                            toastr.error(result.insereProfissionalJornada[0].resultado);
                        } else {
                            $("#cadastrarJornadaProfissional-modal").modal("hide");
                            tabelaListaJornada.ajax.reload();
                            toastr.success(result.insereProfissionalJornada[0].resultado);
                        }
                    },
                    error: function(result) {
                        toastr.error("Falha de Conexão");
                    },
                });
            };

            $scope.edtJornadaProfissional = function() {
                $("#jornadaDiaSemana").prop("disabled", false);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/alteraProfissionalJornada.php",
                    dataType: "json",
                    data: {
                        pjCodigo: $("#pesCodigoJornada").val(),
                        pjHoraIni1: $("#jornadaHoraIni1").val(),
                        pjHoraFim1: $("#jornadaHoraFim1").val(),
                        pjDiaId: $("#jornadaDiaSemana").val(),
                        pjHoraIni2: $("#jornadaHoraIni2").val(),
                        pjHoraFim2: $("#jornadaHoraFim2").val(),
                    },
                    success: function(result) {
                        if (result.alteraProfissionalJornada[0].erro == 1) {
                            toastr.error(result.alteraProfissionalJornada[0].resultado);
                            $("#jornadaDiaSemana").prop("disabled", true);
                        } else {
                            $("#editarJornadaProfissional-modal").modal("hide");
                            tabelaListaJornada.ajax.reload();
                            toastr.success(result.alteraProfissionalJornada[0].resultado);
                            $("#jornadaDiaSemana").prop("disabled", true);
                        }
                    },
                    error: function(result) {
                        toastr.error("Falha de Conexão");
                    },
                });
            };

            $scope.enviaEmailClienteLGPD = function(codigo) {
                swal({
                        title: "Enviar e-mail de consentimento dos termos de uso?",
                        type: "info",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: $_CONFIG.language.sim,
                        cancelButtonText: $_CONFIG.language.nao,
                        closeOnConfirm: true,
                    },
                    function(isConfirm) {
                        if (isConfirm) {
                            $.ajax({
                                dataType: "json",
                                url: "/pages/cadastros/buscaEmailLGPD.php",
                                method: "POST",
                                data: {
                                    pescodigo: codigo,
                                    tipo: 1,
                                },
                                success: function(result) {
                                    if (result.data[0].erro == "0") {
                                        toastr.success(result.data[0].resultado);
                                    } else {
                                        swal(result.data[0].resultado);
                                    }
                                    showLoader(false);
                                },
                                error: function(result) {
                                    swal("Falha na conexão.", "", "error");
                                    showLoader(false);
                                },
                            });
                        } else {
                            showLoader(false);
                        }
                        showLoader(false);
                    }
                );
            };

            $scope.addFavorito = (nome, url, icon, path) => {
                var localFav = localStorage.getItem("favoritos_" + $_CONFIG.CODUSUARIO);

                if (localFav != undefined && localFav != "") {
                    var objFav = JSON.parse(localFav);
                } else {
                    var objFav = [];
                }

                objFav.push({
                    name: nome,
                    url: url,
                    icon: icon,
                    path: path,
                });
                localStorage.setItem(
                    "favoritos_" + $_CONFIG.CODUSUARIO,
                    JSON.stringify(objFav)
                );

                $scope.favoritos = objFav;
                $scope.$apply();
            };

            $scope.removeFavorito = (url, origin) => {
                var localFav = localStorage.getItem("favoritos_" + $_CONFIG.CODUSUARIO);

                if (localFav != undefined && localFav != "") {
                    var objFav = JSON.parse(localFav);
                } else {
                    var objFav = [];
                }

                var newObjFav = _.without(
                    objFav,
                    _.findWhere(objFav, {
                        url: url,
                    })
                );
                localStorage.setItem(
                    "favoritos_" + $_CONFIG.CODUSUARIO,
                    JSON.stringify(newObjFav)
                );

                $scope.favoritos = newObjFav;

                $('.control-menu[ui-sref="' + url + '"]').removeClass("has-favorite");

                if (origin == 1) {
                    $scope.$apply();
                }
            };

            $scope.limpaFavoritos = () => {
                swal({
                        title: $_CONFIG.language.mensagens.excluir_titulo,
                        text: "Deseja limpar os favoritos?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: $_CONFIG.language.sim,
                        cancelButtonText: $_CONFIG.language.nao,
                    },
                    function() {
                        localStorage.removeItem("favoritos_" + $_CONFIG.CODUSUARIO);
                        $scope.favoritos = [];
                        $scope.$apply();
                        $(".has-favorite").removeClass("has-favorite");
                        toastr.success("Favoritos removidos.");
                    }
                );
            };

            $scope.changeRoute = (url) => {
                $state.go(url);
            };

            $scope.favoritos.forEach((favorito) => {
                if ($('.control-menu[ui-sref="' + favorito.url + '"]').length > 0) {
                    $('.control-menu[ui-sref="' + favorito.url + '"]').addClass(
                        "has-favorite"
                    );
                }
            });

            $.contextMenu({
                selector: ".has-favorite",
                callback: (key, options) => {
                    if (key == "favorito") {
                        var opt = options.$trigger[0];
                        var urlFav = opt.getAttribute("ui-sref");
                        $scope.removeFavorito(urlFav, 1);
                    }
                },
                items: {
                    favorito: {
                        name: "Tirar dos Favoritos",
                        icon: "fa-star",
                    },
                },
            });

            $.contextMenu({
                selector: ".control-menu",
                callback: (key, options) => {
                    if (key == "favorito") {
                        $(options.$trigger[0]).addClass("has-favorite");
                        var opt = options.$trigger[0];
                        var nameFav = opt.text.trim();
                        var urlFav = opt.getAttribute("ui-sref");

                        var pathFav = "";

                        var iconFav = "";
                        if ($(opt.parentElement.parentElement).hasClass("treeview-menu")) {
                            var father = opt.parentElement.parentElement;

                            if (
                                $(father.parentElement.parentElement).hasClass("treeview-menu")
                            ) {
                                iconFav =
                                    father.parentElement.parentElement.parentElement.getElementsByTagName(
                                        "i"
                                    )[0].className;
                                pathFav =
                                    father.parentElement.parentElement.parentElement
                                    .getElementsByTagName("a")[0]
                                    .text.trim() +
                                    " ► " +
                                    father.parentElement.getElementsByTagName("a")[0].text.trim();
                            } else {
                                pathFav = opt.parentElement.parentElement.parentElement
                                    .getElementsByTagName("a")[0]
                                    .text.trim();
                                iconFav =
                                    opt.parentElement.parentElement.parentElement.getElementsByTagName(
                                        "i"
                                    )[0].className;
                            }
                        } else {
                            iconFav = opt.getElementsByTagName("i")[0].className;
                        }

                        pathFav = pathFav + " ► " + nameFav;

                        $scope.addFavorito(nameFav, urlFav, iconFav, pathFav);
                    }
                },
                items: {
                    favorito: {
                        name: "Favorito",
                        icon: "fa-star-o",
                    },
                },
            });

            $scope.verDetalhesPacote = function(ppacodigo) {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaPacotePessoaDetalhes.php",
                    data: {
                        ppacodigo: ppacodigo,
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.result.length > 0) {
                            var html = "";
                            for (var i = 0; i < result.result.length; i++) {
                                valores = result.result[i];
                                datahora = valores.PPD_Dat_Cadastro.split(" ");
                                var classIcon = "";
                                var descricao = "";
                                if (valores.Tipo == "Produto") {
                                    classIcon = "fa fa-shopping-cart bg-green";
                                    descricao = valores.Pro_Descricao;
                                } else {
                                    classIcon = "fa fa-scissors bg-blue";
                                    descricao = valores.Ser_Descricao;
                                }

                                html += '<li class="time-label">';
                                html += '<span class="bg-teal-dark">';
                                html += datahora[0];
                                html += "</span>";
                                html += "</li>";
                                html += "<li>";
                                html += '<i class="' + classIcon + '"></i>';
                                html += '<div class="timeline-item">';
                                html +=
                                    '<span class="time"><i class="fa fa-clock-o"></i> ' +
                                    datahora[1] +
                                    " </span>";
                                html +=
                                    '<h3 class="timeline-header"><strong>' +
                                    descricao +
                                    "</strong></h3>";
                                html += '<div class="timeline-body">';
                                html += "<strong>Profissional:</strong> " + valores.Pes_Nome;
                                html +=
                                    "<p><strong>Quantidade:</strong> " +
                                    valores.CIt_Quantidade +
                                    "</p>";
                                html += "</div>";
                                html += '<div class="timeline-footer">';
                                html +=
                                    '<a class="btn btn-primary btn-xs" ng-click="showComandaPacote(' +
                                    valores.Com_Codigo +
                                    ');">Ver Comanda</a>';
                                html += "</div>";
                                html += "</div>";
                                html += "</li>";
                            }
                            $("#timelinePacote").html(html);
                            $compile($("#timelinePacote"))($scope);
                            $("#infoPacotePessoaDetalhes-modal").modal();
                        } else {
                            html = '<li class="time-label">';
                            html += "</li>";
                            html += "<li>";
                            html += '<i class="fa fa-ban"></i>';
                            html += '<div class="timeline-item">';
                            html += '<span class="time"></span>';
                            html +=
                                '<h3 class="timeline-header"><strong>Sem movimentações neste pacote.</strong></h3>';
                            html += "</div>";
                            html += "</li>";
                            $("#timelinePacote").html(html);
                            $("#infoPacotePessoaDetalhes-modal").modal();
                        }
                        var htmlitens = "";
                        $("#showPacItens").removeClass("collapse in");
                        $("#showPacItens").addClass("collapse");
                        $("#iconCaret").removeClass("fa-caret-up");
                        $("#iconCaret").addClass("fa-caret-down");
                        $.ajax({
                            type: "GET",
                            url: "/pages/cadastros/buscaPessoaPacoteDetalhesv2.php",
                            data: {
                                ppacodigo: ppacodigo,
                                tipo: 1,
                            },
                            dataType: "json",
                            success: function(data) {
                                for (var i = 0; i < data.data.length; i++) {
                                    htmlitens += `${data.data[i].ItemDescricao} <br>&nbsp&nbsp&nbsp<b><small>Quantidade: </b> ${data.data[i].PTe_Quantidade} &nbsp<b>- Já Utilizados:</b> ${data.data[i].Utilizados}</small><br>`;
                                }
                                $("#itensPacoteMostrar").html(htmlitens);
                            },
                            error: function(data) {
                                console.log(data);
                            },
                        });
                        showLoader(false);
                    },
                    error: function(result) {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    },
                });
            };

            $scope.showComandaPacote = function(codigo) {
                $scope.buscaItensComandaVer(codigo);
                $("#idComandaVer").html(codigo);
                $("#edtComCartaoVer").val("");
                $("#vercomanda-modal").modal("show");
            };

            $("#changeCaret").click(function() {
                if ($("#iconCaret").hasClass("fa-caret-down")) {
                    $("#iconCaret").removeClass("fa-caret-down");
                    $("#iconCaret").addClass("fa-caret-up");
                } else {
                    $("#iconCaret").removeClass("fa-caret-up");
                    $("#iconCaret").addClass("fa-caret-down");
                }
            });

            function thumbProduto(state) {
                if (!state.id) {
                    return state.text;
                }
                if (
                    state.element.dataset.imagem == "" ||
                    state.element.dataset.imagem == undefined
                ) {
                    var $state = $(
                        '<span><img src="/img/tag_prod.png" class="img-thumb" /> ' +
                        state.text +
                        "</span>"
                    );
                } else {
                    var $state = $(
                        '<span><img src="' +
                        state.element.dataset.imagem +
                        '" class="img-thumb" /> ' +
                        state.text +
                        "</span>"
                    );
                }
                return $state;
            }

            /* SORTEIO */
            $scope.entrantsList = [];

            $scope.getClientList = function(data) {
                $scope.entrantsList = [];
                $scope.entrantsList = data
                    .map((val, i) => {
                        if (val.CodCliente != "") {
                            return [val.Cliente, val.CodCliente];
                        } else {
                            return false;
                        }
                    })
                    .filter(((t = {}), (a) => !(t[a] = a in t)))
                    .filter((item) => item != false);
                if ($scope.entrantsList.length > 1) {
                    $("#btn-sortear").show();
                } else {
                    $("#btn-sortear").hide();
                }
            };
            $scope.getRandomName = function() {
                var rand = Math.floor(Math.random() * $scope.entrantsList.length);
                var name = $scope.entrantsList[rand];
                $("#namesSorteio").text(name[0]);
                $("#namesSorteio").attr("data-codigo", name[1]);
            };

            $scope.doClick = function() {
                $("#sorteioCliente-modal").modal();
                $("#rollSorteio").html("Sortear");
                $("#rollSorteio").on("click", function(e) {
                    $(this).hide();

                    $scope.startDeceleratingTimeout(
                        function() {
                            $scope.getRandomName();
                        },
                        2,
                        90
                    );

                    setTimeout(function() {
                        var winner = $("#namesSorteio").text();
                        $("#winnerSorteio").text(winner);
                        $("#namesSorteio").hide();
                        var htmlWinner = `
            <span>Cliente Sorteado: </span>
            <br>
            <strong> ${winner} </strong>
            <br>
            <a href="#" id="roll-againSorteio">Realizar novo Sorteio</a>
            <br>
            <a href="#" id="info-clienteSorteio">Info do Cliente</a>
          `;
                        $("#winnerSorteio").html(htmlWinner);

                        $.ajax({
                            dataType: "json",
                            method: "POST",
                            url: "/pages/cadastros/insereLog.php",
                            data: {
                                descricao: "Sorteio realizado. Sorteado: " +
                                    $("#namesSorteio").get(0).dataset.codigo,
                                tipo: 24,
                            },
                        });

                        $("#roll-againSorteio").on("click", function(e) {
                            e.preventDefault();
                            $("#roll-againSorteio").unbind("click");
                            $("#info-clienteSorteio").unbind("click");
                            $("#winnerSorteio").html("");
                            $("#namesSorteio").show();
                            $("#rollSorteio").click();
                        });
                        $("#info-clienteSorteio").on("click", function(e) {
                            e.preventDefault();
                            $scope.mostraInfoClientes(
                                $("#namesSorteio").get(0).dataset.codigo
                            );
                        });
                    }, 9000);

                    e.preventDefault();
                });
            };

            $scope.startDeceleratingTimeout = function(callback, factor, times) {
                var internalCallback = (function(t, counter) {
                    return function() {
                        if (--t > 0) {
                            window.setTimeout(internalCallback, ++counter * factor);
                            callback();
                        }
                    };
                })(times, 0);

                window.setTimeout(internalCallback, factor);
            };

            $scope.removeClienteInfo = function() {
                swal({
                        title: $_CONFIG.language.mensagens.excluir_titulo,
                        text: '<h4><b>Deseja realmente excluir esse cliente?<br>Antes de excluir o cliente confira esse <a target="_blank" href="https://appbarber-appbeleza.zendesk.com/hc/pt-br/articles/360016694451-Meu-cliente-n%C3%A3o-consegue-se-cadastrar-ou-quer-utilizar-o-aplicativo-mas-ja-tenho-ele-cadastrado-o-que-devo-fazer-">TUTORIAL</a>, e verifique se a exclusão pode ser evitada com as orientações lá apresentadas</b></h4>' /*$_CONFIG.language.mensagens.excluir_cliente.replace("_NOME_", registroTabela.Nome)*/ ,
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: $_CONFIG.language.sim,
                        cancelButtonText: $_CONFIG.language.nao,
                        closeOnConfirm: false,
                        closeOnCancel: true,
                        html: true,
                    },
                    function(isConfirm) {
                        if (isConfirm) {
                            swal({
                                    title: "Está certo disso?",
                                    text: '<h4><b><span style="color:red">Essa operação é irreversível.</span><br><br> O cliente não terá mais acesso ao seu estabelecimento no aplicativo, e não conseguirá se cadastrar novamente com o mesmo email;<br><br> Você não terá acesso as informações do cliente;</b></h4>' /*$_CONFIG.language.mensagens.excluir_cliente.replace("_NOME_", registroTabela.Nome)*/ ,
                                    type: "warning",
                                    showCancelButton: true,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: $_CONFIG.language.sim,
                                    cancelButtonText: $_CONFIG.language.nao,
                                    html: true,
                                },
                                function() {
                                    showLoader(true);

                                    $.ajax({
                                        dataType: "html",
                                        url: "/pages/cadastros/removeClientes.php",
                                        data: {
                                            pescodigo: $("#cliPesCodigoInfo").val(),
                                        },
                                        success: function(data) {
                                            if (data == "0") {
                                                toastr.success(
                                                    $_CONFIG.language.mensagens.cliente_excluido
                                                );
                                            } else {
                                                toastr.error(
                                                    data,
                                                    $_CONFIG.language.mensagens.falha_excluir
                                                );
                                            }
                                            showLoader(false);
                                        },
                                        error: function(result) {
                                            toastr.error($_CONFIG.language.mensagens.falha_conexao);
                                            showLoader(false);
                                        },
                                    });
                                    $("#infoCliente-modal").modal("hide");
                                    showLoader(false);
                                }
                            );
                        }
                    }
                );
            };

            function thumbServico(state) {
                if (!state.id) {
                    return state.text;
                }

                if (
                    (state.element.dataset.tipopreco == "Igual a" ||
                        state.element.dataset.tipopreco == "A partir de") &&
                    state.element.dataset.valor.length != 0
                ) {
                    var $state = $(
                        "<span>" +
                        state.text +
                        '<br><small style="color:#adadad">' +
                        state.element.dataset.tipopreco +
                        " - " +
                        $_CONFIG.MOEDA +
                        " " +
                        state.element.dataset.valor +
                        "</small></span>"
                    );
                } else if (
                    state.element.dataset.tipopreco != "Igual a" &&
                    state.element.dataset.tipopreco != "A partir de" &&
                    state.element.dataset.valor.length != 0
                ) {
                    var $state = $(
                        "<span>" +
                        state.text +
                        '<br><small style="color:#adadad">' +
                        $_CONFIG.MOEDA +
                        " " +
                        state.element.dataset.valor +
                        "</small></span>"
                    );
                } else {
                    var $state = $("<span>" + state.text + "</span>");
                }

                return $state;
            }

            $scope.initScan = function() {
                // Initialize with options

                onScan.attachTo(document, {
                    avgTimeByChar: 35,
                    suffixKeyCodes: [9, 13], // enter-key expected at the end of a scan
                    reactToPaste: false,
                    minLength: 8, // Compatibility to built-in scanners in paste-mode (as opposed to keyboard-mode)
                    onScan: function(sCode, iQty) {
                        // Alternative to document.addEventListener('scan')

                        if ($("#comanda-modal").hasClass("in")) {
                            // Se está com a comanda aberta, insere o produto.
                            addScanProduct(sCode);
                        } else if (
                            location.hash == "#/estoque" &&
                            $("#cadastrar-modal").hasClass("in")
                        ) {
                            // Se está inserindo um novo produto, cola o código no campo de Código de Barras
                            if (
                                $(document.activeElement).hasClass("form-control") &&
                                document.activeElement.id != "proBarCode"
                            ) {
                                $(document.activeElement).val(
                                    $(document.activeElement).val().replace(sCode, "")
                                );
                            }
                            $("#proBarCode").val(sCode);
                        } else if (
                            location.hash == "#/estoque" &&
                            $("#editar-modal").hasClass("in")
                        ) {
                            // Se está editando um produto, cola o código no campo de código de barras
                            if (
                                $(document.activeElement).hasClass("form-control") &&
                                document.activeElement.id != "proBarCodeEdt"
                            ) {
                                $(document.activeElement).val(
                                    $(document.activeElement).val().replace(sCode, "")
                                );
                            }
                            $("#proBarCodeEdt").val(sCode);
                        } else if ($("#infoProdutoModal-modal").hasClass("in")) {
                            // Se não está em nenhuma das outras telas, mostra o modal de informações do produto.
                            infoScanProduct(sCode);
                        }
                    },
                    onKeyDetect: function(iKeyCode) {
                        // output all potentially relevant key events - great for debugging!
                    },
                    onScanError: function(oDebug) {},
                    onPaste: function(sPasted, oEvent) {},
                });
            };

            $scope.insereProdutoComissionadoComanda = function(
                profissionalSelecionado
            ) {
                showLoader(true);

                var valorcomissaoprofissional =
                    profissionalSelecionado.valor *
                    (profissionalSelecionado.comissao / 100);

                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereComandaItensv2.php",
                    data: {
                        comcodigo: profissionalSelecionado.comcodigo,
                        procodigo: profissionalSelecionado.procodigo,
                        valor: profissionalSelecionado.valor,
                        valorunitario: profissionalSelecionado.valorunitario,
                        cittoken: "",
                        citvenda: 0,
                        citcomissaoproduto: valorcomissaoprofissional,
                        pescodigoprocomissao: profissionalSelecionado.pescodigoprocomissao,
                        citcortesia: 0,
                        iscombo: 0,
                        qtd: 1,
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.result[0].erro == "0") {
                            $("#profissionalComissaoBarCode-modal").modal("hide");
                            $scope.atualizaDadosItens();
                            if (location.hash == "#/comandasabertas") {
                                $rootScope.$emit("atualizaDadosComanda", {});
                            }

                            toastr.success(result.result[0].resultado);
                        } else {
                            toastr.error(result.result[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        if ($("#comProduto option:selected").get(0).dataset.iscombo == 0) {
                            $("#comValorInsert").attr("disabled", true);
                        }
                        showLoader(false);
                    },
                });
            };

            $scope.goToContratar = function() {
                $state.go("contratacao");
            };

            function addScanProduct(sCode) {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaProdutosv3.php",
                    data: {
                        codigobarras: sCode,
                        tipo: 3,
                    },
                    success: function(result) {
                        if (result && result.data && result.data.length > 0) {
                            if (
                                result.data[0].Pro_Comissao != "" &&
                                result.data[0].Pro_Comissao != "0"
                            ) {
                                // Busca Profissionais Comissão
                                $scope.listProfissionaisComissaoCodigoBarras = new Array();
                                $.ajax({
                                    dataType: "json",
                                    method: "POST",
                                    url: "/pages/cadastros/buscaPessoaProduto.php",
                                    data: {
                                        procodigo: result.data[0].Pro_Codigo,
                                        tipo: 2,
                                    },
                                    success: function(resultProfissionais) {
                                        if (
                                            resultProfissionais &&
                                            resultProfissionais.data &&
                                            resultProfissionais.data.length > 0
                                        ) {
                                            resultProfissionais.data.forEach((element) => {
                                                var imagemProfissional =
                                                    "https://sistema.appbarber.com.br/img/nopicture.png";

                                                if (
                                                    element.PAF_Imagem != undefined &&
                                                    element.PAF_Imagem != ""
                                                ) {
                                                    imagemProfissional = element.PAF_Imagem;
                                                }

                                                $scope.listProfissionaisComissaoCodigoBarras.push({
                                                    comcodigo: $("#idComanda").html(),
                                                    procodigo: result.data[0].Pro_Codigo,
                                                    valor: result.data[0].Pro_Valor.replace(",", "."),
                                                    valorunitario: result.data[0].Pro_Valor.replace(
                                                        ",",
                                                        "."
                                                    ),
                                                    comissao: element.comissao,
                                                    pescodigoprocomissao: element.Pes_Codigo,
                                                    apelido: element.Pes_Apelido,
                                                    imagem: imagemProfissional,
                                                });
                                            });
                                            $scope.$apply();
                                            $("#profissionalComissaoBarCode-modal").modal();
                                        }
                                    },
                                });
                            } else {
                                $.ajax({
                                    type: "POST",
                                    url: "/pages/cadastros/insereComandaItensv2.php",
                                    data: {
                                        comcodigo: $("#idComanda").html(),
                                        procodigo: result.data[0].Pro_Codigo,
                                        valor: result.data[0].Pro_Valor.replace(",", "."),
                                        valorunitario: result.data[0].Pro_Valor.replace(",", "."),
                                        cittoken: "",
                                        citvenda: 0,
                                        citcomissaoproduto: "",
                                        pescodigoprocomissao: "",
                                        citcortesia: 0,
                                        iscombo: 0,
                                        qtd: 1,
                                    },
                                    dataType: "json",
                                    success: function(result) {
                                        if (result.result[0].erro == "0") {
                                            $scope.atualizaDadosItens();
                                            if (location.hash == "#/comandasabertas") {
                                                $rootScope.$emit("atualizaDadosComanda", {});
                                            }

                                            toastr.success(result.result[0].resultado);
                                        } else {
                                            toastr.error(result.result[0].resultado);
                                        }
                                    },
                                    error: function(result) {
                                        toastr.error("Falha na conexão.");
                                        if (
                                            $("#comProduto option:selected").get(0).dataset.iscombo ==
                                            0
                                        ) {
                                            $("#comValorInsert").attr("disabled", true);
                                        }
                                    },
                                });
                            }
                        } else {
                            toastr.error(
                                `Não foi encontrado nenhum produto cadastrado com o código de barras ${sCode}`
                            );
                        }
                        showLoader(false);
                    },
                });
            }

            function infoScanProduct(sCode) {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/buscaProdutosv3.php",
                    data: {
                        codigobarras: sCode,
                        tipo: 3,
                    },
                    success: function(result) {
                        if (result && result.data && result.data.length > 0) {
                            $("#nomeProdutoScan").html(result.data[0].Pro_Descricao);
                            $("#marcaProdutoScan").html(result.data[0].Pro_Marca);
                            $("#valorProdutoScan").html(
                                result.data[0].Moeda + " " + result.data[0].Pro_Valor
                            );
                            $("#valorProfProdutoScan").html(
                                result.data[0].Moeda + " " + result.data[0].Pro_Vlr_Profissional
                            );
                            $("#qtdEmEstoqueProdutoScan").html(result.data[0].Pro_Saldo);

                            $("#modeloProdutoScan").html(result.data[0].Pro_Descricao);

                            if (result.data[0].Pro_Categoria == "") {
                                $("#marcaProdutoScan").html("Não informada.");
                            } else {
                                $("#marcaProdutoScan").html(result.data[0].Pro_Marca);
                            }

                            if (result.data[0].Pro_Categoria == "") {
                                $("#modeloProdutoScan").html("Não informada.");
                            } else {
                                $("#modeloProdutoScan").html(result.data[0].Pro_Categoria);
                            }

                            if (result.data[0].Pro_Figura == "") {
                                $("#imagemProdutoScan").prop("src", "/img/prod_sem_imagem.png");
                            } else {
                                $("#imagemProdutoScan").prop("src", result.data[0].Pro_Figura);
                            }
                            document
                                .getElementById("flipCardprod")
                                .classList.add("flip-card-rotate");
                        } else {
                            toastr.error(
                                `Não foi encontrado nenhum produto cadastrado com o código de barras ${sCode}`
                            );
                        }
                        showLoader(false);
                    },
                });
            }

            $scope.initScan();

            setTimeout(function() {
                if ($scope.parnota == 0) {
                    $("#emissoesItemMenu").remove();
                }
            }, 20000);

            setTimeout(function() {
                if ($scope.caixinha == 0) {
                    $("#itemMenuCaixinha").remove();
                }
            }, 20000);

            const closeComanda = function(
                thisInsereCaixa,
                thisCliCaixinha,
                emiteNota
            ) {
                showLoader(true);
                var parcelado = 0;
                var numPagamentos = 1;
                if ($("#tipoPagamento1 option:selected").val() !== undefined) {
                    numPagamentos = 2;
                }
                var tiposPagamento = `${$(
          "#tipoPagamento0 option:selected"
        ).val()},${$scope.isUndefined(
          $("#tipoPagamento1 option:selected").val()
        )}`;
                var tiposBandeiras = `${$(
          "#divBandeiraPag0 option:selected"
        ).val()},${$scope.isUndefined(
          $("#divBandeiraPag1 option:selected").val()
        )}`;
                var valorPagamento = `${$("#valorPagamento0")
          .val()
          .replace(",", ".")},${$scope
          .isUndefined($("#valorPagamento1").val())
          .replace(",", ".")}`;
                var codigoTransacao = `${$scope.isUndefined(
          $("#codigoTransacao0").val()
        )},${$scope.isUndefined($("#codigoTransacao1").val())}`;

                if ($("#parcelarCaixa").get(0).checked) {
                    parcelado = "1";
                } else {
                    parcelado = "0";
                }

                var numeroParcelas = $("#selVezesParcela").val();
                var periodiciadadeParcelas = $("#selPeriodicidadeVenda").val();
                if (parcelado == "0") {
                    periodiciadadeParcelas = "";
                }
                var comCodigo = $("#idComanda").html();

                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/atualizaComandav3.php",
                    data: {
                        comcodigo: comCodigo,
                        tipo: 1,
                        valorpagamento: valorPagamento,
                        tpacodigo: tiposPagamento,
                        tbacodigo: tiposBandeiras,
                        codtransacao: codigoTransacao,
                        inserecaixa: thisInsereCaixa,
                        inserecontacli: thisCliCaixinha.contacli,
                        inserecaixinha: thisCliCaixinha.caixinha,
                        parcelado: parcelado,
                        qtdparcela: numeroParcelas,
                        periodicidade: periodiciadadeParcelas,
                        motivo: "",
                        transacao: $("#codigoTransacao0").val(),
                        numpagamento: numPagamentos,
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.data[0].erro == "0") {
                            $("#linhaPagamento1").remove();
                            j = 1;
                            $("#comanda-modal").modal("hide");
                            $("#divBandeiraPag").hide();

                            $("#insereCaixa").prop("checked", true);
                            $("#parcelarCaixa").prop("checked", false);
                            $("#trParcelar").hide();
                            $("#trParcelarPer").hide();

                            if (location.hash == "#/agenda") {
                                $rootScope.$emit("BuscaAgenda", {});
                            } else if (location.hash == "#/comandasabertas") {
                                $rootScope.$emit("atualizaDadosComanda", {});
                            } else if (location.hash == "#/comandashistorico") {
                                $rootScope.$emit("atualizaDadosComandaHistorico", {});
                            } else if (location.hash == "#/filaDeEspera") {
                                $rootScope.$emit("atualizaDadosFila", {});
                            } else if (location.hash == "#/relGerencialEstoque") {
                                $rootScope.$emit("atulizaRelEstoque", {});
                            }
                            if (emiteNota == true) {
                                $scope.generateCupom(
                                    $("#idComanda").html(),
                                    $("#codCliente").val()
                                );
                            }
                            toastr.success(result.data[0].resultado);
                            $("#btnFinalizarComanda").prop("disabled", false);
                        } else {
                            toastr.error(
                                result.data[0].resultado,
                                "Falha ao Finalizar Comanda."
                            );
                            $("#btnFinalizarComanda").prop("disabled", false);
                        }
                        showLoader(false);
                    },
                    error: function(result) {
                        toastr.error("Falha na conexão.");
                        if ($("#comProduto option:selected").get(0).dataset.iscombo == 0) {
                            $("#comValorInsert").attr("disabled", true);
                        }
                        $("#btnFinalizarComanda").prop("disabled", false);
                    },
                });
            };

            const displayComanda = function(comcodigo) {
                $.ajax({
                    dataType: "json",
                    url: localStorage.getItem("host"),
                    data: {
                        metodo: "buscaComanda",
                        id: $scope.idCliente,
                        comcodigo: comcodigo,
                        tipo: 9,
                    },
                    success: (data) => {
                        $("#idComandaExterno").hide();
                        $("#iconInfoCliente").hide();
                        $("#infoPontosCli").hide();
                        let pessoaConta = "";
                        let configContaCli = {};
                        if (data.result[0].PCo_Saldo_Real < 0.0) {
                            configContaCli.typeInsert = 1;
                            configContaCli.color = "red";
                        } else if (data.result[0].PCo_Saldo_Real > 0.0) {
                            configContaCli.typeInsert = 2;
                            configContaCli.color = "green";
                        }
                        $("#nomeClienteComanda").html(data.result[0].ClienteInfo);
                        if (data.result[0].TPR_Codigo == 3) {
                            $("#TprTipoComanda").html(data.result[0].TPR_Codigo);
                            configContaCli.type = "profissional";
                        } else {
                            configContaCli.type = "cliente";
                            $("#TprTipoComanda").html(data.result[0].TPR_Codigo);
                            if (data.result[0].Cliente != "") {
                                $("#iconInfoCliente").show();
                                $("#infoPontosCli").show();

                                $.ajax({
                                    dataType: "html",
                                    url: "/pages/relatorios/buscaProgramaFidelidade.php",
                                    method: "POST",
                                    data: {
                                        selCliente: data.result[0].CodigoCliente,
                                        selTipo: 1,
                                    },
                                    dataType: "json",
                                    success: function(data) {
                                        if (data.data.length == 1) {
                                            $("#stringPontosCli").html(data.data[0].TotalPontos);
                                        } else {
                                            $("#stringPontosCli").html(0);
                                        }
                                    },
                                });
                            }
                        }
                        pessoaConta += `<label>
									<span style='color:${configContaCli.color}'>
										Saldo na conta do ${configContaCli.type}: ${data.result[0].PCo_Saldo}
									</span>
								</label>&nbsp&nbsp
								<button ng-click='detalhesContaCliente()' class='btn btn-primary btn-xs'>Ver detalhes</button>&nbsp<button id='btnPagacomanda' class='btn btn-warning btn-xs' ng-click='pagaContaCliente(2,${data.result[0].PCo_Saldo_Real})'>Pagar</button>`;

                        $("#pessoaConta").html(pessoaConta);
                        $compile($("#pessoaConta"))($scope);
                        $("#idComanda").html(data.result[0].Com_Codigo);
                        $("#idComandaExterno").html(data.result[0].CCE_Cod_Externo);

                        if (data.result[0].CCE_Cod_Externo != "") {
                            $("#idComandaExterno").show();
                        }
                        $("#dataComanda").html(data.result[0].Com_Dat_Cadastro);
                        $("#edtComCartao").val(data.result[0].Com_Cod_Externo);
                        $("#codCliente").val(data.result[0].CodigoCliente);
                        var PromissePagamento = new Promise((resolve, reject) => {
                            resolve($scope.atualizaTipoPagemento());
                        });
                        PromissePagamento.then(() => {
                            $scope.buscaItensComanda(comcodigo);
                        });
                        $("#comanda-modal").modal("show");
                    },
                    error: (data) => {},
                });
            };

            $scope.setDestinoVale = function(tipo) {
                var datetoday = moment().locale("pt-br").format("L");

                $(".date.divDataFinVale").datepicker("update", datetoday);
                $("#destinoVale").val(tipo);
                $("#codigoCaixaVale").val($(".caxCodigoSai").val());
                if (tipo == 1) {
                    $("#divDataFinVale").hide();
                    $scope.tiposPagamento = $_CONFIG.LISTA_PAGAMAENTO;
                    $scope.buscaValeLancamento();
                } else {
                    $("#divDataFinVale").show();
                }
            };

            $scope.buscaValeLancamento = function() {
                var vale = "";
                var pagamento = "";
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaDespesa.php",
                    dataType: "json",
                    success: function(result) {
                        if (result.data.length >= 1) {
                            for (var i = 0; i < result.data.length; i++) {
                                if (result.data[i].TDe_Vale == "1") {
                                    vale +=
                                        "<option value='" +
                                        result.data[i].TDe_Codigo +
                                        "' >" +
                                        result.data[i].TDe_Descricao +
                                        "</option>";
                                }
                            }
                        } else {
                            vale += "<option value='' >Sem Vales Cadastrados</option>";
                        }

                        $("#buscaTipoVale").html(vale);
                    },
                    error: function(result) {},
                });

                pagamento += "<option value='' >Nenhum</option>";

                for (var i = 0; i < $scope.tiposPagamento.length; i++) {
                    pagamento +=
                        "<option value='" +
                        $scope.tiposPagamento[i].TPa_Codigo +
                        "' >" +
                        $scope.tiposPagamento[i].TPa_Descricao +
                        "</option>";
                }
                $("#tipoPagamentoVale").html(pagamento);
            };
            $scope.buscaValeLancamento();

            $scope.salvaValeProfissional = function() {
                $("#btnSalvaMovimentacaoVale").attr("disabled", true);

                if ($("#buscaTipoVale").val() != "") {
                    if ($("#profissionalSelVale").val() != "") {
                        if ($("#destinoVale").val() == 1) {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereFinanceiroCaixaMovimentacao.php",
                                data: {
                                    codigo: $("#codigoCaixaVale").val(),
                                    valor: $("#valorValeProfissional").val(),
                                    descricao: `Vale no CAIXA para o profissional ${$(
                    "#profissionalSelVale option:selected"
                  ).text()}:  ${$("#profissionalObsVale").val()}`,
                                    tipo: 0,
                                    tdecodigo: $("#buscaTipoVale").val(),
                                    proximocaixa: 0,
                                    profissional: $("#profissionalSelVale").val(),
                                    sangria: 0,
                                    tpacodigo: $("#tipoPagamentoVale").val(),
                                },
                                dataType: "json",
                                success: (result) => {
                                    if (result.result[0].erro == "0") {
                                        toastr.success(result.result[0].resultado);
                                        $("#cadastraVale-modal").modal("hide");
                                        $("#valorValeProfissional").val("");
                                        $("#buscaTipoVale").val("");
                                        $("#tipoPagamentoVale").val("");
                                        $("#profissionalSelVale").val("");
                                        $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                                    } else {
                                        swal(result.result[0].resultado, "", "error");
                                        $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                                    }
                                    showLoader(false);
                                },
                                error: () => {
                                    $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                                    swal("Falha na conexão.", "", "error");
                                    showLoader(false);
                                },
                            });
                        } else {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereFinanceirov4.php",
                                data: {
                                    finDescricao: `Vale no FINANCEIRO para o profissional ${$(
                    "#profissionalSelVale option:selected"
                  ).text()}:  ${$("#profissionalObsVale").val()} `,
                                    finValor: $("#valorValeProfissional").val(),
                                    finEntradaSaida: 0,
                                    finData: $("#finDataVale").val(),
                                    finBaixado: 1,
                                    buscaDespesa: $("#buscaTipoVale").val(),
                                    buscaProfissional: $("#profissionalSelVale").val(),
                                    tipoPagamento: $("#tipoPagamentoVale").val(),
                                    buscaConta: $("#buscaContaValeFin").val(),
                                },
                                dataType: "json",
                                success: function(result) {
                                    if (result.result[0].erro == "0") {
                                        $("#cadastraVale-modal").modal("hide");
                                        $("#valorValeProfissional").val("");
                                        $("#buscaTipoVale").val("");
                                        $("#tipoPagamentoVale").val("");
                                        $("#profissionalSelVale").val("");
                                        $("#finDataVale").val("");
                                        toastr.success(result.result[0].resultado);
                                        $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                                    } else {
                                        toastr.error(result.result[0].resultado);
                                        $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                                    }
                                    showLoader(false);
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                    $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                                    showLoader(false);
                                },
                            });
                        }
                    } else {
                        toastr.error("Favor informe o profissional");
                        $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                    }
                } else {
                    toastr.error("Favor informe o tipo de vale");
                    $("#btnSalvaMovimentacaoVale").attr("disabled", false);
                }
            };

            $scope.cadastrarValeSistema = function() {
                showLoader(true);
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/insereDespesa.php",
                    data: {
                        Despesa: $("#DescricaoValeSistema").val(),
                        vale: $("#indicaValeSistema").val(),
                    },
                    dataType: "json",
                    success: (result) => {
                        if (result.data[0].erro == "0") {
                            toastr.success(result.data[0].resultado);
                            $("#novovale-modal").modal("hide");
                            $("#DescricaoValeSistema").val("");
                            $scope.buscaValeLancamento();
                        } else {
                            toastr.error(result.data[0].resultado);
                        }
                        showLoader(false);
                    },
                    error: () => {
                        toastr.error("Falha na conexão.");
                        showLoader(false);
                    },
                });
            };

            $scope.undoFlipProd = function() {
                document
                    .getElementById("flipCardprod")
                    .classList.remove("flip-card-rotate");
                $("#nomeProdutoScan").html("Informações do Produto");
            };

            $scope.imprimirVerDia = function() {
                PrintElem("Ver Dia", "#printVerDia");
            };

            $("#parceladoContaCliModal").change(() => {
                if ($("#ContaCliValorEnt").val() != "") {
                    if ($("#parceladoContaCliModal").val() == "1") {
                        $(".divNumParcelasModal").show();
                        var valorParcela = $("#ContaCliValorEnt").maskMoney("unmasked")[0];
                        var parcelas = "";
                        for (var i = 2; i <= 12; i++) {
                            parcelas += `<option value='${i}'>${i}X de ${$_CONFIG.MOEDA} ${(
                valorParcela / i
              )
                .toFixed(2)
                .replace(".", ",")}</option>`;
                        }

                        $("#numParcelasContaCliModal").html(parcelas);
                    } else {
                        $(".divNumParcelasModal").hide();
                    }
                } else {
                    $(".divNumParcelasModal").hide();
                    $("#parceladoContaCliModal").val(0);
                    toastr.warning("Informe o valor para realizar o parcelamento");
                }
            });

            $("#ContaCliValorEnt").keyup(() => {
                if ($("#parceladoContaCliModal").val() == "1") {
                    if ($("#ContaCliValorEnt").val() == "0,00") {
                        $("#parceladoContaCliModal").val(0).change();
                    } else {
                        var valorParcela = $("#ContaCliValorEnt").maskMoney("unmasked")[0];
                        var parcelas = "";
                        for (var i = 2; i <= 12; i++) {
                            parcelas += `<option value='${i}'>${i}X de ${$_CONFIG.MOEDA} ${(
                valorParcela / i
              )
                .toFixed(2)
                .replace(".", ",")}</option>`;
                        }
                    }

                    $("#numParcelasContaCliModal").html(parcelas);
                }
            });

            $scope.generateCupomAssinatura = function(
                apfcodigo,
                assvalor,
                assdescricao,
                cliente,
                tipoassinatura = 1
            ) {
                if ($scope.parnfssinatura == 1 && $scope.parnota == 1) {
                    $("#apfCodigoNotaAssinatura").val(apfcodigo);

                    $("#valorCupomNotaAssinatura").html(assvalor);
                    $("#valorCupomDisplayNotaAssinatura").val(
                        `${$_CONFIG.MOEDA} ${assvalor.replace(",", ".")}`
                    );
                    $("#servicosPrestadosNotaAssinatura").html(assdescricao);
                    $("#servicosPrestadosDisplayNotaAssinatura").val(assdescricao);

                    var html = "<option value=''>Estado</option>";
                    for (var i = 0; i < $_CONFIG.LISTA_ESTADO.length; i++) {
                        html +=
                            "<option value='" +
                            $_CONFIG.LISTA_ESTADO[i].Est_Sigla +
                            "'> " +
                            $_CONFIG.LISTA_ESTADO[i].Est_Sigla +
                            "</option>";
                    }

                    $("#cliCupomUFNotaAssinatura").html(html);

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoa.php",
                        async: false,
                        data: {
                            tipo: 1,
                        },
                        dataType: "json",
                        success: function(result) {
                            $scope.dadosEmpresaNotaAssinatura = result.buscaPessoa[0];
                            $("#empresaCNAENotaAssinatura").val(result.buscaPessoa[0].CNAE);
                            // $("#empresaCodigoNFAssinatura").val(result.buscaPessoa[0].CodigoNF);

                            var codigoempresahtml = `<option value="${result.buscaPessoa[0].CodigoNF}">${result.buscaPessoa[0].CNPJ}</option>`;
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/buscaPessoaEnotas.php",
                                dataType: "json",
                                async: false,
                                success: function(result) {
                                    if (result.data.length > 0) {
                                        for (var i = 0; i < result.data.length; i++) {
                                            codigoempresahtml += `<option value="${result.data[i].PEn_Codigo_GW}">${result.data[i].PEn_CNPJ}</option>`;
                                        }
                                    }
                                },
                                error: function(result) {},
                            });

                            $("#empresaCodigoNFAssinatura").html(codigoempresahtml);

                            $scope.emiteSemClientePacote =
                                result.buscaPessoa[0].Cid_Emissao_SemCliente;
                            $scope.emiteSemCPFPacote =
                                result.buscaPessoa[0].Cid_Emissao_SemCPF;
                            $scope.emiteSemEnderecoPacote =
                                result.buscaPessoa[0].Cid_Emissao_SemEndereco;
                            $("#empresaCSTNotaAssinatura").val(result.buscaPessoa[0].CST);

                            if ($scope.emiteSemCliente == 0) {
                                $("#nomeObrigatorioNotaAssinatura").show();
                            } else {
                                $("#nomeObrigatorioNotaAssinatura").hide();
                            }

                            if ($scope.emiteSemCPF == 0) {
                                $("#CPFObrigatorioNotaAssinatura").show();
                            } else {
                                $("#CPFObrigatorioNotaAssinatura").hide();
                            }

                            if ($scope.emiteSemEndereco == 0) {
                                $("#EstadoObrigatorioNotaAssinatura").show();
                                $("#CidadeObrigatorioNotaAssinatura").show();
                                $("#CepObrigatorioNotaAssinatura").show();
                                $("#BairroObrigatorioNotaAssinatura").show();
                                $("#NumeroObrigatorioNotaAssinatura").show();
                                $("#LogradouroObrigatorioNotaAssinatura").show();
                            } else {
                                $("#EstadoObrigatorioNotaAssinatura").hide();
                                $("#CidadeObrigatorioNotaAssinatura").hide();
                                $("#CepObrigatorioNotaAssinatura").hide();
                                $("#BairroObrigatorioNotaAssinatura").hide();
                                $("#LogradouroObrigatorioNotaAssinatura").hide();
                                $("#NumeroObrigatorioNotaAssinatura").hide();
                            }
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                        },
                    });

                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoaNatureza.php",
                        data: {
                            tipo: "1",
                        },
                        dataType: "json",
                        success: function(result) {
                            var naturezalista = "";
                            for (var i = 0; i < result.data.length; i++) {
                                naturezalista += `<option value='${result.data[i].Nat_Codigo_Externo}'  data-nbs='${result.data[i].Nat_NBS}' data-itemlista='${result.data[i].PNa_Codigo_Municipal_Servico}' data-aliquota='${result.data[i].PNa_Aliquota}'>${result.data[i].Nat_Descricao}</option>`;
                            }
                            $("#servicoNaturezaNotaAssinatura").html(naturezalista);
                            $("#servicoNaturezaNotaAssinatura").select2();
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                        },
                    });

                    if (cliente != "") {
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaClienteAlteraAgenda.php",
                            data: {
                                cliente: cliente,
                            },
                            dataType: "json",
                            success: function(result) {
                                $scope.dadosClienteNotaAssinatura = result.result[0];
                                $("#cliCupomNomeNotaAssinatura").val(result.result[0].Pes_Nome);
                                $("#cliCupomEmailNotaAssinatura").val(
                                    result.result[0].Paf_Email
                                );
                                $("#cliCupomCPFNotaAssinatura").val(result.result[0].Paf_Cpf);
                                $("#cliCupomCEPNotaAssinatura").val(result.result[0].Paf_CEP);
                                $("#cliCupomUFNotaAssinatura").val(result.result[0].Est_Sigla);
                                $("#cliCupomCidadeNotaAssinatura").val(
                                    result.result[0].Cid_Nome
                                );
                                $("#cliCupomBairroNotaAssinatura").val(
                                    result.result[0].Paf_Bairro
                                );
                                $("#cliCupomLogradouroNotaAssinatura").val(
                                    result.result[0].Paf_Endereco
                                );
                                $("#cliCupomNumeroNotaAssinatura").val(
                                    result.result[0].Paf_Numero
                                );
                                $("#cliCupomComplementoNotaAssinatura").val(
                                    result.result[0].Paf_Complemento
                                );
                                $("#cliCupomNomeProdNotaAssinatura").val(
                                    result.result[0].Pes_Nome
                                );
                                $("#cliCupomEmailProdNotaAssinatura").val(
                                    result.result[0].Paf_Email
                                );
                                $("#cliCupomCPFProdNotaAssinatura").val(
                                    result.result[0].Paf_Cpf
                                );
                                $("#cliCupomCEPProdNotaAssinatura").val(
                                    result.result[0].Paf_CEP
                                );
                                $("#cliCupomUFProdNotaAssinatura").val(
                                    result.result[0].Est_Sigla
                                );
                                $("#cliCupomCidadeProdNotaAssinatura").val(
                                    result.result[0].Cid_Nome
                                );
                                $("#cliCupomBairroProdNotaAssinatura").val(
                                    result.result[0].Paf_Bairro
                                );
                                $("#cliCupomLogradouroProdNotaAssinatura").val(
                                    result.result[0].Paf_Endereco
                                );
                                $("#cliCupomNumeroProdNotaAssinatura").val(
                                    result.result[0].Paf_Numero
                                );
                                $("#cliCupomComplementoProdNotaAssinatura").val(
                                    result.result[0].Paf_Complemento
                                );
                                $("#cliCupomTelefoneProdNotaAssinatura").val(
                                    result.result[0].Paf_Celular
                                );
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                            },
                        });
                    }

                    if ($scope.parnfdescontoparceiro == 1) {
                        var obsParceiro = "";
                        var valorComissao = 0.0;
                        if (tipoassinatura == 1) {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/buscaAssinaturaComissaoNotaParceiro.php",
                                async: false,
                                data: {
                                    tipo: "1",
                                    dataini: "",
                                    datafim: "",
                                    apfcodigo: apfcodigo,
                                },
                                dataType: "json",
                                success: function(data) {
                                    if (data.data.length > 0) {
                                        for (var i = 0; i < data.data.length; i++) {
                                            var dadoComissaoLoop = data.data[i].ComissaoReceber;
                                            var dadoPesCodigoLoop = data.data[i].CodigoProfissional;
                                            if (
                                                dadoPesCodigoLoop != "" &&
                                                dadoPesCodigoLoop != undefined
                                            ) {
                                                $.ajax({
                                                    type: "POST",
                                                    url: "/pages/cadastros/buscaPessoav2.php",
                                                    async: false,
                                                    data: {
                                                        tipo: 2,
                                                        pescodigo: dadoPesCodigoLoop,
                                                    },
                                                    dataType: "json",
                                                    success: function(result) {
                                                        if (result.data.length != 0) {
                                                            if (
                                                                result.data[0].PAF_CPF != "" &&
                                                                result.data[0].PNa_Codigo != ""
                                                            ) {
                                                                var cnpjParceiro = result.data[0].PAF_CPF;
                                                                $.ajax({
                                                                    type: "POST",
                                                                    url: "/pages/cadastros/buscaPessoaNaturezav2.php",
                                                                    async: false,
                                                                    data: {
                                                                        tipo: "1",
                                                                        pescodigo: dadoPesCodigoLoop,
                                                                    },
                                                                    dataType: "json",
                                                                    success: function(result) {
                                                                        var valorcomissaodesconto = parseFloat(
                                                                            dadoComissaoLoop.replace(",", ".")
                                                                        );
                                                                        valorComissao =
                                                                            valorComissao + valorcomissaodesconto;
                                                                        var profissional = "";
                                                                        if ($scope.nomeProfissionalNota == 1) {
                                                                            profissional = `${result.data[0].Pes_Nome},`;
                                                                        }

                                                                        if (
                                                                            cnpjParceiro.replace(/\D/g, "").length >=
                                                                            14
                                                                        ) {
                                                                            obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                        2
                                      )} de cota-parte profissional parceiro ${profissional} CNPJ ${cnpjParceiro}, emitida no código: ${
                                        result.data[0].Codigo
                                      };\n`;
                                                                        } else {
                                                                            obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                        2
                                      )} de cota-parte profissional parceiro ${profissional} CPF ${cnpjParceiro}, emitida no código: ${
                                        result.data[0].Codigo
                                      };\n`;
                                                                        }
                                                                    },
                                                                    error: function(result) {
                                                                        toastr.error("Falha na conexão.");
                                                                    },
                                                                });
                                                            }
                                                        }
                                                    },
                                                    error: function(result) {
                                                        toastr.error("Falha na conexão.");
                                                    },
                                                });
                                            }
                                        }
                                    }
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                },
                            });
                        } else {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/PLANO_ASSINATURA_Busca_Comissao.php",
                                async: false,
                                data: {
                                    type: 3,
                                    professional_code: "",
                                    start_date: "",
                                    end_date: "",
                                    client_subscription_finantial_code: apfcodigo,
                                },
                                dataType: "json",
                                success: function(data) {
                                    if (data.data.length > 0) {
                                        for (var i = 0; i < data.data.length; i++) {
                                            var dadoComissaoLoop =
                                                data.data[i].professional_value.toString();
                                            var dadoPesCodigoLoop = data.data[i].professional_code;
                                            if (
                                                dadoPesCodigoLoop != "" &&
                                                dadoPesCodigoLoop != undefined
                                            ) {
                                                $.ajax({
                                                    type: "POST",
                                                    url: "/pages/cadastros/buscaPessoav2.php",
                                                    async: false,
                                                    data: {
                                                        tipo: 2,
                                                        pescodigo: dadoPesCodigoLoop,
                                                    },
                                                    dataType: "json",
                                                    success: function(result) {
                                                        if (result.data.length != 0) {
                                                            if (
                                                                result.data[0].PAF_CPF != "" &&
                                                                result.data[0].PNa_Codigo != ""
                                                            ) {
                                                                var cnpjParceiro = result.data[0].PAF_CPF;
                                                                $.ajax({
                                                                    type: "POST",
                                                                    url: "/pages/cadastros/buscaPessoaNaturezav2.php",
                                                                    async: false,
                                                                    data: {
                                                                        tipo: "1",
                                                                        pescodigo: dadoPesCodigoLoop,
                                                                    },
                                                                    dataType: "json",
                                                                    success: function(result) {
                                                                        var valorcomissaodesconto = parseFloat(
                                                                            dadoComissaoLoop.replace(",", ".")
                                                                        );
                                                                        valorComissao =
                                                                            valorComissao + valorcomissaodesconto;
                                                                        var profissional = "";
                                                                        if ($scope.nomeProfissionalNota == 1) {
                                                                            profissional = `${result.data[0].Pes_Nome},`;
                                                                        }

                                                                        if (
                                                                            cnpjParceiro.replace(/\D/g, "").length >=
                                                                            14
                                                                        ) {
                                                                            obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                        2
                                      )} de cota-parte profissional parceiro ${profissional} CNPJ ${cnpjParceiro}, emitida no código: ${
                                        result.data[0].Codigo
                                      };\n`;
                                                                        } else {
                                                                            obsParceiro += `R$ ${valorcomissaodesconto.toFixed(
                                        2
                                      )} de cota-parte profissional parceiro ${profissional} CPF ${cnpjParceiro}, emitida no código: ${
                                        result.data[0].Codigo
                                      };\n`;
                                                                        }
                                                                    },
                                                                    error: function(result) {
                                                                        toastr.error("Falha na conexão.");
                                                                    },
                                                                });
                                                            }
                                                        }
                                                    },
                                                    error: function(result) {
                                                        toastr.error("Falha na conexão.");
                                                    },
                                                });
                                            }
                                        }
                                    }
                                },
                                error: function(result) {
                                    toastr.error("Falha na conexão.");
                                },
                            });
                        }
                    }

                    var infoOrigem = "";
                    var infoProcon = "";
                    if ($scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 189886) {
                        infoOrigem =
                            "Fonte: IBPT/FECOMERCIO RJ - 18.1.A Resolução CGSN Nº 137, de 04 de Dezembro de 2017.\n";
                    } else if (
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 8866546 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 12690404 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 320798 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 7007706 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 3224558 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 13329906 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 1034072 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 20271388 ||
                        $scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 20657910
                    ) {
                        infoOrigem =
                            "EMISSAO DE NOTA CONFORME RESOLUCAO CGSN N. 140, DE 22 DE MAIO DE 2018\n";
                    } else if ($scope.dadosEmpresaNotaAssinatura.Pes_Codigo == 17774557) {
                        infoOrigem =
                            "Serviço prestado sob regime de parceria nos termos da Lei nº 13.352/2016\n";
                    }

                    if ($scope.dadosEmpresaNotaAssinatura.Cid_Codigo != "") {
                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaCidadeProcon.php",
                            async: false,
                            data: {
                                cidcodigo: $scope.dadosEmpresaNotaAssinatura.Cid_Codigo,
                            },
                            dataType: "json",
                            success: function(result) {
                                if (result.data.length > 0) {
                                    infoProcon = `TELEFONE DO PROCON: ${result.data[0].CPo_Telefone} \n ENDERECO DO PROCON: ${result.data[0].CPo_Endereco}`;
                                }
                            },
                            error: function(result) {
                                toastr.error("Falha na conexão.");
                            },
                        });
                    }

                    if ($scope.parnfdescontoparceiro == 1) {
                        var valorServicos = parseFloat(
                            $("#valorCupomNotaAssinatura")
                            .html()
                            .replace($_CONFIG.MOEDA, "")
                            .replace(",", ".")
                        );
                        if ($scope.parDescriaoSalaoParceiro == 1) {
                            $("#valorComissaoDisplayNotaAssinatura").val(0.0);
                        } else {
                            $("#valorComissaoDisplayNotaAssinatura").val(
                                valorComissao.toFixed(2)
                            );
                        }
                        if (obsParceiro != "") {
                            $("#cliCupomObsNotaAssinatura").val(
                                `${infoOrigem}R$ ${(valorServicos - valorComissao).toFixed(
                  2
                )} de cota-parte do salão parceiro: ${
                  $scope.dadosEmpresaNotaAssinatura.CNPJ
                }\n${obsParceiro} \n\n\n ${infoProcon}`
                            );
                        } else {
                            $("#cliCupomObsNotaAssinatura").val(
                                `${infoOrigem}\n\n\n ${infoProcon}`
                            );
                        }
                    } else {
                        $("#valorComissaoDisplayNotaAssinatura").val(0.0);
                        $("#cliCupomObsNotaAssinatura").val(
                            `${infoOrigem} \n\n\n ${infoProcon}`
                        );
                    }

                    setTimeout(() => {
                        if ($scope.parEnderecoNota == 0) {
                            $("#usaEnderecoNotaAssinatura").val(0).change();
                        } else {
                            $("#usaEnderecoNotaAssinatura").val(1).change();
                        }
                    }, 1000);

                    $("#generateCupomAssinatura-modal").modal();
                }
            };

            $scope.criaCupomNotaAssinatura = function() {
                showLoader(true);
                var timegerado = new Date().getTime();
                var proceedNota = 1;
                var msgerro = "";

                if ($scope.emiteSemEnderecoPacote == undefined) {
                    $scope.emiteSemEnderecoPacote = 1;
                } else if ($scope.emiteSemEnderecoPacote == 0) {
                    if (
                        $("#cliCupomUFNotaAssinatura").val() == "" ||
                        $("#cliCupomUFNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o estado do cliente.";
                    } else if (
                        $("#cliCupomCidadeNotaAssinatura").val() == "" ||
                        $("#cliCupomCidadeNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe a cidade do cliente.";
                    } else if (
                        $("#cliCupomCEPNotaAssinatura").val() == "" ||
                        $("#cliCupomCEPNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o CEP do cliente.";
                    } else if (
                        $("#cliCupomBairroNotaAssinatura").val() == "" ||
                        $("#cliCupomBairroNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o bairro do cliente.";
                    } else if (
                        $("#cliCupomLogradouroNotaAssinatura").val() == "" ||
                        $("#cliCupomLogradouroNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o logradouro do cliente.";
                    } else if (
                        $("#cliCupomNumeroNotaAssinatura").val() == "" ||
                        $("#cliCupomNumeroNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o endereço do tomador do serviço. Favor informe o numero do endereço do cliente.";
                    }
                }

                if ($scope.emiteSemCPFPacote == undefined) {
                    $scope.emiteSemCPFPacote = 1;
                } else if ($scope.emiteSemCPFPacote == 0) {
                    if (
                        $("#cliCupomCPFNotaAssinatura").val() == "" ||
                        $("#cliCupomCPFNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o CPF do tomador do serviço. Favor informe o CPF do cliente.";
                    }
                }

                if ($scope.emiteSemClientePacote == undefined) {
                    $scope.emiteSemClientePacote = 1;
                } else if ($scope.emiteSemClientePacote == 0) {
                    if (
                        $("#cliCupomNomeNotaAssinatura").val() == "" ||
                        $("#cliCupomNomeNotaAssinatura").val() == undefined
                    ) {
                        proceedNota = 0;
                        msgerro =
                            "Sua cidade exige o nome do tomador do serviço. Favor informe o nome do cliente.";
                    }
                }

                if (
                    $("#enviaCupomEmailNotaAssinatura").val() == "1" &&
                    $("#cliCupomEmailNotaAssinatura").val() == ""
                ) {
                    proceedNota = 0;
                    msgerro = "Informe um e-mail pra o envio a emissão.";
                }

                if (proceedNota == 1) {
                    if (
                        $("#servicoNaturezaNotaAssinatura option:selected").get(0) !=
                        undefined
                    ) {
                        if (
                            $("#empresaCodigoNFAssinatura").val() != "" &&
                            $("#empresaCodigoNFAssinatura").val() != undefined
                        ) {
                            $.ajax({
                                type: "POST",
                                url: "/pages/cadastros/insereNotaFiscalAssinatura.php",
                                data: {
                                    apfcodigo: $("#apfCodigoNotaAssinatura").val(),
                                    idEmpresa: $("#empresaCodigoNFAssinatura").val(),
                                    idExternoNota: $("#apfCodigoNotaAssinatura").val() + "_" + timegerado,
                                    enviarEmail: $("#enviaCupomEmailNotaAssinatura").val(),
                                    nomeCliente: $("#cliCupomNomeNotaAssinatura").val(),
                                    emailCliente: $("#cliCupomEmailNotaAssinatura").val(),
                                    cpfCliente: $("#cliCupomCPFNotaAssinatura").val(),
                                    logradouroCliente: $(
                                        "#cliCupomLogradouroNotaAssinatura"
                                    ).val(),
                                    numeroCliente: $("#cliCupomNumeroNotaAssinatura").val(),
                                    complementoCliente: $(
                                        "#cliCupomComplementoNotaAssinatura"
                                    ).val(),
                                    bairroCliente: $("#cliCupomBairroNotaAssinatura").val(),
                                    cepCliente: $("#cliCupomCEPNotaAssinatura").val(),
                                    ufCliente: $("#cliCupomUFNotaAssinatura").val(),
                                    cidadeCliente: $("#cliCupomCidadeNotaAssinatura").val(),
                                    descricaoServico: $(
                                        "#servicosPrestadosNotaAssinatura"
                                    ).html(),
                                    aliquotaIss: parseFloat(
                                        $("#servicoNaturezaNotaAssinatura option:selected").get(0)
                                        .dataset.aliquota
                                    ),
                                    itemServico: $(
                                        "#servicoNaturezaNotaAssinatura option:selected"
                                    ).get(0).dataset.itemlista,
                                    cnae: $("#empresaCNAENotaAssinatura").val(),
                                    codigoServico: $("#servicoNaturezaNotaAssinatura").val(),
                                    valorTotal: parseFloat(
                                        $("#valorCupomNotaAssinatura")
                                        .html()
                                        .replace($_CONFIG.MOEDA, "")
                                        .replace(",", ".")
                                    ),
                                    timegerado: timegerado,
                                    valorClss: parseFloat(
                                        $("#valorClssNotaAssinatura").html().replace(",", ".")
                                    ),
                                    valorPis: parseFloat(
                                        $("#valorPisNotaAssinatura").html().replace(",", ".")
                                    ),
                                    valorCofins: parseFloat(
                                        $("#valorCofinsNotaAssinatura").html().replace(",", ".")
                                    ),
                                    valorInss: parseFloat(
                                        $("#valorIrNotaAssinatura").html().replace(",", ".")
                                    ),
                                    valorIr: parseFloat(
                                        $("#valorInssNotaAssinatura").html().replace(",", ".")
                                    ),
                                    observacao: $("#cliCupomObsNotaAssinatura").val(),
                                    deducoes: $("#valorComissaoDisplayNotaAssinatura").val(),
                                    descricaocidadeservico: $(
                                        "#servicoNaturezaNotaAssinatura option:selected"
                                    ).get(0).text,
                                    metadados: "",
                                    codigoNBS: $(
                                        "#servicoNaturezaNotaAssinatura option:selected"
                                    ).get(0).dataset.nbs,
                                },
                                dataType: "json",
                                success: function(result) {
                                    showLoader(false);
                                    if (result.data[0].erro == 1) {
                                        toastr.warning(result.data[0].resultado);
                                    } else {
                                        toastr.warning(result.resultNota.erronf);
                                        if (
                                            result.resultNota.nfid == "" ||
                                            result.resultNota.nfid == undefined
                                        ) {
                                            $.ajax({
                                                type: "POST",
                                                url: "/pages/cadastros/removeAssinaturaNotaFiscal.php",
                                                data: {
                                                    anfcodigoexterno: $("#apfCodigoNotaAssinatura").val() +
                                                        "_" +
                                                        timegerado,
                                                },
                                                dataType: "json",
                                                success: function(data) {
                                                    if (data.data.erro != undefined) {
                                                        toastr.error(data.data.resultado);
                                                    } else {
                                                        if (data.data[0].erro == "0") {
                                                            toastr.success(data.data[0].resultado);
                                                        } else {
                                                            toastr.error(data.data[0].resultado);
                                                        }
                                                    }
                                                },
                                                error: function(result) {
                                                    toastr.error("Falha na conexão.");
                                                },
                                            });
                                        }
                                    }
                                    $("#generateCupomAssinatura-modal").modal("hide");
                                },
                                error: function(result) {
                                    showLoader(false);
                                    toastr.error("Falha na conexão.");
                                },
                            });
                        } else {
                            showLoader(false);
                            toastr.error("Informe o ID da empresa");
                        }
                    } else {
                        showLoader(false);
                        toastr.error("Selecione o Serviço");
                    }
                } else {
                    showLoader(false);
                    toastr.error(msgerro);
                }
            };

            $scope.listaClienteTroca = function() {
                $("#clienteListaTrocaNota").select2({
                    ajax: {
                        url: localStorage.getItem("host"),
                        dataType: "json",
                        delay: 250,
                        data: function(params) {
                            return {
                                nome: params.term,
                                metodo: "buscaClientes_v4",
                                tipo: 5,
                                id: $_CONFIG.ID,
                            };
                        },
                        processResults: function(data, params) {
                            return {
                                results: data.result,
                            };
                        },
                        cache: true,
                    },
                    placeholder: "Sem Cadastro",
                    escapeMarkup: function(markup) {
                        return markup;
                    }, // let our custom formatter work
                    minimumInputLength: 3,
                    templateResult: thumbClienteName,
                    templateSelection: formatRepoSelection,
                });

                $("#listaClienteTrocaNota-modal").modal();
            };

            $scope.listaClienteTrocaProduto = function() {
                $("#clienteListaTrocaNotaProduto").select2({
                    ajax: {
                        url: localStorage.getItem("host"),
                        dataType: "json",
                        delay: 250,
                        data: function(params) {
                            return {
                                nome: params.term,
                                metodo: "buscaClientes_v4",
                                tipo: 5,
                                id: $_CONFIG.ID,
                            };
                        },
                        processResults: function(data, params) {
                            return {
                                results: data.result,
                            };
                        },
                        cache: true,
                    },
                    placeholder: "Sem Cadastro",
                    escapeMarkup: function(markup) {
                        return markup;
                    }, // let our custom formatter work
                    minimumInputLength: 3,
                    templateResult: thumbClienteName,
                    templateSelection: formatRepoSelection,
                });

                $("#listaClienteTrocaNotaProduto-modal").modal();
            };

            $scope.listaClienteTrocaAssinatura = function() {
                $("#clienteListaTrocaNotaAssinatura").select2({
                    ajax: {
                        url: localStorage.getItem("host"),
                        dataType: "json",
                        delay: 250,
                        data: function(params) {
                            return {
                                nome: params.term,
                                metodo: "buscaClientes_v4",
                                tipo: 5,
                                id: $_CONFIG.ID,
                            };
                        },
                        processResults: function(data, params) {
                            return {
                                results: data.result,
                            };
                        },
                        cache: true,
                    },
                    placeholder: "Sem Cadastro",
                    escapeMarkup: function(markup) {
                        return markup;
                    }, // let our custom formatter work
                    minimumInputLength: 3,
                    templateResult: thumbClienteName,
                    templateSelection: formatRepoSelection,
                });

                $("#listaClienteTrocaNotaAssinatura-modal").modal();
            };

            $scope.listaClienteTrocaPacote = function() {
                $("#clienteListaTrocaNotaPacote").select2({
                    ajax: {
                        url: localStorage.getItem("host"),
                        dataType: "json",
                        delay: 250,
                        data: function(params) {
                            return {
                                nome: params.term,
                                metodo: "buscaClientes_v4",
                                tipo: 5,
                                id: $_CONFIG.ID,
                            };
                        },
                        processResults: function(data, params) {
                            return {
                                results: data.result,
                            };
                        },
                        cache: true,
                    },
                    placeholder: "Sem Cadastro",
                    escapeMarkup: function(markup) {
                        return markup;
                    }, // let our custom formatter work
                    minimumInputLength: 3,
                    templateResult: thumbClienteName,
                    templateSelection: formatRepoSelection,
                });

                $("#listaClienteTrocaNotaPacote-modal").modal();
            };

            $scope.buscaDadadosClienteTroca = function() {
                if ($("#clienteListaTrocaNota").val() != "") {
                    showLoader(true);
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoav2.php",
                        data: {
                            tipo: 1,
                            pescodigo: $("#clienteListaTrocaNota").val(),
                        },
                        dataType: "json",
                        success: function(result) {
                            if (result.data.length > 0) {
                                $scope.dadosClienteNota = result.data[0];
                                $("#cliCupomNome").val(result.data[0].Pes_Nome);

                                $("#cliCupomEmail").val(result.data[0].PAF_Email);

                                if (result.data[0].PAF_CPF.length <= 14) {
                                    $("#tipoPessoaNota").val("F");
                                } else {
                                    $("#tipoPessoaNota").val("J");
                                }

                                $("#cliCupomCPF").val(result.data[0].PAF_CPF);
                                $("#cliCupomCEP").val(result.data[0].PAF_CEP);
                                $("#cliCupomUF").val(result.data[0].Est_Codigo);
                                $("#cliCupomCidade").val(result.data[0].Cid_Nome);
                                $("#cliCupomBairro").val(result.data[0].PAF_Bairro);
                                $("#cliCupomLogradouro").val(result.data[0].PAF_Endereco);
                                $("#cliCupomNumero").val(result.data[0].PAF_Numero);
                                if (result.data[0].PAF_IE != "") {
                                    $("#cliCupomIE").val(result.data[0].PAF_IE);
                                } else {
                                    $("#cliCupomIE").val("");
                                }
                                if (result.data[0].PAF_IM != "") {
                                    $("#cliCupomIM").val(result.data[0].PAF_IM);
                                } else {
                                    $("#cliCupomIM").val("");
                                }
                                $("#cliCupomComplemento").val(result.data[0].PAF_Complemento);
                                $("#listaClienteTrocaNota-modal").modal("hide");
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                }
            };

            $scope.buscaDadadosClienteTrocaProduto = function() {
                if ($("#clienteListaTrocaNotaProduto").val() != "") {
                    showLoader(true);
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoav2.php",
                        data: {
                            tipo: 1,
                            pescodigo: $("#clienteListaTrocaNotaProduto").val(),
                        },
                        dataType: "json",
                        success: function(result) {
                            if (result.data.length > 0) {
                                $scope.dadosClienteNota = result.data[0];
                                $("#cliCupomNomeProd").val(result.data[0].Pes_Nome);

                                $("#cliCupomEmailProd").val(result.data[0].PAF_Email);

                                $("#cliCupomCPFProd").val(result.data[0].PAF_CPF);
                                $("#cliCupomCEPProd").val(result.data[0].PAF_CEP);
                                $("#cliCupomUFProd").val(result.data[0].Est_Sigla);
                                $("#cliCupomCidadeProd").val(result.data[0].Cid_Nome);
                                $("#cliCupomBairroProd").val(result.data[0].PAF_Bairro);
                                $("#cliCupomLogradouroProd").val(result.data[0].PAF_Endereco);
                                $("#cliCupomNumeroProd").val(result.data[0].PAF_Numero);
                                $("#cliCupomTelefoneProd").val(result.data[0].PAF_Celular);
                                if (result.data[0].PAF_IE != "") {
                                    $("#cliCupomIEProd").val(result.data[0].PAF_IE);
                                } else {
                                    $("#cliCupomIEProd").val("");
                                }
                                if (result.data[0].PAF_IM != "") {
                                    $("#cliCupomIMProd").val(result.data[0].PAF_IM);
                                } else {
                                    $("#cliCupomIMProd").val("");
                                }
                                $("#cliCupomComplementoProd").val(
                                    result.data[0].PAF_Complemento
                                );
                                $("#listaClienteTrocaNotaProduto-modal").modal("hide");
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                }
            };

            $scope.buscaDadadosClienteTrocaAssinatura = function() {
                if ($("#clienteListaTrocaNotaAssinatura").val() != "") {
                    showLoader(true);
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoav2.php",
                        data: {
                            tipo: 1,
                            pescodigo: $("#clienteListaTrocaNotaAssinatura").val(),
                        },
                        dataType: "json",
                        success: function(result) {
                            if (result.data.length > 0) {
                                $scope.dadosClienteNota = result.data[0];
                                $("#cliCupomNomeNotaAssinatura").val(result.data[0].Pes_Nome);
                                $("#cliCupomEmailNotaAssinatura").val(result.data[0].PAF_Email);
                                $("#cliCupomCPFNotaAssinatura").val(result.data[0].PAF_CPF);
                                $("#cliCupomCEPNotaAssinatura").val(result.data[0].PAF_CEP);
                                $("#cliCupomUFNotaAssinatura").val(result.data[0].Est_Codigo);
                                $("#cliCupomCidadeNotaAssinatura").val(result.data[0].Cid_Nome);
                                $("#cliCupomBairroNotaAssinatura").val(
                                    result.data[0].PAF_Bairro
                                );
                                $("#cliCupomLogradouroNotaAssinatura").val(
                                    result.data[0].PAF_Endereco
                                );
                                $("#cliCupomNumeroNotaAssinatura ").val(
                                    result.data[0].PAF_Numero
                                );
                                $("#cliCupomComplementoNotaAssinatura").val(
                                    result.data[0].PAF_Complemento
                                );
                                $("#listaClienteTrocaNotaAssinatura-modal").modal("hide");
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                }
            };

            $scope.buscaDadadosClienteTrocaPacote = function() {
                if ($("#clienteListaTrocaNotaPacote").val() != "") {
                    showLoader(true);
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaPessoav2.php",
                        data: {
                            tipo: 1,
                            pescodigo: $("#clienteListaTrocaNotaPacote").val(),
                        },
                        dataType: "json",
                        success: function(result) {
                            if (result.data.length > 0) {
                                $scope.dadosClienteNota = result.data[0];
                                $("#cliCupomNomeNotaPacote").val(result.data[0].Pes_Nome);

                                $("#cliCupomEmailNotaPacote").val(result.data[0].PAF_Email);

                                $("#cliCupomCPFNotaPacote").val(result.data[0].PAF_CPF);
                                $("#cliCupomCEPNotaPacote").val(result.data[0].PAF_CEP);
                                $("#cliCupomUFNotaPacote").val(result.data[0].Est_Codigo);
                                $("#cliCupomCidadeNotaPacote").val(result.data[0].Cid_Nome);
                                $("#cliCupomBairroNotaPacote").val(result.data[0].PAF_Bairro);
                                $("#cliCupomLogradouroNotaPacote").val(
                                    result.data[0].PAF_Endereco
                                );
                                $("#cliCupomNumeroNotaPacote ").val(result.data[0].PAF_Numero);
                                $("#cliCupomComplementoNotaPacote").val(
                                    result.data[0].PAF_Complemento
                                );
                                $("#listaClienteTrocaNotaPacote-modal").modal("hide");
                            }
                            showLoader(false);
                        },
                        error: function(result) {
                            toastr.error("Falha na conexão.");
                            showLoader(false);
                        },
                    });
                }
            };

            $scope.limparDadosCliente = function() {
                $scope.dadosClienteNota = "";
                $("#cliCupomNome").val("");
                $("#cliCupomEmail").val("");
                $("#tipoPessoaNota").val("F");
                $("#cliCupomCPF").val("");
                $("#cliCupomCEP").val("");
                $("#cliCupomUF").val("");
                $("#cliCupomCidade").val("");
                $("#cliCupomBairro").val("");
                $("#cliCupomLogradouro").val("");
                $("#cliCupomNumero").val("");
                $("#cliCupomIE").val("");
                $("#cliCupomIM").val("");
                $("#cliCupomComplemento").val("");
            };

            $scope.limparDadosClienteProduto = function() {
                $scope.dadosClienteNota = "";
                $("#cliCupomNomeProd").val("");
                $("#cliCupomEmailProd").val("");

                $("#cliCupomCPFProd").val("");
                $("#cliCupomCEPProd").val("");
                $("#cliCupomUFProd").val("");
                $("#cliCupomCidadeProd").val("");
                $("#cliCupomBairroProd").val("");
                $("#cliCupomLogradouroProd").val("");
                $("#cliCupomNumeroProd").val("");
                $("#cliCupomIEProd").val("");
                $("#cliCupomIMProd").val("");
                $("#cliCupomComplementoProd").val("");
                $("#cliCupomTelefoneProd").val("");
            };

            $scope.limparDadosClienteAssinatura = function() {
                $scope.dadosClienteNota = "";
                $("#cliCupomNomeNotaAssinatura").val("");
                $("#cliCupomEmailNotaAssinatura").val("");
                $("#cliCupomCPFNotaAssinatura").val("");
                $("#cliCupomCEPNotaAssinatura").val("");
                $("#cliCupomUFNotaAssinatura").val("");
                $("#cliCupomCidadeNotaAssinatura").val("");
                $("#cliCupomBairroNotaAssinatura").val("");
                $("#cliCupomLogradouroNotaAssinatura").val("");
                $("#cliCupomNumeroNotaAssinatura").val("");
                $("#cliCupomComplementoNotaAssinatura").val("");
            };

            $scope.limparDadosClientePacote = function() {
                $scope.dadosClienteNota = "";
                $("#cliCupomNomeNotaPacote").val("");
                $("#cliCupomEmailNotaPacote").val("");
                $("#cliCupomCPFNotaPacote").val("");
                $("#cliCupomCEPNotaPacote").val("");
                $("#cliCupomUFNotaPacote").val("");
                $("#cliCupomCidadeNotaPacote").val("");
                $("#cliCupomBairroNotaPacote").val("");
                $("#cliCupomLogradouroNotaPacote").val("");
                $("#cliCupomNumeroNotaPacote").val("");
                $("#cliCupomComplementoNotaPacote").val("");
            };

            $("#btnInteresseNF").click(() => {
                $scope.NFGeraLog();
            });
            $scope.NFGeraLog = function() {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/inserePessoaInteresse.php",
                    data: {
                        tipo: 1,
                    },
                    dataType: "json",
                    success: function(result) {
                        console.log("success");
                    },
                    error: function(result) {
                        console.log("error");
                    },
                });
            };

            $("#btnInteressePrime").click(() => {
                $scope.PrimeGeraLog();
            });
            $scope.PrimeGeraLog = function() {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/inserePessoaInteresse.php",
                    data: {
                        tipo: 2,
                    },
                    dataType: "json",
                    success: function(result) {
                        console.log("success");
                    },
                    error: function(result) {
                        console.log("error");
                    },
                });
            };

            $scope.buscaListaConta = function() {
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/buscaSubContav2.php",
                    data: {
                        tipo: 2,
                    },
                    dataType: "json",
                    success: function(result) {
                        var contalive = "";
                        contalive += "<option value=''>Conta</option>";

                        for (var i = 0; i < result.data.length; i++) {
                            if (result.data[i].Excluido == 0) {
                                contalive +=
                                    "<option value='" +
                                    result.data[i].Con_Codigo +
                                    "'>" +
                                    result.data[i].Con_Descricao +
                                    "</option>";
                            }
                        }
                        $("#buscaContaValeFin").html(contalive);
                    },
                    error: function(result) {},
                });
            };

            $scope.buscaListaConta();

            $scope.cobraClienteContaDigital = function() {
                $("#optCombrancaContaDigital-modal").modal();
            };

            $scope.cobraContaDigitalPix = function() {
                showLoader(true);
                $("#optCombrancaContaDigital-modal").modal("hide");
                var com_codigo = $("#idComanda").html();
                var browserScreenHeight =
                    window.innerHeight ||
                    document.documentElement.clientHeight ||
                    document.body.clientHeight;
                var browserScreenWidth =
                    window.innerWidth ||
                    document.documentElement.clientWidth ||
                    document.body.clientWidth;
                var time_zone_off_set = new Date().getTimezoneOffset() / 60;
                var qrcode_pix;
                var pixIntervId;
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/pay_with_pix_zoop.php",
                    data: {
                        invoice_code: com_codigo,
                        payment_amount: $("#valorPagamento0").val().replace(",", "."),
                        payment_currency: "BRL",
                        payment_description: `${$_CONFIG.APELIDOESTABELECIMENTO}_${com_codigo}_PIX`,
                        device_color_depth: screen.colorDepth,
                        device_java_enabled: navigator.javaEnabled(),
                        device_language: navigator.language,
                        device_screen_height: browserScreenHeight,
                        device_screen_width: browserScreenWidth,
                        device_time_zone_off_set: time_zone_off_set,
                        device_type: "BROWSER",
                        postal_code: $scope.dadosClienteComanda.Cli_CEP,
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data.data.error == false) {
                            if (qrcode_pix != undefined) {
                                $("#qrcode-pagamento-comanda").html("")
                                clearInterval(pixIntervId);
                                pixIntervId = null;
                            } else {
                                $("#qrcode-pagamento-comanda").html("")
                                clearInterval(pixIntervId);
                                pixIntervId = null;
                                $("#qrcode-pagamento-comanda").qrcode(data.data.online_payment[0].pix_qr_code)
                                /*qrcode_pix = new QRCode(
                                  document.getElementById("qrcode-pagamento-comanda"),
                                  {
                                    text: data.data.online_payment[0].pix_qr_code,
                                    width: 200,
                                    height: 200,
                                    colorDark: "#000000",
                                    colorLight: "#FFFFFF",
                                    correctLevel: QRCode.CorrectLevel.H,
                                  }
                                );*/
                                $("#com_codigo_title_pix").html(com_codigo);

                                var htmlData =
                                    '<button class="btn btn-sm btn-primary btnClipLinkQrCode" data-clipboard-text="' +
                                    data.data.online_payment[0].pix_qr_code +
                                    '" ><i class="fa fa-copy" alt="Copiar"></i> Pix Copia e Cola</button>';
                                $("#btnBaixarImagemQRCode_pix").html(htmlData);
                                var clipboard = new ClipboardJS(".btnClipLinkQrCode");
                                clipboard.on("success", function(e) {
                                    toastr.success("Copiado!");
                                });

                                clearInterval(pixIntervId);
                                pixIntervId = null;
                                pixIntervId = setInterval(function() {
                                    if (buscaComandaPagoOnline(com_codigo) == true) {
                                        $("#qrCodePagamento-modal").modal("hide");
                                        clearInterval(pixIntervId);
                                        displayComanda(com_codigo);
                                        $("#btnCobrarCliente").hide();
                                    }
                                }, 10000);

                                var cincoMin = 60 * 5;
                                var display = document.querySelector("#timer_pix");
                                $scope.startTimer(cincoMin, display);
                                setTimeout(function() {
                                    clearInterval(pixIntervId);
                                }, 300000);

                                $("#qrCodePagamento-modal").modal();

                                showLoader(false);
                            }
                        } else {
                            showLoader(false);
                            toastr.error(data.data.message);
                        }
                    },
                    error: function(data) {
                        showLoader(false);
                    },
                });
            };

            function buscaComandaPagoOnline(com_codigo) {
                var retorno = false;
                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/COMANDA_Busca_Pagamento_Online_Empresa.php",
                    async: false,
                    data: {
                        type: 1,
                        invoice_code: com_codigo,
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data.data.error == false) {
                            retorno = true;
                        } else {
                            retorno = false;
                        }
                    },
                    error: function(result) {},
                });
                return retorno;
            }

            $scope.startTimer = function(duration, display) {
                var timer = duration,
                    minutes,
                    seconds;
                var countdown;
                clearInterval(countdown);
                countdown = null;
                countdown = setInterval(function() {
                    minutes = parseInt(timer / 60, 10);
                    seconds = parseInt(timer % 60, 10);

                    minutes = minutes < 10 ? "0" + minutes : minutes;
                    seconds = seconds < 10 ? "0" + seconds : seconds;

                    display.textContent = minutes + ":" + seconds;

                    if (--timer < 0) {
                        $("#label_timer_pix").html(
                            '<b style="color:red">Seu código expirou, a tela será fechada automaticamente<b/>'
                        );
                        setTimeout(function() {
                            $("#qrCodePagamento-modal").modal("hide");
                        }, 4000);
                        clearInterval(countdown);
                    }
                }, 1000);
            };

            $scope.cobraContaDigitalCartao = function() {
                var com_codigo = $("#idComanda").html();
                $("#optCombrancaContaDigital-modal").modal("hide");
                $("#confima_compra_credito-modal").modal();
                $("#com_codigo_title_card").html(com_codigo);
            };

            $scope.pay_invoice_with_card = function() {
                showLoader(true);
                var com_codigo = $("#idComanda").html();
                var browserScreenHeight =
                    window.innerHeight ||
                    document.documentElement.clientHeight ||
                    document.body.clientHeight;
                var browserScreenWidth =
                    window.innerWidth ||
                    document.documentElement.clientWidth ||
                    document.body.clientWidth;
                var time_zone_off_set = new Date().getTimezoneOffset() / 60;

                $.ajax({
                    type: "POST",
                    url: "/pages/cadastros/pay_with_card_zoop.php",
                    data: {
                        invoice_code: com_codigo,
                        payment_amount: $("#valorPagamento0").val().replace(",", "."),
                        payment_currency: "BRL",
                        payment_description: `${$_CONFIG.APELIDOESTABELECIMENTO}_${com_codigo}_CARD`,
                        establishment_name: $_CONFIG.ESTABELECIMENTO,
                        customer_external_ID: $scope.dadosClienteComanda.CIE_ID_Externo,
                        device_color_depth: screen.colorDepth,
                        device_java_enabled: navigator.javaEnabled(),
                        device_language: navigator.language,
                        device_screen_height: browserScreenHeight,
                        device_screen_width: browserScreenWidth,
                        device_time_zone_off_set: time_zone_off_set,
                        device_type: "BROWSER",
                        postal_code: $scope.dadosClienteComanda.Cli_CEP,
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data.data.error == false) {
                            showLoader(false);
                            $("#confima_compra_credito-modal").modal("hide");
                            $("#btnCobrarCliente").hide();
                            displayComanda(com_codigo);
                        } else {
                            toastr.error(data.data.online_payment[0].result);
                            showLoader(false);
                        }
                    },
                    error: function(data) {
                        showLoader(false);
                    },
                });
            };

            $scope.salvaParametro = function(
                parCodigo,
                parValorPrincipal,
                parValorSecundario
            ) {
                $.ajax({
                    dataType: "json",
                    url: "/pages/cadastros/atualizaParametro.php",
                    method: "POST",
                    data: {
                        parCodigo: parCodigo,
                        parValor: parValorPrincipal,
                        parValor2: parValorSecundario,
                    },
                    success: function(result) {
                        if (result.result[0].erro == "0") {
                            toastr.success(result.result[0].resultado);
                        } else {
                            swal(result.result[0].resultado, "", "error");
                        }
                    },
                    error: function(data) {
                        showLoader(false);
                    },
                });
            };

            $scope.getSubParameters = function() {
                var params = getAllParameters();
                var assList = [115, 164, 165, 166, 203, 214];
                if ($scope.parContaDigital2 == 1) {
                    var assList = [115, 146, 164, 165, 166, 182, 183, 184, 203, 214];
                }

                var paramAssList = [];
                for (let i = 0; i < assList.length; i++) {
                    paramAssList.push(
                        params.find(({
                            parameter_code
                        }) => parameter_code === assList[i])
                    );
                }

                if (typeof optTabelaParametro != "undefined") {
                    $("#params_table tbody").unbind("click");
                    optTabelaParametro.destroy();
                }
                optTabelaParametro = $("#params_table").DataTable({
                    dom: 'T<"clear">lfrtip',
                    data: paramAssList,
                    scrollX: isPortrait,
                    columns: [{
                            data: "parameter_description",
                            title: "Parametro",
                            width: "80%",
                        },

                        {
                            orderable: false,
                            data: "parameter_code",
                            width: "10%",
                            render: function(data, t, r) {
                                if (r.parameter_primary_value == 1) {
                                    var istrue = "selected";
                                    var isfalse = "";
                                } else {
                                    var istrue = "";
                                    var isfalse = "selected";
                                }
                                return `<select class='form-control' id="select_value_${r.parameter_code}">
                                    <option value="1" ${istrue}>Sim</option>
                                    <option value="0" ${isfalse}>Não</option>
                                </select>`;
                            },
                        },
                        {
                            class: "saveParameter",
                            orderable: false,
                            data: null,
                            width: "5%",
                            defaultContent: '<button class="btn btn-success btn-xs" ><i class="fa fa-floppy-o"></i></button>',
                        },
                    ],
                    ordering: false,
                    language: {
                        url: "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json",
                    },
                });

                $("#params_table tbody").on("click", "td.saveParameter", function() {
                    var tr = $(this).closest("tr");
                    var row = optTabelaParametro.row(tr);
                    var data = row.data();

                    $scope.salvaParametro(
                        data.parameter_code,
                        $(`#select_value_${data.parameter_code}`).val(),
                        ""
                    );
                });

                $("#param_modal-modal").modal();
                setTimeout(() => {
                    resizeContent();
                }, 1000);
            };

            $scope.geraCupomComanda = function() {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    method: "POST",
                    url: "/pages/cadastros/buscaComandaItens.php",
                    async: false,
                    data: {
                        codigo: $("#lblComCodigo").html(),
                    },
                    success: function(data) {
                        $scope.itensComandacupon = data.data;
                        var trloop = "";

                        for (var a = 0; a < $scope.itensComandacupon.length; a++) {
                            var comcodigocupom = $scope.itensComandacupon[a].Com_Codigo;
                            var nomecupom = $scope.itensComandacupon[a].Cliente;
                            var valorcupom = $scope.itensComandacupon[a].Com_Vlr_Total;
                            var datacomanda = $scope.itensComandacupon[a].Com_Dat_Cadastro;
                            var nomeitem = $scope.itensComandacupon[a].Ser_Descricao;
                            if ($scope.itensComandacupon[a].Ser_Descricao == "") {
                                nomeitem = $scope.itensComandacupon[a].Pro_Descricao;
                            }

                            trloop += `<tr>
									<td>
										<h6>${nomeitem}</h6>
									</td>
									<td>
										<h6>${$scope.itensComandacupon[a].Profissional}</h6>
									</td>
									<td>
										<h6>${$scope.itensComandacupon[a].CIt_Quantidade}</h6>
									</td>
									<td>
										<h6>${$scope.itensComandacupon[a].CIt_Valor}</h6>
									</td>
							  </tr>`;
                        }

                        var htmlTeste = `<html>
								<head>
									<meta charset="UTF-8">
									<title>AppBeleza - Comprovante</title>
								</head>

								<body style="background-color:#EEEEEE; font-family:Verdana;">
									<table  style="width:100%;background-color:#FFF" border="0" align="center" cellpadding="0" cellspacing="0">
										<tr>
											<td height="245" align="center" valign="middle" style="background-color:#000; color:#FFF">
												<h2 style="font-weight:300;">Olá, ${nomecupom}.</h2>
												<h5 style="font-weight:300;">Aqui está seu comprovante não fiscal de atendimento.</h5>
												<div style="background-color:#FFF; color:#000; font-family:Verdana;">
													<h3>Comanda ${comcodigocupom}</h3>
													<h5>${datacomanda}</h5>
													<hr>
													<table style="width:100%;">
														<tr style="text-align:left;">
															<th style="width:40%;">Produto</th>
															<th style="width:30%;">Prof.</th>
															<th style="width:10%;">Qtd</th>
															<th style="width:20%;">Valor(R$)</th>
														</tr>
														${trloop}
													</table>
													<hr>
													<table style="width: 100%;">
														<tr>
															<th>Total da Comanda:</th>
															<td>R$ ${valorcupom}</td>
														</tr>
													</table>
												</div>
											</td>
										</tr>
									</table>
								</body>

							</html>`;

                        var element = htmlTeste;
                        var opt = {
                            margin: [15, 15],
                            filename: `${nomecupom}-${comcodigocupom}.pdf`,
                            image: {
                                type: "jpeg",
                                quality: 0.98,
                            },
                            html2canvas: {
                                scale: 2,
                                letterRendering: true,
                            },
                            jsPDF: {
                                unit: "pt",
                                format: "letter",
                                orientation: "portrait",
                            },
                            pagebreak: {
                                mode: ["avoid-all", "css", "legacy"],
                            },
                        };
                        html2pdf().set(opt).from(element).save();

                        showLoader(false);
                    },
                    error: function(data) {
                        $scope.itensComandacupon = "";
                        showLoader(false);
                    },
                });
            };

            $scope.buscaValorServico = function() {
                var servico = "";
                $.ajax({
                    dataType: "json",
                    url: "pages/cadastros/buscaServicoSelect.php",
                    data: {},
                    success: function(data) {
                        var servico =
                            '<option  value="" selected>Selecione seu serviço de corte</option>';
                        for (var i = 0; i < data.servicos.length; i++) {
                            var valor = data.servicos[i].Ser_Valor;
                            var nome = data.servicos[i].Ser_Descricao;
                            var moeda = data.servicos[i].Moeda;
                            servico += `<option value="${valor}">${nome} - ${moeda}${valor}</option>`;
                        }
                        $("#valorCorte").html(servico);
                    },
                });
            };

            $scope.precificacaoPlanos = function() {
                $("#calcularPlanos-modal").modal();
                if (!localStorage.getItem("videoModalMostrado")) {
                    $("#videoModal").modal();
                    localStorage.setItem("videoModalMostrado", "true"); // Marca como mostrado
                }
                var fim = moment().locale("pt-br").format("L");
                var ini = moment().add(-60, "days").locale("pt-br").format("L");
                $scope.buscaValorServico();
                /*$.ajax({
            type: "POST", 
            url: 'pages/relatorios/buscaNovosClientesCadastrados.php',
            data: {
                tipo: 10,
                dataIni: ini,
                dataFim: fim
            },
            dataType: "json",
            success: function (data) {
                var total = data.data[0].TotalResultados;
                $("#clientesUnicos").val(total);
            },
            error: function (result) {
                swal(result.data[0].erro, "", "error");
            }
             
        });

        if (typeof (tableAgendamentos) != "undefined") {
            $(`#tabelaTotalAgendamentos tbody`).unbind('click')
            tableAgendamentos.destroy();
        }
        tableAgendamentos = $('#tabelaTotalAgendamentos').DataTable({
            "dom": 'T<"clear">lfrtip',
            "ajax": {
                "url": "/pages/relatorios/buscaRelGerencialRankingv5.php",
                "method": "POST",
                'data': function (d) {
                    d.tipo = 1;
                    d.dataini = ini;
                    d.datafim = fim;
                }
            },
            "scrollX": isPortrait,
            "columns": [
                {
                    "data": "Ser_Descricao",
                    "title": "Descrição"
                },
                {
                    "data": "QTD",
                    "title": "Quantidade"
                },
                {
                    "title": "Selecionar",
                    "orderable": false,
                    "render": function (data, type, row) {
                        return `<input type="checkbox" class="select-checkbox" data-qtd="${row.QTD}">`;
                    }
                }
            ],
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json"
            }
        });

        $('#tabelaTotalAgendamentos tbody').on('change', '.select-checkbox', function () {
            var checkbox = $(this);
            var qtd = parseFloat(checkbox.attr('data-qtd')); // Quantidade da linha
            var totalAtendimentos = parseFloat($('#totalAtendimentos').val()) || 0; // Valor atual do campo
    
            if (checkbox.is(':checked')) {
                // Se marcado, soma a quantidade
                totalAtendimentos += qtd;
            } else {
                // Se desmarcado, subtrai a quantidade
                totalAtendimentos -= qtd;
            }
    
            // Atualiza o campo totalAtendimentos
            $('#totalAtendimentos').val(totalAtendimentos);
        });*/
            };

            $scope.calcularPreco = function() {
                var atendimentos = parseFloat($("#totalAtendimentos").val());
                var clientes = parseFloat($("#clientesUnicos").val());
                var faturado = parseFloat($("#valorCorte").val().replace(",", "."));

                var preco = faturado * (atendimentos / clientes);
                var barba = preco * 1.17;
                var combo = preco * 1.76;

                $("#planoCorte").val("R$ " + preco.toFixed(2).replace(".", ","));
                $("#planoBarba").val("R$ " + barba.toFixed(2).replace(".", ","));
                $("#planoCombo").val("R$ " + combo.toFixed(2).replace(".", ","));
            };

            $("#videoModal").on("hidden.bs.modal", function() {
                var iframe = $(this).find("iframe");
                var src = iframe.attr("src");
                iframe.attr("src", ""); // Remove o src (para forçar o stop)
                iframe.attr("src", src); // Reatribui o src original
            });

            $scope.buscaTabelaComandaTotem = function() {
                if (typeof tabelacomandatotemopt !== "undefined") {
                    tabelacomandatotemopt.destroy();
                }
                tabelacomandatotemopt = $("#comandaTotemTable").DataTable({
                    ajax: {
                        url: "/pages/cadastros/COMANDA_TOTEM_STATUS_Busca.php",
                        method: "POST",
                        data: function(d) {
                            d.type = 1;
                        },
                    },
                    scrollX: isPortrait,
                    initComplete: function() {
                        $compile($("#comandaTotemTable"))($scope);
                        $("#comandaTotemTableo_paginate").click(function() {
                            $compile($("#comandaTotemTable"))($scope);
                        });
                        $("#comandaTotemTable_filter").change(function() {
                            $compile($("#tabelaserProfAsso"))($scope);
                        });
                        $("#comandaTotemTable_length").change(function() {
                            $compile($("#comandaTotemTable"))($scope);
                        });
                        resizeContent();
                    },
                    columns: [{
                            data: "invoice_code",
                            title: "Comanda",
                        },
                        {
                            data: "person_name",
                            title: "Cliente",
                        },
                        {
                            data: "invoice_message",
                            title: "Mensagem",
                        },
                        {
                            data: "insert_date",
                            title: "Data do pagamento",
                        },
                        {
                            class: "abrecomanda-control",
                            orderable: false,
                            data: null,
                            defaultContent: '<button class="btn btn-success btn-xs " id="abreComandaContaCliente">Ver Comanda</button>',
                        },
                    ],
                    ordering: false,
                    searching: false,
                    lenghtChange: false,
                    paging: false,
                    language: {
                        url: $_CONFIG.language.datatables,
                    },
                });

                $("#comandaTotemTable tbody").on(
                    "click",
                    "td.abrecomanda-control",
                    function() {
                        var tr = $(this).closest("tr");
                        var row = tabelacomandatotemopt.row(tr);
                        var data = row.data();
                        displayComanda(data.invoice_code);
                        $("#listaComandaTotem-modal").modal("hide");
                    }
                );

                $("#listaComandaTotem-modal").modal();
            };
        }
    );