angular.module('appBeleza').controller('notificacaoCtrl', function($scope, $http, $interval, $state) {
    $scope.alertas = '';
    $scope.mensagens = '';
    $scope.aniversariantes = '';
    $scope.totAlertas = '';
    $scope.totMensagens = '';
    $scope.totAniversariantes = '';
    $scope.notFirstExecAlert = false;
    $scope.notFirstExecMsg = false;
    $scope.totResumo = 0;
    $scope.filterSol = '';
    $scope.timerNotificacoesMS = 300000;

    $('.btnFilter').click(function(e) {
        $('.btnFilter').removeClass('bg-green');
        $('.btnFilter').addClass('bg-gray');
        $(this).removeClass('bg-gray');
        $(this).addClass('bg-green');
        e.stopPropagation();
    });

    $('.btnSolCad').click(function(e) {
        e.stopPropagation();
    });

    $scope.enviaMsg = function(codigo, today) {

        buscaClientes($scope.enviaMsgCliente, codigo, today);
    }
    $scope.enviaMsgCliente = function(codigo, isToday) {

        $('#todosSelecionadosmsg').hide();
        $('#divmsgUsuario').show();
        $('#formCadastroMensagem').each(function() {
            this.reset();
        });
        if (isToday) {

            var dataini = moment().locale('pt-br').format('L');
            $('.date.divDataIni').datepicker('update', dataini);
            $('#cadastrarmsg-modal').modal();
            setTimeout(function() {
                $('#msgUsuario option[data-codigo="' + codigo + '"]').get(0).selected = true;
                $('#msgUsuario').trigger('change');
            }, 1200);
        }
    }

    $('#formCadastroMensagem').submit(function(event) {
        event.preventDefault();
        formCadastro = $(this);
        showLoader(true);

        var horamin = $('#msgHoraEnvio').val().split(':');
        var valoresPes = [];
        var valoresUsu = [];
        var semUsu = 0;
        var obj = $('#msgUsuario').select2('data');
        var isSingleMsg = $("#isSingleMSG").val();

        var limitEnvios = 50;
        if ($state.current.name == "relDiasSemVir") {
            limitEnvios = 1000;
        }

        if (obj.length > 0) {

            if (obj.length > limitEnvios) {

                var htmlAviso = `
					<p>O número máximo de clientes permitidos por envio é <strong>${limitEnvios}</strong>.</p><br>
					<p> Caso necessite enviar para todos clientes, utilize a opção <strong class="text-green">Notícias</strong> </p><br>
					<p> <h4>Maiores dúvidas, acesse nossa <strong><a target="_blank" href="https://appbarber-appbeleza.zendesk.com/hc/pt-br/articles/360002981011-Qual-a-diferen%C3%A7a-entre-Envio-de-Not%C3%ADcias-e-Envio-de-Mensagem">Central de Ajuda</a></strong>.</h4></p>
				`;
                swal({
                    title: "Limite de Clientes para Envio.",
                    text: htmlAviso,
                    html: true,
                    type: "warning",
                });

                showLoader(false);
                return false;

            } else {

                if (hasManyClients && (isSingleMsg == "1")) {
                    obj.forEach(function(e, idx) {
                        valoresPes.push(e.Pes_Codigo);
                        valoresUsu.push(e.Usu_Codigo);
                    });
                } else {
                    obj.forEach(function(e, idx) {
                        if (e.element.dataset.codigo != undefined && e.element.dataset.codigo != '') {
                            valoresPes.push(e.element.dataset.codigo);
                        }
                        if (e.element.value != undefined && e.element.value != '') {
                            valoresUsu.push(e.element.value);
                        }

                    });
                }



                for (var index = 0; index < valoresUsu.length; index++) {
                    if (valoresUsu[index] == '') {
                        semUsu = 1;
                    }
                }

                var horamin = $('#msgHoraEnvio').val().split(':');

                if (horamin[0] > 23) {
                    swal('Horário Inválido.', 'Informe um horário válido', 'error');
                    showLoader(false);
                } else if (horamin[1] > 59) {
                    swal('Horário Inválido.', 'Informe um horário válido', 'error');
                    showLoader(false);
                } else if ($('#msgEnviarSms').get(0).checked && parseInt($('#lblSaldoSMSMsg').html()) <= 0) {
                    swal('Saldo SMS insuficiente.', 'Você não possui créditos SMS. Por favor, faça uma recarga para enviar SMS.', 'error');
                    showLoader(false);
                } else if ($('#msgEnviarSms').get(0).checked && parseInt($('#lblSaldoSMSMsg').html()) < $("#msgUsuario").val().length) {
                    swal('Saldo SMS insuficiente.', 'Você não possui créditos SMS suficientes para fazer todos os envios.', 'error');
                    showLoader(false);
                } else if (!$('#msgEnviarSms').get(0).checked && $('#msgUsuario').val() == '') {
                    swal('Cliente sem usuário.', 'Este cliente não possui usuário cadastrado e não receberá essa mensagem. Por favor utilize o envio com SMS ou a criação de um usuário para este cliente.', 'error');
                    showLoader(false);
                } else {

                    dataInsere = new FormData(this);
                    if ($('#msgEnviarSms').get(0).checked) {
                        dataInsere.append('usasms', '1');
                    } else {
                        dataInsere.append('usasms', '0');
                    }
                    dataInsere.append('msgPesCodigo', valoresPes);

                    if (dataInsere.delete != undefined) {
                        dataInsere.delete('msgUsuario');
                    }

                    dataInsere.append('msgUsuario', valoresUsu);
                    $.ajax({
                        type: 'POST',
                        url: '/pages/cadastros/insereMensagem.php',
                        data: dataInsere,
                        dataType: 'json',
                        processData: false,
                        contentType: false,
                        success: function(result) {
                            var texto = `<span style="color:green;">
											<i class="fa fa-check"></i>&nbspEnviados com sucesso:&nbsp${result.sucesso}
										</span>`;

                            if (result.falha > 0) {
                                texto += `<span style="color:red;">
												<i class="fa fa-times"></i>&nbspFalhas no envio:&nbsp${result.falha}
											</span>`;
                            }

                            swal({
                                title: '<small>Resultado</small>',
                                text: texto,
                                html: true
                            });
                            $('#cadastrarmsg-modal').modal('hide');
                            formCadastro.each(function() {
                                this.reset();
                            });
                            $('#todosSelecionadosmsg').hide();
                            $('#divmsgUsuario').show();
                            $scope.buscaSaldoSMSMsg();
                            $('#divSaldoSmsMsg').hide();
                            $('#charNumMsg').hide();
                            $('#divDescNot').removeClass('has-error');
                            showLoader(false);
                        },
                        error: function(result) {
                            swal('Falha na conexão.', '', 'error');
                            showLoader(false);
                        }
                    });
                }

                return true;

            }

        } else {
            swal('Nenhum cliente informado.', 'Favor selecione ao menos um cliente para receber a mensagem', 'error');
            showLoader(false);
            return false;
        }
    });


    $('#cadastrarmsg-modal').on('hidden.bs.modal', function() {
        $("#isSingleMSG").val("");
    });
    // $scope.buscaResumo = function () {
    // 	$http.get('/pages/relatorios/buscaRelDashboard.php').
    // 	success(function (data, status, headers, config) {

    // 		var keys = []
    // 		var countResumo = 0;
    // 		var obj = data.data[0];
    // 		for (var key in obj) {
    // 			keys.push(key)
    // 		}
    // 		for (var i = 0; i < keys.length; i++) {
    // 			if (obj[keys[i]] != 0) {
    // 				countResumo++;
    // 			}
    // 		}
    // 		$scope.totResumo = countResumo;
    // 		$('#countResumo').show();
    // 	});
    // }

    $scope.buscaAniversariantes = function() {
        $scope.valorSelecionado = '';
        $http.get(localStorage.getItem('host') + '?metodo=buscaAniversariante&id=' + $_CONFIG.ID).
        success(function(data, status, headers, config) {
            arrAniv = new Array();

            for (var i = 0; i < data.result.length; i++) {
                objAniv = new Object();
                dataAniversario = new Date(data.result[i].PAF_Dat_Nascimento);
                momDate = moment(dataAniversario);
                momDateNow = moment({
                    month: momDate.month(),
                    day: momDate.date(),
                    year: moment().year()
                });

                DiaAniversario = moment(momDateNow).locale('PT-BR').calendar(null, {
                    sameDay: '[Hoje]',
                    nextDay: '[Amanhã]',
                    nextWeek: 'dddd',
                    lastDay: '[Ontem]',
                    lastWeek: '[Semana Passada]'
                });
                objAniv['DiaAniversario'] = DiaAniversario
                objAniv['Nome'] = data.result[i].Pes_Nome.trim();
                objAniv['TotalHoje'] = data.result[i].TotalHoje;
                objAniv['UsuCodigo'] = data.result[i].Usu_Codigo;
                objAniv['PesCodigo'] = data.result[i].Pes_Codigo;

                if (DiaAniversario == 'Hoje') {
                    objAniv['isToday'] = true;
                    objAniv['textStyle'] = 'font-weight:bold';
                    objAniv['textSize'] = 'font-size:small';
                } else {
                    objAniv['isToday'] = false;
                    objAniv['textStyle'] = 'font-weight:normal';
                    objAniv['textSize'] = 'font-size:x-small';
                }

                if (data.result[i].PAF_Imagem == '') {
                    objAniv['Imagem'] = '/img/nopicture.png';
                } else {
                    objAniv['Imagem'] = data.result[i].PAF_Imagem;
                }
                arrAniv.push(objAniv);
            };
            $scope.aniversariantes = arrAniv;

            if ($scope.aniversariantes.length == 0) {
                $scope.totAniversariantes = '';
            } else {
                $scope.totAniversariantes = $scope.aniversariantes[0].TotalHoje;
                $('#countAniv').show();
            }

        }).
        error(function(data, status, headers, config) {
            console.log('Falha ao buscar as mensagens. Erro:' + data);
        });
    };

    $scope.buscaAlerta = function() {
        $scope.valorSelecionado = '';

        $http.get(localStorage.getItem('host') + '?metodo=buscaMensagemUsuario&tipo=2&id=' + $_CONFIG.ID).
        success(function(data, status, headers, config) {
            $scope.alertas = data.result;

            if (($scope.alertas.length > $scope.totAlertas) && $scope.notFirstExecAlert) {
                soundNewMessage.play();
            }
            if ($scope.alertas.length == 0) {
                $scope.totAlertas = '';
            } else {
                $scope.totAlertas = $scope.alertas.length;
                $('#countAlert').show();
            }

            $scope.notFirstExecAlert = true;

        }).
        error(function(data, status, headers, config) {
            console.log('Falha ao buscar os alertas. Erro:' + data);
        });

    };

    $scope.buscaMensagem = function() {
        $scope.valorSelecionado = '';
        $scope.listamsg = '';
        $scope.listamsg2 = '';
        $http.get(localStorage.getItem('host') + '?metodo=buscaMensagemUsuario&tipo=1&id=' + $_CONFIG.ID).
        success(function(data, status, headers, config) {
            $scope.listamsg = data.result;

            /* if ( ($scope.mensagens.length > $scope.totMensagens) &&
                   ($scope.notFirstExecMsg)) {
               soundNewMessage.play();
             }
             if ($scope.mensagens.length == 0){
               $scope.totMensagens = '';
             } else {
               $scope.totMensagens = $scope.mensagens.length;
               $('#countMsg').show();
             }
             $scope.notFirstExecMsg = true;*/

            /*-----------------------------------------------------*/

            $http.get('https://api.appbarber.com.br/buscaMensagemUsuarioProfissional?api_key=TcskrU3Ejze.6&tipo=1&id=' + $_CONFIG.ID).
            success(function(data, status, headers, config) {
                $scope.listamsg2 = data.result;

                /* if ( ($scope.mensagens.length > $scope.totMensagens) &&
                      ($scope.notFirstExecMsg)) {
                  soundNewMessage.play();
                }
                if ($scope.mensagens.length == 0){
                  $scope.totMensagens = '';
                } else {
                  $scope.totMensagens = $scope.mensagens.length;
                  $('#countMsg').show();
                }
                $scope.notFirstExecMsg = true;*/

                $scope.mensagens = angular.extend($scope.listamsg, $scope.listamsg2)
                if (($scope.mensagens.length > $scope.totMensagens) &&
                    ($scope.notFirstExecMsg)) {
                    soundNewMessage.play();
                }
                if ($scope.mensagens.length == 0) {
                    $scope.totMensagens = '';
                } else {
                    $scope.totMensagens = $scope.mensagens.length;
                    $('#countMsg').show();
                }
                $scope.notFirstExecMsg = true;

            }).
            error(function(data, status, headers, config) {
                console.log('Falha ao buscar as mensagens. Erro:' + data);
            });


            /*-----------------------------------------------------*/

        }).
        error(function(data, status, headers, config) {
            console.log('Falha ao buscar as mensagens. Erro:' + data);
        });



    };

    $scope.buscaSolCad = function() {

        $http.get(localStorage.getItem('host') + '?metodo=buscaSolicitacaoCadastro&tipo=5&id=' + $_CONFIG.ID).
        success(function(data, status, headers, config) {
            $scope.solcad = data.result;

            //Adiciona o indíce, para que funcione o idx correto quando filtrado.
            for (var i = 0; i < data.result.length; i++) {
                $scope.solcad[i].idx = i;
                if (data.result[i].SCa_Imagem == '') {
                    $scope.solcad[i].SCa_Imagem = '/img/nopicture.png';
                } else {
                    $scope.solcad[i].SCa_Imagem = data.result[i].SCa_Imagem;
                }
            }

            if (($scope.solcad.length > $scope.totSolCad) &&
                ($scope.notFirstExecSolCad)) {
                soundNewMessage.play();
            }
            if ($scope.solcad.length == 0) {
                $scope.totSolCad = '';
            } else {
                $scope.totSolCad = $scope.solcad.length;
                $scope.totSolCadBadge = $scope.solcad[0].Total;
                $('#countNewUser').show();
            }

            $scope.notFirstExecSolCad = true;

            if ($scope.totSolCadBadge > 0) {
                if ($scope.totSolCadBadge == 1) {
                    $scope.titleSolCad = 'Há ' + $scope.totSolCadBadge + ' solicitação pendente.';
                } else {
                    $scope.titleSolCad = 'Há ' + $scope.totSolCadBadge + ' solicitações pendentes.';
                }
            } else {
                $scope.titleSolCad = 'Nenhuma solicitação pendente.';
            }

        }).
        error(function(data, status, headers, config) {
            console.log('Falha ao buscar as solicitações de cadastro. Erro:' + data);
        });
    };

    $scope.atualizaMensagem = function(mencodigo) {

        $http.get(localStorage.getItem('host') + '?metodo=atualizaMensagemUsuario&mencodigo=' + mencodigo +
            '&id=' + $scope.idCliente).
        success(function(data, status, headers, config) {
            $scope.buscaMensagem();
        }).
        error(function(data, status, headers, config) {
            console.log('Falha ao atualizar Mensagem. Erro:' + data);
        });
    };


    $scope.atualizaMensagemProfissional = function(mencodigo) {

        $.ajax({
            type: "POST",
            url: "/pages/cadastros/alteraMensagemUsuarioProfissional.php",
            data: {
                mepcodigo: mencodigo
            },
            dataType: "json",
            success: function(result) {
                $scope.buscaMensagem();
            },
            error: function(result) {
                console.log('Falha ao atualizar Mensagem: ' + data);
            }
        });
    };




    $scope.showMessage = function(id, title, text, icon, tipo) {

        if (tipo == 1) {
            $scope.atualizaMensagem(id);
        } else {
            $scope.atualizaMensagemProfissional(id)
        }
        swal({
            html: true,
            imageUrl: icon,
            title: title,
            animation: 'slide-from-top',
            text: '<h4 align="justify" style="color:black;">' + text + '</h4>',

        });
    }

    $scope.confirmNewUser = function(index) {

        if ($scope.solcad[index].TipoSolicitacao == 1) {

            var url = localStorage.getItem('host') + '?metodo=insereCliente_v2&id=' + $scope.idCliente +
                '&nome=' + $scope.solcad[index].SCa_Nome +
                '&email=' + $scope.solcad[index].SCa_Email +
                '&cpf=' + $scope.solcad[index].SCa_CPF +
                '&celular=' + $scope.solcad[index].SCa_Celular +
                '&login=' + $scope.solcad[index].SCa_Login +
                '&senha=' + $scope.solcad[index].SCa_Senha +
                '&idterceiro=' + $scope.solcad[index].IDTerceiro +
                '&tipo=' + $scope.solcad[index].SCa_Tipo +
                '&imagem=' + $scope.solcad[index].SCa_Imagem.replace(/&/g, '%26');

            showLoader(true);

            $http.get(url.replace(/ /g, '%20')).
            success(function(data, status, headers, config) {
                if (data.insereCliente[0].erro == '0') {
                    $http.get(localStorage.getItem('host') +
                        '?metodo=atualizaSolicitacaoCadastro&id=' + $scope.idCliente +
                        '&scacodigo=' + $scope.solcad[index].SCa_Codigo +
                        '&scaaprovado=1'
                    ).
                    success(function(data, status, headers, config) {
                        if (data.result[0].erro == '0') {
                            toastr['success'](data.result[0].resultado);
                            showLoader(false);
                        } else {
                            toastr['error'](data.result[0].resultado);
                            showLoader(false);
                        }
                        $scope.buscaSolCad();
                    }).
                    error(function(data, status, headers, config) {
                        console.log('Falha ao inserir Cliente. Erro:' + data);
                        showLoader(false);
                    });
                } else {
                    toastr['error'](data.insereCliente[0].resultado);
                    showLoader(false);
                }
            }).
            error(function(data, status, headers, config) {
                console.log('Falha ao inserir Cliente. Erro:' + data);
                showLoader(false);
            });

        } else {
            showLoader(true);
            $.ajax({
                type: "POST",
                url: "/pages/cadastros/CLIENTEAprovaVinculo.php",
                data: {
                    join_request_code: $scope.solcad[index].SCa_Codigo,
                    join_request_approve: 1
                },
                dataType: "json",
                success: function(data) {
                    if (data.data.error == false) {
                        toastr['success'](data.data.message);
                        showLoader(false);
                    } else {
                        toastr['error'](data.data.message);
                        showLoader(false);
                    }
                    $scope.buscaSolCad();
                },
                error: function(data) {
                    console.log('Falha ao inserir Cliente. Erro:' + data);
                    showLoader(false);
                }
            });
        }

    }

    $scope.reproveNewUser = function(index) {

        if ($scope.solcad[index].TipoSolicitacao == 1) {

            $http.get(
                localStorage.getItem('host') + '?metodo=atualizaSolicitacaoCadastro&id=' + $scope.idCliente +
                '&scacodigo=' + $scope.solcad[index].SCa_Codigo +
                '&scaaprovado=0'
            ).
            success(function(data, status, headers, config) {
                if (data.result[0].erro == '0') {
                    toastr["success"](data.result[0].resultado)
                } else {
                    toastr["error"](data.result[0].resultado)
                }
                $scope.buscaSolCad();
            }).
            error(function(data, status, headers, config) {
                console.log("Falha ao inserir Cliente. Erro:" + data);
            });

        } else {
            showLoader(true);
            $.ajax({
                type: "POST",
                url: "/pages/cadastros/CLIENTEAprovaVinculo.php",
                data: {
                    join_request_code: $scope.solcad[index].SCa_Codigo,
                    join_request_approve: 0
                },
                dataType: "json",
                success: function(data) {
                    if (data.data.error == false) {
                        toastr['success'](data.data.message);
                        showLoader(false);
                    } else {
                        toastr['error'](data.data.message);
                        showLoader(false);
                    }
                    $scope.buscaSolCad();
                },
                error: function(data) {
                    console.log('Falha ao inserir Cliente. Erro:' + data);
                    showLoader(false);
                }
            });
        }
    }

    $scope.undoNewUser = function(index) {

        if ($scope.solcad[index].TipoSolicitacao == 1) {
            $http.get(
                localStorage.getItem('host') + '?metodo=alteraSolicitacaoCadastro&id=' + $scope.idCliente +
                '&scacodigo=' + $scope.solcad[index].SCa_Codigo +
                '&tipo=1'
            ).
            success(function(data, status, headers, config) {
                if (data.result[0].erro == "0") {
                    toastr['success'](data.result[0].resultado)
                } else {
                    toastr['error'](data.result[0].resultado)
                }
                $scope.buscaSolCad();
            }).
            error(function(data, status, headers, config) {
                console.log('Falha ao inserir Cliente. Erro:' + data);
            });
        } else {
            showLoader(true);
            $.ajax({
                type: "POST",
                url: "/pages/cadastros/CLIENTEAprovaVinculo.php",
                data: {
                    join_request_code: $scope.solcad[index].SCa_Codigo,
                    join_request_approve: 2
                },
                dataType: "json",
                success: function(data) {
                    if (data.data.error == false) {
                        toastr['success'](data.data.message);
                        showLoader(false);
                    } else {
                        toastr['error'](data.data.message);
                        showLoader(false);
                    }
                    $scope.buscaSolCad();
                },
                error: function(data) {
                    console.log('Falha ao inserir Cliente. Erro:' + data);
                    showLoader(false);
                }
            });
        }
    }

    //$scope.buscaAlerta();
    $scope.buscaMensagem();
    $scope.buscaAniversariantes();
    $scope.buscaSolCad();
    /*$scope.buscaResumo();*/

    $interval(() => {
        if (updateSchedule) {
            //$scope.buscaAlerta();
            $scope.buscaMensagem();
            $scope.buscaSolCad();
        }
    }, $scope.timerNotificacoesMS);




});