angular.module('appBeleza').controller("caixaCtrl", function($rootScope, $scope, $http, $compile, $state, $interval) {

    $rootScope.header = sSistema + " | Caixa";
    $scope.timerIntervalCaixa = 300000;
    $("#navProf").hide();
    $("#formProf").hide();

    changeHeightBody();
    $('[data-toggle="popover"]').popover({
        container: 'body'
    });

    if ($state.current.name == "caixa") {
        validaPerfil($state.current.name);
        $(".btn-caixa").hide();
        $("#formCaxSaida").unbind("submit");
        $("#formCaxEntrada").unbind("submit");
        $("#formCadastroCaixa").unbind("submit");
        $("#formDespesaCaixa").unbind("submit");
    } else {
        if (isMobile) {
            $(".btn-caixa").hide();
        } else {
            $(".btn-caixa").show();
        }
    }

    $(".input-group.divData").datepicker({
        language: "pt-BR",
        orientation: "top auto",
        autoclose: true,
        format: "dd/mm/yyyy"
    });

    $scope.verdia = 0;
    $scope.buscaParVerDia = function() {
        $.ajax({
            dataType: 'json',
            url: localStorage.getItem('host'),
            async: false,
            data: {
                metodo: 'buscaParametro',
                id: $scope.idCliente,
                parcodigo: 69
            },
            success: function(data) {
                if (data.result.length > 0) {
                    if (data.result[0].PVa_Vlr_Principal == '1') {
                        $scope.verdia = 1;
                    } else {
                        $scope.verdia = 0;
                        $(".caixaVerDia").hide();
                    }
                } else {
                    $scope.verdia = 0;
                }
            }
        });

        $.ajax({
            dataType: 'json',
            url: localStorage.getItem('host'),
            async: false,
            data: {
                metodo: 'buscaParametro',
                id: $scope.idCliente,
                parcodigo: 215
            },
            success: function(data) {
                if (data.result.length > 0) {
                    if ($_CONFIG.ISG != 1) {
                        if (data.result[0].PVa_Vlr_Principal == '1') {
                            $(".btnEdtCaixa").hide();
                        } else {
                            $(".btnEdtCaixa").show();
                        }
                    } else {
                        $(".btnEdtCaixa").show();
                    }
                } else {
                    $(".btnEdtCaixa").show()
                }
            }
        });
    }
    $scope.buscaParVerDia()

    $scope.idCliente = $_CONFIG.ID;

    $.ajax({
        dataType: "json",
        url: localStorage.getItem("host"),
        data: {
            metodo: 'buscaDataAtual',
            id: $scope.idCliente
        },
        success: function(data) {
            var datahoralocal = moment(data.buscaDataAtual[0].resultado).locale("pt-br").format("L");

            $('.input-group.divData').datepicker('update', datahoralocal);
            var datafim = moment().locale("pt-br").format("L");
            $('.date.dateSangriaEntrada').datepicker('update', datafim);

        },
        error: function() {
            var dataini = moment().locale("pt-br").format("L");
            $('.input-group.divData').datepicker('update', dataini);
        }
    });

    $.ajax({
        dataType: "json",
        url: localStorage.getItem("host"),
        data: {
            metodo: 'buscaTipoPagamento',
            id: $scope.idCliente
        },
        success: function(data) {
            var html = "";
            html += '<option data-cartao="0" value="">Forma de Pagamento</option>';
            for (var i = 0; i < data.result.length; i++) {
                var codigo = data.result[i].TPa_Codigo;
                var descricao = data.result[i].TPa_Descricao;
                var cartao = data.result[i].TPa_Cartao;
                html += '<option data-cartao="' + cartao + '" value="' + codigo + '" >' + descricao + '</option>';
            }
            $("#pFormaPag").html(html);
            $("#pFormaPagSaida").html(html);
            $("#pFormaPag").change();
        }
    });

    $("#pFormaPag").change(function() {
        if ($("#pFormaPag option:selected")[0].dataset.cartao == 1) {
            $("#bandeirasHide").show();
            $scope.buscabandeira($("#pFormaPag option:selected").val());
        } else {
            $("#bandeirasHide").hide();
        }
    });

    $scope.buscabandeira = function(tpacodigo) {
        $.ajax({
            dataType: "json",
            url: localStorage.getItem("host"),
            data: {
                metodo: 'buscaTipoBandeira',
                id: $scope.idCliente,
                tpacodigo: tpacodigo
            },
            success: function(data) {
                var html2 = '';
                html2 += '<option  value="" selected>Sem Bandeira</option>';
                if (data.result.length > 0) {
                    for (var i = 0; i < data.result.length; i++) {
                        var codigo = data.result[i].TBa_Codigo;
                        var descricao = data.result[i].TBa_Descricao;
                        html2 += '<option  value="' + codigo + '" >' + descricao + '</option>';
                    }
                }
                $("#divBandeiraPag").html(html2);
            }
        });
    };

    $scope.buscaProfissionalValeCaixa = function() {
        $http.get('/php/buscaSessao.php').
        success(function(data, status, headers, config) {
            $scope.idCliente = data;
            $.ajax({
                dataType: "json",
                url: localStorage.getItem("host"),
                data: {
                    metodo: 'buscaProfissionais',
                    id: $scope.idCliente,
                    tipo: 5
                },
                success: function(data) {
                    var html = "";
                    html += '<option value="">Profissional</option>';
                    for (var i = 0; i < data.profissionais.length; i++) {
                        var codigo = data.profissionais[i].Pes_Codigo;
                        var nome = data.profissionais[i].Pes_Nome;
                        var apelido = data.profissionais[i].Pes_Apelido;
                        html += '<option value="' + codigo + '">' + nome + '</option>';
                    }
                    $("#buscaProfissionalCaixa").html(html);
                }
            });
        });
    };

    function init() {
        carregaDados();
        $scope.buscaReceita();
        $scope.buscaDespesa();
    }

    $scope.buscaDespesa = function() {
        var despesa = "";
        $("#proxCaixa").val(0)
        $("#proxCaixa").attr('disabled', false)
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/buscaDespesa.php",
            dataType: "json",
            success: (result) => {
                despesa += "<option value=''>Nenhuma</option>";
                for (var i = 0; i < result.data.length; i++) {
                    despesa += "<option value='" + result.data[i].TDe_Codigo + "' data-vale='" + result.data[i].TDe_Vale + "'>" + result.data[i].TDe_Descricao + "</option>";
                };
                $('#buscaDespesaCaixa').html(despesa);
            },
            error: () => {}
        });
    }

    $scope.buscaReceita = function() {
        var receita = "";
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/buscaReceita.php",
            dataType: "json",
            success: (result) => {
                //$("#buscaReceitaCaixa").multiselect("destroy");
                receita += "<option value=''>Nenhuma</option>";
                for (var i = 0; i < result.data.length; i++) {
                    receita += "<option value='" + result.data[i].TRe_Codigo + "'>" + result.data[i].TRe_Descricao + "</option>";
                };
                $('#buscaReceitaCaixa').html(receita);
                /*$('#buscaReceitaCaixa').multiselect({
                	enableFiltering: true,
                	nonSelectedText: 'Receitas',
                	filterPlaceholder: 'Buscar'
                });*/
            },
            error: (result) => {
                /*$('#buscaReceitaCaixa').multiselect({
                	enableFiltering: true,
                	nonSelectedText: 'Receitas',
                	filterPlaceholder: 'Buscar'
                });*/
            }
        });
    }

    function colors(value, row, index) {
        let cor = '';

        if (value.FCM_Entrada == 1) {
            cor = 'green';
        } else {
            cor = 'red';
        }

        return {
            css: {
                "color": cor,
                "font-size": 'smaller'
            }
        };
    }

    function currencySorter(a, b) {
        var numA = parseFloat(a.replace(/[^0-9,.-]/g, '').replace(',', '.'));
        var numB = parseFloat(b.replace(/[^0-9,.-]/g, '').replace(',', '.'));
        return numA - numB;
    }

    function editFormatter(value, row) {
        var btnComanda = `<button class="btn btn-primary comandaModal btn-xs" data-codigo="${row.FCM_Codigo}">
								<i class="fa fa-list-alt" ></i>
							</button>`;

        var btnInfo = `<button class="btn btn-info infoModal btn-xs" data-codigo="${row.FCM_Codigo}">
							<i class="fa fa-info" ></i>
						</button>`;

        var btnRemover = `<button class="btn btn-danger btn-xs deletedModal" data-codigo="${row.FCM_Codigo}">
								<i class="fa fa-trash" ></i>
							</button>`;


        if (row.Com_Codigo == "") {
            return `${btnInfo} ${btnRemover}`
        } else {
            return `${btnComanda} ${btnInfo} ${btnRemover}`
        }
    }

    function carregaDados() {

        $.ajax({
            type: "GET",
            url: getStorage('host'),
            data: {
                tipo: 1,
                metodo: 'buscaFinanceiroCaixa',
                id: $_CONFIG.ID
            },
            dataType: "json",
            success: (data) => {

                if (data.result.length > 0 && data.result[0].FCa_Codigo !== undefined) {
                    /*---------------------------------------------------------------------------------------------------------------------------*/
                    var fcacodigo = data.result[0].FCa_Codigo;
                    $("#FCaCodigoCaixa").val(fcacodigo)
                    $(".divLoader").hide();
                    $('#boxMovCaixa').bootstrapTable('destroy')
                    $('#boxMovCaixa').bootstrapTable({
                        url: getStorage('host'),
                        method: 'get',
                        dataType: 'json',
                        queryParams: (p) => {
                            p.fcacodigo = fcacodigo;
                            p.metodo = 'buscaFinanceiroCaixaMovimentacao';
                            p.id = $_CONFIG.ID;
                            return p;
                        },
                        responseHandler: (res) => {
                            return res.result
                        },
                        contentType: 'application/x-www-form-urlencoded',
                        uniqueId: "FCM_Codigo",
                        rowStyle: colors,
                        iconSize: 'sm',
                        theadClasses: 'thead-light',
                        columns: [{
                                field: 'FCM_Descricao',
                                title: 'Descricao',
                                sortable: true
                            }, {
                                field: 'FCM_Valor',
                                title: 'Valor',
                                sortable: true,
                                sorter: currencySorter
                            },
                            {
                                field: 'TPa_Descricao',
                                title: 'Pagamento',
                                sortable: true
                            }, {
                                field: '',
                                formatter: editFormatter,
                                title: '',
                                width: "85px"
                            }
                        ],
                        search: true,
                        showRefresh: true,
                        locale: 'pt-BR',
                        onSearch: (e) => {
                            $("#boxMovCaixa").bootstrapTable('refresh');
                        },
                        onPostBody: () => {
                            $(".comandaModal").on("click", function(e) {
                                $row = $("#boxMovCaixa").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                                $scope.verComanda($row.Com_Codigo)
                            });
                            $(".infoModal").on("click", function(e) {
                                $row = $("#boxMovCaixa").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                                $scope.verMovimentacao($row.FCM_Codigo)
                            });

                            $(".deletedModal").on("click", function(e) {
                                $row = $("#boxMovCaixa").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                                $scope.removeMovimentacao($row.FCM_Codigo)
                            });
                        }


                    });

                    $(".caxCodigo").val(data.result[0].FCa_Codigo);
                    $(".caxDescricao").val(data.result[0].FCa_Descricao);

                    if (data.result[0].FCa_Codigo == "") {
                        $(".caxCodigoEnt").val("");
                    } else {
                        $(".caxCodigoEnt").val(data.result[0].FCa_Codigo);
                    }
                    $(".caxCodigoSai").val(data.result[0].FCa_Codigo);

                    $(".lblNome").html(data.result[0].Usu_Nome);
                    $(".lblData").html(data.result[0].FCa_Dat_Caixa);
                    $(".lblTotalCaixa").html(data.result[0].FCa_Saldo);
                    $(".lblValorInicial").html(data.result[0].FCa_Vlr_Inicial);
                    $(".boxCaixa").show();
                    $(".semCaixa").hide();

                    $("#iconCaixa").hide();
                    $(".btn-caixa").removeClass('caixa-fechado');



                    var listaPagCaixaEntrada = [];
                    var listaPagCaixaSaida = [];
                    var listaPagCaixaOther = [];
                    $.ajax({
                        type: "GET",
                        url: getStorage('host'),
                        async: false,
                        data: {
                            tipo: 13,
                            metodo: 'buscaFinanceiroCaixa',
                            id: $_CONFIG.ID
                        },
                        dataType: "json",
                        success: (result) => {

                            for (var i = 0; i < result.result.length; i++) {
                                if (result.result[i].FCM_Entrada == 1) {
                                    listaPagCaixaEntrada.push(result.result[i])
                                } else if (result.result[i].FCM_Entrada == 0) {
                                    listaPagCaixaSaida.push(result.result[i])

                                } else {
                                    listaPagCaixaOther.push(result.result[i])
                                }
                            }
                        },
                        error: () => {
                            console.log("Falha na conexão.", "", "error");
                        }
                    })

                    var primary = [];
                    var secondary = [];
                    var primaryColor = '';
                    var secondaryColor = '';
                    var primaryValor = 0.00;
                    var secondaryValor = 0.00;
                    var primarytype = '';
                    var secondarytype = '';
                    if (listaPagCaixaEntrada.length >= listaPagCaixaSaida.length) {
                        primary = listaPagCaixaEntrada;
                        secondary = listaPagCaixaSaida;
                        primaryColor = 'green';
                        secondaryColor = 'red';
                        primarytype = 'Entradas';
                        secondarytype = 'Saídas';

                    } else {
                        primary = listaPagCaixaSaida;
                        secondary = listaPagCaixaEntrada;
                        primaryColor = 'red';
                        secondaryColor = 'green';
                        primarytype = 'Saídas';
                        secondarytype = 'Entradas';
                    }
                    $(".divTotalizador").html('')
                    $(".divTotalizador").append(`<tr><th><b>${primarytype}</b></th><th><b>${secondarytype}</b></th></tr>`)

                    for (var j = 0; j < primary.length; j++) {
                        if (secondary.length > 0) {
                            for (var k = 0; k < secondary.length; k++) {
                                if (primary[j].TPa_Codigo == secondary[k].TPa_Codigo) {
                                    $(".divTotalizador").append(`<tr><td><span style="color:${primaryColor}">${primary[j].TipoPagamento}: <b>${primary[j].Valor}</b></span></td><td><span style="color:${secondaryColor}">${secondary[k].TipoPagamento}: <b>${secondary[k].Valor}</b></span></td></tr>`)
                                    primaryValor = primaryValor + parseFloat(primary[j].ValorReal)
                                    secondaryValor = secondaryValor + parseFloat(secondary[k].ValorReal)
                                    secondary.splice(k, 1);
                                    break;
                                } else if (k == (secondary.length - 1)) {
                                    $(".divTotalizador").append(`<tr><td><span style="color:${primaryColor}">${primary[j].TipoPagamento}: <b>${primary[j].Valor}</b></span></td><td>-</td></tr>`)
                                    primaryValor = primaryValor + parseFloat(primary[j].ValorReal)
                                }
                            }
                            if (j == (primary.length - 1) && secondary.length > 0) {
                                for (var l = 0; l < secondary.length; l++) {
                                    $(".divTotalizador").append(`<tr><td>-</td><td><span style="color:${secondaryColor}">${secondary[l].TipoPagamento}: <b>${secondary[l].Valor}</b></span</td></tr>`)
                                    secondaryValor = secondaryValor + parseFloat(secondary[l].ValorReal)
                                }
                            }
                        } else {
                            $(".divTotalizador").append(`<tr><td><span style="color:${primaryColor}">${primary[j].TipoPagamento}: <b>${primary[j].Valor}</b></span></td><td>-</td></tr>`)
                            primaryValor = primaryValor + parseFloat(primary[j].ValorReal)
                        }
                    }
                    for (var m = 0; m < listaPagCaixaOther.length; m++) {
                        $(".divTotalizador").append(`<tr><td >${listaPagCaixaOther[m].TipoPagamento}: <b>${listaPagCaixaOther[m].Valor}</b></td><td>-</td></tr>`)
                    }
                    $(".divTotalizador").append(`<tr><td>Total de ${primarytype}: <b>${$_CONFIG.MOEDA} ${primaryValor.toFixed(2).replace('.',',')}</b></td><td>Total de ${secondarytype}: <b>${$_CONFIG.MOEDA} ${secondaryValor.toFixed(2).replace('.',',')}</b></td></tr>`)


                } else {
                    $.ajax({
                        type: "POST",
                        url: "/pages/cadastros/buscaFinanceiroCaixa.php",
                        data: {
                            tipo: 2
                        },
                        dataType: "json",
                        success: (data2) => {
                            if (data2.result[0].PrimeiroCaixa == "1") {
                                $("#msgPrimeiroCaixa").show();
                            } else {
                                $("#msgPrimeiroCaixa").hide();
                            }
                        },
                        error: () => {
                            console.log("Falha na conexão.", "", "error");
                        }
                    });
                    $(".lblTotalCaixa").html("");
                    $(".lblValorInicial").html("");
                    $(".lblNome").html("");
                    $(".lblData").html("");
                    $(".boxCaixa").hide();
                    $(".semCaixa").show();

                    $("#iconCaixa").show();
                    $(".btn-caixa").addClass('caixa-fechado');
                }

                resizeContent();
            },
            error: () => {
                console.log("Falha na conexão.", "", "error");
            }
        });
    }

    $('#formCadastroCaixa').submit(function(event) {
        event.preventDefault();
        showLoader(true);
        dataForm = new FormData(this);
        dataForm.append("valor", $('#caxValor').maskMoney('unmasked')[0]);
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/insereFinanceiroCaixa.php",
            data: dataForm,
            dataType: "json",
            processData: false,
            contentType: false,
            success: (result) => {
                if (result.result[0].erro == "0") {
                    toastr.success(result.result[0].resultado);
                    $('#cadastrarCaixa-modal').modal('hide');
                    carregaDados();
                } else {
                    swal(result.result[0].resultado, "", "error");
                }
                showLoader(false);
            },
            error: () => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
        return true;
    });

    $('#formCaxEntrada').submit(function(event) {
        event.preventDefault();
        formentrada = $(this);
        showLoader(true);
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/insereFinanceiroCaixaMovimentacaov2.php",
            data: {
                codigo: $("#caxCodigoEnt").val(),
                valor: $('#caxValorEnt').maskMoney('unmasked')[0],
                descricao: $("#caxDescEnt").val(),
                tpacodigo: $("#pFormaPag option:selected").val(),
                tbacodigo: $("#divBandeiraPag option:selected").val(),
                tipo: 1,
                trecodigo: $("#buscaReceitaCaixa option:selected").val(),
                suprimento: $("#suprimentoCaixa").val()

            },
            dataType: "json",
            success: (result) => {
                if (result.result[0].erro == "0") {
                    toastr.success(result.result[0].resultado);
                    carregaDados();
                    $("#entradaCaixa-modal").modal("hide");
                    $("#pFormaPag").val("");
                    $("#pFormaPag").change();
                    $("#divBandeiraPag").hide();
                    formentrada.each(function() {
                        this.reset();
                    });
                } else {
                    swal(result.result[0].resultado, "", "error");
                }
                showLoader(false);
                $scope.deselectMultiselect();
            },
            error: (result) => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
        return true;
    });

    $("#sangria").change(() => {
        if ($("#sangria").is(":checked")) {
            $("#proxCaixa").val(0)
            $("#proxCaixa").prop('disabled', true)
            if ($("#buscaDespesaCaixa option:selected").get(0).dataset.vale == 1) {
                $("#buscaDespesaCaixa").val("");
                $("#buscaDespesaCaixa").change();
                toastr.error("Sangrias de Caixa não podem ser vales");
            }
        } else {
            $("#proxCaixa").val(0)
            $("#proxCaixa").prop('disabled', false)
        }
    })

    $('#formCaxSaida').submit(function(event) {
        $("#btnSalvarMovCaixa").attr('disabled', true);
        var sangria = 0;
        if ($("#sangria").is(":checked")) {
            sangria = 1;
        } else {
            sangria = 0;
        }
        event.preventDefault();
        showLoader(true);
        var valorSaidaCaixa = $('#caxValorSai').val()
        var descricaoSaidaCaixa = $("#caxDescSai").val()
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/insereFinanceiroCaixaMovimentacao.php",
            data: {
                codigo: $("#caxCodigoSai").val(),
                valor: $('#caxValorSai').maskMoney('unmasked')[0],
                descricao: $("#caxDescSai").val(),
                tipo: 0,
                tdecodigo: $("#buscaDespesaCaixa option:selected").val(),
                proximocaixa: $("#proxCaixa option:selected").val(),
                profissional: $("#buscaProfissionalCaixa").val(),
                sangria: sangria,
                tpacodigo: $("#pFormaPagSaida").val()
            },
            dataType: "json",
            success: (result) => {
                if (result.result[0].erro == "0") {
                    toastr.success(result.result[0].resultado);

                    if (sangria == 1) {
                        swal({
                            title: "Sangria de Caixa",
                            text: "Você acabou de fazer uma sangria de caixa, é recomendado que você realize uma entrada de sangria no seu financeiro, deseja realizar essa entrada agora?",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "Sim",
                            cancelButtonText: "Não"
                        }, (isconfirm) => {
                            if (isconfirm) {
                                $scope.buscaContaComboSangria();
                                $("#valorInsereFinSangria").val(valorSaidaCaixa)
                                $("#descricaoInsereFinSangria").val('Entrada de sangria referente a movimentação: ' + descricaoSaidaCaixa)
                                $("#insereFinanceiroSangria-modal").modal()
                            } else {
                                toastr.warning("Você optou por não inserir a movimentação agora. Você pode fazer o lançamento manualmente em 'Financeiro > Entrada/Saída' quando desejar.");
                            }
                        });
                    }
                    carregaDados();

                    $("#saidaCaixa-modal").modal("hide");
                    $("#caxValorSai").val("");
                    $("#caxDescSai").val("");
                    $("#sangria").prop("checked", false);
                    $("#btnSalvarMovCaixa").attr('disabled', false);
                } else {
                    toastr.error(result.result[0].resultado);
                    $("#btnSalvarMovCaixa").attr('disabled', false);
                }
                showLoader(false);
                $scope.deselectMultiselect();
                $("#divProfissionalCaixa").hide();
            },
            error: () => {
                $("#btnSalvarMovCaixa").attr('disabled', false);
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });
        return true;
    });


    $scope.btnfecharcaixa = function() {

        var textomsg = "";
        var hasSaidaCaixa = 0;
        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/buscaFinanceiroCaixa.php',
            async: false,
            data: {
                fcacodigo: $("#caxCodigo").val(),
                tipo: 12
            },
            success: (data) => {
                if (data.result.length > 0) {
                    textomsg = "Deseja fechar este caixa?"
                    hasSaidaCaixa = 1;
                } else {
                    textomsg = "ATENÇÃO: Não existe nenhuma saída para o próximo caixa, Deseja realmente fechar esse caixa?"
                    hasSaidaCaixa = 0;
                }
            },
            error: () => {
                toastr.error("Falha na conexão.");
            }
        });

        if (!hasSaidaCaixa) {
            $("#semSaidaCaixa-modal").modal()

        } else {
            swal({
                title: "Confirmar fechamento:",
                type: "input",
                inputPlaceholder: "Observações",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Sim",
                cancelButtonText: "Não",
                inputValue: $("#caxDescricao").val(),
                text: textomsg
            }, (inputValue) => {
                showLoader(true);
                $.ajax({
                    dataType: "json",
                    method: "POST",
                    url: '/pages/cadastros/atualizaFinanceiroCaixav3.php',
                    data: {
                        codigo: $("#caxCodigo").val(),
                        tipo: 1,
                        descricao: inputValue
                    },
                    success: (data) => {
                        if (data.data[0].erro == "0") {
                            toastr["success"]("Caixa finalizado com Sucesso.");
                            carregaDados();
                        } else {
                            swal("Falha ao Finalizar.", data.data[0].resultado, "error");
                        }
                        showLoader(false);
                    },
                    error: () => {
                        swal("Falha na conexão.", "", "error");
                        showLoader(false);
                    }
                });
            });
        }

    };

    $scope.fechaCaixaSemSaida = function() {
        $("#semSaidaCaixa-modal").modal('hide')
        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/buscaFinanceiroCaixa.php',
            async: false,
            data: {
                fcacodigo: $("#caxCodigo").val(),
                tipo: 12
            },
            success: (data) => {
                if (data.result.length > 0) {
                    textomsg = "Deseja fechar este caixa?"
                    hasSaidaCaixa = 1;
                } else {
                    textomsg = "ATENÇÃO: Não existe nenhuma saída para o próximo caixa, Deseja realmente fechar esse caixa?"
                    hasSaidaCaixa = 0;
                }
            },
            error: () => {
                toastr.error("Falha na conexão.");
            }
        });

        swal({
            title: "Confirmar fechamento:",
            type: "input",
            inputPlaceholder: "Observações",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Sim",
            cancelButtonText: "Não",
            inputValue: $("#caxDescricao").val(),
            text: textomsg
        }, (inputValue) => {
            showLoader(true);
            $.ajax({
                dataType: "json",
                method: "POST",
                url: '/pages/cadastros/atualizaFinanceiroCaixav3.php',
                data: {
                    codigo: $("#caxCodigo").val(),
                    tipo: 1,
                    descricao: inputValue
                },
                success: (data) => {
                    if (data.data[0].erro == "0") {
                        toastr["success"]("Caixa finalizado com Sucesso.");
                        carregaDados();
                    } else {
                        swal("Falha ao Finalizar.", data.data[0].resultado, "error");
                    }
                    showLoader(false);
                },
                error: () => {
                    swal("Falha na conexão.", "", "error");
                    showLoader(false);
                }
            });
        });
    }

    $scope.addSaidaProximoCaixa = function() {
        $("#semSaidaCaixa-modal").modal('hide');
        $("#proxCaixa").val(1)
        $("#proxCaixa").attr('disabled', true)
        $("#saidaCaixa-modal").modal()
    }

    $("#btnAtualizaCaixa").click(() => {
        carregaDados();
    });

    $scope.removeMovimentacao = function(codigo) {
        swal({
            title: "Confirmar remoção:",
            text: "Deseja remover este item?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Sim",
            cancelButtonText: "Não"
        }, () => {
            showLoader(true);
            $.ajax({
                dataType: "json",
                method: "POST",
                url: '/pages/cadastros/removeFinanceiroCaixaMovimentacao.php',
                data: {
                    codigo: codigo
                },
                success: (data) => {
                    if (data.result[0].erro == "0") {
                        toastr.success("Movimentação removida com Sucesso.");
                        carregaDados();
                    } else {
                        swal("Falha ao Remover.", data.result[0].resultado, "error");
                    }
                    showLoader(false);
                },
                error: (result) => {
                    swal("Falha na conexão.", "", "error");
                    showLoader(false);
                }
            });
        });
    }

    $scope.deselectMultiselect = function() {
        $('#buscaDespesaCaixa').val('');
        $('#buscaDespesaCaixa').change();
        $('#proxCaixa').val(0);
        $('#proxCaixa').change();
        /*$('#buscaReceitaCaixa').multiselect('select', ['']);
        $('#buscaReceitaCaixa').multiselect('refresh');*/
    }

    $scope.verComanda = function(codigo) {
        $("#vercomanda-modal").modal("show");
        $("#idComandaVer").html(codigo);

        if (typeof(tabelaComItensVer) != "undefined") {
            tabelaComItensVer.api().destroy();
        }

        tabelaComItensVer = $('#tbComandaItensVer').dataTable({
            ajax: "/pages/cadastros/buscaItensComanda.php?codigo=" + codigo,
            language: {
                "url": "//cdn.datatables.net/plug-ins/1.10.7/i18n/Portuguese-Brasil.json"
            },
            bPaginate: false,
            bLengthChange: false,
            bFilter: false,
            bSort: false,
            bInfo: false,
            bAutoWidth: false,
            "scrollX": isPortrait,
            "fnRowCallback": (nRow, aData) => {
                var id = aData.Cortesia;
                if (id == 1) {
                    nRow.children[8].innerHTML = 'Sim';
                } else {
                    nRow.children[8].innerHTML = 'Não';
                }
            },
            initComplete: function() {
                var vlrTotal = this.fnGetData(0);
                $("#valorTotalComandaVer").html($_CONFIG.MOEDA + vlrTotal.ValorTotal);
                if (vlrTotal.comandaVlrPagamento != "") {
                    $("#valorPagoComandaVer").html($_CONFIG.MOEDA + vlrTotal.comandaVlrPagamento);
                    $("#vlrPagoVer").css("display", "block");
                } else {
                    $("#vlrPagoVer").css("display", "none");
                    $("#valorPagoComandaVer").html("");
                }

                $("#nomeClienteComandaVer").html(vlrTotal.Cliente);
                $("#idComandaVer").html(vlrTotal.Codigo);
                $("#dataComandaVer").html(vlrTotal.dataComanda);


                $("#comValorPagVer").val(vlrTotal.ValorTotal);
                $("#pagamentoComandaVer").html(vlrTotal.tipoPagamento.replace("/", "<br>"));
            },
            columnDefs: [{
                "targets": [0, 1, 2, 3, 5, 6, 11, 12],
                "visible": false,
                "searchable": false
            }],
            columns: [{
                    "data": "Codigo"
                },
                {
                    "data": "CodItem"
                },
                {
                    "data": "CodSerPro"
                },
                {
                    "data": "TipoItem"
                },
                {
                    "data": "ImgItem"
                },
                {
                    "data": "Data"
                },
                {
                    "data": "Usuario"
                },
                {
                    "data": "Valor"
                },
                {
                    "data": "ValorUn"
                },
                {
                    "data": "Desconto"
                },
                {
                    "data": "Quantidade"
                },
                {
                    "data": "Comissao"
                },
                {
                    "data": "ValorTotal"
                },
                {
                    "data": "Item"
                },
                {
                    "data": "Profissional"
                },
                {
                    "data": "Cliente"
                },
                {
                    "data": "Cortesia"
                },
                {
                    "data": null,
                    "defaultContent": '',
                    "render": function(data, t, row) {
                        if (row.ExistePacote == '1') {
                            return 'Pacote';
                        } else if (row.asscodigo != '') {
                            return 'Clube de Assintura'
                        }
                    }
                }
            ]
        });
    };

    $scope.$on("$destroy", function() {
        if (isMobile) {
            $(".btn-caixa").hide();
        } else {
            $(".btn-caixa").show();
        }
        carregaDados();

    });

    // if (intervalCaixa === undefined) {
    // 	intervalCaixa = $interval(function () {
    // 		carregaDados();
    // 	}, $scope.timerIntervalCaixa);

    // }
    $("#btn-caixa_busca").click(function() {

        var shroom = $("#caixaSide");
        if (shroom.hasClass('open')) {
            carregaDados();
        }
    })

    init();

    $("#divProfissionalCaixa").hide();

    $("#buscaDespesaCaixa").change(() => {
        if ($("#buscaDespesaCaixa option:selected").get(0).dataset.vale == 1) {
            if ($("#sangria").is(":checked")) {
                $("#buscaDespesaCaixa").val("")
                $("#buscaDespesaCaixa").change()
                toastr.error("Sangrias de Caixa não podem ser vales");
            } else {
                $scope.buscaProfissionalValeCaixa();
                $("#divProfissionalCaixa").show();
                $("#proxCaixa").val(0);
                $("#proxCaixa").prop('disabled', true);
            }

        } else {
            $("#buscaProfissionalCaixa").val('');
            $("#divProfissionalCaixa").hide();
            if ($("#sangria").is(":checked")) {
                $("#proxCaixa").val(0);
                $("#proxCaixa").prop('disabled', true);
            } else {
                $("#proxCaixa").val(0);
                $("#proxCaixa").prop('disabled', false);
            }
        }
    });

    $('#proxCaixa').change(() => {
        if ($("#buscaDespesaCaixa option:selected").get(0).dataset.vale == 1) {
            toastr.error("Vales não podem ser lançados como saídas para proximos caixas");
            $("#buscaDespesaCaixa").val("")
            $("#buscaDespesaCaixa").change()
        }

    });

    $scope.editaCaixaModal = function() {
        $("#valorInicialCaixaEdt").val(parseFloat($(".lblValorInicial").html().replace(',', '.').replace($_CONFIG.MOEDA, '')).toFixed(2))
        $("#editaCaixa-modal").modal();
    }
    $scope.editaDataCaixaModal = function() {
        $("#editaDataCaixa-modal").modal();
    }

    $scope.editaCaixa = function() {
        showLoader(true);
        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/alteraFinanceiroCaixa.php',
            data: {
                fcacodigo: $("#caxCodigo").val(),
                valor: $("#valorInicialCaixaEdt").val().replace(',', '.'),
                tipo: 1
            },
            success: (data) => {
                if (data.data[0].erro == "0") {
                    $("#editaCaixa-modal").modal("hide");
                    toastr.success(data.data[0].resultado);
                    carregaDados();
                    $("#valorInicialCaixaEdt").val("");
                } else {
                    toastr.success(data.data[0].error);
                }
                showLoader(false);
            },
            error: () => {
                toastr.error("Falha na conexão.");
                showLoader(false);
            }
        });
    }

    $scope.editaCaixaData = function() {
        showLoader(true);
        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/alteraFinanceiroCaixa.php',
            data: {
                fcacodigo: $("#caxCodigo").val(),
                data: $("#DataCaixaEdt").val(),
                tipo: 2
            },
            success: (data) => {
                if (data.data[0].erro == "0") {
                    $("#editaDataCaixa-modal").modal("hide");
                    toastr.success(data.data[0].resultado);
                    carregaDados();

                } else {
                    toastr.success(data.data[0].error);
                }
                showLoader(false);
            },
            error: () => {
                toastr.error("Falha na conexão.");
                showLoader(false);
            }
        });
    }

    $scope.buscaSugestaoCaixa = function() {
        $.ajax({
            dataType: "json",
            url: localStorage.getItem("host"),
            data: {
                metodo: 'buscaDataAtual',
                id: $scope.idCliente
            },
            success: function(data) {
                var datahoralocal = moment(data.buscaDataAtual[0].resultado).locale("pt-br").format("L");

                $('.input-group.divData').datepicker('update', datahoralocal);
                var datafim = moment().locale("pt-br").format("L");
                $('.date.dateSangriaEntrada').datepicker('update', datafim);

            },
            error: function() {
                var dataini = moment().locale("pt-br").format("L");
                $('.input-group.divData').datepicker('update', dataini);
            }
        });
        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/buscaFinanceiroCaixa.php',
            data: {
                tipo: 9
            },
            success: (data) => {
                if (data.result.length > 0) {
                    $("#caxValor").val(data.result[0].FCM_Valor);

                } else {
                    $("#caxValor").val('');
                }
            },
            error: () => {
                toastr.error("Falha na conexão.");
            }
        });
    }

    $scope.verMovimentacao = function(codigo) {
        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/buscaFinanceiroCaixaMovimentacaoDetalhes.php',
            data: {
                fcmcodigo: codigo
            },
            success: (data) => {
                $("#btnGeraReciboCaixa").unbind('click');
                $("#horaMovimentacao").html(data.result[0].FCM_Dat_Cadastro);

                if (data.result[0].FCM_Entrada == 0) {
                    $("#tipoReceitaDespesa").html("Despesa");
                    $("#DesRecMovimentacao").html(data.result[0].TDe_Descricao);
                } else {
                    $("#tipoReceitaDespesa").html("Receita");
                    $("#DesRecMovimentacao").html(data.result[0].TRe_Descricao);
                }

                if (data.result[0].FCM_Entrada == 1) {
                    $("#pagMovimentacao").html(data.result[0].TPa_Descricao);
                    $("#labelPagamento").show()
                } else {
                    $("#pagMovimentacao").html("");
                    $("#labelPagamento").hide()
                }

                $("#sanMovimentacao").html(data.result[0].Sangria);
                $("#proxCaixaMovimentacao").html(data.result[0].ProxCaixa);

                if (data.result[0].TDe_Vale == 0) {
                    $("#divValeReciboCaixa").hide()
                } else {
                    $("#divValeReciboCaixa").show()
                }

                $("#btnGeraReciboCaixa").click(() => {
                    $scope.geraReciboVale(data.result[0])
                })

                $("#infoMovimentacaoCaixa-modal").modal();
            },
            error: () => {
                toastr.error("Falha na conexão.");
            }
        });
    }

    $("#botaocaixa").click(function() {
        var disp = "";
        var rece = "";
        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/buscaFinanceiroCaixa.php',
            async: false,
            data: {
                fcacodigo: $("#caxCodigo").val(),
                tipo: 10
            },
            success: (data) => {
                if (data.result[0].erro != "1") {
                    disp = data.result[0].Valor;

                } else {
                    disp = "";
                }
            },
            error: () => {
                toastr.error("Falha na conexão.");
            }
        });

        $.ajax({
            dataType: "json",
            type: "POST",
            url: '/pages/cadastros/buscaFinanceiroCaixa.php',
            async: false,
            data: {
                fcacodigo: $("#caxCodigo").val(),
                tipo: 11
            },
            success: (data) => {
                if (data.result[0].erro != "1") {
                    rece = data.result[0].Valor;

                } else {
                    rece = "";
                }
            },
            error: () => {
                toastr.error("Falha na conexão.");
            }
        });

        $(this).attr('data-content', '<div><i data-toggle="tooltip" data-placement="top" title="Valor de movimentações que não constam como cartão" class="fa fa-question-circle" style="color:grey" ></i>&nbspSaldo Disponível: ' + disp + '</div><br><div><i data-toggle="tooltip" data-placement="bottom" title="Total de movimentações desconsiderando as saídas e o valor inicial" class="fa fa-question-circle" style="color:grey" ></i>&nbspTotal de recebimentos: ' + rece + '</div>');
        $(this).popover('show')
    })

    $('#formDespesaCaixa').submit((event) => {

        event.preventDefault();

        showLoader(true);
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/insereDespesa.php",
            data: {
                Despesa: $("#DespesaCaixa").val(),
                vale: $("#vale").val()
            },
            dataType: "json",
            success: (result) => {
                if (result.data[0].erro == "0") {
                    toastr.success(result.data[0].resultado);
                    $('#despesacaixa-modal').modal("hide");
                    $("#DespesaCaixa").val("")
                    $scope.buscaDespesa(false);
                } else {
                    toastr.error(result.data[0].resultado);
                }
                showLoader(false);
            },
            error: () => {
                toastr.error("Falha na conexão.");
                showLoader(false);
            }
        });

        return true;
    });

    $("#btnImprimecaixa").click(() => {
        showLoader(true);
        var dadosCaixa = {
            Usu_Nome: $('.lblNome').html(),
            FCa_Vlr_Inicial: $('.lblValorInicial').html(),
            FCa_Saldo: $('.lblTotalCaixa').html(),
            FCa_Dat_Caixa: $('.lblData').html()
        };
        var codigo = $("#caxCodigo").val();
        buscaPrintCaixa(codigo, dadosCaixa)

    })

    $("#btnImprimecaixanaofiscal").click(() => {
        showLoader(true);
        var dadosCaixa = {
            Usu_Nome: $('.lblNome').html(),
            FCa_Vlr_Inicial: $('.lblValorInicial').html(),
            FCa_Saldo: $('.lblTotalCaixa').html(),
            FCa_Dat_Caixa: $('.lblData').html()
        };
        var codigo = $("#caxCodigo").val();
        buscaPrintCaixaNaoFiscal(codigo, dadosCaixa);
    })

    $scope.buscaContaComboSangria = function() {
        var conta = "";
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/buscaSubConta.php",
            dataType: "json",
            success: (result) => {
                conta += "<option value=''>Nenhuma</option>";
                for (var i = 0; i < result.data.length; i++) {
                    conta += "<option value='" + result.data[i].Con_Codigo + "'>" + result.data[i].Con_Descricao + "</option>";
                };
                $("#buscaContaFinSangria").html(conta)
            },
            error: () => {}
        });
    }

    $scope.insereEntradaSangriaCaixa = function() {

        if ($("#descricaoInsereFinSangria").val() == "") {
            toastr.error("Informe a descrição.");
        } else if ($("#valorInsereFinSangria").val() == "") {
            toastr.error("Informe o valor.");
        } else if ($("#dataInsereFinSangria").val() == "") {
            toastr.error("Infome a data.");
        } else {
            showLoader(true);
            $.ajax({
                type: "POST",
                url: "/pages/cadastros/insereFinanceirov4.php",
                dataType: "json",
                data: {
                    finDescricao: $("#descricaoInsereFinSangria").val(),
                    finValor: $("#valorInsereFinSangria").val(),
                    finEntradaSaida: 1,
                    finData: $("#dataInsereFinSangria").val(),
                    finBaixado: 1,
                    buscaDespesa: "",
                    buscaReceita: "",
                    buscaProfissional: "",
                    buscaConta: $("#buscaContaFinSangria").val(),
                    notafiscal: "",
                    buscaFornecedor: "",
                    entradaSangria: 1,
                    retiradaFinanceiro: 0,
                    tipoPagamento: ""
                },
                success: (result) => {
                    $("#descricaoInsereFinSangria").val("")
                    $("#valorInsereFinSangria").val("")
                    $("#dataInsereFinSangria").val("")
                    $("#buscaContaFinSangria").val(""),
                        toastr.success(result.result[0].resultado);
                    $("#insereFinanceiroSangria-modal").modal('hide')
                    showLoader(false);
                },
                error: (result) => {
                    toastr.error("Falha na conexão.");
                    showLoader(false);
                }
            });
        }
    }

    //------------------------------------------------------------------------------------------------

    function viewcolors(value, row, index) {

        let cor = '';
        console.log(value)
        if (value.Entrada == 1) {
            cor = 'green';
        } else if (value.Entrada == 0) {
            cor = 'red';
        } else if (value.Entrada == 3) {
            cor = 'blue'
        } else {
            cor = 'dark-gray'
        }

        return {
            css: {
                "color": cor,
                "font-size": 'smaller'
            }
        };
    }

    function viewFormatter(value, row) {
        var btnComanda = `<button class="btn btn-primary viewcomandaModal btn-xs" data-codigo="${row.Codigo}">
								<i class="fa fa-list-alt" ></i>
							</button>`;

        var btnInfo = `<button class="btn btn-info viewinfoModal btn-xs" data-codigo="${row.Codigo}">
							<i class="fa fa-info" ></i>
						</button>`;


        if (row.ComCodigo == "" && row.Entrada != 2 && row.Entrada != 3) {
            return `${btnInfo} `
        } else if (row.Entrada != 2 && row.Entrada != 3) {
            return `${btnComanda} ${btnInfo} `
        }
    }

    function formatterFooter(data) {
        if (data.length > 0) {
            return `<ul  id="totalCaixaMovDia" ><li ><h4><b>Saldo do Dia:</b> ${data[0].Saldo}</h4></li><li ><h4><b>Saldo Liquido do Dia:</b> ${data[0].SaldoLiquido}</h4></li></ul>`; //data.Saldo
        }
    }

    $scope.verDiaCaixa = function() {
        $scope.buscaCaixaMovimentacaoDia($("#FCaCodigoCaixa").val());
    }

    $scope.buscaCaixaMovimentacaoDia = function(fcacodigo) {

        var tiposPagamento = '';
        var datapagamento = '';
        $.ajax({
            type: "POST",
            url: "/pages/cadastros/buscaFinanceiroCaixaMovimentacaoRelacionado.php",
            dataType: "json",
            async: false,
            data: {
                fcacodigo: fcacodigo,
                tipo: 4
            },
            success: function(result) {
                if (result.data != undefined) {
                    if (result.data.length > 0) {
                        datapagamento = result.data;
                        for (var i = 0; i < result.data.length; i++) {
                            if (result.data[i].Saldo != result.data[i].SaldoLiquido) {
                                tiposPagamento += `<li><b>${result.data[i].Descricao}:</b> ${result.data[i].Saldo} - ${result.data[i].SaldoLiquido}(liq)</li>`;
                            } else {
                                tiposPagamento += `<li><b>${result.data[i].Descricao}:</b> ${result.data[i].Saldo}</li>`;
                            }
                        }
                    } else {
                        tiposPagamento = '';
                    }
                } else {
                    tiposPagamento = '';
                }
            },
            error: function(result) {
                tiposPagamento = '';
            }
        });

        $('#listaMovDia').bootstrapTable('destroy')
        $('#listaMovDia').bootstrapTable({
            url: "/pages/cadastros/buscaFinanceiroCaixaMovimentacaoRelacionado.php",
            method: 'post',
            dataType: 'json',
            queryParams: function(p) {
                p.fcacodigo = fcacodigo;
                p.tipo = 2;
                return p;
            },
            contentType: 'application/x-www-form-urlencoded',
            uniqueId: "Codigo",
            rowStyle: viewcolors,
            iconSize: 'sm',
            pagination: 'true',
            columns: [{
                    field: 'Descricao',
                    title: 'Descrição',
                    footerFormatter: formatterFooter,
                    sortable: true
                }, {
                    field: 'Valor',
                    title: 'Valor',
                    sortable: true,
                    sorter: currencySorter
                },
                {
                    field: 'ValorLiquido',
                    title: 'Valor Liquido',
                    sortable: true,
                    sorter: currencySorter
                },
                {
                    field: 'TipoPagamento',
                    title: 'Pagamento',
                    sortable: true
                },
                {
                    field: 'TipoBandeira',
                    title: 'Bandeira',
                    sortable: true
                },
                {
                    field: '',
                    formatter: viewFormatter,
                    title: '',
                    width: "85px"
                }
            ],

            search: true,
            showRefresh: true,
            showFooter: true,

            locale: 'pt-BR',
            onSearch: function(e) {
                $("#listaMovDia").bootstrapTable('refresh');
            },
            onPostBody: function(f) {
                $scope.buscaPrintVerDiaCaixa(f, datapagamento);
                $(".viewcomandaModal").on("click", function(e) {
                    $row = $("#listaMovDia").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                    $scope.verComanda($row.ComCodigo)
                });
                $(".viewinfoModal").on("click", function(e) {
                    $row = $("#listaMovDia").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                    $scope.verMovimentacao($row.Codigo)
                });

                $("#totalCaixaMovDia").append(tiposPagamento).addClass('table-condensed table-striped')
            },
        });

        $("#caixaMovimentacao-modal").modal()
    }

    $scope.buscaPrintVerDiaCaixa = function(data, pagamento) {
        var html = '';
        var tiposPagamento = '';
        if (data != undefined) {
            if (data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    classEntrada = 'black';
                    if (data[i].Entrada == 1) {
                        classEntrada = 'green'
                    } else if (data[i].Entrada == 0) {
                        classEntrada = 'red'
                    } else if (data[i].Entrada == 3) {
                        classEntrada = 'blue'
                    }
                    html += "<tr><td>" + data[i].Descricao + "</td><td>" + data[i].Valor + "</td><td>" + data[i].ValorLiquido + "</td><td>" + data[i].TipoPagamento + "</td><td>" + data[i].TipoBandeira + "</td></tr>";
                    tiposPagamento = `<tr><td colspan="5"><h4><b>Saldo do Dia:</b> ${data[i].Saldo}</h4></td></tr><tr><td colspan="5"><h4><b>Saldo Liquido do Dia:</b> ${data[i].SaldoLiquido}</h4></td></tr>`
                }
                $("#listaMovDiaPrint tbody").html(html)
            } else {
                html = '';
            }
        }
        if (pagamento != undefined) {
            if (pagamento.length > 0) {
                tiposPagamento += '<tr><td colspan="5"><hr></td></tr>';
                for (var i = 0; i < pagamento.length; i++) {
                    if (pagamento[i].Saldo != pagamento[i].SaldoLiquido) {
                        tiposPagamento += `<tr><td colspan="5"><b>${pagamento[i].Descricao}:</b> ${pagamento[i].Saldo} - ${pagamento[i].SaldoLiquido}(liq)</td></tr>`;
                    } else {
                        tiposPagamento += `<tr><td colspan="5"><b>${pagamento[i].Descricao}:</b> ${pagamento[i].Saldo}</td></tr>`;
                    }
                }
                $("#listaMovDiaPrint tfoot").html(tiposPagamento)
            } else {
                tiposPagamento = '';
            }
        }
    }

    $("#moedaCaixa").html($_CONFIG.MOEDA);


    $scope.buscaCaixaAberto = function() {
        $("#caixaAberto").hide()
        showLoader(true);
        var caixas = "";
        $.ajax({
            dataType: "json",
            method: "POST",
            url: '/pages/cadastros/buscaFinanceiroCaixav2.php',
            data: {
                edtDataIni: '',
                edtDataFim: '',
                tipo: 14
            },
            success: (data) => {
                caixas += "<option value=''>Selecione um caixa</option>";
                for (var i = 0; i < data.data.length; i++) {
                    caixas += `<option value='${data.data[i].FCa_Codigo}'>Usuário: ${data.data[i].Usu_Nome} - Data do caixa: ${data.data[i].FCa_Dat_Caixa}</option>`
                };
                $("#listaCaixaAberto").html(caixas)
                showLoader(false);
            },
            error: () => {
                swal("Falha na conexão.", "", "error");
                showLoader(false);
            }
        });


        $("#verListaCaixa-modal").modal();
    }
    $("#listaCaixaAberto").change(() => {
        $("#caixaAberto").hide();
    })
    $scope.VerCaixaAberto = function() {
        showLoader(true);
        if ($("#listaCaixaAberto").val() != "") {
            $.ajax({
                type: "GET",
                url: getStorage('host'),
                data: {
                    tipo: 16,
                    metodo: 'buscaFinanceiroCaixa',
                    id: $_CONFIG.ID,
                    fcacodigo: $("#listaCaixaAberto").val()
                },
                dataType: "json",
                success: (data) => {

                    if (data.result.length > 0 && data.result[0].FCa_Codigo !== undefined) {
                        /*---------------------------------------------------------------------------------------------------------------------------*/
                        showLoader(false);
                        $("#caixaAberto").show()
                        var fcacodigo = data.result[0].FCa_Codigo;

                        $(".divLoader").hide();
                        $('#boxMovCaixaHistoricoCaixaVer').bootstrapTable('destroy')
                        $('#boxMovCaixaHistoricoCaixaVer').bootstrapTable({
                            url: getStorage('host'),
                            method: 'get',
                            dataType: 'json',
                            queryParams: (p) => {
                                p.fcacodigo = fcacodigo;
                                p.metodo = 'buscaFinanceiroCaixaMovimentacao';
                                p.id = $_CONFIG.ID;
                                return p;
                            },
                            responseHandler: (res) => {
                                return res.result
                            },
                            contentType: 'application/x-www-form-urlencoded',
                            uniqueId: "FCM_Codigo",
                            rowStyle: colors,
                            iconSize: 'sm',
                            theadClasses: 'thead-light',
                            columns: [{
                                    field: 'FCM_Descricao',
                                    title: 'Descricao',
                                    sortable: true
                                }, {
                                    field: 'FCM_Valor',
                                    title: 'Valor',
                                    sortable: true,
                                },
                                {
                                    field: 'TPa_Descricao',
                                    title: 'Pagamento',
                                    sortable: true
                                }, {
                                    field: '',
                                    formatter: editFormatternewCa,
                                    title: '',
                                    width: "85px"
                                }
                            ],
                            search: true,
                            showRefresh: true,
                            locale: 'pt-BR',
                            onSearch: (e) => {
                                $("#boxMovCaixaHistoricoCaixaVer").bootstrapTable('refresh');
                            },
                            onPostBody: () => {
                                $(".comandaModal").on("click", function(e) {
                                    $row = $("#boxMovCaixaHistoricoCaixaVer").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                                    $scope.verComanda($row.Com_Codigo)
                                });
                                $(".infoModal").on("click", function(e) {
                                    $row = $("#boxMovCaixaHistoricoCaixaVer").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                                    $scope.verMovimentacao($row.FCM_Codigo)
                                });

                                $(".deletedModal").on("click", function(e) {
                                    $row = $("#boxMovCaixaHistoricoCaixaVer").bootstrapTable("getRowByUniqueId", this.dataset.codigo);
                                    $scope.removeMovimentacao($row.FCM_Codigo)
                                });
                            }


                        });



                        $(".lblNomeCaixaVer").html(data.result[0].Usu_Nome);
                        $(".lblDatCaixaVer").html(data.result[0].FCa_Dat_Caixa);
                        $(".lblTotalCaixaCaixaVer").html(data.result[0].FCa_Saldo);
                        $(".lblValorInicialCaixaVer").html(data.result[0].FCa_Vlr_Inicial);


                        var listaPagCaixaEntrada = [];
                        var listaPagCaixaSaida = [];
                        var listaPagCaixaOther = [];
                        $.ajax({
                            type: "GET",
                            url: getStorage('host'),
                            async: false,
                            data: {
                                tipo: 17,
                                metodo: 'buscaFinanceiroCaixa',
                                id: $_CONFIG.ID,
                                fcacodigo: $("#listaCaixaAberto").val()
                            },
                            dataType: "json",
                            success: (result) => {

                                for (var i = 0; i < result.result.length; i++) {
                                    if (result.result[i].FCM_Entrada == 1) {
                                        listaPagCaixaEntrada.push(result.result[i])
                                    } else if (result.result[i].FCM_Entrada == 0) {
                                        listaPagCaixaSaida.push(result.result[i])

                                    } else {
                                        listaPagCaixaOther.push(result.result[i])
                                    }
                                }
                            },
                            error: () => {
                                console.log("Falha na conexão.", "", "error");
                            }
                        })

                        var primary = [];
                        var secondary = [];
                        var primaryColor = '';
                        var secondaryColor = '';
                        var primaryValor = 0.00;
                        var secondaryValor = 0.00;
                        var primarytype = '';
                        var secondarytype = '';
                        if (listaPagCaixaEntrada.length >= listaPagCaixaSaida.length) {
                            primary = listaPagCaixaEntrada;
                            secondary = listaPagCaixaSaida;
                            primaryColor = 'green';
                            secondaryColor = 'red';
                            primarytype = 'Entradas';
                            secondarytype = 'Saídas';

                        } else {
                            primary = listaPagCaixaSaida;
                            secondary = listaPagCaixaEntrada;
                            primaryColor = 'red';
                            secondaryColor = 'green';
                            primarytype = 'Saídas';
                            secondarytype = 'Entradas';
                        }
                        $(".divTotalizadorver").html('')
                        $(".divTotalizadorver").append(`<tr><th><b>${primarytype}</b></th><th><b>${secondarytype}</b></th></tr>`)

                        for (var j = 0; j < primary.length; j++) {
                            if (secondary.length > 0) {
                                for (var k = 0; k < secondary.length; k++) {
                                    if (primary[j].TPa_Codigo == secondary[k].TPa_Codigo) {
                                        $(".divTotalizadorver").append(`<tr><td><span style="color:${primaryColor}">${primary[j].TipoPagamento}: <b>${primary[j].Valor}</b></span></td><td><span style="color:${secondaryColor}">${secondary[k].TipoPagamento}: <b>${secondary[k].Valor}</b></span></td></tr>`)
                                        primaryValor = primaryValor + parseFloat(primary[j].ValorReal)
                                        secondaryValor = secondaryValor + parseFloat(secondary[k].ValorReal)
                                        secondary.splice(k, 1);
                                        break;
                                    } else if (k == (secondary.length - 1)) {
                                        $(".divTotalizadorver").append(`<tr><td><span style="color:${primaryColor}">${primary[j].TipoPagamento}: <b>${primary[j].Valor}</b></span></td><td>-</td></tr>`)
                                        primaryValor = primaryValor + parseFloat(primary[j].ValorReal)
                                    }
                                }
                                if (j == (primary.length - 1) && secondary.length > 0) {
                                    for (var l = 0; l < secondary.length; l++) {
                                        $(".divTotalizadorver").append(`<tr><td>-</td><td><span style="color:${secondaryColor}">${secondary[l].TipoPagamento}: <b>${secondary[l].Valor}</b></span</td></tr>`)
                                        secondaryValor = secondaryValor + parseFloat(secondary[l].ValorReal)
                                    }
                                }
                            } else {
                                $(".divTotalizadorver").append(`<tr><td><span style="color:${primaryColor}">${primary[j].TipoPagamento}: <b>${primary[j].Valor}</b></span></td><td>-</td></tr>`)
                                primaryValor = primaryValor + parseFloat(primary[j].ValorReal)
                            }
                        }
                        for (var m = 0; m < listaPagCaixaOther.length; m++) {
                            $(".divTotalizadorver").append(`<tr><td >${listaPagCaixaOther[m].TipoPagamento}: <b>${listaPagCaixaOther[m].Valor}</b></td><td>-</td></tr>`)
                        }
                        $(".divTotalizadorver").append(`<tr><td>Total de ${primarytype}: <b>${$_CONFIG.MOEDA} ${primaryValor.toFixed(2).replace('.',',')}</b></td><td>Total de ${secondarytype}: <b>${$_CONFIG.MOEDA} ${secondaryValor.toFixed(2).replace('.',',')}</b></td></tr>`)

                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaFinanceiroCaixa.php",
                            data: {
                                tipo: 10,
                                fcacodigo: $("#listaCaixaAberto").val()
                            },
                            dataType: "json",
                            success: (result) => {

                                var saldodisp = "";
                                for (var i = 0; i < result.result.length; i++) {

                                    if (result.result[i].Valor != "") {
                                        saldodisp += result.result[i].Valor;
                                    } else {
                                        saldodisp += $_CONFIG.MOEDA + '0,00';
                                    }
                                }

                                $("#lblTotalCaixaDispCaixaVer").html(saldodisp);

                            },
                            error: () => {
                                console.log("Falha na conexão.", "", "error");
                            }
                        });

                        $.ajax({
                            type: "POST",
                            url: "/pages/cadastros/buscaFinanceiroCaixa.php",
                            data: {
                                tipo: 11,
                                fcacodigo: $("#listaCaixaAberto").val()
                            },
                            dataType: "json",
                            success: (result) => {

                                var saldorec = "";
                                for (var i = 0; i < result.result.length; i++) {
                                    if (result.result[i].Valor != "") {
                                        saldorec += result.result[i].Valor;
                                    } else {
                                        saldorec += $_CONFIG.MOEDA + '0,00';
                                    }
                                }

                                $("#lblTotalCaixaReceCaixaVer").html(saldorec);
                            },
                            error: (data) => {
                                console.log("Falha na conexão.", "", "error");
                            }
                        });
                    }

                    resizeContent();
                },
                error: () => {
                    console.log("Falha na conexão.", "", "error");
                }
            });
        } else {
            toastr.error("Selecione um caixa.");
            showLoader(false);
        }

    }

    function editFormatternewCa(value, row) {

        var btnComanda = `<button class="btn btn-primary comandaModal btn-xs" data-codigo="${row.FCM_Codigo}">
									<i class="fa fa-list-alt" ></i>
								</button>`;
        var btnInfo = `<button class="btn btn-info infoModal btn-xs" data-codigo="${row.FCM_Codigo}">
								<i class="fa fa-info" ></i>
							</button>`;



        if (row.Com_Codigo == "") {
            return `${btnInfo}`
        } else {
            var btn = `${btnComanda} ${btnInfo}`
            return btn;
        }
    }


});