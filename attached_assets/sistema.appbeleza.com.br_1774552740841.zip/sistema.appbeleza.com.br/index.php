
<!DOCTYPE html>
<html ng-app="appBeleza" ng-controller="sistemaCtrl">

    <head>
        <meta charset="utf-8">
        <title ng-bind="header"></title>
        	<meta charset="UTF-8">
	<title></title>

	<meta Http-Equiv="Cache-Control" Content="no-cache">
	<meta Http-Equiv="Pragma" Content="no-cache">
	<meta Http-Equiv="Expires" Content="0">

	<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
	
	<link href="https://d3verit7xckkza.cloudfront.net/css/bootstrap.min.css" rel="stylesheet" type="text/css">

	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/iCheck/all.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/fullcalendar/fullcalendar2.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/fullcalendar/fullcalendar.print.css" rel="stylesheet" type="text/css" media='print'/>
	<link href="https://d3verit7xckkza.cloudfront.net/js/plugins/intltelinput/intlTelInput.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/autocomplete/jquery.autocomplete.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/timepicker/jquery.timepicker.css" rel="stylesheet" type="text/css"/>
	<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet" type="text/css"/>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/components/flag.min.css" rel="stylesheet"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/timepicker/bootstrap-timepicker.min.css" rel="stylesheet"/>
	<link href="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.css" rel="stylesheet" type="text/css">

	<link href="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.css" rel="stylesheet" type="text/css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter&family=Dosis&family=Mulish&family=Didact+Gothic&family=Modern+Antiqua&display=swap" rel="stylesheet">

	

	<link href="https://d3verit7xckkza.cloudfront.net/css/font-quicksand.css" id="font-style" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/style.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/titatoggle/titatoggle.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/select2/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/jstree/default/style.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/contextmenu/jquery.contextMenu.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/cropper/cropper.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/jQuery-Impromptu-master/jquery-impromptu.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/bootstrap-select/bootstrap-select1.13.10.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/nicelabel/jquery-nicelabel.css" rel="stylesheet" type="text/css"/>

	<!-- DATA TABLES -->
	<link href="https://d3verit7xckkza.cloudfront.net/css/datatables/datatables.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>

	<link href="https://d3verit7xckkza.cloudfront.net/css/sweetalert/sweet-alert.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/datepicker/datepicker.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/bootstrap-multiselect/bootstrap-multiselect.css" rel="stylesheet" type="text/css"/>
	<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap-fileinput@5.1.5/css/fileinput.min.css" rel="stylesheet" type="text/css" /> -->
	<link href="https://d3verit7xckkza.cloudfront.net/css/fileinput/fileinput.min.css" rel="stylesheet" type="text/css"/>
	<!-- <link href="https://d3verit7xckkza.cloudfront.net/css/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css" /> -->

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/css/ion.rangeSlider.min.css"/>
<!--     
	<link href="https://d3verit7xckkza.cloudfront.net/css/ionslider/ion.rangeSlider.css" rel="stylesheet" type="text/css" />
	<link href="https://d3verit7xckkza.cloudfront.net/css/ionslider/ion.rangeSlider.skinFlat.css?1" rel="stylesheet" type="text/css" /> -->
	<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/agenda.css?v3" rel="stylesheet" type="text/css"/>
	<!-- <link href="./css/agenda.css?v2" rel="stylesheet" type="text/css" /> -->

	<link href="https://d3verit7xckkza.cloudfront.net/css/devices.min.css" rel="stylesheet" type="text/css"/>

	<link href="https://d3verit7xckkza.cloudfront.net/css/imagehover/imagehover.css" rel="stylesheet" media="all">
	<link href="https://d3verit7xckkza.cloudfront.net/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://d3verit7xckkza.cloudfront.net/css/tagify/tagify.css" rel="stylesheet" type="text/css"/>
		<link rel="shortcut icon" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/favicon.ico" type="image/x-icon">
	<link rel="icon" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" sizes="57x57" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/favicon-16x16.png">
	<link rel="manifest" href="/img/icon/manifest.json">
	<style>div.google-visualization-tooltip{display:none}</style>
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="https://d3verit7xckkza.cloudfront.net/imgsystem/icon/ms-icon-144x144.png">
		<style>.stoneModal{border-radius:15px;background-color:#fff;border:solid 2px #06ab37}.stoneModalInside .modal-content{border-radius:15px;background-color:#fff;border:solid 2px #06ab37;text-align:center}.recenterButton{width:80%;margin-left:10%}.flip-card{background-color:transparent;height:150pt;perspective:1000px}.flip-card-inner{position:relative;text-align:center;transition:transform .8s;transform-style:preserve-3d}.flip-card-rotate{transform:rotateY(180deg)}.undoflip-card-rotate{transform:none}.flip-card-front,.flip-card-back{position:absolute;-webkit-backface-visibility:hidden;backface-visibility:hidden}.flip-card-front{}.flip-card-back{transform:rotateY(180deg)}.flip-card-prod{background-color:transparent;height:300pt;perspective:1000px}.flip-card-prod-inner{position:relative;text-align:center;transition:transform .8s;transform-style:preserve-3d}.flip-card-prod-rotate{transform:rotateY(180deg)}.undoflip-prod-card-rotate{transform:none}.flip-card-prod-front,.flip-card-prod-back{position:absolute;-webkit-backface-visibility:hidden;backface-visibility:hidden}.flip-card-prod-front{}.flip-card-prod-back{transform:rotateY(180deg)}</style>

	<style type="text/css">.nav.nav-tabs>li{cursor:pointer}.popover{z-index:9010}.img-thumb{width:50px;height:50px}.list-padding{padding:10px}.twitter-typeahead{display:block!important}.clear-select{background-color:transparent;padding:5px;font-style:bold;border-top:none;border-left:none;border-right:none;color:#b8c7ce;border-color:#636363}.skin-blue .sidebar select{color:#b8c7ce}.skin-blue-light .sidebar select{color:#444}.skin-black .sidebar select{color:#b8c7ce}.skin-black-light .sidebar a{color:#444}.skin-green .sidebar a{color:#b8c7ce}.skin-green-light .sidebar a{color:#444}.skin-red .sidebar a{color:#b8c7ce}.skin-red-light .sidebar a{color:#444}.skin-yellow .sidebar a{color:#b8c7ce}.skin-yellow-light .sidebar a{color:#444}.skin-purple .sidebar a{color:#b8c7ce}.skin-purple-light .sidebar a{color:#444}.clear-select-dark{background-color:transparent;padding:5px;font-style:bold;border-top:none;border-left:none;border-right:none;color:#000;border-color:#636363}.clear-option{color:#000;background-color:rgba(255,255,255,.7)}</style>
	<style type="text/css">.disabledTab{pointer-events:none}.divLoaderMsgPromo{position:absolute;width:100%;height:125px;top:50%;left:0;margin:-100px 0 0 0;background-image:url(https://d3verit7xckkza.cloudfront.net/imgsystem/promo/halloween/halloween-frase2.png);background-repeat:no-repeat;background-size:cover}.tree-left{left:25px;position:absolute;bottom:0;height:120px}.tree-right{right:25px;position:absolute;bottom:0;height:120px}.bat1-left{left:120px;position:absolute;top:11px;height:25px}.bat2-left{left:160px;position:absolute;top:71px;height:25px}.bat1-right{right:240px;position:absolute;top:60px;height:25px}.bat2-right{right:150px;position:absolute;top:78px;height:25px}.bat3-right{right:200px;position:absolute;top:20px;height:25px}@media (max-width:767px){.divLoaderMsgPromo{width:100%;height:150px;top:50%;left:0;margin:-100px 0 0 0;background-image:url(/img/promo/halloween/halloween-frase2.png);background-repeat:no-repeat;background-size:cover}.tree-left{left:8px;position:absolute;bottom:0;height:70px;opacity:.7}.tree-right{right:8px;position:absolute;bottom:0;height:70px;opacity:.7}.bat1-left{left:10px;position:absolute;top:11px;height:10px;opacity:.7}.bat2-left{left:20px;position:absolute;top:51px;height:10px;opacity:.7}.bat1-right{right:20px;position:absolute;top:60px;height:10px;opacity:.7}.bat2-right{right:40px;position:absolute;top:78px;height:10px;opacity:.7}.bat3-right{right:60px;position:absolute;top:20px;height:10px;opacity:.7}}.divLoaderMsg{position:absolute;width:100%;height:125px;top:50%;left:0;margin:-100px 0 0 0;background:#0c537a}@media (max-width:767px){.divLoaderMsg{width:100%;height:150px;top:50%;left:0;margin:-100px 0 0 0;background:#3c8dbc}}.loaderMsg{position:absolute;width:100%;height:100%;z-index:9998;top:0;left:0;background: #00000099}.blurBackground{-webkit-filter:blur(1px);-moz-filter:blur(1px);-o-filter:blur(1px);-ms-filter:blur(1px);filter:blur(1px)}.dropdown-menu{max-height:300px;overflow-y:auto;overflow-x:hidden}</style>
	<style>.ajax_loader{background:url(https://d3verit7xckkza.cloudfront.net/imgsystem/ring-alt.gif) no-repeat center center transparent;width:100%;height:100%}.select2-container--default.select2-container--focus,.select2-selection.select2-container--focus,.select2-container--default:focus,.select2-selection:focus,.select2-container--default:active,.select2-selection:active{outline:none}.select2-container--default .select2-selection--single,.select2-selection .select2-selection--single{border:1px solid #d2d6de;border-radius:0;padding:6px 12px;height:34px}.select2-container--default.select2-container--open{border-color:#3c8dbc}.select2-dropdown{border:1px solid #d2d6de;border-radius:0}.select2-container--default .select2-results__option--highlighted[aria-selected]{background-color:#3c8dbc;color:#fff}.select2-results__option{padding:6px 12px;user-select:none;-webkit-user-select:none}.select2-container .select2-selection--single .select2-selection__rendered{padding-left:0;padding-right:0;height:auto;margin-top:-4px}.select2-container[dir="rtl"] .select2-selection--single .select2-selection__rendered{padding-right:6px;padding-left:20px}.select2-container--default .select2-selection--single .select2-selection__arrow{height:28px;right:3px}.select2-container--default .select2-selection--single .select2-selection__arrow b{margin-top:0}.select2-dropdown .select2-search__field,.select2-search--inline .select2-search__field{border:1px solid #d2d6de}.select2-dropdown .select2-search__field:focus,.select2-search--inline .select2-search__field:focus{outline:none;border:1px solid #3c8dbc}.select2-container--default .select2-results__option[aria-disabled="true"]{color:#999}.select2-container--default .select2-results__option[aria-selected="true"]{background-color:#ddd}.select2-container--default .select2-results__option[aria-selected="true"],.select2-container--default .select2-results__option[aria-selected="true"]:hover{color:#444}.select2-container--default .select2-selection--multiple{border:1px solid #d2d6de;border-radius:0}.select2-container--default .select2-selection--multiple:focus{border-color:#3c8dbc}.select2-container--default.select2-container--focus .select2-selection--multiple{border-color:#d2d6de}.select2-container--default .select2-selection--multiple .select2-selection__choice{background-color:#3c8dbc;border-color:#367fa9;padding:1px 10px;color:#fff}.select2-container--default .select2-selection--multiple .select2-selection__choice__remove{margin-right:5px;color:rgba(255,255,255,.7)}.select2-container--default .select2-selection--multiple .select2-selection__choice__remove:hover{color:#fff}.bg-teal-dark{color:#fff!important;background-color:#00796b!important}.bg-grafite{color:#fff!important;background-color:#424242!important}.bg-blue-gray{color:#fff!important;background-color:#455a64!important}th{font-size:small!important}</style>
	<style>.cc-selector input{margin:0;padding:0;-webkit-appearance:none;-moz-appearance:none;appearance:none}.cc-selector-2 input:active+.drinkcard-cc,.cc-selector input:active+.drinkcard-cc{opacity:.9}.cc-selector-2 input:checked+.drinkcard-cc,.cc-selector input:checked+.drinkcard-cc{-webkit-filter:none;-moz-filter:none;filter:none}.drinkcard-cc{cursor:pointer;background-size:contain;background-repeat:no-repeat;display:inline-block;width:60px;height:30px;-webkit-transition:all 100ms ease-in;-moz-transition:all 100ms ease-in;transition:all 100ms ease-in;-webkit-filter:brightness(1.8) grayscale(1) opacity(.7);-moz-filter:brightness(1.8) grayscale(1) opacity(.7);filter:brightness(1.8) grayscale(1) opacity(.7)}.drinkcard-cc:hover{-webkit-filter:brightness(1.2) grayscale(.5) opacity(.9);-moz-filter:brightness(1.2) grayscale(.5) opacity(.9);filter:brightness(1.2) grayscale(.5) opacity(.9)}.drinkcard-cc2{cursor:pointer;background-size:contain;background-repeat:no-repeat;display:inline-block;width:60px;height:30px}</style>
	<style>table.dataTable td.excluir-control{text-align:center;cursor:pointer}table.dataTable td.excluir-control:before{font-family:FontAwesome;font-weight:normal;font-style:normal;color:#66f;text-decoration:inherit;-webkit-font-smoothing:antialiased;*margin-right: .3em;content:"\f1f8"}table.dataTable td.editar-control{text-align:center;cursor:pointer}table.dataTable td.editar-control:before{font-family:FontAwesome;font-weight:normal;font-style:normal;color:#66f;text-decoration:inherit;-webkit-font-smoothing:antialiased;*margin-right: .3em;content:"\f040"}table.dataTable td.details-control{text-align:center;cursor:pointer}table.dataTable td.details-control:before{font-family:FontAwesome;font-weight:normal;font-style:normal;text-decoration:inherit;-webkit-font-smoothing:antialiased;*margin-right: .3em;content:"\f067"}table.dataTable tr.shown td.details-control:before{content:"\f068"}</style>

	<style type="text/css" media="screen">body{background:#f2f2f2;padding:0;margin:0}#price{text-align:center}.plan{display:inline-block;margin:10px 1%;font-family:'Lato',Arial,sans-serif}.plan-inner{background:#fff;margin:0 auto;min-width:280px;max-width:100%;position:relative}.entry-title{background:#53cfe9;height:140px;position:relative;text-align:center;color:#fff;margin-bottom:30px}.entry-title>h3{background:#20bada;font-size:20px;padding:5px 0;text-transform:uppercase;font-weight:700;margin:0}.entry-title .price{position:absolute;bottom:-25px;background:#20bada;height:95px;width:95px;margin:0 auto;left:0;right:0;overflow:hidden;border-radius:50px;border:5px solid #fff;line-height:80px;font-size:28px;font-weight:700}.entry-title .price-sms{position:absolute;bottom:-25px;background:#20bada;height:95px;width:95px;margin:0 auto;left:0;right:0;overflow:hidden;border-radius:50px;border:5px solid #fff;line-height:80px;font-size:24px;font-weight:700}.price span{position:absolute;font-size:9px;bottom:-10px;left:30px;font-weight:400}.entry-content{color:#323232}.entry-content ul{margin:0;padding:0;list-style:none;text-align:center}.entry-content li{border-bottom:1px solid #e5e5e5;padding:10px 0}.entry-content li:last-child{border:none}.basic .entry-title{background:#75ddd9}.basic .entry-title>h3{background:#44cbc6}.basic .price{background:#44cbc6}.standard .entry-title{background:#4484c1}.standard .entry-title>h3{background:#3772aa}.standard .price{background:#3772aa}.ultimite .entry-title>h3{background:#dd4b5e}.ultimite .entry-title{background:#f75c70}.ultimite .price{background:#dd4b5e}.basic2 .entry-title{background:#ddaf75}.basic2 .entry-title>h3{background:#cb7044}.basic2 .price{background:#cb7044}.standard2 .entry-title{background:#c17244}.standard2 .entry-title>h3{background:#aa5737}.standard2 .price{background:#aa5737}.ultimite2 .entry-title>h3{background:#da5420}.ultimite2 .entry-title{background:#e97d53}.ultimite2 .price{background:#da5420}#HW_badge_cont{position:absolute!important;top:-2px}#HW_badge{background:#dd4b39!important}.datepicker{z-index:99999!important}.bordadireita{border-right-style:solid;border-width:1px;border-color:#eee}</style>

	<style>.sistemaColorPrimary{color:#600239}.sistemaColorLight{color:#801249}.modal-content.rounded{-webkit-border-radius:10px!important;-moz-border-radius:10px!important;border-radius:10px!important}.modal-backdrop{opacity:.7!important}</style>

		
	<style>.sorteiowrapper{width:100%;padding-top:20vh;min-height:60vh;text-align:center;background-color:#253241}#rollSorteio{display:inline-block;color:#fff;background-color:#0072bc;text-decoration:none;font-size:3rem;border:5px solid #00233c;padding:.45em 2em;border-radius:3em;-webkit-transition:400ms ease-in-out;transition:400ms ease-in-out}#roll-againSorteio{display:inline-block;color:#fff;background-color:#00233c;text-decoration:none;font-size:1.5rem;border:3px solid #0072bc;padding:.45em 2em;border-radius:3em;-webkit-transition:400ms ease-in-out;transition:400ms ease-in-out}#info-cliente{display:inline-block;color:#fff;background-color:#0072bc;text-decoration:none;font-size:1.5rem;border:3px solid #00233c;padding:.45em 2em;border-radius:3em;-webkit-transition:400ms ease-in-out;transition:400ms ease-in-out}#rollSorteio:hover{background-color:#fff;color:#253241}#roll-againSorteio:hover{background-color:#fff;color:#253241}#info-cliente:hover{background-color:#fff;color:#253241}#namesSorteio{font-size:2.5rem;color:#fff}#winnerSorteio{font-size:4rem;font-weight:700;color:#00955c}#winnerSorteio span{font-size:3rem;color:#fff}.info-produto-scan{font-family:"Lato",serif;font-weight:400}.info-produto-scan-title{font-family:"Lato",serif;font-weight:500;font-style:bold}.center-div{left:50%;top:50%}.profile-user-img-70{margin:0 auto;width:70px;padding:3px;border:3px solid #d2d6de}.switch{position:relative;display:inline-block;width:32px;height:18px}.switch input{opacity:0;width:0;height:0}.slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#ccc;-webkit-transition:.4s;transition:.4s}.fa-stone:before{content:url(img/xiconeparceirostone.png.pagespeed.ic.rOkodrrapk.webp);width:14px!important}.slider:before{position:absolute;content:"";height:14px;width:14px;left:2px;bottom:2px;background-color:#fff;-webkit-transition:.4s;transition:.4s}input:checked+.slider{background-color:#2196f3}input:focus+.slider{box-shadow:0 0 1px #2196f3}input:checked+.slider:before{-webkit-transform:translateX(14px);-ms-transform:translateX(14px);transform:translateX(14px)}.slider.round{border-radius:34px}.slider.round:before{border-radius:50%}ul.dt-button-collection.dropdown-menu.three-column{width:670px}ul.dt-button-collection.dropdown-menu.two-column{width:670px}</style>

<style>@media (max-width:767px){.main-header .navbar .dropdown-menu li a{color:#777!important}.main-header .navbar .dropdown-menu li a:hover{background:#367fa9!important;color:#fff!important}.main-header .navbar .dropdown-menu .active a{background:#367fa9!important;color:#fff!important}}</style>

        <style>.bg-nps0{background-color:#d50000}.bg-nps1{background-color:#d32f2f}.bg-nps2{background-color:#ff6f00}.bg-nps3{background-color:#ffa000}.bg-nps4{background-color:#ffc400}.bg-nps5{background-color:#ffea00}.bg-nps6{background-color:#c6ff00}.bg-nps7{background-color:#b2ff59}.bg-nps8{background-color:#8bc34a}.bg-nps9{background-color:#689f38}.bg-nps10{background-color:#1b5e20}.btn-nps{color:#fff}.btn-nps:hover{color:#fff}.nps-bottom{z-index:1000;bottom:-250px;position:fixed;left:25%;width:50%;box-shadow: 3px 3px 5px 0px #17774a88}.caixa-side{z-index:1000;top:10%;right:0;position:fixed}.btn-caixa{height:80px;width:30px;border-top-left-radius:5px;border-bottom-left-radius:5px;border:0 solid;margin-top:10px;background-color:#096aa5;color:#fff}.btn-caixa:hover{border-top-left-radius:5px;border-bottom-left-radius:5px;border:0 solid;background-color:#3c8dbc;color:#fff;cursor:pointer!important}.btn-caixa:click{border-top-left-radius:5px;border-bottom-left-radius:5px;border:0 solid;background-color:#3c8dbc;color:#fff}.box-caixa{position:fixed;z-index:1000;right:-650px;width:650px;top:10%;box-shadow:5px 5px 5px 0 #888}.btn-caixa-close{padding:10px}.vertical-text{transform:rotate(270deg);-ms-transform:rotate(270deg);-webkit-transform:rotate(270deg);-webkit-transform-origin:0% 50%;transform-origin:65% 75%;cursor:pointer!important}.caixa-fechado{background-color:#af0711!important}#iconCaixa{display:none}.caixa-fechado:hover{background-color:#e26859}</style>
    </head>

    

    
    <body class=" skin-blue sidebar-mini" ng-controller='caixaCtrl' lang="pt-BR" style="touch-action:manipulation;">

        
            
	<div class="navbar navbar-fixed-bottom text-center" id="appblz-div-contratar">
		<h5 class="hidden-xs" style="color:white;"> Faltam 30 dias para expirar o período de teste. 			<button type="button" class="btn btn-xs appblz-btn-contratar" ng-click="goToContratar()">{{'header.contratar' | translate}}</button>
		</h5>
		<h5 class="visible-xs" style="color:white;">
			<button type="button" class="btn btn-xs appblz-btn-contratar" ng-click="goToContratar()">{{'header.contratar' | translate}}</button>
			Faltam 30 dias para expirar o período de teste. 		</h5>
	</div>

	<!-- <div class="navbar navbar-fixed-bottom text-center" id="appblz-div-contratar">
		<h5 class="hidden-xs" style="color:white;"> 			<button type="button" class="btn btn-xs appblz-btn-contratar" ng-click="goToContratar()" data-toggle='modal' data-target='#contratar-modal'>{{'header.contratar' | translate}}</button>
		</h5>
		<h5 class="visible-xs" style="color:white;">
			<button type="button" class="btn btn-xs appblz-btn-contratar" ng-click="goToContratar()" data-toggle='modal' data-target='#contratar-modal'>{{'header.contratar' | translate}}</button>
					</h5>
	</div> -->



<header class="main-header blurBackground">

	<a href="/index.php#/agenda" class="logo hidden-xs">
		
		<span class="logo-mini"><small id="stringSistemaMini"> </small></span>
<span class="logo-lg "><small id="stringSistema"> </small></span>	</a>

	<nav class="navbar navbar-static-top" role="navigation">
		<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
			<span class="sr-only">{{'header.fecharmenu' | translate}}</span>
		</a>
		<ul class="nav navbar-nav hidden-xs">
			<li class="dropdown notifications-menu hidden-xs" id="favMenus">
				<a class="dropdown-toggle" data-toggle="dropdown">
					<i class="fa fa-star"></i>
				</a>
				<ul class="dropdown-menu" style="max-height: 600px !important;min-height: 280px !important;height: auto;max-width: 400px !important; min-width: 280px !important;width: auto;">
					<li class="header text-center"><strong>{{'header.favoritos' | translate}}</strong></li>
					<li ng-show="favoritos.length > 0">						
						<ul class="menu" id="listFav" style="max-height: 528px !important;min-height: 228px !important;">
							<li ng-repeat="favorito in favoritos" ng-click="changeRoute(favorito.url)">
								<a class="pointer">
									<h5> 
										<i class="{{favorito.icon}}"></i> {{favorito.name}} <i class="fa fa-times pull-right" style="margin-top: 3px;" ng-click="removeFavorito(favorito.url, 2)"></i>
									</h5>   
									<div> <small style="color:grey">{{favorito.path}}</small> </div>
                    			</a>
							</li>
						</ul>
					</li>
					<li ng-show="favoritos.length == 0">
						<div class="row">
							<div class="col-md-12 text-center">
								<p><h5>Nenhum Favorito Adicionado.</h5></p>
								<p><small>Adicione clicando com o botão direito do mouse no menu que deseja.</small></p>
							</div>
						</div>
					</li>
					<li ng-show="favoritos.length > 0" class="footer"><a class="pointer" ng-click="limpaFavoritos()">Excluir Todos</a></li>
				</ul>
			</li>
		</ul>
		
		<ul class="nav navbar-nav hidden-xs hidden-sm">
			<a class="navbar-brand" id="navProf" style="display:none;">{{'header.profissionais' | translate}}: </a>
		</ul>
		<form class="navbar-form navbar-left " id="formProf">
			<div class="form-group">
				<select id="users_menu" multiple="multiple" style="display: none;">
									</select>


			</div>
		</form>

		<div class="navbar-custom-menu" ng-controller="notificacaoCtrl">
			<ul class="nav navbar-nav ">

			
				<li class="dropdown notifications-menu hidden-lg  hidden-sm hidden-md" id="favMenus">
					<a class="dropdown-toggle" data-toggle="dropdown">
						<i class="fa fa-star"></i>
					</a>
					<ul class="dropdown-menu" style="max-height: 600px !important;min-height: 280px !important;height: auto;max-width: 400px !important; min-width: 280px !important;width: auto;">
						<li class="header text-center"><strong>{{'header.favoritos' | translate}}</strong></li>
						<li ng-show="favoritos.length > 0">						
							<ul class="menu" id="listFav" style="max-height: 528px !important;min-height: 228px !important;">
								<li ng-repeat="favorito in favoritos" ng-click="changeRoute(favorito.url)">
									<a class="pointer">
										<h5> 
											<i class="{{favorito.icon}}"></i> {{favorito.name}} <i class="fa fa-times pull-right" style="margin-top: 3px;" ng-click="removeFavorito(favorito.url, 2)"></i>
										</h5>   
										<div> <small style="color:grey">{{favorito.path}}</small> </div>
									</a>
								</li>
							</ul>
						</li>
						<li ng-show="favoritos.length == 0">
							<div class="row">
								<div class="col-md-12 text-center">
									<p><h5>Nenhum Favorito Adicionado.</h5></p>
									<p><small>Segure pressionado o menu que deseja para adicionar aos favoritos.</small></p>
								</div>
							</div>
						</li>
						<li ng-show="favoritos.length > 0" class="footer"><a class="pointer" ng-click="limpaFavoritos()">Excluir Todos</a></li>
					</ul>
				</li>
				

				<li class="dropdown notifications-menu  hidden-sm hidden-xs" id="menuMsg" data-toggle="tooltip" data-placement="bottom" title="Info do produto">
					<a class="dropdown-toggle" data-toggle="modal" data-target="#infoProdutoModal-modal" ng-click="undoFlipProd()">
						<i class="fa fa-barcode"></i>
					</a>
				</li>
									<li class="dropdown notifications-menu" data-toggle="tooltip" data-placement="bottom" title="{{'header.painelfinanceiro' | translate}}">
						<a ui-sref="painelFinanceiro" class="dropdown-toggle">
							<i class="ion ion-social-usd"></i>
						</a>
					</li>
				
				<li class="dropdown notifications-menu" id="menuMsg" data-toggle="tooltip" data-placement="bottom" title="{{'header.resumo'  | translate}}">
					<a ui-sref="relResumo" class="dropdown-toggle">
						<i class="ion ion-clipboard"></i>
						<span class="label label-danger" id="countResumo" style="display:none;" ng-show="totResumo > 0">{{totResumo}}</span>
					</a>
				</li>
				<li class="dropdown notifications-menu" id="menuMsg" data-toggle="tooltip" data-placement="bottom" title="{{'header.aniversarios' | translate}}">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<i class="fa fa-birthday-cake"></i>
						<span class="label label-danger" id="countAniv" style="display:none;" ng-show="totAniversariantes > 0">{{totAniversariantes}}</span>
					</a>
					<ul class="dropdown-menu">
						<li class="header" id="titleAniv"></li>
						<li>
							<div class="text-center" ng-show="totAniversariantes == ''">
								<h4>{{'header.notificacao.sem_aniversario' | translate}}.</h4>
							</div>
							
							<ul class="menu menuHeader" id="listAniv">
								<li ng-repeat="aniversariante in aniversariantes" ng-click="enviaMsg(aniversariante.PesCodigo,aniversariante.isToday)">
									<a style="{{aniversariante.textStyle}};{{aniversariante.textSize}}">
										<img class="img-circle" width="48" height="48" ng-src="{{aniversariante.Imagem}}"></img> {{aniversariante.Nome}}
										<small style="float: right;">{{aniversariante.DiaAniversario}}.</small>
									</a>
								</li>
							</ul>
						</li>
						<li class="footer"><a ui-sref="relAniversariantes">{{'header.verhistorico' | translate}}</a></li>
					</ul>
				</li>

				<li class="dropdown notifications-menu" id="menuMsg" data-toggle="tooltip" data-placement="bottom" title="{{'header.mensagens' | translate}}">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<i class="fa fa-envelope-o"></i>
						<span class="label label-danger" id="countMsg" style="display:none;" ng-show="totMensagens > 0">{{totMensagens}}</span>
					</a>
					<ul class="dropdown-menu">
						<li class="header" id="titleMsg"></li>
						<li>
							<div class="text-center" ng-show="totMensagens == ''">
								<h4>{{'header.notificacao.sem_mensagem' | translate}}</h4>
							</div>
							
							<ul class="menu menuHeader" id="listMsg" ng-show="totMensagens > 0">
								<li ng-repeat="mensagem in mensagens">
									<a ng-click="showMessage(mensagem.MEn_Codigo,mensagem.MEn_Titulo,mensagem.MEn_Descricao,'/img/newmessage.png',mensagem.Tipo)">
										<i class="fa fa-envelope success"></i>{{mensagem.MEn_Titulo}}
									</a>
								</li>
							</ul>
						</li>
						<li class="footer"><a ui-sref="relMenRecebida">{{'header.verhistorico' | translate}}</a></li>
					</ul>
				</li>

				<li class="dropdown notifications-menu" data-toggle="tooltip" data-placement="bottom" title="{{'header.solicitacoes' | translate}}">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" id="menuNewUser">
						<i class="ion ion-person-add"></i>
						<span class="label label-danger" id="countNewUser" style="display:none;" ng-show="totSolCadBadge > 0">{{totSolCadBadge}}</span>
					</a>
					<ul class="dropdown-menu newuser">
						<li class="header" id="titleSolCad">{{titleSolCad}}</li>
						<div class="text-center">
							<small class="label bg-green btnFilter" style="cursor: pointer;" ng-click="filterSol = ''">{{'header.todos' | translate}}</small>
							<small class="label bg-gray btnFilter" style="cursor: pointer;" ng-click="filterSol = 'Pendente'">{{'header.pendentes' | translate}}</small>
							<small class="label bg-gray btnFilter" style="cursor: pointer;" ng-click="filterSol = 'Aprovado'">{{'header.aprovados' | translate}}</small>
							<small class="label bg-gray btnFilter" style="cursor: pointer;" ng-click="filterSol = 'Reprovado'">{{'header.reprovados' | translate}}</small>
						</div>

						<li>
							<ul class="menu menuHeader" id="listNewUser" ng-show="totSolCad > 0">
								<li ng-repeat="newuser in solcad | filter: { SCa_Aprovacao: filterSol}">
									<a style="margin:5px;box-shadow: 1px 1px 5px #888888;" href="#">
										<div class="text-center" style="border-bottom: 1px solid #ddd;margin-bottom: 10px;padding-bottom: 10px;">
											<small>{{newuser.SCa_Dat_Solicitacao}}</small>
										</div>
										<div class="row">
											<div class="col-md-4">
												<img class="img-circle" width="52" height="52" ng-src="{{newuser.SCa_Imagem}}"></img>
											</div>
											<div class="col-md-8">
												<address>
													<label><strong>{{newuser.SCa_Nome}}</strong></label> <br>
													<small style="font-size: 10px;">{{newuser.SCa_Email}}</small> <br>
													<small style="font-size: 10px;" ng-if="newuser.SCa_Celular2 != ''">{{newuser.SCa_Celular2}}</small>
												</address>
											</div>
										</div>
										<div class="row text-right" ng-show="newuser.SCa_Aprovado == ''">
											<div class="col-md-12">
												<button type="button" class="btn btn-success btn-xs btnSolCad" ng-click="confirmNewUser(newuser.idx)"><i class="ion ion-checkmark-round"></i> <strong>Confirmar</strong></button>
												<button type="button" class="btn btn-danger btn-xs btnSolCad" ng-click="reproveNewUser(newuser.idx)"><i class="ion ion-close-round"></i> <strong>Recusar</strong></button>
											</div>
										</div>
										<div class="row text-right" ng-show="newuser.SCa_Aprovado != ''">
											<div class="col-md-12">
												<small class="label  bg-green" ng-show="newuser.SCa_Aprovado == '1'">Aprovado</small>
												<small class="label  bg-red" ng-show="newuser.SCa_Aprovado == '0'">Reprovado</small>
												<button ng-show="newuser.SCa_Aprovado == '0'" type="button" class="btn btn-primary btn-xs pull-right btnSolCad" ng-click="undoNewUser(newuser.idx)" style="margin-left:10px; "><i class="ion ion-refresh"></i> <strong>Desfazer</strong></button>
											</div>
										</div>
									</a>
								</li>
							</ul>
						</li>
						<li class="footer"><a ui-sref="relSolClientes">{{'header.verhistorico' | translate}}</a></li>
					</ul>
				</li>
				<li class="dropdown user user-menu" data-toggle="tooltip" data-placement="bottom" title="{{'header.perfil' | translate}}">

					
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<script data-pagespeed-no-defer>//<![CDATA[
(function(){for(var g="function"==typeof Object.defineProperties?Object.defineProperty:function(b,c,a){if(a.get||a.set)throw new TypeError("ES3 does not support getters and setters.");b!=Array.prototype&&b!=Object.prototype&&(b[c]=a.value)},h="undefined"!=typeof window&&window===this?this:"undefined"!=typeof global&&null!=global?global:this,k=["String","prototype","repeat"],l=0;l<k.length-1;l++){var m=k[l];m in h||(h[m]={});h=h[m]}var n=k[k.length-1],p=h[n],q=p?p:function(b){var c;if(null==this)throw new TypeError("The 'this' value for String.prototype.repeat must not be null or undefined");c=this+"";if(0>b||1342177279<b)throw new RangeError("Invalid count value");b|=0;for(var a="";b;)if(b&1&&(a+=c),b>>>=1)c+=c;return a};q!=p&&null!=q&&g(h,n,{configurable:!0,writable:!0,value:q});var t=this;function u(b,c){var a=b.split("."),d=t;a[0]in d||!d.execScript||d.execScript("var "+a[0]);for(var e;a.length&&(e=a.shift());)a.length||void 0===c?d[e]?d=d[e]:d=d[e]={}:d[e]=c};function v(b){var c=b.length;if(0<c){for(var a=Array(c),d=0;d<c;d++)a[d]=b[d];return a}return[]};function w(b){var c=window;if(c.addEventListener)c.addEventListener("load",b,!1);else if(c.attachEvent)c.attachEvent("onload",b);else{var a=c.onload;c.onload=function(){b.call(this);a&&a.call(this)}}};var x;function y(b,c,a,d,e){this.h=b;this.j=c;this.l=a;this.f=e;this.g={height:window.innerHeight||document.documentElement.clientHeight||document.body.clientHeight,width:window.innerWidth||document.documentElement.clientWidth||document.body.clientWidth};this.i=d;this.b={};this.a=[];this.c={}}function z(b,c){var a,d,e=c.getAttribute("data-pagespeed-url-hash");if(a=e&&!(e in b.c))if(0>=c.offsetWidth&&0>=c.offsetHeight)a=!1;else{d=c.getBoundingClientRect();var f=document.body;a=d.top+("pageYOffset"in window?window.pageYOffset:(document.documentElement||f.parentNode||f).scrollTop);d=d.left+("pageXOffset"in window?window.pageXOffset:(document.documentElement||f.parentNode||f).scrollLeft);f=a.toString()+","+d;b.b.hasOwnProperty(f)?a=!1:(b.b[f]=!0,a=a<=b.g.height&&d<=b.g.width)}a&&(b.a.push(e),b.c[e]=!0)}y.prototype.checkImageForCriticality=function(b){b.getBoundingClientRect&&z(this,b)};u("pagespeed.CriticalImages.checkImageForCriticality",function(b){x.checkImageForCriticality(b)});u("pagespeed.CriticalImages.checkCriticalImages",function(){A(x)});function A(b){b.b={};for(var c=["IMG","INPUT"],a=[],d=0;d<c.length;++d)a=a.concat(v(document.getElementsByTagName(c[d])));if(a.length&&a[0].getBoundingClientRect){for(d=0;c=a[d];++d)z(b,c);a="oh="+b.l;b.f&&(a+="&n="+b.f);if(c=!!b.a.length)for(a+="&ci="+encodeURIComponent(b.a[0]),d=1;d<b.a.length;++d){var e=","+encodeURIComponent(b.a[d]);131072>=a.length+e.length&&(a+=e)}b.i&&(e="&rd="+encodeURIComponent(JSON.stringify(B())),131072>=a.length+e.length&&(a+=e),c=!0);C=a;if(c){d=b.h;b=b.j;var f;if(window.XMLHttpRequest)f=new XMLHttpRequest;else if(window.ActiveXObject)try{f=new ActiveXObject("Msxml2.XMLHTTP")}catch(r){try{f=new ActiveXObject("Microsoft.XMLHTTP")}catch(D){}}f&&(f.open("POST",d+(-1==d.indexOf("?")?"?":"&")+"url="+encodeURIComponent(b)),f.setRequestHeader("Content-Type","application/x-www-form-urlencoded"),f.send(a))}}}function B(){var b={},c;c=document.getElementsByTagName("IMG");if(!c.length)return{};var a=c[0];if(!("naturalWidth"in a&&"naturalHeight"in a))return{};for(var d=0;a=c[d];++d){var e=a.getAttribute("data-pagespeed-url-hash");e&&(!(e in b)&&0<a.width&&0<a.height&&0<a.naturalWidth&&0<a.naturalHeight||e in b&&a.width>=b[e].o&&a.height>=b[e].m)&&(b[e]={rw:a.width,rh:a.height,ow:a.naturalWidth,oh:a.naturalHeight})}return b}var C="";u("pagespeed.CriticalImages.getBeaconData",function(){return C});u("pagespeed.CriticalImages.Run",function(b,c,a,d,e,f){var r=new y(b,c,a,e,f);x=r;d&&w(function(){window.setTimeout(function(){A(r)},0)})});})();pagespeed.CriticalImages.Run('/mod_pagespeed_beacon','https://sistema.appbeleza.com.br/index.php','2L-ZMDIrHf',true,false,'yQXqG4ge10M');
//]]></script><img src="/img/xnopicture.png.pagespeed.ic.fsELxk3BUY.webp" class="user-image" alt="User Image" data-pagespeed-url-hash="3894603355" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
						<span> <i class="caret"></i></span>
					</a>



					<ul class="dropdown-menu" style="width: 400px;">
						
						<li class="user-header">
							﻿<img src="/img/xnopicture.png.pagespeed.ic.fsELxk3BUY.webp" id="imgUsuFoto" class="img-circle" alt="User" data-pagespeed-url-hash="3894603355" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/>							<p>
								Gustavo Bezerra							</p>
						</li>

						<li class="user-footer" style="background-color: #fff;">
							<div class="row">
																	<div class="col-md-3  text-center">
										<a ui-sref="conta" class="btn btn-default btn-flat"><i class="ion ion-ios-home"></i> {{'header.conta' | translate}}</a>
									</div>
									<div class="col-md-3 text-center">
										<a ui-sref="acessos" class="btn btn-default btn-flat"><i class="ion ion-lock-combination"></i> {{'header.acessos' | translate}}</a>
									</div>
									<div class="col-md-3 text-center hidden-xs hidden-sm">
										<a href="#" data-toggle="control-sidebar" class="btn btn-default btn-flat"><i class="ion ion-paintbucket"></i> {{'header.temas' | translate}}</a>
									</div>
									<div class="col-md-3 text-center">
										<a onclick="logout();" id="btnLogoutSistema" class="btn btn-default btn-flat"><i class="ion ion-power"></i> {{'header.logout' | translate}}</a>
									</div>
															</div>
						</li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
</header>            <div class="wrapper row-offcanvas row-offcanvas-left blurBackground">
                <aside class="main-sidebar" style="z-index:99;">
	<section class="sidebar">
		<div class="user-panel">
			<form id="formAlteraLogo" enctype="multipart/form-data">
				<input type="file" style="display:none;" name="file" id="file_teste" accept="image/*" onChange="readURL3(this);">
			</form>
			<div class="image text-center" id="btnAlterarImg" style="cursor:pointer;">
				<img src="/img/xicone.png.pagespeed.ic.H8pArbcu0k.webp" class="img-rounded image" alt="Usuario" data-pagespeed-url-hash="3173940646" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/> 
			</div>
			<br>	
						
			
		</div>
		<ul class="sidebar-menu">
			

				<li>
					<a class="control-menu" ui-sref="agenda">
						<i class="fa fa-calendar"></i>
						<span>{{'menu.agenda' | translate}}</span>
					</a>
				</li>
				
				<li class="treeview">
					<a class="pointer" data-step="1" data-intro="Finalize todos os seus cadastros.">
						<i class="fa fa-book"></i>
						<span>{{'menu.cadastros.titulo' | translate}}</span>
						<i class="fa fa-angle-left pull-right"></i>
					</a>
					<ul class="treeview-menu">
						<li>
							<a class="control-menu" ui-sref="clientes">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.clientes' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="profissionais">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.profissionais' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="servicos">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.servicos' | translate}} </a>
						</li>
						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.pacotes.titulo' | translate}}
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="pacotes">
										<i class="fa fa-circle-o"></i> {{'menu.cadastros.pacotes.meus' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="pacotesVenda">
										<i class="fa fa-circle-o"></i> {{'menu.cadastros.pacotes.venda' | translate}}</a>
								</li>

							</ul>
						</li>
						<li> 
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.tipos.titulo' | translate}}
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="categorias">
										<i class="fa fa fa-circle-o"></i> {{'menu.cadastros.tipos.categoria' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="tipoPagamentos">
										<i class="fa fa fa-circle-o"></i> {{'menu.cadastros.tipos.pagamento' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="despesas">
										<i class="fa fa fa-circle-o"></i> {{'menu.cadastros.tipos.despesa' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="receitas">
										<i class="fa fa fa-circle-o"></i> {{'menu.cadastros.tipos.receita' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="subcontas">
										<i class="fa fa fa-circle-o"></i> {{'menu.cadastros.contas' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="equipamentos">
										<i class="fa fa fa-circle-o"></i> {{'menu.cadastros.tipos.equipamentos' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="fornecedores">
										<i class="fa fa fa-circle-o"></i> {{'menu.cadastros.tipos.fornecedores' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="tipoAnamnese">
										<i class="fa fa fa-circle-o"></i> Tipo de Anamnese </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="tipoBandeira">
										<i class="fa fa fa-circle-o"></i> Bandeiras </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="tipoRemuneracao">
										<i class="fa fa fa-circle-o"></i> Remunerações </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="tipoDeducao">
										<i class="fa fa fa-circle-o"></i> Deduções </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="mensagemPadrao">
										<i class="fa fa fa-circle-o"></i> Mensagens </a>
								</li>
								<li id="divTransportadora" style="display:none">
									<a class="control-menu" ui-sref="tipoTransportadora">
										<i class="fa fa fa-circle-o"></i> Transportadora </a>
								</li>
							</ul>
						</li>
						<li>
							<a ui-sref="mensagens">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.mensagem' | translate}} </a>
						</li>
						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.noticias.titulo' | translate}}
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="noticias">
										<i class="fa fa-circle-o"></i> {{'menu.cadastros.noticias.nova' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="grupos">
										<i class="fa fa-circle-o"></i> {{'menu.cadastros.noticias.grupos' | translate}} </a>
								</li>
							</ul>
						</li>
						<li>
							<a class="control-menu" ui-sref="pesquisa">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.pesquisa' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="lembretes">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.lembrete' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="estoque">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.produtos' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="clubeVantagens">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.clubecliente' | translate}}</a>
						</li>
						<li>
							<a class="control-menu" ui-sref="cupomDesconto">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.cupomdesconto' | translate}}</a>
						</li>
						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> Clubes de Assinatura
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="assinaturas">
										<i class="fa fa-circle-o"></i> Planos de Assinatura</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="assinantes">
										<i class="fa fa-circle-o"></i> Assinantes </a>
								</li>
							</ul>
						</li>
						
					</ul>
				</li>
				
				<li class="treeview">
					<a class="pointer" data-step="2" data-intro="Abra comandas manualmente ou verifique as comandas abertas automáticas pelo agendamento.">
						<i class="fa fa-list-alt"></i>
						<span>{{'menu.comandas.titulo' | translate}}</span>
						<i class="fa fa-angle-left pull-right"></i>
					</a>
					<ul class="treeview-menu">
						<li>
							<a class="control-menu" ui-sref="comandasAbertas">
								<i class="fa fa-angle-double-right"></i> {{'menu.comandas.abertas' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="comandasHistorico">
								<i class="fa fa-angle-double-right"></i> {{'menu.comandas.historico' | translate}} </a>
						</li>
					</ul>
				</li>
				
				<li class="treeview">
					<a class="pointer" data-step="3" data-intro="Abra caixa do dias, controle as comissões de seu profissional e o estoque de seu estabelecimento.">
						<i class="fa fa-dollar"></i>
						<span>{{'menu.financeiro.titulo' | translate}}</span>
						<i class="fa fa-angle-left pull-right"></i>
					</a>
					<ul class="treeview-menu">
						<li>
							<a class="control-menu" ui-sref="caixa">
								<i class="fa fa-angle-double-right"></i> {{'menu.financeiro.caixa' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="relCaixa">
								<i class="fa fa-angle-double-right"></i> {{'menu.financeiro.historico' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="movCaixa">
								<i class="fa fa-angle-double-right"></i> {{'menu.financeiro.entradasaida' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="comissaoProf">
								<i class="fa fa-angle-double-right"></i> {{'menu.financeiro.comissoes' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="contaCliente">
								<i class="fa fa-angle-double-right"></i> {{'menu.financeiro.contadocliente' | translate}}</a>
						</li>
						<li>
							<a class="control-menu" ui-sref="estoque">
								<i class="fa fa-angle-double-right"></i> {{'menu.financeiro.estoque' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="painelFinanceiro">
								<i class="fa fa-angle-double-right"></i> Fluxo de Caixa </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="contaProfissional">
								<i class="fa fa-angle-double-right"></i> {{'menu.financeiro.contadoprofissional' | translate}} </a>
						</li>
						<li id="itemMenuCaixinha">
							<a class="control-menu" ui-sref="caixinhaProfissionais">
								<i class="fa fa-angle-double-right"></i> Caixinha dos Profissionais</a>
						</li>
											</ul>
				</li>
				
				<li class="treeview">
					<a class="pointer" data-step="4" data-intro="Verifique o que está acontecendo com o seu estabelecimento com os relatórios gerenciais.">
						<i class="fa fa-bar-chart-o"></i>
						<span>{{'menu.relatorios.titulo' | translate}}</span>
						<i class="fa fa-angle-left pull-right"></i>
					</a>
					<ul class="treeview-menu">
						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> {{'menu.relatorios.agendamentos.titulo' | translate}}
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="relAgendameto">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.agendamentos.geral' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relClientes">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.agendamentos.clientes' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relProfissionais">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.agendamentos.profissionais' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relDiasSemVir">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.agendamentos.informacoes' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relRecorrente">
										<i class="fa fa-circle-o"></i> Recorrentes</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relAgendamentosAssinaturas">
										<i class="fa fa-circle-o"></i> Assinaturas</a>
								</li>
							</ul>
						</li>
						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> {{'menu.relatorios.gerencial.titulo' | translate}}
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="relGerencialAgendamentos">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.gerencial.agendamentos' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialPerfil">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.gerencial.perfilcliente' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialFinanceiro">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.gerencial.financeiro' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialComandas">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.gerencial.comandascanceladas' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialComandasItens">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.gerencial.comandasitens' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialEstoque">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.gerencial.estoque' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialPacotes">
										<i class="fa fa-circle-o"></i> {{'menu.relatorios.gerencial.pacotes' | translate}}</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialRankings">
										<i class="fa fa-circle-o"></i> Rankings</a>
								</li> 
								<li id="emissoesItemMenu">
									<a class="control-menu" ui-sref="emissoes">
										<i class="fa fa-circle-o"></i> Emissões</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relGerencialAssinaturas">
										<i class="fa fa-circle-o"></i> Assinaturas</a>
								</li>

							</ul>
						</li>
						<li>
							<a class="control-menu" ui-sref="relFidelidade">
								<i class="fa fa-angle-double-right"></i> {{'menu.relatorios.programafidelidade' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="relRetorno">
								<i class="fa fa-angle-double-right"></i> {{'menu.cadastros.clientes' | translate}}</a>
						</li>
						<li>
							<a class="control-menu" ui-sref="relResumo">
								<i class="fa fa-angle-double-right"></i> {{'menu.relatorios.resumo' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="relAniversariantes">
								<i class="fa fa-angle-double-right"></i> Aniversariantes </a>
						</li>
					</ul>
				</li>

				
				<li class="treeview">
					<a class="pointer" data-step="5" data-intro="Configure alguns parâmetros de controle, rodízio de profissionais, etc.">
						<i class="fa fa-gear"></i>
						<span>{{'menu.configuracoes.titulo' | translate}}</span>
						<i class="fa fa-angle-left pull-right"></i>
					</a>
					<ul class="treeview-menu">
						<li>
							<a class="control-menu" ui-sref="parametros">
								<i class="fa fa-angle-double-right"></i> {{'menu.configuracoes.parametros' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="rodizio">
								<i class="fa fa-angle-double-right"></i> {{'menu.configuracoes.rodizio' | translate}} </a>
						</li>

						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> {{'menu.configuracoes.filadeespera.titulo' | translate}}
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="fila">
										<i class="fa fa-circle-o"></i> {{'menu.configuracoes.filadeespera.fila' | translate}} </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="relFila">
										<i class="fa fa-circle-o"></i> {{'menu.configuracoes.filadeespera.historico' | translate}} </a>
								</li>
							</ul>
						</li>
						<li>
							<a class="control-menu" ui-sref="listaEspera">
								<i class="fa fa-angle-double-right"></i> {{'menu.configuracoes.listadeespera' | translate}} </a>
						</li>

						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> Anamnese
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="cadastroFormulario">
										<i class="fa fa-circle-o"></i> Formulários </a>
								</li>
								<li>
									<a class="control-menu" ui-sref="anamnese">
										<i class="fa fa-circle-o"></i> Clientes </a>
								</li>
							</ul>
						</li>

						<li>
							<a class="pointer">
								<i class="fa fa-angle-double-right"></i> Documentos
								<i class="fa fa-angle-left pull-right"></i>
							</a>
							<ul class="treeview-menu">
								<li>
									<a class="control-menu" ui-sref="documentos">
										<i class="fa fa-circle-o"></i> Meus Documentos</a>
								</li>
								<li>
									<a class="control-menu" ui-sref="clientedocumento">
										<i class="fa fa-circle-o"></i> Clientes </a>
								</li> 
								<li>
									<a class="control-menu" ui-sref="profissionaldocumento">
										<i class="fa fa-circle-o"></i> Profissionais </a>
								</li> 
							</ul>
						</li>
						
						<li>
							<a class="control-menu" ui-sref="preferenciasLocais">
								<i class="fa fa-angle-double-right"></i> Preferências Locais </a>
						</li>
												<li>
							<a class="control-menu" ui-sref="avaliacoes">
								<i class="fa fa-angle-double-right"></i> Avaliações </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="restricaoCliente">
								<i class="fa fa-angle-double-right"></i> Lista de Restrições </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="funcionamentoEmpresa">
								<i class="fa fa-angle-double-right"></i> Funcionamento </a>
						</li>
						<li>
							<a class="control-menu" ui-sref="alertaEmpresa">
								<i class="fa fa-angle-double-right"></i> Alertas </a>
						</li>
					</ul>
				</li>

								<li>
					<a class="control-menu" ui-sref="tutoriais">
						<i class="fa fa-video-camera"></i>
						<span>Videos Tutoriais</span>
					</a>
				</li>
								<li class="treeview">
					<a class="pointer">
						<i class="fa fa-question"></i>
						<span>{{'menu.ajuda.titulo' | translate}}</span>
						<i class="fa fa-angle-left pull-right"></i>
					</a>
					<ul class="treeview-menu">
<!-- 						
						<li>
							<a class="control-menu" ui-sref="divulgacao">
								<i class="fa fa-angle-double-right"></i> {{'menu.ajuda.divulgacao' | translate}} </a>
						</li> -->
						
						<li>
							<a class="control-menu pointer" data-toggle="modal" data-target="#primeiroAcesso-modal">
								<i class="fa fa-angle-double-right"></i> {{'menu.ajuda.oquefazer' | translate}} </a>
						</li>
						<li>
							<a class="control-menu" href="https://appbarber-appbeleza.zendesk.com/hc/pt-br" target="_blank">
								<i class="fa fa-angle-double-right"></i> {{'menu.ajuda.faq' | translate}} </a>
						</li>
												<li>
							<a href=" https://appbeleza.com.br/termodeuso " target="_blank">
								<i class="fa fa-angle-double-right"></i> {{'menu.ajuda.termodeuso' | translate}} </a>
						</li>

						<li>
							<a href=" https://www.instagram.com/appbeleza_/ " target="_blank">
								<i class="fa fa-instagram"></i> Instagram </a>
						</li>

						<li>
							<a href=" https://blog.appbeleza.com.br/ " target="_blank">
								<i class="fa fa-book"></i> Blog </a>
						</li>

						<li>
							<a href=" https://www.youtube.com/@appbelezagestaoonline2978 " target="_blank">
								<i class="fa fa-youtube"></i> Youtube </a>
						</li>
						

					</ul>
				</li>
				<li>
					<a class="control-menu" ui-sref="divulgacao">
					<i class="fa fa-rocket"></i>Imagens de Divulgação </a>
						
				</li>
				
						</ul>
	</section>
</aside>

                <aside class="content-wrapper" ui-view> </aside>

                <aside class="control-sidebar control-sidebar-dark">
                    <div class="tab-content">
                        <div class="tab-pane" id="control-sidebar-home-tab"></div>
                    </div>
                </aside>

                <div class="control-sidebar-bg"></div>

                
                <div class="caixa-side hidden-xs" id="caixaSide">
                    <div class="btn-caixa" id='btn-caixa_busca'>
                        <div class="row vertical-text"> <label>Caixa &nbsp<i id="iconCaixa" class="fa fa-exclamation"></i></label> </div>
                    </div>
                    <div class="row">
                        <div class="box box-solid box-caixa boxCaixa" id="boxCaixa">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="box box-success box-solid">
                                            <div class="box-header with-border">
                                                <input type="hidden" name="caxCodigo" id="caxCodigo" class="form-control caxCodigo">
                                                <input type="hidden" name="caxDescricao" id="caxDescricao" class="form-control caxDescricao">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h5>Usuário: <label class="lblNome"></label></h5>
                                                        <p>
                                                            <h5>Data Inicio: <label class="lblData"></label>&nbsp&nbsp<button type="button" name="button" class="btn bg-teal-dark btn-xs btnEdtCaixa" ng-click="editaDataCaixaModal()"><i class="fa fa-pencil"></i></button></h5>
                                                        </p>
                                                        <p>
                                                            <h5>Valor Inicial: <label class="lblValorInicial"></label>&nbsp&nbsp<button type="button" name="button" class="btn bg-teal-dark btn-xs btnEdtCaixa" ng-click="editaCaixaModal()"><i class="fa fa-pencil"></i></button></h5>
                                                        </p>
                                                    </div>
                                                    <div class="col-md-6 " align="right">
                                                      &nbsp&nbsp<button type="button" name="button" class="btn bg-teal-dark btn-sm" ng-click="buscaCaixaAberto()" id="btnVerCaixaAbertoGestor"><i class="fa fa-list"></i> Ver mais caixas</button>                                                         <a class="btn btn-sm btn-primary " id="btnFecharCaixa" ng-click="btnfecharcaixa()">
                                                            <i class="fa fa-check"></i> Encerrar Caixa
                                                        </a>
                                                        <p>
                                                            <div class="btn-group ">
                                                                <div class='btn-group '>
                                                                    <button type='button' class='btn btn-sm bg-purple dropdown-toggle' data-toggle='dropdown' aria-expanded='false'>
                                                                        <i class='fa fa-print'></i>
                                                                        <span class='fa fa-caret-down'></span>
                                                                    </button>
                                                                    <ul class='dropdown-menu ' style="color:black;min-width:auto !important;" align="left">
                                                                        <li><a class='pointer' id="btnImprimecaixa" style="color:black;"> A4</a></li>
                                                                        <li><a class='pointer' id="btnImprimecaixanaofiscal" style="color:black;">Não-Fiscal</a></li>
                                                                    </ul>
                                                                </div>
                                                                <a class=" btn btn-sm bg-purple" target="blank" href="https://appbarber-appbeleza.zendesk.com/hc/pt-br/articles/360002607332-Como-funciona-o-Caixa-"><i class="fa fa-question-circle"></i></a>
                                                                <a type="button" id="btnAtualizaCaixa" class="btn btn-sm bg-purple"><i class="fa fa-refresh"></i></a>
                                                            </div>
                                                        </p>
                                                        <input type="hidden" id="FCaCodigoCaixa">
                                                        <a class="btn btn-sm btn-warning caixaVerDia" ng-click="verDiaCaixa()">
                                                            <i class="fa fa-book"></i> Ver Dia
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="box-body">
                                                <table id="boxMovCaixa" data-height="200" data-search-accent-neutralise="true" class="table-sm"></table>
                                            </div>
                                            <div class="overlay divLoader" id="divLoader">
                                                <i class="fa fa-circle-o-notch fa-spin"></i>
                                            </div>
                                            <div class="box-footer">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-3 col-md-12">
                                                            <div class="row" style="margin-bottom:5px">
                                                                <button type="button" class="btn btn-sm btn-success btn-block" ng-click="buscaReceita()" data-toggle="modal" data-target="#entradaCaixa-modal"><i class="fa fa-arrow-up"></i> Entrada</button>
                                                            </div>
                                                            <div class="row" style="margin-bottom:5px">
                                                                <button type="button" class="btn btn-sm btn-danger btn-block" ng-click="buscaDespesa()" data-toggle="modal" data-target="#saidaCaixa-modal"><i class="fa fa-arrow-down"></i> Saída</button>
                                                            </div>
                                                            <div class="row" style="margin-bottom:5px">
                                                                <button id="buttonAbreNovaComanda" type="button" class="btn btn-sm bg-teal-dark btn-block" data-toggle="modal" data-target="#cadastrarComanda-modal"><i class="fa fa-plus"></i> Comanda</button>
                                                            </div>
                                                            <div class="row">
                                                                <button id="buttonCallVale" type="button" class="btn btn-sm btn-warning btn-block" data-toggle="modal" data-target="#cadastraVale-modal" ng-click="setDestinoVale(1)"><i class="fa fa-user"></i> Vale</button>
                                                            </div>
                                                            <br><br>
                                                        </div>
                                                        <div class="col-md-9 col-md-12" align="right" style="max-height:100px;overflow-y:scroll;">
                                                            <table class="divTotalizador table table-condensed table-striped" name="divTotalizador" align="right"></table>
                                                        </div>
                                                        <h4 class="text-center"> Saldo: <label class="lblTotalCaixa"></label><br><button class="btn btn-xs text-center" id="botaocaixa" data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="left" class="fa fa-question-circle" style="color:grey" data-content="" data-html="true">Detalhes</button></h4>
                                                    </div>
                                                    <div class="row" align="center"></div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="semCaixa" class="box-caixa box box-solid semCaixa" style="padding:10px;">
                            <div class="row">
                                <div class="col-md-12" align="center">
                                    <a class="btn btn-primary" data-toggle="modal" ng-click="buscaSugestaoCaixa()" data-target="#cadastrarCaixa-modal">
                                        <i class="fa fa-plus"></i> Abrir Caixa
                                    </a>
                                </div>
                            </div>
                            <br>
                            <div class="callout callout-danger">
                                <h4>Não há nenhum caixa aberto!</h4>
                                <p>Clique no botão acima para abrir um novo caixa.</p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="nps-bottom hidden-xs box box-success" id="nps-bottom">
                    <div class="box-header text-center">

                                                <h3 class="box-title">Em uma escala de 0 a 10, o quanto você indicaria o AppBeleza para um amigo ou colega?</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool btnRemoveNPS"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div id="semCaixa" class="box-nps">
                                <br>                                
                                <div class="buttons-nps row">
                                    <div class="col-md-12 text-center">
                                        <div class="btn-group">
                                            <button class="btn btn-lg margin btn-nps bg-nps0" onclick="sendNps(0);" type="button">0</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps1" onclick="sendNps(1);" type="button">1</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps2" onclick="sendNps(2);" type="button">2</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps3" onclick="sendNps(3);" type="button">3</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps4" onclick="sendNps(4);" type="button">4</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps5" onclick="sendNps(5);" type="button">5</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps6" onclick="sendNps(6);" type="button">6</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps7" onclick="sendNps(7);" type="button">7</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps8" onclick="sendNps(8);" type="button">8</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps9" onclick="sendNps(9);" type="button">9</button>
                                            <button class="btn btn-lg margin btn-nps bg-nps10" onclick="sendNps(10);" type="button">10</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade" id="cadastrarComanda-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title"><i class="fa fa-barcode"></i> Nova Comanda </h4>
                            </div>

                            <form id="formCadastroComanda">
                                <div class="modal-body">
                                    <div class="box-body">
                                        <div class="box box-primary">

                                            <div class="box-header" data-toggle="tooltip"></div>

                                            <div class="box-body">
                                                <div class="row">
                                                    <!-- <div class="col-md-12">
                                                        <div class="form-group ">
                                                            <label>Tipo:</label>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <input type="radio" id="comTipoManual0" name="comTipoManual" value="0" ng-click="buscaTipoInsercao()" checked="true">&nbsp&nbspCliente</input>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <input type="radio" id="comTipoManual1" name="comTipoManual" value="1" ng-click="buscaTipoInsercao()">&nbsp&nbspProfissional</input>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div> -->


                                                    <div class="col-md-12">
                                                        <div class="form-group ">
                                                            <label>Tipo:</label>
                                                            <select name="comTipoManual" id="comTipoManual" class="form-control">
                                                                <option value="0">Cliente (Atendimento/Venda)</option>
                                                                <option value="1">Consumo de Profissional</option>
                                                            </select>
                                                            <!-- <div class="row">
                                                                <div class="col-md-12">
                                                                    <input type="radio" id="comTipoManual0" name="comTipoManual" value="0" ng-click="buscaTipoInsercao()" checked="true">&nbsp&nbspCliente</input>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <input type="radio" id="comTipoManual1" name="comTipoManual" value="1" ng-click="buscaTipoInsercao()">&nbsp&nbspProfissional</input>
                                                                </div>
                                                            </div> -->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row" id="divClienteCadastroComanda">
                                                    <div class="col-md-12 col-sm-12">
                                                        <div class="form-group">
                                                            <label id="lblCliente">Cliente:</label>
                                                            <div class="input-group">
                                                                <select class="form-control select2" id="comCliente" name="comCliente" style="width: 100%">
                                                                    <option value="0">Sem Cadastro</option>
                                                                </select>
                                                                <span class="input-group-btn">
                                                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#cadastrarClienteComanda-modal"><i class="fa fa-plus"></i> Novo</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="divProfissionalCadastroComanda">
                                                    <div class="row">
                                                        <div class="col-md-12 col-sm-12">
                                                            <div class="form-group">
                                                                <label id="lblProfissional">Profissional:</label>
                                                                <br>
                                                                <select class="form-control select2" id="comProfissional" name="comProfissional" style="width: 100%"></select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-8 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Data da Comanda</label>
                                                            <div class="input-group date DataComandaAbre">
                                                                <div class="input-group-addon"> <i class="fa fa-calendar"></i></div>
                                                                <input type="text" name="comandaAbreData" id="comandaAbreData" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Hora*</label>
                                                            <select name="comandaAbreHora" id="horaComandaInicio" class="input-large form-control select2" style="width:100%;">
                                                                
                                                                ﻿<option value='00:00'>00:00</option><option value='00:15'>00:15</option><option value='00:30'>00:30</option><option value='00:45'>00:45</option><option value='01:00'>01:00</option><option value='01:15'>01:15</option><option value='01:30'>01:30</option><option value='01:45'>01:45</option><option value='02:00'>02:00</option><option value='02:15'>02:15</option><option value='02:30'>02:30</option><option value='02:45'>02:45</option><option value='03:00'>03:00</option><option value='03:15'>03:15</option><option value='03:30'>03:30</option><option value='03:45'>03:45</option><option value='04:00'>04:00</option><option value='04:15'>04:15</option><option value='04:30'>04:30</option><option value='04:45'>04:45</option><option value='05:00'>05:00</option><option value='05:15'>05:15</option><option value='05:30'>05:30</option><option value='05:45'>05:45</option><option value='06:00'>06:00</option><option value='06:15'>06:15</option><option value='06:30'>06:30</option><option value='06:45'>06:45</option><option value='07:00'>07:00</option><option value='07:15'>07:15</option><option value='07:30'>07:30</option><option value='07:45'>07:45</option><option value='08:00'>08:00</option><option value='08:15'>08:15</option><option value='08:30'>08:30</option><option value='08:45'>08:45</option><option value='09:00'>09:00</option><option value='09:15'>09:15</option><option value='09:30'>09:30</option><option value='09:45'>09:45</option><option value='10:00'>10:00</option><option value='10:15'>10:15</option><option value='10:30'>10:30</option><option value='10:45'>10:45</option><option value='11:00'>11:00</option><option value='11:15'>11:15</option><option value='11:30'>11:30</option><option value='11:45'>11:45</option><option value='12:00'>12:00</option><option value='12:15'>12:15</option><option value='12:30'>12:30</option><option value='12:45'>12:45</option><option value='13:00'>13:00</option><option value='13:15'>13:15</option><option value='13:30'>13:30</option><option value='13:45'>13:45</option><option value='14:00'>14:00</option><option value='14:15'>14:15</option><option value='14:30'>14:30</option><option value='14:45'>14:45</option><option value='15:00'>15:00</option><option value='15:15'>15:15</option><option value='15:30'>15:30</option><option value='15:45'>15:45</option><option value='16:00'>16:00</option><option value='16:15'>16:15</option><option value='16:30'>16:30</option><option value='16:45'>16:45</option><option value='17:00'>17:00</option><option value='17:15'>17:15</option><option value='17:30'>17:30</option><option value='17:45'>17:45</option><option value='18:00'>18:00</option><option value='18:15'>18:15</option><option value='18:30'>18:30</option><option value='18:45'>18:45</option><option value='19:00'>19:00</option><option value='19:15'>19:15</option><option value='19:30'>19:30</option><option value='19:45'>19:45</option><option value='20:00'>20:00</option><option value='20:15'>20:15</option><option value='20:30'>20:30</option><option value='20:45'>20:45</option><option value='21:00'>21:00</option><option value='21:15'>21:15</option><option value='21:30'>21:30</option><option value='21:45'>21:45</option><option value='22:00'>22:00</option><option value='22:15'>22:15</option><option value='22:30'>22:30</option><option value='22:45'>22:45</option><option value='23:00'>23:00</option><option value='23:15'>23:15</option><option value='23:30'>23:30</option><option value='23:45'>23:45</option><option value='00:00'>00:00</option>                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Observação</label>
                                                            <textarea class="form-control" name="comObs" id="comObs"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12 col-sm-12">
                                                        <div class="form-group">
                                                            <label>N˚ Cartão</label>
                                                            <input type="text" class="form-control" name="comNumCartao" id="comNumCartao" placeholder="Número do Cartão de Controle do seu Estabelecimento"></input>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="box-footer">
                                                <button type="submit" class="btn btn-success">Abrir Comanda</button>
                                                <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="editaCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-starapp-30">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title"><i class="fa fa-pencil"></i> Editar Caixa </h4>
                            </div>

                            <div class="modal-body">
                                <div class="box-body">
                                    <div class="box box-success">
                                        <div class="box-header">
                                            <h3 class="box-title"></h3>
                                        </div>
                                        <div class="box-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group ">
                                                        <label>Valor Inicial</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon" id="moedaCaixa">R$</span>
                                                            <input type="text" min="0.00" step="0.01" max="2500" name="valorInicialCaixaEdt" onkeyup="formataValorDinheiro(this);" id="valorInicialCaixaEdt" class="form-control" placeholder="Valor Inicial">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                        <button type="button" class="btn btn-success" ng-click="editaCaixa()">Salvar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="editaDataCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-starapp-30">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title"><i class="fa fa-pencil"></i> Editar Caixa </h4>
                            </div>

                            <div class="modal-body">
                                <div class="box-body">
                                    <div class="box box-success">
                                        <div class="box-header">
                                            <h3 class="box-title"></h3>
                                        </div>
                                        <div class="box-body">
                                            <div class="row">
                                                <div class="col-lg-12 col-xs-12">
                                                    <div class="form-group">
                                                        <label>Data Inicial:*</label>
                                                        <div class="input-group date divData">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-calendar"></i>
                                                            </div>
                                                            <input type="text" id="DataCaixaEdt" name="DataCaixaEdt" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="box-footer">
                                    <button type="button" class="btn btn-success" ng-click="editaCaixaData()">Salvar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="printCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="box-body">
                                <div id="printCaixa">
                                    <table class="print">
                                        <thead>
                                            <tr></tr>
                                            <tr>
                                                <th id="thLogoEmpresa"></th>
                                                <th colspan="2">
                                                    Usuário:
                                                    <label id='lblNomePrint'></label>
                                                    <br> Data:
                                                    <label id='lblDataPrint'></label>
                                                    <br> Valor Inicial:
                                                    <label id='lblValorInicialPrint'></label>
                                                    <br>
                                                </th>
                                            </tr>
                                            <tr>
                                                <th colspan="3" style="text-align:center;">
                                                    <hr> Movimentações
                                                </th>
                                            </tr>
                                        </thead>
                                        <br>
                                        <tbody id="tbPrintCaixa" aling="right"></tbody>
                                        <tr>
                                            <td colspan="3" id="divTotalizadorImprime" name="divTotalizadorImprime"></td>
                                            <hr>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                                <label>Produtos:
                                                    <span id="totalProdutoImprime"></span>- *
                                                    <span id="totalProdutoImprimeNp"></span>
                                                </label>
                                                <br>
                                                <label>Serviço:
                                                    <span id="totalServicoImprime"></span>- *
                                                    <span id="totalServicoImprimeNp">
                                                </label>
                                                <br>
                                                <label>Outros:
                                                    <span id="totalOutrosImprime"></span>
                                                </label>
                                                <br> *
                                                <small> - Valores sem o cálculo de proporcionalidade</small>
                                            </td>
                                        </tr>
                                        <tfoot>
                                            <tr>
                                                <td colspan="3">
                                                    <strong>Saldo:
                                                        <label id='lblTotalCaixaPrint'></label>
                                                    </strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3">
                                                    <small>Saldo Disponível:
                                                        <label id='lblTotalCaixaDispPrint'></label>
                                                    </small>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3">
                                                    <small>Total de Recebimentos:
                                                        <label id='lblTotalCaixaRecePrint'></label>
                                                    </small>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                            <div class="loaderMsg">
                    <div class="divLoaderMsg">
                        <div style="margin-left:15%; margin-top:15px;">
                            <label style="color:white;" id="introTitulo"><i class="fa fa-spinner fa-spin"></i> Carregando...</label>
                            <h4 style="color:white;font-family: 'Ubuntu', serif;" id="introMensagem"> A melhor maneira de aprender seja o que for, é fazendo. </h4>
                        </div>
                    </div>
                </div>
                       
            </div>
            <script>var intervalCaixa;var hasManyClients=false;var totalClients=0;var version=740;var hasNps=true;var nps='';var showNps=false;</script>

            <div class="modal fade" id="bloqueioHorario-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-plus-square-o"></i> Bloquear/Desbloquear horário
                    <i data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Bloquear horários quando não houver expediente por demais motivos (ex.: férias, reuniões, etc.)."></i>
                </h4>
            </div>
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a data-target="#tabBloquear" data-toggle="tab">Bloquear Horário</a></li>
                    <li><a data-target="#tabDesbloquear" data-toggle="tab">Desbloquear Horário</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tabBloquear">
                        <form id="formHorarioBloqueadoModal" action="#" method="POST">
                            <div class="modal-body">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="form-group">
                                                <label>Dia Inicio:</label>
                                                <div class="input-group date">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input type="text" id="edtDataBloqueadoModal" name="edtDataBloqueadoModal" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                    <input type="hidden" id="edtData2BloqueadoModal"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="bootstrap-timepicker">
                                                <div class="form-group">
                                                    <label>Hora Início:</label>
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-clock-o"></i>
                                                        </div>
                                                        <input type="text" id="edtHoraIniBloqueadoModal" name="edtHoraIniBloqueadoModal" class="form-control timepicker"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="form-group">
                                                <label>Dia Fim:</label>
                                                <div class="input-group date">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input type="text" id="edtDataFimBloqueadoModal" name="edtDataFimBloqueadoModal" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                    <input type="hidden" id="edtDataFim2BloqueadoModal"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="bootstrap-timepicker">
                                                <div class="form-group">
                                                    <label>Hora Fim:</label>
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-clock-o"></i>
                                                        </div>
                                                        <input type="text" id="edtHoraFimBloqueadoModal" name="edtHoraFimBloqueadoModal" class="form-control timepicker"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label id="lblProfissionalBloqueado">Profissional:</label>
                                        <select class="form-control" id="edtProfissionalBloqueadoModal">
                                            <option value="25899314">Gustavo Bezerra</option>                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Observações</label>
                                        <textarea class="form-control" rows="3" id="txtObsBloqueadoModal"></textarea>
                                    </div>
                                </div>
                                <div class="box-footer">
                                    <button type="button" id="btnInserirBloqueadoModal" class="btn btn-primary">Bloquear</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="tabDesbloquear">
                        <form id="formHorarioDesbloquear" action="#" method="POST">
                            <div class="modal-body">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="form-group">
                                                <label>Dia Inicio:</label>
                                                <div class="input-group date">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input type="text" id="edtDataDesbloquear" name="edtDataDesbloquear" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                    <input type="hidden" id="edtData2Desbloquear"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="bootstrap-timepicker">
                                                <div class="form-group">
                                                    <label>Hora Início:</label>
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-clock-o"></i>
                                                        </div>
                                                        <input type="text" id="edtHoraIniDesbloquear" name="edtHoraIniDesbloquear" class="form-control timepicker"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="form-group">
                                                <label>Dia Fim:</label>
                                                <div class="input-group date">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input type="text" id="edtDataFimDesbloquear" name="edtDataFimDesbloquear" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                                    <input type="hidden" id="edtDataFim2Desbloquear"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xs-6">
                                            <div class="bootstrap-timepicker">
                                                <div class="form-group">
                                                    <label>Hora Fim:</label>
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-clock-o"></i>
                                                        </div>
                                                        <input type="text" id="edtHoraFimDesbloquear" name="edtHoraFimDesbloquear" class="form-control timepicker"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label id="lblProfissionalDesbloquear">Profissional:</label>
                                        <select class="form-control" id="edtProfissionalDesbloquear">
                                            <option value="25899314">Gustavo Bezerra</option>                                        </select>
                                    </div>

                                </div>
                                <div class="box-footer">
                                    <button type="button" id="btnInserirDesbloquear" class="btn btn-primary">Desbloquear</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="infoCliente-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:9999;">
    <div class="modal-dialog modal-starapp-75">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i> {{'clientes.informacoes_cliente' | translate
                    }} </h4>

            </div>


                        <!-- ---------------------------- -->
                        <div class="nav nav-tabs-custom " id="allowInfoCli">
                <ul class="nav nav-tabs ">
                    <li class=""><a data-toggle="tab" data-target="#tab_1">{{'informacoes_pessoais' | translate
                                        }}</a></li>
                    <li class="active"><a data-toggle="tab" data-target="#tab_2">{{'dashboard' | translate }}</a></li>
                    <li class=""><a data-toggle="tab" data-target="#tab_3">{{'historico_agendamento' | translate }}</a>
                    </li>
                    <li class=""><a data-toggle="tab" data-target="#tab_4">{{'historico_comanda' | translate }}</a></li>
                    <li class=""><a data-toggle="tab" data-target="#tab_5">{{'pacotes' | translate }}</a></li>
                    <li class=""><a data-toggle="tab" data-target="#tab_6">{{'prontuario' | translate }}</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane " id="tab_1">
                        <input type="hidden" name="cliCodigoInfo" id="cliCodigoInfo" class="form-control"/>
                        <label id="cliCodigoInfo"></label>
                        <input type="hidden" name="cliPesCodigoInfo" id="cliPesCodigoInfo" class="form-control"/>
                        <div class="col-md-12">
                            <div class="box box-widget widget-user">
                                <div class="widget-user-header bg-green">
                                    <div class="widget-user-image">
                                        <img class="img-circle" src="/img/130x130xnopicture.png.pagespeed.ic.-eH2kBEHSC.webp" id="cliImagemInfo" style="width:130px;height:130px;margin-right:30px;" data-pagespeed-url-hash="3894603355" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/>
                                    </div>
                                    <h3 class="widget-user-username" id="cliNomeInfo"></h3>
                                    <button class="btn btn-success btn-sm pull-right" ng-click="geraComandaInfo()">+Abrir
                                        comanda</button>
                                    <h5 class="widget-user-desc" id="cliEmailInfo"></h5>
                                    <div id="divBtnLGPD">
                                    </div>
                                    <br><br>

                                </div>
                                <div class="box-footer">
                                    <button class="btn btn-success btn-xs btnAlteracaoCliente" ng-click="editarClienteInfo()"><i class="fa fa-pencil"></i> Editar</button>
                                    <button class="btn btn-danger btn-xs btnAlteracaoCliente" ng-click="removeClienteInfo()"><i class="fa fa-trash"></i> Excluir</button>
                                    <br><br>
                                    <label>{{'cpf' | translate }}: <span id="cliCpfInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'celular' | translate }}: <span id="cliCelularInfo" style="color:#00ACD6;"></span></label>&nbsp<button class="btn btn-success btn-sm" id="btnEnviaWhatsCliente"><i class="fa fa-whatsapp"></i></button><br>
                                    <label>{{'telefone' | translate }}: <span id="cliTelefoneInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'login' | translate }}: <span id="cliLoginInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'sexo.titulo' | translate }}: <span id="cliSexoInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'nascimento' | translate }}: <span id="cliDataNascimentoInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'endereco' | translate }}: <span id="cliEnderecoInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'bairro' | translate }}: <span id="cliBairroInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'cidade' | translate }}: <span id="cliCidadeInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'estado' | translate }}: <span id="cliEstadoInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'cep' | translate }}: <span id="cliCepInfo" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'data_cadastro' | translate }}: <span id="cliDatCadastro" style="color:#00ACD6;"></span></label><br>
                                    <label>{{'obs' | translate }}: <span id="cliObsInfo" style="color:#00ACD6;"></span></label><br>

                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane active" id="tab_2">

                        <div class="box-body">

                            <div class="row">

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon bg-aqua" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;"><i class="fa fa-scissors"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">{{'servico_mais_realizado' | translate }}</span>
                                            <span class="info-box-number" id='serDescricao'></span>
                                            <span class="info-box-number" id='serTotal'></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon bg-purple" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;"><i class="fa fa-shopping-cart"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">{{'produto_mais_utilizado' | translate }}</span>
                                            <span class="info-box-number" id="proNome"></span>
                                            <span class="info-box-number" id='porTotal'></span>

                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon bg-yellow" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;"><i class="fa fa-calendar-o"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">{{'dias_sem_vir' | translate }}</span>
                                            <span class="info-box-number" id="totalDias"></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon bg-green" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;"><i class="fa fa-money"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">{{'ja_gastou' | translate }}</span>
                                            <span class="info-box-number" id="totalGasto"></span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row">

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon bg-brown" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;"><i style="color:white" class="fa fa-mobile"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">Acesso</span>
                                            <span class="info-box-number" id="ultimoAcessoCliente"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;background-color:#883fa3;"><i style="color:white" class="fa fa-trophy"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">Pontos programa de fidelidade</span>
                                            <span class="info-box-number" id="pontosClientes"></span>
                                        </div>
                                        <button class="btn btn-success btn-sm" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;" ng-click="infoshowGeraToken()">Gerar Token</button>
                                        <button class="btn btn-info btn-sm" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;" ng-click="displaydetalhespontos()">Ver Movimentações</button>
                                    </div>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;background-color:#d9f442;"><i style="color:white" class="fa fa-clipboard"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">Anamnese</span>

                                            <button class="btn btn-success btn-sm" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;" ng-click="goToAnamnese()">Ver Avaliações</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;background-color:#ff66de;"><i style="color:white" class="fa fa-usd"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">Conta Do Cliente</span>
                                            <span class="info-box-number" id="saldoContaCli"></span>
                                            <button class="btn btn-success btn-sm" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;" ng-click="showDetailsContaCliente()">Detalhes</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row">

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="info-box" style="border-top-right-radius:50px; border-top-left-radius: 50px;border-bottom-right-radius:50px;background-color:#f2f2f2;">
                                        <span class="info-box-icon" style="border-bottom-right-radius:50px; border-top-left-radius: 50px;border-top-right-radius:50px;background-color:#ed4415;"><i style="color:white" class="fa fa-calendar-check-o"></i></span>

                                        <div class="info-box-content">
                                            <span class="info-box-text">Último Agendamento</span>
                                            <small class="info-box-number" id='CliAgeInicio'></small>
                                            <small class="info-box-number" id='CliLastServico'></small>
                                            <small class="info-box-number" id='CliLastProf'></small>
                                        
                                        </div>
                                    </div>
                                </div>
                          
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane" id="tab_3">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-5  col-xs-12  col-sm-12">

                                    <div class="form-group">
                                        <label>{{'data_inicio' | translate }}</label>
                                        <div class="input-group date divDataIniAge">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatInicioAge" id="cliDatInicioAge" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-5  col-xs-12  col-sm-12">

                                    <div class="form-group">
                                        <label>{{'data_fim' | translate }}</label>
                                        <div class="input-group date divDataFimAge">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatFimAge" id="cliDatFimAge" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-2  col-xs-12  col-sm-12">
                                    <label>{{'btn_buscar' | translate }}</label>
                                    <button type="button" class="btn btn-primary btn-block" id="btnCliAgendamento">{{'btn_buscar' | translate }}</button>
                                    <br>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 table-responsive">
                                    <table class="table table-bordered table-striped dataTable no-footer table-condensed hover" id="tabelaClienteAgendamento" data-source="/pages/cadastros/buscaClienteInfo.php" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>{{'servico' | translate }}</th>
                                                <th>{{'profissional' | translate }}</th>
                                                <th>{{'data' | translate }}</th>
                                                <th>{{'cadastrado_por' | translate }}</th>
                                                <th>{{'data_cadastro' | translate }}</th>
                                                <th>{{'status' | translate }}</th>
                                                <th>{{'valor' | translate }}</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_4">
                        <div class="box-body">

                            <div class="row">
                                <div class="col-md-5 col-xs-12  col-sm-12">

                                    <div class="form-group">
                                        <label>{{'data_inicio' | translate }}</label>
                                        <div class="input-group date divDataIniCom">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatInicioCom" id="cliDatInicioCom" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-5  col-xs-12  col-sm-12">

                                    <div class="form-group">
                                        <label>{{'data_fim' | translate }}</label>
                                        <div class="input-group date divDataFimCom">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatFimCom" id="cliDatFimCom" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-2  col-xs-12  col-sm-12">
                                    <label>{{'btn_buscar' | translate }}</label>
                                    <button type="button" class="btn btn-primary btn-block" id="btnCliComanda">{{'btn_buscar' | translate }}</button>
                                    <br>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 table-responsive">
                                    <table class="table table-bordered table-striped dataTable no-footer table-condensed hover" id="tabelaClienteComanda" data-source="/pages/cadastros/buscaClienteInfo.php" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>{{'comanda' | translate }}</th>
                                                <th>{{'status' | translate }}</th>
                                                <th>{{'aberta_por' | translate }}</th>
                                                <th>Valor Total</th>
                                                <th>Valor Pago</th>
                                                <th>{{'obs' | translate }}</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_5">
                        <div class="box-body">

                            <div class="row">
                                <div class="col-md-5">

                                    <div class="form-group">
                                        <label>{{'data_inicio' | translate }}</label>
                                        <div class="input-group date divDataIniCom">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatInicioPac" id="cliDatInicioPac" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-5">

                                    <div class="form-group">
                                        <label>{{'data_fim' | translate }}</label>
                                        <div class="input-group date divDataFimPac">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatFimPac" id="cliDatFimPac" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-2 ">
                                    <label>{{'btn_buscar' | translate }}</label>
                                    <button type="button" class="btn btn-primary btn-block" id="btnCliPacote">{{'btn_buscar' |
                                                    translate }}</button>
                                    <br>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 table-responsive">

                                    <table class="table table-bordered table-striped dataTable no-footer table-condensed hover" id="tabelaClientePacotes" data-source="/pages/cadastros/buscaClienteInfo.php" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th style="width:50%">{{'pacote' | translate }}</th>
                                                <th>{{'data_compra' | translate }}</th>
                                                <th>{{'utilizado' | translate }}</th>
                                                <th>{{'valor' | translate }}</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_6">
                        <div class="box-body">
                            <div class="row">
                                <input type="hidden" id="pescodigoProntuario">
                                <div class="col-md-5">

                                    <div class="form-group">
                                        <label>{{'data_inicio' | translate }}</label>
                                        <div class="input-group date divDataIniPron">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatInicioPron" id="cliDatInicioPron" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-5">

                                    <div class="form-group">
                                        <label>{{'data_fim' | translate }}</label>
                                        <div class="input-group date divDataFimPron">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="cliDatFimPron" id="cliDatFimPron" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-2 pull-right">
                                    <button type="button" class="btn btn-warning btn-block" id="btnLimpaDataPron" ng-click="limpaDataPront()" style="margin-top:25px;">Limpar Datas</button>
                                    <br>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="ser">Serviço</label>
                                        <select name="servicoPront" id="servicoPront" class="form-control"></select>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="pro">Profissional</label>
                                        <select name="profPront" id="profPront" class="form-control"></select>
                                    </div>
                                </div>
                                <div class="col-md-2 pull-right">
                                    <button type="button" class="btn btn-primary btn-block" id="btnCliPron" ng-click="runBuscaProntuarioCliente()" style="margin-top:25px;"><i class="fa fa-search"></i>{{'btn_buscar' | translate }}</button>
                                    <br>
                                </div>
                            </div>


                            <div class="col-md-12 table-responsive">

                                <table class="table table-bordered table-striped  table-condensed hover" style="width:100%" id="tableProntuario">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>{{'data' | translate }}</th>
                                            <th>{{'servico' | translate }}</th>
                                            <th style="display: none;"></th>
                                            <th>{{'profissional' | translate }}</th>
                                            <th style="width:16%;"></th>
                                            <th style="width:16%;"></th>
                                            <th style="display: none;"></th>
                                            <th style="display: none;"></th>
                                            <th style="display: none;"></th>
                                            <th style="display: none;"></th>

                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_7">
                        <div class="box-body">
                            <div class="col-md-12">

                                <table class="table table-bordered table-striped dataTable no-footer table-condensed hover" style="width:100%" id="tableCliPontos">
                                    <thead>
                                        <tr>
                                            <th>{{'nome' | translate }}</th>
                                            <th>{{'pontos' | translate }}</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

                        <!-- ---------------------------- -->
        </div>
    </div>
</div>

<div class="modal fade" id="infoPacotePessoaDetalhes-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:99999;">
    <div class="modal-dialog  modal-starapp-80">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="small-box bg-teal-dark">
                    <div class="inner">
                        <h4 id="pacdescricao"></h4>
                        <p>Data de Compra: <label id="pacdatcadastro"></label></p>
                        <div class="progress active" style="width:90%">
                            <div class="progress-bar progress-bar-warning progress-bar-striped" id="progPacote" role="progressbar" style="width:100%">
                                <label id="qtdConsumo"></label> de <label id="qtdTotal"></label> Utilizados
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <label>Itens do Pacote</label>
                                <button class="btn btn-primary btn-xs" id="changeCaret" type="button" data-toggle="collapse" data-target="#showPacItens" aria-expanded="false" aria-controls="showPacItens">
                                    <i class="fa fa-caret-down" id="iconCaret"></i>
                                </button>
                                <div class="collapse" id="showPacItens">
                                    <div class="card card-body">
                                        <div id="itensPacoteMostrar">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="icon">
                        <i class="fa fa-gift"></i>
                    </div>
                </div>
                <hr>
                <ul class="timeline" id="timelinePacote"></ul>
            </div>
        </div>
    </div>
</div>

<div class="modal fade appblz-modal-lg" id="comanda-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" id="dialog-comanda-modal">
        <section class="invoice" id="printInvoice">
            <div class="row">
                <div class="col-lg-2 visible-lg">
                    <div class="image" align="center">
                        <img src="/img/120x120xicone.png.pagespeed.ic.lPC7AT_RoP.webp" width="120" height="120" class="img-rounded image" alt="Logo" data-pagespeed-url-hash="3173940646" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/>                    </div>
                </div>
                <div class="col-lg-7 col-xs-7">
                    <div class="invoice-col" id="enderecoEstabelecimento" style="margin-left: 10px;">
                        <address>
                            <strong><label id='nomeSalao'></label></strong><br>
                            <font size="1" id="infoSalao"></font>
                        </address>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-5" align="right">
                    <h4>N˚: <label id="idComanda"></label><br>
                        <small><label id="idComandaExterno"></label></small><br>
                        <small id="dataComanda"></small></h4>
                    <div class="input-group input-group-sm col-md-8 no-print">
                        <input id="edtComCartao" name="edtComCartao" placeholder="Cartão" type="text" class="form-control">
                        <span class="input-group-btn">
                            <button class="btn btn-primary no-print" id="btnComCartao" type="button"><i class="fa fa-save visible-xs visible-sm"></i><label class="visible-md visible-lg">Salvar</label></button>
                        </span>
                    </div>
                    <div class="only-print" style="display:none;">
                        <small><label id="printCartaoExterno"></label></small>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <h4 class="pull-left">
                        <strong><span id='labelTipoClienteComanda'>Cliente:</span>
                            <label id="nomeClienteComanda"></label>
                            <i class="ion ion-ios-information-outline" style="cursor:pointer;" id="iconInfoCliente"></i>
                            <label id="codClienteComanda" style="display: none"></label>
                            <label id="TprTipoComanda" style="display: none"></label>
                        </strong>
                        <button class="btn btn-primary btn-xs" id="btnAssociaClienteComanda" ng-click="associaClienteComanda()"><i class="fa fa-user"></i>&nbspAssociar</button>
                        <br>
                        <small id="infoPontosCli">Pontos do programa de fidelidade: <span id="stringPontosCli"></span></small>
                    </h4>
                    <br>
                    <button id="btnInsereProdutoComanda" ng-click="buscaProdutoCombo()" onclick="insereItemComanda();" class="btn btn-sm pull-right no-print" style=" color: #ffffff;background-color:#ae5cf2"><i class="fa fa-plus"></i> Produto </button>

                    <button id="btnInsereServicoComanda" style="margin-right: 5px; color: #ffffff;background-color:#704718" onclick="insereServicoComanda(1);" class="btn btn-sm pull-right no-print"><i class="fa fa-plus"></i> Serviço </button>

                    <button id="btnInsereGorjeta" ng-click="diplayGorjeta()" style="margin-right: 5px;" class="btn bg-teal-dark pull-right btn-sm no-print"><i class="fa fa-plus" aria-hidden="true"></i> Gorjeta</button>

                    <button id="btnInsereDesconto" ng-click="insereDesconto()" style="margin-right: 5px;" class="btn btn-primary pull-right btn-sm no-print"><i class="fa fa-money" aria-hidden="true"></i>&nbsp<b>%</b></button>
                    <div class="btn-group pull-right no-print" style="margin-right: 5px;">
                        <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-print"></i>
                            <span class="fa fa-caret-down"></span></button>
                        <ul class="dropdown-menu" role="menu">
                            <li><a onclick="PrintComanda($('#printInvoice').html());">Impressão A4</a></li>
                            <li><a onclick="PrintComandaNaoFiscal($('#printInvoice').html());">Impressão não-fiscal</a>
                            </li>
                            <li><a onclick="EnviaEmailComanda($('#idComanda').html());">Enviar E-mail</a></li>
                        </ul>
                    </div>
                </div>
                <div id="pessoaConta" class=" pull-left col-xs-12" style="margin-right: 5px;"></div>
                <div id="pessoaDetalhesAssinaturas" class=" pull-left col-xs-12" style="margin-right: 5px;"></div>
            </div>
            <div class="row">
                <div class="col-xs-12 table-responsive">
                    <table id="tbComandaItens" class="table table-condensed table-hover display nowrap">
                        <thead>
                            <tr>
                                <th style="display:none;">Codigo</th>
                                <th style="display:none;">CodigoItem</th>
                                <th style="display:none;">CodigoSerPro</th>
                                <th style="display:none;">TipoItem</th>
                                <th style="width:50px;">Tipo</th>
                                <th style="display:none;">Data</th>
                                <th style="display:none;">Usuario</th>
                                <th style="width:60px;">Valor</th>
                                <th style="width:80px;">Valor Un.</th>
                                <th style="display:none;">Desconto</th>
                                <th style="width:50px;">Qtd</th>
                                <th style="display:none;">Comissao</th>
                                <th style="display:none;">ValorTotal</th>
                                <th>Item</th>
                                <th>Profissional</th>
                                <th style="display:none;">Cliente</th>
                                <th style="display:none;">TipoDesconto</th>
                                <th style="display:none;">ComissoPadrao</th>
                                <th style="display:none;">ComissoPrincipal</th>
                                <th style="display:none;">ExistePacote</th>
                                <th class="no-print" style="width:40px;">P/ Uso</th>
                                <th style="display:none;">Venda</th>
                                <th style="display:none;">ProValor</th>
                                <th class="no-print" style="width:30px;"></th>
                                <th class="no-print" style="width:30px;"></th>
                                <th class="no-print" style="width:30px;"></th>
                                <th class="no-print" style="width:30px;"></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
            <hr class='no-print'>

            <div class="row no-print">
                <div class="col-md-6 col-xs-12">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <label class="hide" id="senhaDesconto"></label>                            <h3 class="box-title">Formas de Pagamento</h3>
                        </div>
                        <div class="box-body">
                            <div id='variostiposdepagamento'>
                                <div class="row hidden-xs">
                                    <div class="col-md-4"><label>Tipo de Pagamento</label></div>
                                    <div class="col-md-4"><label>Bandeira</label></div>
                                    <div class="col-md-3"><label>Valor Pago <i data-toggle="popover" data-container="#dialog-comanda-modal" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Valor por forma de pagamento. Para dar desconto, edite o item da comanda."></i></label>
                                    </div>
                                    <div class="col-md-1"><label></label></div>
                                </div>
                            </div>
                            <div align="center">
                                <button class="btn btn-success btn-sm no-print" id="btnNovoTipo"><i class="fa fa-plus"></i>&nbsp&nbspForma
                                    de Pagamento</button>
                            </div>
                            <hr class="visible-xs">
                        </div>
                    </div>

                </div>
                <div class="col-md-3 col-xs-12">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title">Pagamento</h3>
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-7 col-xs-12">
                                    <h6><label>Total da Comanda:</label></h6>
                                </div>
                                <div class="col-md-5 col-xs-12">
                                    <h6><label name="valorTotalComanda" id="valorTotalComanda"></label></h6>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 col-xs-12">
                                    <h6><label>Valor Pagamento:</label></h6>
                                </div>
                                <div class="col-md-5 col-xs-12">
                                    <h6><label name="comValorTotal" id="comValorTotal"></label></h6>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 col-xs-12">
                                    <label class="hide" id="senhaInserecaixa"></label>                                    <h6><label>Inserir no Caixa? <i data-toggle="popover" data-container="#dialog-comanda-modal" tabindex="0" data-trigger="focus" data-placement="left" class="fa fa-question-circle" style="color:grey" data-content="Caso essa opção for desmarcada a comanda NÃO será contabilizada como uma receita no seu caixa/financeiro."></i></label>
                                    </h6>
                                </div>
                                <div class="col-md-5 col-xs-12">
                                    <input type="checkbox" name="insereCaixa" id="insereCaixa" checked="true">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 col-xs-12">
                                    <h6><label>Parcelado?</label></h6>
                                </div>
                                <div class="col-md-5 col-xs-12">
                                    <input type="checkbox" ng-modal="parcelarCaixa" name="parcelarCaixa" id="parcelarCaixa">
                                </div>
                            </div>
                            <div class="row" id="trParcelar" style="display: none;">
                                <div class="col-md-7 col-xs-12">
                                    <h6><label>Parcelas</label></h6>
                                </div>
                                <div class="col-md-5 col-xs-12">
                                    <select class="form-control input-sm" name="selVezesParcela" id="selVezesParcela"></select>
                                </div>
                            </div>
                            <div class="row" id="trParcelarPer" style="display: none;">
                                <div class="col-md-7 col-xs-12">
                                    <h6><label>Periodicidade</label></h6>
                                </div>
                                <div class="col-md-5 col-xs-12">
                                    <select class="form-control input-sm" name="selPeriodicidadeVenda" id="selPeriodicidadeVenda">
                                        <option value="7">7 dias</option>
                                        <option value="15">15 dias</option>
                                        <option value="30" selected="true">30 dias</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-xs-12">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title">Troco <i data-toggle="popover" data-container="#dialog-comanda-modal" tabindex="0" data-trigger="focus" data-placement="top" class="fa fa-question-circle" style="color:grey" data-content="Valor informativo, apenas para auxiliar no cálculo de troco."></i>
                            </h3>
                        </div>
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table tbRowComanda">
                                    <tbody>
                                        <tr>
                                            <th>Recebido:</th>
                                            <td><input type="text" class="form-control input-sm valorFormat" name="comValorRecebido" id="comValorRecebido" placeholder="" style="width:100%;"></td>
                                        </tr>
                                        <tr>
                                            <th>Troco:</th>
                                            <td><input type="text" class="form-control input-sm valorFormat" name="comValorTroco" id="comValorTroco" placeholder="" style="width:100%;" readonly></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="only-print" style="display:none;">
                <div class="row">
                    <div class="col-xs-6">
                        <table class="table" id="tableTpPagamentoPrint">
                            <thead>
                                <tr align="center">
                                    <th colspan="3">
                                        <h4>Formas de Pagamento</h4>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="txt12">Tipo</th>
                                    <th class="txt12">Bandeira</th>
                                    <th class="txt12">Valor</th>
                                </tr>
                            </thead>
                            <tbody id="rowsTpPag"></tbody>
                        </table>
                    </div>

                    <div class="col-xs-6 pull-right verticalLine">
                        <table class="table" id="tableResumoPagPrint">
                            <thead>
                                <tr align="center">
                                    <th colspan="2">
                                        <h4>Resumo</h4>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="rowResumoPag"></tbody>
                        </table>
                    </div>
                </div>
                <small>*Não é documento fiscal</small>
            </div>
            <input type="hidden" name="codCliente" id="codCliente">
            <div class="row no-print">
                <div class="col-xs-12" id="comandaProfissionalAviso">

                </div>
                <div class="col-xs-12">
                    <button id="btnFinalizarComanda" class="btn btn-sm btn-success pull-right no-print">Finalizar
                        Comanda</button>
                    <button id="btnFecharComanda" class="btn  btn-sm btn-warning pull-right no-print" data-dismiss="modal" style="margin-right: 5px;">Fechar</button>
                    <button id="btnCobrarCliente" class="btn  btn-sm bg-orange pull-right no-print" style="margin-right: 5px;" ng-click="cobraClienteContaDigital()" style="display:none">Conta Digital</button>
                </div>
            </div>
        </section>
    </div>
</div>

<div class="modal fade" id="descontoComanda-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i> Desconto </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <label for="ok">Desconto(%)</label>
                        <input type="number" name="comValorDesconto" id="comValorDesconto" class="form-control">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="insereDescontoComanda" type="button" class="btn btn-success" ng-click="geraDescontoComanda()">Salvar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="codigoTransacao-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i> Codigo da transação </h4>
            </div>
            <input type="hidden" id="idxCodigoTransac">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <label for="ok">Codigo</label>
                        <input type="text" name="inputcodigo" id="inputcodigo" class="form-control">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="insereTransacaoComanda" type="button" class="btn btn-success" ng-click="guardaCodigoTransac()">Salvar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="comandaInsert-modal" tabindex="-1" role="dialog" data-backdrop="false" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h4 class="modal-title"> Inserir Novo Produto</h4>
            </div>
            <div class="modal-body">
                <form id="formInsereItemComanda">
                    <input type="hidden" name="comCodigoInsert" id="comCodigoInsert">
                    <input type="hidden" name="insereProdutoOrigem" id="insereProdutoOrigem">
                    <div class="form-group">
                        <label>Produto*</label><br>
                        <select name="comProduto" id="comProduto" class="col-md-12 " required></select>
                    </div>


                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Valor Unitário</label>
                                <input type="text" name="comValorHdInsert" id="comValorHdInsert" class="form-control" placeholder="Valor" onkeyup="formataValorDinheiro(this); calculaValorInsert();">
                                <input type="hidden" name="comValorHdInsertOLD" id="comValorHdInsertOLD" class="form-control" placeholder="Valor" onkeyup="formataValorDinheiro(this); calculaValorInsert();">

                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Valor Total</label>
                                <input type="text" name="comValorInsert" id="comValorInsert" class="form-control" placeholder="Valor" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Quantidade</label>
                                <div class="input-group">
                                    <input type="number" name="comQtdeInsert" id="comQtdeInsert" min="1" onchange="calculaValorInsert();" class="form-control" placeholder="Quantidade">
                                    <div class="input-group-addon" id="tipoUnidadeAddonComanda">
													
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Token</label>
                                <div class="input-group" id="divTokenComInsert">
                                    <span class="input-group-addon"><i id="tokenComInsert" class=""></i><i class="fa fa-spinner fa-pulse fa-fw" id="spinneridinsert" style="display:none;"></i></span>
                                    <input type="text" id="comTokenInsert" name="comTokenInsert" class="form-control" placeholder="Token">
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-success btn-flat" id="btnValidarTokenInsert">Validar</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h4 class="help-block" id="msgTokenComInsert"></h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 campoComissaoComanda">
                            <div class="form-group">
                                <label>Comissão</label>
                                <input type="text" id="comProComissao" name="comProComissao" class="form-control" placeholder="Comissão" readonly="true">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Profissional</label>
                                <select id="comProfissionalComissao" name="comProfissionalComissao" class="form-control"></select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <input type="checkbox" name="comParaUsoInsert" id="comParaUsoInsert"/> <label> Para
                                uso</label>
                            <small class="help-block">*O Produto marcado como uso, não será contabilizado na
                                comanda.</small>
                        </div>
                    </div>
                    <div class="row" id="listaServicoUso" style="display:none;margin-bottom: 10px;">
                        <div class="col-md-12">
                            <label for="">Utilizado no serviço:</label>
                            <select name="listServicoComanda" id="listServicoComanda" class="form-control"></select>
                        </div>
                        <br>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <input type="checkbox" name="comCortesiaInsert" id="comCortesiaInsert"/> <label>
                                Cortesia</label>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button id="btnInsereItemComanda" type="submit" class="btn btn-success">Salvar</button>
                        <button id="btnFechaItemComanda" type="button" class="btn btn-warning" data-dismiss="modal">Voltar</button>
                        <button id="btnFechaItemComandaModal" type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                    </div>

                </form>

            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="comandaInsertSer-modal" tabindex="-1" role="dialog" data-backdrop="false" aria-hidden="true">
    <div class="modal-dialog modal-starapp-50">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h4 class="modal-title"> Inserir Novo Serviço</h4>
            </div>
            <div class="modal-body">
                <form id="formInsereItemComandaSer">
                    <input type="hidden" name="comCodigoInsertSer" id="comCodigoInsertSer">
                    <input type="hidden" name="insereServicoOrigem" id="insereServicoOrigem">
                    <input type="hidden" name="comClienteInsertSer" id="comClienteInsertSer">

                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>Serviço*</label>
                                <br>
                                <select name="comInsertServico" id="comInsertServico" class="input-large form-control select2" style="width:100%;" required>
                                    <option selected="true" value="">Selecione um Serviço</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>Profissional*</label>
                                <br>
                                <select name="comInsertProfissional" id="comInsertProfissional" class="input-large form-control select2" style="width:100%;" required>
                                    <option selected="true" value="">Selecione um Profissional</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>Data Início*</label>
                                <div class="input-group date divDataIni divDataComanda">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" maxlength="10" onKeyPress="mascara(this,soData)" name="comDataIni" id="comDataIni" class="form-control" placeholder="Data Início" data-inputmask="'alias': 'dd/mm/yyyy'" required>
                                </div>
                            </div>

                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>Hora*</label>
                                <select name="comHoraIni" id="comHoraIni" class="input-large form-control select2" style="width:100%;" required>
                                    <option value="" selected>Hora</option>
                                    <option value='00:00'>00:00</option><option value='00:05'>00:05</option><option value='00:10'>00:10</option><option value='00:15'>00:15</option><option value='00:20'>00:20</option><option value='00:25'>00:25</option><option value='00:30'>00:30</option><option value='00:35'>00:35</option><option value='00:40'>00:40</option><option value='00:45'>00:45</option><option value='00:50'>00:50</option><option value='00:55'>00:55</option><option value='01:00'>01:00</option><option value='01:05'>01:05</option><option value='01:10'>01:10</option><option value='01:15'>01:15</option><option value='01:20'>01:20</option><option value='01:25'>01:25</option><option value='01:30'>01:30</option><option value='01:35'>01:35</option><option value='01:40'>01:40</option><option value='01:45'>01:45</option><option value='01:50'>01:50</option><option value='01:55'>01:55</option><option value='02:00'>02:00</option><option value='02:05'>02:05</option><option value='02:10'>02:10</option><option value='02:15'>02:15</option><option value='02:20'>02:20</option><option value='02:25'>02:25</option><option value='02:30'>02:30</option><option value='02:35'>02:35</option><option value='02:40'>02:40</option><option value='02:45'>02:45</option><option value='02:50'>02:50</option><option value='02:55'>02:55</option><option value='03:00'>03:00</option><option value='03:05'>03:05</option><option value='03:10'>03:10</option><option value='03:15'>03:15</option><option value='03:20'>03:20</option><option value='03:25'>03:25</option><option value='03:30'>03:30</option><option value='03:35'>03:35</option><option value='03:40'>03:40</option><option value='03:45'>03:45</option><option value='03:50'>03:50</option><option value='03:55'>03:55</option><option value='04:00'>04:00</option><option value='04:05'>04:05</option><option value='04:10'>04:10</option><option value='04:15'>04:15</option><option value='04:20'>04:20</option><option value='04:25'>04:25</option><option value='04:30'>04:30</option><option value='04:35'>04:35</option><option value='04:40'>04:40</option><option value='04:45'>04:45</option><option value='04:50'>04:50</option><option value='04:55'>04:55</option><option value='05:00'>05:00</option><option value='05:05'>05:05</option><option value='05:10'>05:10</option><option value='05:15'>05:15</option><option value='05:20'>05:20</option><option value='05:25'>05:25</option><option value='05:30'>05:30</option><option value='05:35'>05:35</option><option value='05:40'>05:40</option><option value='05:45'>05:45</option><option value='05:50'>05:50</option><option value='05:55'>05:55</option><option value='06:00'>06:00</option><option value='06:05'>06:05</option><option value='06:10'>06:10</option><option value='06:15'>06:15</option><option value='06:20'>06:20</option><option value='06:25'>06:25</option><option value='06:30'>06:30</option><option value='06:35'>06:35</option><option value='06:40'>06:40</option><option value='06:45'>06:45</option><option value='06:50'>06:50</option><option value='06:55'>06:55</option><option value='07:00'>07:00</option><option value='07:05'>07:05</option><option value='07:10'>07:10</option><option value='07:15'>07:15</option><option value='07:20'>07:20</option><option value='07:25'>07:25</option><option value='07:30'>07:30</option><option value='07:35'>07:35</option><option value='07:40'>07:40</option><option value='07:45'>07:45</option><option value='07:50'>07:50</option><option value='07:55'>07:55</option><option value='08:00'>08:00</option><option value='08:05'>08:05</option><option value='08:10'>08:10</option><option value='08:15'>08:15</option><option value='08:20'>08:20</option><option value='08:25'>08:25</option><option value='08:30'>08:30</option><option value='08:35'>08:35</option><option value='08:40'>08:40</option><option value='08:45'>08:45</option><option value='08:50'>08:50</option><option value='08:55'>08:55</option><option value='09:00'>09:00</option><option value='09:05'>09:05</option><option value='09:10'>09:10</option><option value='09:15'>09:15</option><option value='09:20'>09:20</option><option value='09:25'>09:25</option><option value='09:30'>09:30</option><option value='09:35'>09:35</option><option value='09:40'>09:40</option><option value='09:45'>09:45</option><option value='09:50'>09:50</option><option value='09:55'>09:55</option><option value='10:00'>10:00</option><option value='10:05'>10:05</option><option value='10:10'>10:10</option><option value='10:15'>10:15</option><option value='10:20'>10:20</option><option value='10:25'>10:25</option><option value='10:30'>10:30</option><option value='10:35'>10:35</option><option value='10:40'>10:40</option><option value='10:45'>10:45</option><option value='10:50'>10:50</option><option value='10:55'>10:55</option><option value='11:00'>11:00</option><option value='11:05'>11:05</option><option value='11:10'>11:10</option><option value='11:15'>11:15</option><option value='11:20'>11:20</option><option value='11:25'>11:25</option><option value='11:30'>11:30</option><option value='11:35'>11:35</option><option value='11:40'>11:40</option><option value='11:45'>11:45</option><option value='11:50'>11:50</option><option value='11:55'>11:55</option><option value='12:00'>12:00</option><option value='12:05'>12:05</option><option value='12:10'>12:10</option><option value='12:15'>12:15</option><option value='12:20'>12:20</option><option value='12:25'>12:25</option><option value='12:30'>12:30</option><option value='12:35'>12:35</option><option value='12:40'>12:40</option><option value='12:45'>12:45</option><option value='12:50'>12:50</option><option value='12:55'>12:55</option><option value='13:00'>13:00</option><option value='13:05'>13:05</option><option value='13:10'>13:10</option><option value='13:15'>13:15</option><option value='13:20'>13:20</option><option value='13:25'>13:25</option><option value='13:30'>13:30</option><option value='13:35'>13:35</option><option value='13:40'>13:40</option><option value='13:45'>13:45</option><option value='13:50'>13:50</option><option value='13:55'>13:55</option><option value='14:00'>14:00</option><option value='14:05'>14:05</option><option value='14:10'>14:10</option><option value='14:15'>14:15</option><option value='14:20'>14:20</option><option value='14:25'>14:25</option><option value='14:30'>14:30</option><option value='14:35'>14:35</option><option value='14:40'>14:40</option><option value='14:45'>14:45</option><option value='14:50'>14:50</option><option value='14:55'>14:55</option><option value='15:00'>15:00</option><option value='15:05'>15:05</option><option value='15:10'>15:10</option><option value='15:15'>15:15</option><option value='15:20'>15:20</option><option value='15:25'>15:25</option><option value='15:30'>15:30</option><option value='15:35'>15:35</option><option value='15:40'>15:40</option><option value='15:45'>15:45</option><option value='15:50'>15:50</option><option value='15:55'>15:55</option><option value='16:00'>16:00</option><option value='16:05'>16:05</option><option value='16:10'>16:10</option><option value='16:15'>16:15</option><option value='16:20'>16:20</option><option value='16:25'>16:25</option><option value='16:30'>16:30</option><option value='16:35'>16:35</option><option value='16:40'>16:40</option><option value='16:45'>16:45</option><option value='16:50'>16:50</option><option value='16:55'>16:55</option><option value='17:00'>17:00</option><option value='17:05'>17:05</option><option value='17:10'>17:10</option><option value='17:15'>17:15</option><option value='17:20'>17:20</option><option value='17:25'>17:25</option><option value='17:30'>17:30</option><option value='17:35'>17:35</option><option value='17:40'>17:40</option><option value='17:45'>17:45</option><option value='17:50'>17:50</option><option value='17:55'>17:55</option><option value='18:00'>18:00</option><option value='18:05'>18:05</option><option value='18:10'>18:10</option><option value='18:15'>18:15</option><option value='18:20'>18:20</option><option value='18:25'>18:25</option><option value='18:30'>18:30</option><option value='18:35'>18:35</option><option value='18:40'>18:40</option><option value='18:45'>18:45</option><option value='18:50'>18:50</option><option value='18:55'>18:55</option><option value='19:00'>19:00</option><option value='19:05'>19:05</option><option value='19:10'>19:10</option><option value='19:15'>19:15</option><option value='19:20'>19:20</option><option value='19:25'>19:25</option><option value='19:30'>19:30</option><option value='19:35'>19:35</option><option value='19:40'>19:40</option><option value='19:45'>19:45</option><option value='19:50'>19:50</option><option value='19:55'>19:55</option><option value='20:00'>20:00</option><option value='20:05'>20:05</option><option value='20:10'>20:10</option><option value='20:15'>20:15</option><option value='20:20'>20:20</option><option value='20:25'>20:25</option><option value='20:30'>20:30</option><option value='20:35'>20:35</option><option value='20:40'>20:40</option><option value='20:45'>20:45</option><option value='20:50'>20:50</option><option value='20:55'>20:55</option><option value='21:00'>21:00</option><option value='21:05'>21:05</option><option value='21:10'>21:10</option><option value='21:15'>21:15</option><option value='21:20'>21:20</option><option value='21:25'>21:25</option><option value='21:30'>21:30</option><option value='21:35'>21:35</option><option value='21:40'>21:40</option><option value='21:45'>21:45</option><option value='21:50'>21:50</option><option value='21:55'>21:55</option><option value='22:00'>22:00</option><option value='22:05'>22:05</option><option value='22:10'>22:10</option><option value='22:15'>22:15</option><option value='22:20'>22:20</option><option value='22:25'>22:25</option><option value='22:30'>22:30</option><option value='22:35'>22:35</option><option value='22:40'>22:40</option><option value='22:45'>22:45</option><option value='22:50'>22:50</option><option value='22:55'>22:55</option><option value='23:00'>23:00</option><option value='23:05'>23:05</option><option value='23:10'>23:10</option><option value='23:15'>23:15</option><option value='23:20'>23:20</option><option value='23:25'>23:25</option><option value='23:30'>23:30</option><option value='23:35'>23:35</option><option value='23:40'>23:40</option><option value='23:45'>23:45</option><option value='23:50'>23:50</option><option value='23:55'>23:55</option><option value='00:00'>00:00</option>                                </select>
                            </div>
                        </div>
                    </div>
                    <small class="text-red">* Este serviço será adicionado como Encaixe. Nos encaixes, não são
                        verificados choques de horário.</small>
                    <div class="box-footer">
                        <button id="btnInsereItemComandaSer" type="submit" class="btn btn-success">Salvar</button>
                        <button id="btnFechaItemComandaSer" type="button" class="btn btn-warning" data-dismiss="modal">Voltar</button>
                        <button id="btnFechaServicoModal" type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="comandaEdit-modal" tabindex="-1" role="dialog" data-backdrop="false" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h4 class="modal-title"><label id="itemNome"></label></h4>
            </div>
            <div class="modal-body">
                <form id="formAlteraItemComanda">
                    <input type="hidden" name="comCodItem" id="comCodItem" class="form-control">
                    <input type="hidden" name="comCodSerPro" id="comCodSerPro" class="form-control">
                    <input type="hidden" name="comTipoItem" id="comTipoItem" class="form-control">
                    <input type="hidden" name="comProValor" id="comProValor" class="form-control">
                    <input type="hidden" name="comValSerHd" id="comValSerHd" class="form-control">
                    <input type="hidden" name="comValorRestore" id="comValorRestore" class="form-control">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Valor Unitário</label>
                                <input type="text" name="comValorHd" onkeyup="formataValorDinheiro(this); calculaValor();" id="comValorHd" class="form-control" placeholder="Valor">
                                <input type="hidden" name="comValorHdOLD" onkeyup="formataValorDinheiro(this); calculaValor();" id="comValorHdOLD" class="form-control" placeholder="Valor">
                                <input type="hidden" name="itemValorOriginal" id="itemValorOriginal" class="form-control">

                                <input type="hidden" name="comDesconto" id="comDesconto" class="form-control" placeholder="Valor">

                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Valor Total</label>
                                <input type="text" name="comValor" id="comValor" class="form-control" placeholder="Valor" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Quantidade</label>
                                <div class="input-group">
                                    <input type="number" name="comQtde" id="comQtde" min="1" onchange="calculaValor();" class="form-control" placeholder="Quantidade">
                                    <div class="input-group-addon" id="tipoUnidadeAddonEdtComanda">
													
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="comComissaoHd"></input>
                        <input type="hidden" id="comComissaoPrincipalHd"></input>
                        <div class="col-md-6 col-sm-6 campoComissaoComanda">
                            <div class="form-group">
                                <label>Comissão</label>
                                <input type="text" name="comComissao" id="comComissao" class="form-control valorFormat" placeholder="Comissão" readonly="true">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label>Token</label>
                            <div class="form-group input-group" id="divTokenCom">
                                <span class="input-group-addon">
                                    <i id="tokenCom" class=""></i>
                                    <i class="fa fa-spinner fa-pulse fa-fw" id="spinnerid" style="display:none;"></i>
                                </span>
                                <input type="text" id="comToken" name="comToken" class="form-control" placeholder="Token">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-success btn-flat" id="btnValidarToken">Validar</button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class="help-block" id="msgTokenCom"></h4>
                        </div>
                    </div>
                    <div class="row" id="comParaUsoTipoItem">
                        <div class="col-md-12">
                            <input type="checkbox" name="comParaUso" id="comParaUso"/> <label> Para uso</label>
                            <small class="help-block">*O Produto marcado como uso, não será contabilizado na
                                comanda.</small>
                        </div>
                    </div>
                    <div class="row" id="listaServicoUsoEdt" style="display:none;margin-bottom: 10px;">
                        <div class="col-md-12">
                            <label for="">Utilizado no serviço:</label>
                            <select name="listServicoComandaEdt" id="listServicoComandaEdt" class="form-control"></select>
                        </div>
                        <br>
                    </div>
                    <div class="row" id="comCortesiaTipoItem">
                        <div class="col-md-12">
                            <input type="checkbox" name="comCortesia" id="comCortesia"/> <label> Cortesia</label>
                        </div>
                    </div>
                    <div class="row" id="comAlteraDataAgendamento">
                        <hr>
                        <div class="col-md-12">
                            <label>Editar Data do Agendamento:</label><br>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="form-group">
                                <label>Dia:</label>
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" id="dataCamandaAlteracao" name="dataCamandaAlteracao" class="form-control date" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label>Hora Início:</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                        <input type="text" id="horaComandaAlteracao" name="horaComandaAlteracao" class="form-control timepicker"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <small>* Comissões não serão debitadas do Caixa automaticamente.</small>

                    <div class="box-footer">
                        <button id="btnAlteraItemComanda" type="submit" class="btn btn-success">Salvar</button>
                        <button id="btnCancelaItemComanda" type="button" class="btn btn-warning" data-dismiss="modal">Voltar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="selectTipoAssociacao-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h4 class="modal-title">Associar</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <button class="btn btn-default btn-block" style="padding: 20px;color:#00a65a;" ng-click="displayOptionPacote()"> <i class="fa fa-gift fa-5x"></i>
                            <h1>
                                Pacote
                            </h1>
                        </button>
                    </div>
                    <div class="col-md-6">
                        <button class="btn btn-default btn-block" style="padding: 20px;color:purple" ng-click="displayOptionAssinatura()"> <i class="fa fa fa-users fa-5x"></i>
                            <h1>
                                Assinatura
                            </h1>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="comandaAssinatura-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h4 class="modal-title">Associar a Assinatura</h4>
            </div>
            <div class="modal-body text-center">
                <div class="row">
                    <div class="col-md-12">
                        <h3><b>Assinatura:</b> <span id="titleAssinatura"></span></h3>
                        <h4><b>Vencimento:</b> <span id="titleVencimento"></span></h4>
                        <h4><b>Utilizações do serviço:</b> <span id="titleUtilizacao"></span></h4>
                        <input type="hidden" id="AssCodigoAssocia">
                        <input type="hidden" id="APFCodigoAssocia">
                        <input type="hidden" id="CitCodigoAssocia">
                        <input type="hidden" id="IsMultiUnidade">
                        <hr>
                    </div>
                    <div class="col-md-9">
                        <button class="btn btn-block bg-purple" ng-click="insereAgendamentoClube()">Associar</button>
                    </div>
                    <div class="col-md-3">
                        <button id="btnCancelaAssinturaComanda" type="button" class="btn btn-warning btn-block" data-dismiss="modal">Voltar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="comandaPacote-modal" tabindex="-1" role="dialog" data-backdrop="false" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h4 class="modal-title"><label id="itemNomePacote"></label></h4>
            </div>
            <div class="modal-body">
                <form id="formAlteraItemPacote">
                    <input type="hidden" name="comCodItemPac" id="comCodItemPac" class="form-control">
                    <input type="hidden" name="comCodSerProPac" id="comCodSerProPac" class="form-control">
                    <input type="hidden" name="comTipoItemPac" id="comTipoItemPac" class="form-control">

                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group">
                                <label>Pacotes</label>
                                <br>
                                <select name="pacotesComandaCombo" id="pacotesComandaCombo" class="input-large form-control select2" style="width:100%;">
                                    <option value="-1" selected="true">Selecione um Pacote</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <label class="text-black" id="txtPacotesComandaDataCompra" style="display:none;">Data da
                                Compra: <label id="pacotesComandaDataCompra"></label></label>
                            <div class="progress active" id="divPacotesComandaProgress" style="display:none;">
                                <div class="progress-bar progress-bar-success progress-bar-striped" id="pacotesComandaProgress" role="progressbar" style="width:0%;">
                                </div>

                                <font class="text-black"><label id="pacotesComandaConsumo"></label> de <label id="pacotesComandaTotal"></label>
                                    Utilizados</font>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <label id="pacotesComandaSaldo"></label>
                        </div>
                    </div>

                    <small>* Comissões não serão debitadas do Caixa automaticamente.</small>

                    <div class="box-footer">
                        <button id="btnAlteraPacoteComanda" type="submit" class="btn btn-success">Salvar</button>
                        <button id="btnCancelaPacoteComanda" type="button" class="btn btn-warning" data-dismiss="modal">Voltar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cadastrarmsg-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-envelope-o"></i> Nova Mensagem </h4>
            </div>
            <input type="hidden" id="isSingleMSG">
            <form id="formCadastroMensagem">
                <div class="modal-body">
                    <div class="box-body">

                        <div class="form-group" style="display:none;">
                            <label>Título</label>
                            <input type="hidden" name="msgTitulo" class="form-control" placeholder="Título">
                        </div>

                        <div class="form-group" id="divDescMsg">
                            <label>Descrição*</label>
                            <textarea name="msgDescricao" id="msgDescricao" class="form-control" rows="5" placeholder="Descrição" required ng-model="mensagempreview"> </textarea>
                            <span class="help-block" id="charNumMsg" style="display:none;"> <label id="charTextMsg">
                                </label> (Máx. {{textMax}} caracteres) </span>
                        </div>

                        <div class="row">
                            <div class="col-md-12 col-lg-6">
                                <div class="form-group">
                                    <label>Data Envio*</label>
                                    <div class="input-group date divDataIni">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" maxlength="10" onKeyPress="mascara(this,soData)" name="msgDataEnvio" class="form-control" placeholder="Data Início" data-inputmask="'alias': 'dd/mm/yyyy'" ng-model="datamensagempreview" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-6">
                                <div class="form-group">
                                    <label>Hora Envio:</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                        <input type="text" name="msgHoraEnvio" id="msgHoraEnvio" maxlength="5" class="form-control hora" ng-model="horaenviomensagenpreview"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="checkbox" name="msgEnviarSms" id="msgEnviarSms" class="iCheck"> Enviar SMS?
                        </div>
                        <div class="form-group" id="divSaldoSmsMsg" style="display:none;">
                            <div class="row">
                                <div class="col-md-12">
                                    Saldo de SMS: <label id="lblSaldoSMSMsg"></label>&nbsp <a class="btn btn-primary btn-xs" id="btnCompraSms"><i class="fa fa-plus"></i>&nbspComprar sms</a>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label id="lblCliente">Cliente:</label><span class="btn btn-xs " id="infoMensagemStatusCliente" data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="left" class="fa fa-question-circle" style="color:grey" data-content="" data-html="true"><i class="fa fa-question-circle"></i></span>
                            <br>
                            <h4 id="todosSelecionadosmsg">Todos os clientes da lista.</h4>
                            <div id="divmsgUsuario">
                                <select class="form-control selectConectado select2-multiple" id="msgUsuario" name="msgUsuario" style="width: 100%" multiple="multiple">
                                                                    </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>(*) Campos Obrigatórios.</label>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Cadastrar</button>
                            <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                            <button type="button" class="btn btn-info pull-right" ng-click="verpreviewmensagem()">Visualizar</button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="cadastrarCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-barcode"></i> Caixa </h4>
            </div>

            <form id="formCadastroCaixa">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-primary">
                            <div class="box-header" data-toggle="tooltip"></div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="control-label">Data*</label>
                                            <div class="input-group date divData" align="center" id="DivCaxData">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" name="caxData" id="caxData" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Valor Inicial*</label>
                                            <input type="text" min="0.00" step="0.01" max="25000" name="caxValor" id="caxValor" class="form-control " placeholder="Valor" required onkeyup="formataValorDinheiro(this);">
                                        </div>
                                        <p class="help-block text-red" id="msgPrimeiroCaixa" style="display:none;">Como
                                            este é seu primeiro caixa, este valor será adicionado na movimentação.</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Observação</label>
                                            <input type="text" name="caxObservacao" class="form-control" placeholder="Observação">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Abrir Caixa</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="entradaCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-barcode"></i> Entrada </h4>
            </div>
            <form id="formCaxEntrada" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-success">
                            <div class="box-body">
                                <input type="hidden" name="caxCodigoEnt" id="caxCodigoEnt" class="form-control caxCodigoEnt">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <label>Valor*</label>
                                            <input type="text" min="0.00" step="0.01" max="2500" value="0.00" name="caxValorEnt" id="caxValorEnt" class="form-control" onkeyup="formataValorDinheiro(this);" placeholder="Valor" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Descrição*</label>
                                            <input type="text" name="caxDescEnt" id="caxDescEnt" class="form-control" placeholder="Descrição" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="divReceita">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <label>Tipo de Receita</label><br>
                                            <select name="buscaReceitaCaixa" id="buscaReceitaCaixa" class="form-control"></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Forma de pagamento*</label>
                                            <select class="form-control " id="pFormaPag" required></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="bandeirasHide">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Bandeira</label>
                                            <select class="form-control " id="divBandeiraPag"></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <label>Suprimento de Caixa</label><br>
                                            <select name="suprimentoCaixa" id="suprimentoCaixa" class="form-control">
                                                <option value="">Não</option>
                                                <option value="1">Sim</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-success">Salvar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="saidaCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true" style='z-index:999998'>
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-barcode"></i> Saída </h4>
            </div>
            <form id="formCaxSaida" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-danger">
                            <div class="box-body">
                                <input type="hidden" name="caxCodigoSai" id="caxCodigoSai" class="form-control caxCodigoSai">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group ">
                                            <label>Valor*</label>
                                            <input type="text" min="0.00" step="0.01" max="2500" name="caxValorSai" id="caxValorSai" class="form-control" onkeyup="formataValorDinheiro(this);" placeholder="Valor" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Descrição*</label>

                                            <input type="text" name="caxDescSai" id="caxDescSai" class="form-control" placeholder="Descrição" required>

                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="divReceita">
                                    <div class="col-md-6">
                                        <div class="form-group ">
                                            <label>Tipo de Despesa</label><br>
                                            <div class="input-group">
                                                <span class="input-group-btn">

                                                    <button type="button" class="btn btn-default" data-toggle="modal" data-target="#despesacaixa-modal">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </span>
                                                <select name="buscaDespesaCaixa" id="buscaDespesaCaixa" class="form-control"></select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group ">
                                            <label>Para próximo caixa</label><br>
                                            <select name="proxCaixa" id="proxCaixa" class="form-control">
                                                <option value="0" selected>Não</option>
                                                <option value="1">Sim</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Forma de pagamento</label>
                                            <select class="form-control " id="pFormaPagSaida"></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Sangria&nbsp</label> <a href="https://appbarber-appbeleza.zendesk.com/hc/pt-br/articles/360013513752-Sangria-de-Caixa-o-que-%C3%A9-Como-lan%C3%A7ar-no-sistema-" target="blank">
                                                <i data-toggle="popover" tabindex="0" data-trigger="hover" data-placement="right" class="fa fa-question-circle" style="color:grey" data-html="true" data-content="Saída de caixa que não irá contar como despesa, ou seja, quantia que será retirada do caixa e será movida para outro lugar." data-original-title="" title=""></i><br>
                                            </a>
                                            <input type="checkbox" id="sangria" value="1">
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="divProfissionalCaixa">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <label>Profissional</label><br>
                                            <select name="buscaProfissionalCaixa" id="buscaProfissionalCaixa" class="form-control" style="width:100%;"></select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-success" id="btnSalvarMovCaixa">Salvar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="contaClienteDeatalhes-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-75">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i> Informações </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <table id="tbContaClienteDetalhes" class="table table-condensed" style="width:100%">
                            <thead>
                                <tr>
                                    <th style="display:none;">ID</th>
                                    <th style="display:none;">Código</th>
                                    <th style="width:100px;">Descricao</th>
                                    <th style="width:100px;">Data</th>
                                    <th style="width:50px;">Valor</th>
                                    <th style="width:20px">Tipo</th>
                                    <th style="width:50px;">Saldo</th>
                                    <th style="display:none;">CodTipo</th>
                                    <th style="display:none;">ValorReal</th>
                                    <th style="display:none;">Comanda</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
            <h3 align="right" id="lblSaldo" style="display:none;padding-right:20px;">Saldo: <label id="valorTotal"></label></h3>
            <br>
        </div>
    </div>
</div>


<div class="modal fade" id="primeiroAcesso-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body" style="background-color:#D2D6DE;">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12" align="center">
                            <h3 style="background-color:#00A65A;color:white;padding:5px;">E agora, o que fazer?</h3>
                        </div>
                    </div>

                                        <div class="row">
                        <div class="col-md-12">
                            <div class="info-box">
                                <span class="info-box-icon bg-green"><i class="ion ion-compose"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-number">Complete seus Cadastros</span>
                                    <span>Acesse o menu Cadastros e realize os cadastros de seus clientes, serviços e
                                        profissionais.</span>
                                </div>
                            </div>
                            <div class="info-box">
                                <span class="info-box-icon bg-green"><i class="ion ion-location"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-number">Complete os Dados do Estabelecimento</span>
                                    <span>Preencha as informações de Horário de Funcionamento, Imagens do
                                        Estabelecimento, Redes Sociais clicando <a href="#/conta">aqui</a>.</span>
                                </div>
                            </div>
                            <div class="info-box">
                                <span class="info-box-icon bg-green"><i class="ion ion-iphone"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-number">Baixe o App para iOS e/ou Android</span>
                                    <span>Faça o download na <a href="https://itunes.apple.com/us/app/appbeleza/id989887626?mt=8" onclick="handleClick(1);" target="_blank">Apple Store</a> e/ou <a href="https://play.google.com/store/apps/details?id=com.startapp.belezaapp" onclick="handleClick(1);" id="" target="_blank">Play Store</a> e acesse com
                                        seu usuário e senha para receber notificações.</span>
                                </div>
                            </div>
                            <div class="info-box">
                                <span class="info-box-icon bg-green"><i class="ion ion-android-calendar"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-number">Simule agendamentos</span>
                                    <span>Crie agendamentos de testes pelo WebAdmin e pelo App.</span>
                                </div>
                            </div>
                                                        <div class="info-box">
                                <span class="info-box-icon bg-green"><i class="fa fa-facebook-official"></i></span>
                                                                <div class="info-box-content">
                                    <span class="info-box-number">Divulgue o Aplicativo para os seus clientes</span>
                                    <span>Faça o download da imagem de divulgação <a href="/enviaImagem.php" onclick="handleClick(2);" target="_blank">aqui</a> e compartilhe nas suas
                                        redes sociais para divulgar para seus clientes.</span>
                                </div>

                            </div>
                                                    </div>
                    </div>
                    <div align="center">
                        <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade appblz-modal-lg" id="vercomanda-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:99999">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-usd"></i> Comanda </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div align="left" class="col-md-2">
                            <h3>N˚: <label id="idComandaVer"></label></h3>
                            <h4><label id="idComandaExternoVer"></label></h4>
                        </div>
                        <div class="col-md-10">
                            <div align="left" class="col-md-6">
                                <h3 id="nomeClienteComandaVer"></h3>
                            </div>
                            <div align="right" class="col-md-6">
                                <h3 id="dataComandaVer"></h3>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <table id="tbComandaItensVer" class="table table-condensed table-hover">
                                    <thead>
                                        <tr>
                                            <th style="display:none;">Codigo</th>
                                            <th style="display:none;">CodigoItem</th>
                                            <th style="display:none;">CodigoSerPro</th>
                                            <th style="display:none;">TipoItem</th>
                                            <th style="width:50px;">Tipo</th>
                                            <th style="display:none;">Data</th>
                                            <th style="display:none;">Usuario</th>
                                            <th style="width:50px;">Valor</th>
                                            <th style="width:50px;">Valor Un.</th>
                                            <th style="width:50px;">Desconto</th>
                                            <th style="width:50px;">Quantidade</th>
                                            <th style="display:none;">Comissao</th>
                                            <th style="display:none;">ValorTotal</th>
                                            <th style="width:50px;">Item</th>
                                            <th style="width:50px;">Profissional</th>
                                            <th style="width:50px;">Cliente</th>
                                            <th style="width:50px;">Cortesia</th>
                                            <th style="width:50px;">Associação</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-6 col-md-offset-6">
                                <table class="pull-right table table-condensed table-striped" style="width:100%;">
                                    <tr>
                                        <td><b>Valor pago:</b></td>
                                        <td id="valorPagoComandaVer"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Total: </b></td>
                                        <td id="valorTotalComandaVer"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Forma de Pagamento:</b></td>
                                        <td id="pagamentoComandaVer"></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cadastrarClienteComanda-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-envelope-o"></i> Novo Cadastro </h4>
            </div>
            <form id="formCadastroClienteComanda" autocomplete="off">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-primary">
                            <div class="box-header" data-toggle="tooltip" title="(*) Campos Obrigatórios.">
                                <h3 class="box-title">Dados Pessoais</h3>
                                <button type="submit" class="btn btn-xs btn-primary pull-right">Cadastrar</button>
                            </div>
                            <div class="box-body">

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Nome Completo*</label>
                                            <input type="text" name="cliNome" id="cliNomeComanda" class="form-control" placeholder="Nome" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Celular*</label>
                                            <!-- <input type="text" maxlength="15" name="cliCelular" id="cliCelularComanda" class="form-control" placeholder="Celular" required> -->
                                            <input type="tel" id="cliCelularComanda" name="cliCelular" class="form-control">
                                            <input type="hidden" id="cliDialCodeComanda" name="cliDialCode">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>E-mail <i data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Obrigatório para clientes com usuário."></i></label>
                                            <input onkeyup="this.value=this.value.replace(/[' ']/g,'')" type="email" name="cliEmail" id="cliEmail2" class="form-control" placeholder="E-mail">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Telefone</label>
                                            <input type="text" maxlength="15" name="cliTelefone" id="cliTelefone" class="form-control" placeholder="Telefone">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>CPF</label>
                                            <input type="text" maxlength="14" onKeyPress="mascara(this,soCpf)" name="cliCpf" class="form-control" placeholder="CPF">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>RG</label>
                                            <input type="text" maxlength="14" name="cliRG" class="form-control" placeholder="RG">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Sexo</label>
                                            <select name="cliSexo" class="input-large form-control">
                                                <option value="" selected>Sexo</option>
                                                <option value="Feminino">Feminino</option>
                                                <option value="Masculino">Masculino</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label>Data Nascimento</label>
                                            <div class="input-group date">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" name="cliDataNascimento" id="cliDataNascimento" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>CEP</label>
                                            <input type="text" maxlength="9" onKeyPress="mascara(this,soCep)" name="cliCep" id="cliCep2" class="form-control" placeholder="CEP">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Endereço Completo</label>
                                            <input name="cliEndereco" id="cliEndereco2" class="form-control" rows="3" placeholder="Endereço Completo">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Estado</label>
                                            <select name="cliEstado" id="cliEstado2" class="input-large form-control">
                                                <option selected="selected" value="-1">Estado</option>
                                                <option id='AC' value=5>Acre</option><option id='AL' value=2>Alagoas</option><option id='AM' value=4>Amazonas</option><option id='AP' value=3>Amapá</option><option id='BA' value=6>Bahia</option><option id='CE' value=7>Ceará</option><option id='DF' value=8>Distrito Federal</option><option id='ES' value=9>Espírito Santo</option><option id='GO' value=10>Goiás</option><option id='MA' value=11>Maranhão</option><option id='MG' value=14>Minas Gerais</option><option id='MS' value=13>Mato Grosso do Sul</option><option id='MT' value=12>Mato Grosso</option><option id='PA' value=15>Pará</option><option id='PB' value=16>Paraíba</option><option id='PE' value=18>Pernambuco</option><option id='PI' value=19>Piauí</option><option id='PR' value=17>Paraná</option><option id='RJ' value=20>Rio de Janeiro</option><option id='RN' value=21>Rio Grande do Norte</option><option id='RO' value=23>Rondônia</option><option id='RR' value=24>Roraima</option><option id='RS' value=22>Rio Grande do Sul</option><option id='SC' value=1>Santa Catarina</option><option id='SE' value=26>Sergipe</option><option id='SP' value=25>São Paulo</option><option id='TO' value=27>Tocantins</option>                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Cidade</label>
                                            <select name="cliCidade" id="cliCidade2" class="input-large form-control" disabled>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Bairro</label>
                                            <input type="text" name="cliBairro" id="cliBairro2" class="form-control" placeholder="Bairro">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Número</label>
                                            <input type="text" name="cliNumero" id="cliNumero2" class="form-control" placeholder="Número">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Complemento</label>
                                            <input type="text" name="cliComplemento" id="cliComplemento" class="form-control" placeholder="Complemento">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Observações</label>
                                            <input type="text" name="cliObservacao" id="cliObservacao" class="form-control" placeholder="Observações">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="cliFoto">Foto</label>
                                            <input type="file" id="cliFoto" name="cliFoto" accept="image/*">
                                            <p class="help-block">Max. 500Kb</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="clionde">Como Soube do Estabelecimento?</label>
                                            <input class="form-control" id="cliOnde" name="cliOnde">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="box box-primary" hidden>
                            <div class="box-header">
                                <h3 class="box-title">Dados Usuário</h3>
                                <i data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Usuário e Senha para o cliente acessar o aplicativo."></i>
                            </div>
                            <div class="box-body">
                                                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{"usuario" | translate}}</label>
                                            <input type="password" style="display:none;"/>
                                            <input type="text" id="cliLoginId2" class="form-control" placeholder="E-mail" autocomplete="off" disabled="true" value="{{loginEmailModal}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Senha</label>
                                            <input type="password" style="display:none;"/>
                                            <input onkeypress="this.value=this.value.replace(/[' ']/g,'')" type="password" name="cliSenha" id="cliSenha" class="form-control" placeholder="Senha" autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>(*) Campos Obrigatórios.</label>
                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Cadastrar</button>
                            <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="insereProntuario-modal" tabindex="-1" role="dialog" aria-hidden="false" style="z-index: 99999;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title"><i class="fa fa-plus"></i> Prontuário </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">

                        <div class="col-md-12 " id="imagem">
                            <div class="box box-success " id="novoProntuarioImagens">
                                <form id="formInsereImagemAgendamento" enctype="multipart/form-data" class="ng-pristine ng-valid">
                                    <input type="hidden" id="codigoAgendamentoImagem" name="codigoAgendamentoImagem" value="8261588">
                                    <div class="box-header" data-toggle="tooltip" data-original-title="" title="">
                                        <h3 class="box-title">Imagens do Agendamento</h3>
                                    </div>
                                    <div class="box-body">

                                        <div class="row">

                                            <div class="col-md-12" ng-click="edtImgProntuario()">

                                                <div class="row text-center">
                                                    <div class="col-md-4 mouse-over">
                                                        <a class="pointer"><img src="https://d3verit7xckkza.cloudfront.net/imgsystem/pront_sem_imagem.png" alt="" style="width: 75%;" id="imagemProntuario0" data-pagespeed-url-hash="3639138637" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                                                    </div>
                                                    <div class="col-md-4 mouse-over">
                                                        <a class="pointer"><img src="https://d3verit7xckkza.cloudfront.net/imgsystem/pront_sem_imagem.png" alt="" style="width: 75%;" id="imagemProntuario1" data-pagespeed-url-hash="3639138637" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>

                                                    </div>
                                                    <div class="col-md-4 mouse-over">
                                                        <a class="pointer"><img src="https://d3verit7xckkza.cloudfront.net/imgsystem/pront_sem_imagem.png" alt="" style="width: 75%;" id="imagemProntuario2" data-pagespeed-url-hash="3639138637" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="form-group" style="display:none;">
                                                <label>Imagem</label>
                                                <span class="file-input file-input-new">
                                                    <div class="kv-upload-progress hide"></div>
                                                    <div class="input-group ">
                                                        <div tabindex="-1" class="form-control file-caption  kv-fileinput-caption">
                                                            <span class="file-caption-ellipsis">…</span>
                                                            <div class="file-caption-name"></div>
                                                        </div>
                                                        <div class="input-group-btn">
                                                            <button type="button" title="Clear selected files" class="btn btn-default fileinput-remove fileinput-remove-button"><i class="glyphicon glyphicon-trash"></i> Remover</button>
                                                            <button type="button" title="Abort ongoing upload" class="hide btn btn-default fileinput-cancel fileinput-cancel-button"><i class="glyphicon glyphicon-ban-circle"></i> Cancel</button>

                                                            <div class="btn btn-primary btn-file"> Procurar <input type="file" name="aimImagem" id="aimImagemInsere" accept="image/*" onchange="readURL2(this, '#formInsereImagemAgendamento')"></div>
                                                        </div>
                                                    </div>
                                                </span>
                                                <p class="help-block">*PNG/JPG</p>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                        <div class="col-md-12 " id="divDetalhes">
                            <form id="formInsereDetalhesAgendamento" enctype="multipart/form-data" class="ng-pristine ng-valid">
                                <input type="hidden" id="codigoAgendamento" name="codigoAgendamento" value="8261588">
                                <div class="box box-success " id="novoProntuarioDetalhes">
                                    <div class="box-header" data-toggle="tooltip" data-original-title="" title="">

                                        <h3 class="box-title">Detalhes do Agendamento</h3>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Material Utilizado</label><br>
                                                    <input type="text" id="ageMaterial" name="ageMaterial" class="form-control" placeholder="Material">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Tipo de Procedimento</label><br>
                                                    <input type="text" id="ageCorte" name="ageCorte" class="form-control" placeholder="Tipo de Procedimento">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Observação</label><br>
                                            <textarea type="text" id="ageDetalhes" name="ageDetalhes" class="form-control" placeholder="Observação"></textarea>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                        <button type="submit" class="btn btn-primary btn-block">Salvar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- <div class="col-md-12 " id="imagem">
                            <div class="box box-success " id="novoProntuarioImagens">
                                <form id="formInsereImagemAgendamento" enctype="multipart/form-data">
                                    <input type="hidden" id="codigoAgendamentoImagem" name="codigoAgendamentoImagem">
                                    <div class="box-header" data-toggle="tooltip" data-original-title="" title="">
                                        <h3 class="box-title">Imagens do Agendamento</h3>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">

                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Imagem</label>
                                                    <input type="file" name="aimImagem" id="aimImagemInsere" accept="image/*" onChange="readURL2(this, '#formInsereImagemAgendamento')">
                                                    <p class="help-block">*PNG/JPG</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                        <button type="submit" class="btn btn-primary">Salvar</button>
                                    </div>
                                </form>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="ampliaImagem-modal" tabindex="-1" role="dialog" style="z-index:999999">
    <div class="modal-dialog" role="document" style="width: 100%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <img id="imagemProntuario" src="" alt="" data-pagespeed-url-hash="83945255" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cortaImagem-modal" tabindex="-1" role="dialog" style="z-index:9999">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <img id="imagemCut" style="width: 100%;max-width: 100%;max-height: 100%;height:100%" src="" alt="" data-pagespeed-url-hash="83945255" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="rotateImage(-90);"><i class="fa fa-undo"></i></button>
                <button type="button" class="btn btn-primary" onclick="rotateImage(90)"><i class="fa fa-repeat"></i></button>
                <button type="button" class="btn btn-success" onclick="saveImageCrop('logo')">Salvar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cortaImagemAll-modal" data-backdrop="static" tabindex="-1" role="dialog" style="z-index:99999">
    <div class="modal-dialog" role="document">
        <input type="hidden" id="formid"/>
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <img id="imagemCutAll" style="width: 100%;max-width: 100%;max-height: 100%;" src="" alt="" data-pagespeed-url-hash="83945255" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" ng-click="rotateImage(-90);"><i class="fa fa-undo"></i></button>
                <button type="button" class="btn btn-primary" ng-click="rotateImage(90)"><i class="fa fa-repeat"></i></button>
                <button type="button" class="btn btn-success" ng-click="saveImageCrop()">Salvar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="EditaProntuario-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:99998">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title"><i class="fa fa-plus"></i> Editar </h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="AgeCodigoBuscaImagem" name="AgeCodigoBuscaImagem">
                <div class="box-body">
                    <div class="row">


                        <div class="row">
                            <div class="col-md-12">
                                <div class="box box-success " id="novoProntuarioDetalhes">
                                    <div class="box-header" data-toggle="tooltip" data-original-title="" title="">
                                        <!-- <input id="AdeCodgioAltera" name="AdeCodgioAltera" hidden=""> -->

                                        <h3 class="box-title">Imagens</h3>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">

                                            <div class="col-md-12">

                                                <div class="row text-center" id="divimgagealt">
                                                    <!-- <div class="col-md-4">
                                                        <img src="../../img/prod_sem_imagem.png" alt="" width="100px" id="imagemProntuario0">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <img src="../../img/prod_sem_imagem.png" alt="" width="100px" id="imagemProntuario1">

                                                    </div>
                                                    <div class="col-md-4">
                                                        <img src="../../img/prod_sem_imagem.png" alt="" width="100px" id="imagemProntuario2">
                                                    </div> -->



                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <form id="formAlteraDetalhesAgendamento" enctype="multipart/form-data" class="ng-pristine ng-valid">
                                    <div class="box box-success " id="novoProntuarioDetalhes">
                                        <div class="box-header" data-toggle="tooltip" data-original-title="" title="">
                                            <input id="AdeCodgioAltera" name="AdeCodgioAltera" hidden>

                                            <h3 class="box-title">Detalhes do Agendamento</h3>
                                        </div>
                                        <div class="box-body">
                                            <div class="form-group">
                                                <label>Material Utilizado</label><br>
                                                <input type="text" id="ageMaterialEdt" name="ageMaterialEdt" class="form-control" placeholder="Material">
                                            </div>
                                            <div class="form-group">
                                                <label>Observação</label><br>
                                                <textarea type="text" id="ageDetalhesEdt" name="ageDetalhesEdt" class="form-control" placeholder="Observação"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Tipo de Corte</label><br>
                                                <input type="text" id="ageCorteEdt" name="ageCorteEdt" class="form-control" placeholder="Tipo de Corte">
                                            </div>
                                        </div>
                                        <div class="box-footer">
                                            <button type="submit" class="btn btn-success btn-block">Salvar</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- <div class="col-md-12 ">
                            <div class="box box-success " id="novoProntuarioImagens">
                                <form id="formInsereImagemAgendamentoEDT" enctype="multipart/form-data">
                                    <div class="box-body">
                                        <div class="form-group">
                                            <input type="hidden" id="codigoAgendamentoImagemEdit" name="codigoAgendamentoImagem">

                                            <label>Imagem</label>
                                            <input type="file" name="aimImagem" id="aimImagemEdt" accept="image/*" onChange='readURL2(this,$("#formInsereImagemAgendamentoEDT"));'>
                                            <p class="help-block">*PNG/JPG</p>
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-success" type="submit">Inserir Nova Imagem</button>
                                        </div>
                                    </div>

                                </form>
                                <hr>
                                <form id="formAlteraImagemAgendamento" enctype="multipart/form-data">
                                    <div class="box-header" data-toggle="tooltip" data-original-title="" title="">
                                        <h3 class="box-title">Imagens do Agendamento</h3>
                                        <input id="AimCodigoAltera" name="AimCodigoAltera" hidden>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">
                                            <div id="divimgagealt" class="row"></div>
                                            <input type="file" style="display:none;" name="imgAgeAlter" id="imgAgeAlter" accept="image/*" ng-model="imgAgeAlter" onChange='readURL2(this,$("#formAlteraImagemAgendamento"));'>

                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="catalogoProduto-modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-starapp-70" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tabProduto" data-toggle="tab">Produtos</a></li>
                        <li><a href="#tabServico" data-toggle="tab">Serviço</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tabProduto">
                            <div class="row">
                                <div class="text-center">
                                    <h3>Cardápio de Produtos</h3>
                                </div>
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <input type="text" placeholder="Pesquisar por produto" name="" ng-model="search.Descricao" value="" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <button type="button" class="btn btn-block btn-default" ng-click="printCatalogoProduto()">Imprimir</button>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <table class="table table-condensed table-hover ">
                                        <tr ng-repeat="produto in infos.produtos  | filter:search">
                                            <td><b>{{produto.Descricao}}
                                                </b></td>
                                            <td>{{produto.Moeda}} {{produto.Valor}}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="border col-md-6 col-sm-6" style="margin-top:5px;margin-bottom:5px;">
                                    <table class="table table-condensed table-hover ">
                                        <tr ng-repeat="produto2 in infos.produtos2  | filter:search">
                                            <td><b>{{produto2.Descricao}}</b></td>
                                            <td>{{produto2.Moeda}} {{produto2.Valor}}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

                            <div class="row" id="catProduto" style='display:none'>
                                <div class="col-md-12">
                                    <table class="table table-condensed table-hover " style="width:50%; float:left;">
                                        <tr ng-repeat="produto in infos.produtos  | filter:search">
                                            <td><b>{{produto.Descricao}}
                                                </b></td>
                                            <td>{{produto.Moeda}} {{produto.Valor}}</td>
                                        </tr>
                                    </table>
                                    <table class="table table-condensed table-hover " style="width:50%; float:right">
                                        <tr ng-repeat="produto2 in infos.produtos2  | filter:search">
                                            <td><b>{{produto2.Descricao}}</b></td>
                                            <td>{{produto2.Moeda}} {{produto2.Valor}}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tabServico">
                            <div class="row">
                                <div class="text-center">
                                    <h3>Cardápio de Serviços</h3>
                                </div>
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <input type="text" placeholder="Pesquisar por serviço" name="" ng-model="searchs.Ser_Descricao" value="" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <button type="button" class="btn btn-block btn-default" ng-click="printCatalogoServico()">Imprimir</button>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-6" style="margin-top:5px;margin-bottom:5px;">
                                    <table class="table table-condensed table-hover ">
                                        <tr ng-repeat="servico in infos.servico | filter:searchs">
                                            <td><b>{{servico.Ser_Descricao}}</b></td>
                                            <td>{{servico.Moeda}} {{servico.Ser_Valor}}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="border col-md-6 col-sm-6" style="margin-top:5px;margin-bottom:5px;">
                                    <table class="table table-condensed table-hover ">
                                        <tr ng-repeat="servico2 in infos.servico2 | filter:searchs">
                                            <td><b>{{servico2.Ser_Descricao}}</b></td>
                                            <td>{{servico2.Moeda}} {{servico2.Ser_Valor}}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="row" id="catServico" style='display:none'>
                                <div class="col-md-12">
                                    <table class="table table-condensed table-hover " style="width:50%; float:left;">
                                        <tr ng-repeat="servico in infos.servico | filter:searchs">
                                            <td><b>{{servico.Ser_Descricao}}</b></td>
                                            <td>{{servico.Moeda}} {{servico.Ser_Valor}}</td>
                                        </tr>
                                    </table>
                                    <table class="table table-condensed table-hover " style="width:50%; float:right">
                                        <tr ng-repeat="servico2 in infos.servico2 | filter:searchs">
                                            <td><b>{{servico2.Ser_Descricao}}</b></td>
                                            <td>{{servico2.Moeda}} {{servico2.Ser_Valor}}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="infoMovimentacaoCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:99999">
    <div class="modal-dialog modal-starapp-20">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i> Detalhes </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <label>Hora: </label>&nbsp<span id="horaMovimentacao"></span><br>
                        <label id="tipoReceitaDespesa">Receita: </label>&nbsp<span id="DesRecMovimentacao"></span><br>
                        <span id="labelPagamento"><label>Pagamento: </label>&nbsp<span id="pagMovimentacao"></span><br></span>
                        <label>Sangria: </label>&nbsp<span id="sanMovimentacao"></span><br>
                        <label>Próximo Caixa: </label>&nbsp<span id="proxCaixaMovimentacao"></span><br>
                        <div id="divValeReciboCaixa">
                            <hr>
                            <button class="btn btn-sm btn-warning btn-block" id="btnGeraReciboCaixa">
                                Gerar Recibo para o Vale
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editarClienteAgenda-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:99999;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-envelope-o"></i> {{'clientes.editar_cadastro' | translate }}
                </h4>
            </div>

            <form id="formEditarClienteAgenda">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-primary">
                            <div class="box-header" data-toggle="tooltip" title="(*) {{'campos_obrigatorios' | translate }}.">
                                <h3 class="box-title">{{'dados_pessoais' | translate }}</h3>
                                <button type="submit" class="btn btn-primary pull-right">{{'btn_salvar' | translate
                                    }}</button>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'nome' | translate }}*</label>
                                            <input type="text" name="cliNomeEdt" id="cliNomeEdtAgenda" class="form-control" placeholder="{{'nome' | translate }}" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'celular' | translate }}*</label>
                                            <!-- <input type="text" maxlength="{{'mascaras.max_celular' | translate }}" name="cliCelularEdt" id="cliCelularEdtAgenda" class="form-control" placeholder="{{'celular' | translate }}" required> -->
                                            <input type="tel" id="cliCelularEdtAgenda" name="cliCelularEdt" class="form-control">
                                            <input type="hidden" id="cliDialCodeEdtAgenda" name="cliDialCodeEdt">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'email' | translate }} <i data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Obrigatório para clientes com usuário."></i></label></label>
                                            <input onkeyup="this.value=this.value.replace(/[' ']/g,'')" type="email" name="cliEmailEdt" id="cliEmailEdtAgenda" class="form-control" placeholder="{{'email' | translate }}" ng-model="cliEmailModelAgenda">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'telefone' | translate }}</label>
                                            <input type="text" maxlength="{{'mascaras.max_telefone' | translate }}" name="cliTelefoneEdt" id="cliTelefoneEdtAgenda" class="form-control" placeholder="{{'telefone' | translate }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'cpf' | translate }}</label>
                                            <input type="text" maxlength="14" onKeyPress="mascara(this,soCpf)" name="cliCpfEdt" id="cliCpfEdtAgenda" class="form-control" placeholder="{{'cpf' | translate }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'rg' | translate }}</label>
                                            <input type="text" maxlength="14" name="cliRGEdt" id="cliRGEdtAgenda" class="form-control" placeholder="{{'rg' | translate }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'sexo.titulo' | translate }}</label>
                                            <select name="cliSexoEdt" id="cliSexoEdtAgenda" class="input-large form-control">
                                                <option value="" selected>{{'sexo.titulo' | translate }}</option>
                                                <option value="Feminino">{{'sexo.feminino' | translate }}</option>
                                                <option value="Masculino">{{'sexo.masculino' | translate }}</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'nascimento' | translate }}</label>
                                            <div class="input-group date">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" name="cliDataNascimentoEdt" id="cliDataNascimentoEdtAgenda" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>País</label>
                                            <select name="cliPaisAgendaEdt" id="cliPaisAgendaEdt" class="input-large form-control"></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'estado' | translate }}</label>
                                            <select name="cliEstadoEdt" id="cliEstadoEdtAgenda" class="input-large form-control"></select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'cidade' | translate }}</label>
                                            <select name="cliCidadeEdt" id="cliCidadeEdtAgenda" class="input-large form-control" disabled></select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'cep' | translate }}</label>
                                            <input type="text" maxlength="{{'mascaras.max_cep' | translate }}" onKeyPress="mascara(this,soCep)" name="cliCepEdt" id="cliCepEdtAgenda" class="form-control" placeholder="{{'cep' | translate }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'endereco' | translate }}</label>
                                            <input name="cliEnderecoEdt" id="cliEnderecoEdtAgenda" class="form-control" rows="3" placeholder="{{'endereco' | translate }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'bairro' | translate }}</label>
                                            <input type="text" name="cliBairroEdt" id="cliBairroEdtAgenda" class="form-control" placeholder="{{'bairro' | translate }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'numero' | translate }}</label>
                                            <input type="text" name="cliNumeroEdt" id="cliNumeroEdtAgenda" class="form-control" placeholder="{{'numero' | translate }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'complemento' | translate }}</label>
                                            <input type="text" name="cliComplementoEdt" id="cliComplementoEdtAgenda" class="form-control" placeholder="{{'complemento' | translate }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'obs' | translate }}</label>
                                            <input type="text" name="cliObservacaoEdt" id="cliObservacaoEdtAgenda" class="form-control" placeholder="{{'obs' | translate }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="cliFoto">{{'imagem' | translate }}</label>
                                            <input type="file" id="cliFotoEdtAgenda" name="cliFotoEdt" accept="image/*">
                                            <p class="help-block">Max. 500Kb</p>
                                        </div>
                                    </div>
                                </div>

                                <input type="hidden" name="cliCodigoEdt" id="cliCodigoEdtAgenda" class="form-control">
                                <div class="form-group">
                                    <label>(*) {{'campos_obrigatorios' | translate }}.</label>
                                </div>

                            </div>
                        </div>
                        <!-- <div class="box box-primary">
                            <input type="hidden" id="usucodigoalteracao">
                            <div class="box-header">
                                <h3 class="box-title">{{'dados_usuario' | translate }}</h3>
                                <i data-toggle="popover" tabindex="0" data-trigger="focus" data-placement="right" class="fa fa-question-circle" style="color:grey" data-content="Usuário e Senha para o cliente acessar o aplicativo."></i><br>
                                <span id="possuiusu">Já possui</span>
                                <span id="npossuiusu">Não possui</span>
                            </div>
                            <div class="box-body">
                                                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'usuario' | translate }}</label>
                                            <input type="password" style="display:none;" />
                                            <input type="email" ng-model="cliLogin" id="cliLoginIdAgenda" class="form-control" placeholder="{{'email' | translate }}" autocomplete="off" disabled="true" value="{{cliLogin=cliEmailModelAgenda}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>{{'senha' | translate }}</label>
                                            <input type="password" style="display:none;" />
                                            <input onkeypress="this.value=this.value.replace(/[' ']/g,'')" type="password" name="cliSenha" id="cliSenhaAgenda" class="form-control" placeholder="{{'senha' | translate }}" autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->

                    </div>
                </div>

                <div class="box-footer">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary pull-right" name="btnEdtCli" id="btnEdtCliAgenda">{{'btn_salvar'|
                                    translate }}</button>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="acao-video-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-85">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="titleModalAcaoVideo"></h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12" style="width:100% !important;height:100% !important;">
                            <div id="player-acao"></div>
                        </div>
                    </div>
                    <div align="center">
                        <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="acao-imagem-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-50">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="titleModalAcaoImagem"></h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12" id="containerImgAcao" align="center" style="width:100% !important;height:100% !important;">
                            <img class="pointer" src="img/ajax-loader2.gif.pagespeed.ce.c-V5NzBNif.gif" style="max-height:500px;" id="imgAcao" alt="" data-pagespeed-url-hash="437721229" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/>
                        </div>
                    </div>
                </div>
                <div class="box-footer" align="center">
                    <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="associaClienteComanda-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <form id="formAssociaClienteComanda">
                    <input type="hidden" id="associaComCodigo" name="associaComCodigo">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="cliente">Cliente</label>
                                    <br>
                                    <select name="buscaClienteAssociaComanda" id="buscaClienteAssociaComanda" class="form-control" style="width:100%"></select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer" align="center">
                        <button type="button" class="btn btn-warning" data-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-success">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="geratokenCliente-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-plus"></i> Gerar Token </h4>
            </div>
            <form id="formAddPontos" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-success">
                            <div class="box-body">
                                <div class="row">
                                    <input type="hidden" id="pesCodigoTokenInfo"></input>
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label>Item</label>
                                                <select name="itemTokemInfo" id="itemTokemInfo" class="form-control"></select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button ng-click="resgataTokenInfo()" class="btn btn-success">{{'btn_salvar' | translate }}</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="showTokenClienteInfo-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-plus"></i> Token </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-success">
                        <div class="box-body">
                            <div class="row">

                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group text-center">
                                            <h4 id="resultadoTokenInfo"></h4>
                                            <b>
                                                <h2 id="tokenIdInfo"></h2>
                                            </b>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="prontuarioImprime-modal" style="z-index:99999">
    <div class="modal-dialog" role="document" style="width:60%">
        <div class="modal-content">
            <div class="modal-header">

            </div>
            <div class="modal-body">
                <div class="box-body">

                    <div id="prontuarioImprimir" class="col-xs-12">

                        <div class="text-center row">
                            <h3>PRONTUÁRIO</h3>
                        </div>
                        <div class="row">

                            <div class="col-xs-12">
                                <table style="width:100%; border:none;" class="table">
                                    <thead>
                                        <th style="width:20%"></th>
                                        <th style="width:40%"></th>
                                        <th style="width:40%"></th>

                                    </thead>
                                    <tr>
                                        <td>
                                            <img src="" class="img-rounded image" alt="Usuario" style="width:100px;" id="imgPrint" data-pagespeed-url-hash="83945255" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/>
                                        </td>
                                        <td>
                                            <label>Nome:</label>&nbsp<span id="nomePrint"></span><br>
                                            <label>Celular:</label>&nbsp<span id="celPrint"></span><br>
                                            <label>Telefone:</label>&nbsp<span id="telPrint"></span><br>
                                            <label>Email:</label>&nbsp<span id="emailPrint"></span><br>
                                            <label>CPF:</label>&nbsp<span id="cpfPrint"></span><br>
                                            <label>Sexo:</label>&nbsp<span id="sexoPrint"></span><br>
                                        </td>

                                        <td>
                                            <label>Estado:</label>&nbsp<span id="estPrint"></span><br>
                                            <label>Cidade:</label>&nbsp<span id="cidPrint"></span><br>
                                            <label>Bairro:</label>&nbsp<span id="bairroPrint"></span><br>
                                            <label>Endereço:</label>&nbsp<span id="endPrint"></span><br>
                                            <label>Data de Nascimento:</label>&nbsp<span id="datanascPrint"></span><br>
                                            <label>Data de Cadastro:</label>&nbsp<span id="dataCadPrint"></span><br>
                                        </td>
                                    </tr>
                                </table>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-12">
                                <table style="width:100%; border:none;" class="table">
                                    <thead>
                                        <th style="width:50%"></th>
                                        <th style="width:50%"></th>

                                    </thead>
                                    <tr>
                                        <td>Data:</td>
                                        <td>
                                            <span id="printData"></span>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>Profissional:</td>
                                        <td>
                                            <span id="printProfissional"></span>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>Serviço:</td>
                                        <td>
                                            <span id="printServico"></span>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>Material Utilizado:</td>
                                        <td>
                                            <span id="printMaterial"></span>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>Tipo de Procedimento: </td>
                                        <td>
                                            <span id="printPro"></span>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>Detalhes:</td>
                                        <td>
                                            <span id="printObs"></span>
                                        </td>

                                    </tr>

                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cadastrarcategoria-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    <i class="fa fa-envelope-o"></i> Nova Categoria </h4>
            </div>
            <form id="formCategoria" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-success">
                            <div class="box-header" data-toggle="tooltip">
                                <h3 class="box-title">Dados Categoria</h3>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Descrição*</label>
                                            <input type="text" name="Categoria" id="Categoria" class="form-control" placeholder="Descrição" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Tipo</label>
                                            <select name="tipocategoria" id="tipocategoria" class="form-control"></select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>(*) Campos Obrigatórios.</label>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Cadastrar</button>
                                <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="despesacaixa-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:999999">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-envelope-o"></i> Nova Despesa </h4>
            </div>
            <form id="formDespesaCaixa" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-danger">
                            <div class="box-header" data-toggle="tooltip">
                                <h3 class="box-title">Dados Despesa</h3>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Descrição*</label>
                                            <input type="text" name="DespesaCaixa" id="DespesaCaixa" class="form-control" placeholder="Exemplo: Fornecedores" required>
                                            <input type="hidden" name="vale" id="vale" class="form-control" value="0" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>(*) Campos Obrigatórios.</label>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Cadastrar</button>
                                <button type="reset" value="Reset" class="btn btn-danger">Limpar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="previewmensagem-modal" data-backdrop="static" tabindex="-1" role="dialog" style="z-index:99999">
    <div class="modal-dialog modal-starapp-70" role="document">
        <input type="hidden" id="formid"/>
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body ">
                <div class="row">
                    <div class="col-md-12">
                        <label>Este é apenas um exemplo de visualização da mensagem em um smartphone, a disposição de
                            alguns itens podem mudar dependendo do modelo e versão do aparelho. <br>Para uma melhor
                            visualização das informações preencha todos os campos. </label>
                    </div>
                </div>
                <hr>
                <div class="nav-tabs-custom ">
                    <ul class="nav nav-tabs">
                        <li class="disabled  active">
                            <a data-target="#mensagemapp" data-toggle="tab">App</a>
                        </li>
                        <li class="disabled ">
                            <a data-target="#mensagemsms" data-toggle="tab">SMS*</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="mensagemapp">

                            <div class="row">
                                <div class="col-md-4 col-md-offset-4">
                                    <div class="marvel-device note8 ">
                                        <div class="inner"></div>
                                        <div class="overflow">
                                            <div class="shadow"></div>
                                        </div>
                                        <div class="speaker"></div>
                                        <div class="sensors"></div>

                                        <div class="sleep"></div>
                                        <div class="volume"></div>
                                        <div class="camera"></div>
                                        <div class="screen">
                                            <div class="row" style="border:solid 1px #d9dce0;">
                                                <div class="col-md-12" style="margin-left:5%;padding-right:12%;">
                                                    <div class="row">
                                                        <div class="col-md-12 ">
                                                            <img src="../../img/logo_notificationblue.png" id='logopushbarber' alt="" style="width:20px" data-pagespeed-url-hash="1304629619" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                                                            <img src="img/20xNxlogo_brancabeleza.png.pagespeed.ic.1FBawx3icP.webp" id='logopushbeleza' alt="" style="width:20px" data-pagespeed-url-hash="341998080" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                                                            &nbsp&nbsp
                                                            <small style="font-size:80%;margin-bottom:1%;color:black">{{sistemaName}}&nbsp&nbsp{{horaenviomensagenpreview}}</small><br>
                                                            <span>{{sistemaName}}</span>

                                                            <p style="margin-top:2%;font-size:80%;white-space:nowrap;word-wrap: nowrap;overflow:hidden;text-overflow:ellipsis;">
                                                                Gustavo Bezerra -
                                                                {{mensagempreview}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row" style="background-color:darkgray; height:100%">
                                                <div class="col-md-12 " style="margin-top: 35%;">

                                                    <div style="margin:5%; background-color:white; vertical-align: middle; ">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div style="margin:5%; ">
                                                                    {{mensagempreview}}
                                                                    <br>
                                                                    <label class="pull-right"> OK</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                        <div class="tab-pane" id="mensagemsms">

                            <div class="row">
                                <div class="col-md-12">
                                    <p>* Apenas enviado caso a opção esteja selecionada e existam créditos disponíveis
                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-md-offset-4">
                                    <div class="marvel-device note8 ">
                                        <div class="inner"></div>
                                        <div class="overflow">
                                            <div class="shadow"></div>
                                        </div>
                                        <div class="speaker"></div>
                                        <div class="sensors"></div>

                                        <div class="sleep"></div>
                                        <div class="volume"></div>
                                        <div class="camera"></div>
                                        <div class="screen">

                                            <div class="row" style="background-color:white; height:100%">
                                                <div class="col-md-12 text-center" style="border-bottom:solid 1px #d9dce0;">
                                                    <small>Mensagem</small><br>
                                                    <small>{{datamensagempreview}}&nbsp{{horaenviomensagenpreview}}</small>
                                                </div>
                                                <hr>
                                                <div class="col-md-12 " style="margin-top: 70%;">

                                                    <div style="margin:5%; background-color:#e0e0e0;  border-top-right-radius:10px; border-top-left-radius: 10px;border-bottom-right-radius:10px;">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div style="margin:5%; ">
                                                                    {{sistemaName}}: {{mensagempreview}}

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="listaDocumentos-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-75">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Documentos do Cliente</h4>
            </div>

            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12" id="divBtnNovoDocumento">

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">

                            <table class="table" id="tabelaListaDocumentos">
                                <thead>
                                    <tr>
                                        <th style="width:50%">Documento</th>
                                        <th style="width:30%">Data de Cadastro</th>
                                        <th style="width:5%"></th>
                                        <th style="width:5%"></th>
                                        <th style="width:5%"></th>
                                        <th style="width:5%"></th>
                                    </tr>
                                </thead>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="novodocumentocliente-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-75">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    Novo Documento </h4>
            </div>
            <form id="formCliDocumento" enctype="multipart/form-data">
                <input type="hidden" id="adeCodigoDocumento" name="adeCodigoDocumento">
                <input type="hidden" id="pesCodigoClienteDocumento" name="pesCodigoClienteDocumento">
                <input type="hidden" id="pesCodigoProfissionalDocumento" name="pesCodigoProfissionalDocumento">
                <input type="hidden" id="ageCodigoDocumento" name="ageCodigoDocumento">
                <input type="hidden" id="serCodigoDocumento" name="serCodigoDocumento">
                <input type="hidden" id="assCodigoDocumento" name="assCodigoDocumento">
                <div class="modal-body">
                    <div class="box-body">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Documento*</label>
                                    <select name="documentoSelect" id="documentoSelect" class="form-control"></select>
                                </div>
                            </div>
                        </div>

                        <div class="row" id="divCorpoDocumento">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="corpoDocumentoCliente">Corpo do documento*</label>
                                    <textarea name="corpoDocumentoCliente" id="corpoDocumentoCliente" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Cadastrar</button>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="novodocumentoprofissional-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-75">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    Novo Documento </h4>
            </div>
            <form id="formProDocumento" enctype="multipart/form-data">
                <input type="hidden" id="codigoProfissionalDocumento" name="codigoProfissionalDocumento">
                <div class="modal-body">
                    <div class="box-body">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Documento*</label>
                                    <select name="documentoSelectProfissional" id="documentoSelectProfissional" class="form-control"></select>
                                </div>
                            </div>
                        </div>

                        <div class="row" id="divCorpoDocumentoProfissional">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="corpoDocumentoProfissional">Corpo do documento*</label>
                                    <textarea name="corpoDocumentoProfissional" id="corpoDocumentoProfissional" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Cadastrar</button>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="viewdocumentocliente-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-75">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    Ver Documento </h4>
            </div>

            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-default" id="btnImprimeDocumento"><i class="fa fa-print"></i>
                                Imprimir</button>
                            <button class="btn btn-default" id="btnPDFDocumento"><i class="fa fa-file-pdf-o"></i>
                                PDF</button>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h3 id="tituloDocumentoView"></h3>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div id="corpoDocumentoView">

                            </div>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 20px;">
                        <div class="col-md-12 text-center">
                            <div id="assinaturaDocumentoView">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="auxiliar-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i> Auxiliar </h4>
            </div>
            <input type="hidden" id="CitCodigoAuxiliar">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <button id="removeAuxiliarComanda" style="display:none;" ng-click="removeAuxiliar()" type="button" class="btn btn-block btn-danger">Remover Auxiliar</button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="aux">Auxiliar</label>
                            <select name="PesAuxiliar" id="PesAuxiliar" class="form-control"></select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="por">Porcentagem(%)</label>
                            <input type="text" class="form-control valorFormat" id="PorAuxiliar" name="PorAuxiliar">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="insereAuxiliarComanda" ng-click="salvaAuxiliar()" type="button" class="btn btn-success">Salvar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="movPontos-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-85">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Movimentações</h4>
            </div>

            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-5">

                            <div class="form-group">
                                <label>{{'data_inicio' | translate }}</label>
                                <div class="input-group date divDataIniPts">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" name="cliDatInicioPonto" id="cliDatInicioPonto" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                </div>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="form-group">
                                <label>{{'data_fim' | translate }}</label>
                                <div class="input-group date divDataFimPts">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" name="cliDatFimPonto" id="cliDatFimPonto" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'">
                                </div>
                            </div>

                        </div>
                        <div class="col-md-2 pull-right">
                            <button type="button" class="btn btn-primary" id="btnCliPonto" ng-click="buscaClienteMovPonto()" style="margin-top:25px">{{'btn_buscar' |
                                        translate }}</button>
                            <br>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">

                            <table class="table" id="tabelaMovPtsCliente" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Nome</th>
                                        <th>Cadastro</th>
                                        <th>Expiração</th>
                                        <th>Pontos</th>
                                        <th>Tipo</th>
                                        <th>Item</th>
                                        <th>Token</th>
                                        <th>Observação</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="clienteContaDetalhes-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">

    <div class="modal-dialog modal-starapp-85">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    <i class="fa fa-user"></i> Informações </h4>
            </div>

            <div class="modal-body">

                <div class="row">
                    <div class="col-md-2">
                        <img class="img-circle" style="width: 100px" height="100" max-width="100" max-height="100" src="img/100x100xnopicture.png.pagespeed.ic.6kdGd7HH_d.webp" id="cliImagemInfoConta" data-pagespeed-url-hash="3894603355" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/>
                    </div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Nome: </label>
                            <label id="cliNomeInfoConta" style="color:#00ACD6;"></label>
                            <br>
                            <label>E-mail: </label>
                            <label id="cliEmailInfoConta" style="color:#00ACD6;"></label>
                            <br>
                            <label align="right">Telefone: </label>
                            <label id="cliTelefoneInfoConta" style="color:#00ACD6;"></label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-success btn-block" id="btnCreditoContaCli" data-toggle="modal" data-target="#creditocontacli-modal">
                            <i class="fa fa-plus"></i>&nbsp Crédito </button>
                        <br>
                        <button type="button" class="btn btn-danger btn-block" id="btnDebitoContaCli" data-toggle="modal" data-target="#debitocontacli-modal">
                            <i class="fa fa-minus"></i>&nbsp Débito </button>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 table-responsive">
                        <table id="tbContaClienteInfo" class="table  table-condensed" style="padding:5px;width:100%;">
                            <thead>
                                <tr>
                                    <th style="display:none;">ID</th>
                                    <th style="display:none;">Código</th>
                                    <th style="width:100px;">Descricao</th>
                                    <th style="width:100px;">Data</th>
                                    <th style="width:50px;">Valor</th>
                                    <th style="width:20px">Tipo</th>
                                    <th style="width:50px;">Saldo</th>
                                    <th style="display:none;">CodTipo</th>
                                    <th style="display:none;">ValorReal</th>
                                    <th style="display:none;">Comanda</th>
                                    <th style="width:30px;"></th>
                                    <th style="width:30px;"></th>
                                    <th style="width:30px;"></th>
                                    <th style="width:30px;">Inserido</th>
                                    <th style="width:30px;">Data de inserção</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
            <h3 align="right" id="lblSaldoContaCli" style="display:none;padding-right:20px;">Saldo:
                <label id="valorTotalContaCli"></label>
            </h3>
            <br>
        </div>
    </div>
</div>

<div class="modal fade" id="creditocontacli-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    <i class="fa fa-barcode"></i> Entrada </h4>
            </div>
            <form id="formCreditoContaCli" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-success">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <lable class="hide" id="senhaInserecaixacontacli"></lable>                                            <label>Valor*</label>
                                            <input type="text" name="ContaCliValor" id="ContaCliValorEnt" class="form-control valor" placeholder="Valor" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Descrição*</label>
                                            <input type="text" name="ContaCliDesc" id="ContaCliDescEnt" class="form-control" placeholder="Descrição" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Data*</label>
                                            <div class="input-group date dataInContaCli">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" id="ContaCliDataEnt" name="ContaCliData" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6">
                                        <label>Inserir no Caixa?</label>
                                        <br>
                                        <select id="insereCaixaContaCli" name="insereCaixaContaCli" class="form-control">
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-sm-12 divParceladoModal">
                                        <div class="form-group">
                                            <label>Parcelado</label>
                                            <select id="parceladoContaCliModal" name="parceladoContaCliModal" class="form-control">
                                                <option value="0">Não</option>
                                                <option value="1">Sim</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row divNumParcelasModal" style="display:none">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label>Parcelas</label>
                                            <select id="numParcelasContaCliModal" name="numParcelasContaCliModal" class="form-control"></select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label>Periodicidade</label>
                                            <select id="periodicidadeContaCliModal" name="periodicidadeContaCliModal" class="form-control">
                                                <option value="7">7 dias</option>
                                                <option value="15">15 dias</option>
                                                <option value="21">21 dias</option>
                                                <option value="30">30 dias</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="divTipoPagamentoContaCli">
                                    <div id="divPagamentoContaCli">
                                        <div class="col-md-6">
                                            <label>Tipo De Pagamento</label>
                                            <select name="tipoPagamentoContaCli" id="tipoPagamentoContaCli" class="form-control"></select>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Tipo De Bandeira</label>
                                            <select name="tipoBandeiraContaCli" id="tipoBandeiraContaCli" class="form-control"></select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="button" ng-click="verificaSenhaContaCli()" class="btn btn-success">Salvar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="debitocontacli-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    <i class="fa fa-barcode"></i> Saída </h4>
            </div>
            <form id="formDebitoContaCliente" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="box-body">
                        <div class="box box-danger">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group ">
                                            <label>Valor*</label>
                                            <input type="text" name="ContaCliValor" id="ContaCliValorSai" class="form-control valor" placeholder="Valor" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Descrição*</label>
                                            <input type="text" name="cclDesc" id="ContaCliDescSai" class="form-control" placeholder="Descrição" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Data*</label>
                                            <div class="input-group date dataOut">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" id="ContaCliDataSai" name="cclData" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-success">Salvar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="insereFinanceiroSangria-modal" style="z-index:9999" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    <i class="fa fa-barcode"></i> Entrada de Sangria </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-success">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label>Descrição*</label>
                                        <input type="text" name="finDescricao" id="descricaoInsereFinSangria" class="form-control" placeholder="Descrição" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group ">
                                        <label>Valor*</label>
                                        <input type="text" name="finValor" id="valorInsereFinSangria" class="form-control" onkeyup="formataValorDinheiro(this);" placeholder="Valor">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label>Data*</label>
                                        <div class="input-group date dateSangriaEntrada">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" id="dataInsereFinSangria" name="finData" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group ">
                                        <label>Conta</label>
                                        <select name="buscaConta" id="buscaContaFinSangria" class="form-control">
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group ">
                                        <label>Entrada de Sangria</label>
                                        <select name="entradaSangria" id="entradaSangriaFinSangria" class="form-control">
                                            <option value="1">Sim</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="buttton" class="btn btn-success" ng-click="insereEntradaSangriaCaixa()">Salvar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="generateCupon-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-90">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-user"></i> Cupom - <span id="numComanda"></span> </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <h4 class="text-center">Emissão - Serviço</h4>
                    <div class="col-md-4">
                        <input type="text" id="empresaCNAE" hidden>
                        <!-- <input type="text" id="empresaCodigoNF" hidden> -->
                        <input type="text" id="empresaCST" hidden>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="ok">CNPJ</label>
                                    <select name="empresaCodigoNF" id="empresaCodigoNF" class="form-control" style="width: 100%;"></select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Valor:</label>
                                    <input type="text" disabled class="form-control" id="valorCupomDisplay"/>
                                    <input type="hidden" disabled class="form-control" id="valorComissaoDisplay"/>
                                    <span hidden id="valorCupom"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Serviços Prestados</label>
                                    <input type="text" disabled class="form-control" id="servicosPrestadosDisplay"/>
                                    <span hidden id="servicosPrestados"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8">
                        <div class="row">
                            <input type="hidden" id="oldValueNatureza">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ok">Operação</label>
                                    <select name="servicoNatureza" id="servicoNatureza" class="form-control" style="width: 100%;"></select>
                                </div>
                            </div>
                            <!-- STATE -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Competência:</label><small> Apenas caso deseje mudar a data da emissão</small>
                                    <div class="input-group date divDataCompetencia">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" id="dataCompetencia" name="dataCompetencia" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="ok">Enviar via Email?</label>
                                    <select name="enviaCupomEmail" id="enviaCupomEmail" class="form-control">
                                        <option value="0">Não</option>
                                        <option value="1">Sim</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="ok">Usar endereço</label>
                                    <select name="usaEndereco" id="usaEndereco" class="form-control">
                                        <option value="0">Cliente</option>
                                        <option value="1">Empresa</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

                <div class="row" id="divCSTEmpresa">
                    <div class="col-md-12">
                        <ul class="list-inline">
                            <li><b>Clss (R$):</b> <span id="valorClss"></span></li>
                            <li><b>Pis (R$):</b> <span id="valorPis"></span></li>
                            <li><b>Cofins (R$):</b> <span id="valorCofins"></span></li>
                            <li><b>Ir (R$):</b> <span id="valorIr"></span></li>
                            <li><b>Inss (R$):</b> <span id="valorInss"></span> </li>
                        </ul>
                    </div>

                </div>


                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="row"> 
                                <h4 class="text-center">Cliente  <button class="btn btn-primary btn-xs" ng-click="listaClienteTroca()">Trocar Cliente</button> <button class="btn btn-warning btn-xs" ng-click="limparDadosCliente()">Limpar dados de cliente</button></h4>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nome: <span id="nomeObrigatorio">*</span></label><input id="cliCupomNome" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email: </label><input id="cliCupomEmail" class="form-control">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Tipo de Pessoa:*</label>
                                        <select name="tipoPessoaNota" id="tipoPessoaNota" class="form-control">
                                            <option value="F">Física</option>
                                            <option value="J">Juridica</option>
                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>CPF: <span id="CPFObrigatorio">*</span></label>


                                        <input type="text" name="cliCupomCPF" id="cliCupomCPF" class="form-control" placeholder="{{'cpf' | translate }}">


                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Inscrição Estadual: <small>Obrigatório caso o cliente seja pessoa jurídica</small></label><input id="cliCupomIE" class="form-control" type="text">

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Inscrição Municipal:</label><input id="cliCupomIM" class="form-control" type="number">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Estado: <span id="EstadoObrigatorio">*</span> </label>
                                        <select name="cliCupomUF" id="cliCupomUF" class="form-control">

                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Cidade: <span id="CidadeObrigatorio">*</span></label><input id="cliCupomCidade" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CEP: <span id="CepObrigatorio">*</span></label><input id="cliCupomCEP" class="form-control" onKeyPress="mascara(this,soCep)" placeholder="{{'cep' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group"><label>Bairro: <span id="BairroObrigatorio">*</span></label><input id="cliCupomBairro" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Logradouro: <span id="LogradouroObrigatorio">*</span></label><input id="cliCupomLogradouro" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número: <span id="NumeroObrigatorio">*</v></label><input id="cliCupomNumero" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Complemento: </label><input id="cliCupomComplemento" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Observação: </label><textarea id="cliCupomObs" class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row" style="display:none;">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Metadata: </label><textarea id="cliCupomMetadata" class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <small>(*) Campos obrigatórios</small>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning btn-block" data-dismiss="modal" aria-hidden="true">Fechar</button>
                    </div>
                    <div class="col-md-10">

                        <button id="btnCriaCupom" type="button" class="btn btn-success btn-block" ng-click="criaCupom()">Salvar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="comandaInsereGorjeta-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Gorjeta </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-success">
                        <div class="box-body">
                            <div class="row">

                                <div class="col-md-12">

                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label for="gorjeta">Valor</label>
                                                <input type="text" id="valorComandaGorjeta" class="form-control valorFormat">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label for="gorjeta">Profissional</label>
                                                <select name="profissionalGorjeta" id="profissionalGorjeta" class="form-control"></select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="buttton" class="btn btn-success" ng-click="insereComandaGorjeta()">Salvar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="comandaAlteraGorjeta-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Editar Gorjeta</h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-success">
                        <div class="box-body">
                            <input type="text" id="itemComandaGorjeta" hidden>
                            <div class="row">

                                <div class="col-md-12">

                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label for="gorjeta">Valor</label>
                                                <input type="text" id="valorComandaGorjetaAltera" class="form-control valorFormat">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label for="gorjeta">Profissional</label>
                                                <select name="profissionalGorjetaAltera" id="profissionalGorjetaAltera" class="form-control"></select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="buttton" class="btn btn-success" ng-click="alteraComandaGorjeta()">Salvar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="caixaMovimentacao-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-70">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Movimentações do Dia</h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-success">
                        <div class="box-body">
                            <button class="btn btn-default" ng-click="imprimirVerDia()"><i class="fa fa-print"></i></button>
                            <table id="listaMovDia" data-search-accent-neutralise="true" class="table-sm"></table>
                        </div>
                    </div>
                </div>
                <div class="box-body" style="display:none;">
                    <div class="box box-success">
                        <div class="box-body" id="printVerDia">
                            <table id="listaMovDiaPrint" class="table-sm" style="width:100%">
                                <thead>
                                    <th>Descricao</th>
                                    <th>Valor</th>
                                    <th>Valor Liquido</th>
                                    <th>Pagamento</th>
                                    <th>Bandeira</th>
                                </thead>
                                <tbody></tbody>
                                <tfoot></tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="reciboVale-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:99999">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Recibo Vale</h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-success">
                        <div class="box-body">

                            <div id="reciboValeImprimir" class="col-xs-12" style="margin: 5mm;">
                                <div class="text-center row">
                                    <h3>RECIBO DE VALE</h3>
                                </div>


                                <p style="text-align: justify">
                                    Declaro para os devidos fins o recebimento da quantia de <span id='valorReciboVale'></span> (<span id='valorExtensoReciboVale'></span>) referente a vale/adiantamento, efetuado na data <span id='dataReciboVale'></span>.
                                </p>
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="col-xs-4 col-xs-offset-1">
                                            <div class="text-center" style="border-bottom:solid;margin-top:30%;"></div>

                                            <div class="text-center">
                                                <label>
                                                    Gustavo Bezerra
                                                </label>

                                            </div>
                                        </div>
                                        <div class="col-xs-4  col-xs-offset-2">
                                            <div style="border-bottom:solid; margin-top:30%;"></div>
                                            <div class="text-center">
                                                <label id="nomeReciboVale"></label><br>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-xs-4 col-xs-offset-4 text-center">
                                        <span id="dataLocalReciboVale"> </span>
                                        <br>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <button class="btn btn-default btn-sm btn-block" ng-click="imorimeReciboVale()">Imprimir</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="generateCuponProduto-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-95">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-user"></i> Cupom - <span id="numComandaProd"></span> </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <h4 class="text-center">Emissão - Produto</h4>
                    <div class="col-md-2">

                        <!-- <input type="text" id="empresaCodigoNFProd" hidden> -->
                        <input type="text" id="cidCodigoEmpresaNotaProduto" hidden>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Valor:</label>
                                    <input type="text" disabled class="form-control" id="valorCupomDisplayProd"/>
                                    <span hidden id="valorCupomProd"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <div class="col-md-10">
                        <table class="table table-striped table-condensed">
                            <thead>
                                <th>Produto</th>
                                <th>Quantidade</th>
                                <th>Valor</th>
                                <th>CFOP</th>
                            </thead>
                            <tbody id="tableItensNfProduto">
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Natureza</label>
                            <select name="naturezaNotaProduto" id="naturezaNotaProduto" class="form-control">
                                <option value="Venda">Venda</option>
                                <option value="Bonificacao">Bonificação</option>
                                <option value="Remessa">Remessa</option>
                                <option value="Exportacao">Exportação</option>
                                <option value="Industrializacao">Industrialização</option>
                                <option value="Baixa de estoque por perda ou extravio">Baixa de estoque por perda ou extravio</option>
                                <option value="Devolucao de compra">Devolução de compra</option>
                                <option value="Transferencia entre Filiais">Transferência entre Filiais</option>
                                <option value="Uso e Consumo">Uso e Consumo</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="ok">Enviar via Email?</label>
                            <select name="enviaCupomEmailProd" id="enviaCupomEmailProd" class="form-control">
                                <option value="0">Não</option>
                                <option value="1">Sim</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="ok">Tipo de Pessoa</label>
                            <select name="tipoPessoaEmitProd" id="tipoPessoaEmitProd" class="form-control">
                                <option value="F">Física</option>
                                <option value="J">Jurídica</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="ok">Usar endereço</label>
                            <select name="usaEnderecoProd" id="usaEnderecoProd" class="form-control">
                                <option value="0">Cliente</option>
                                <option value="1">Empresa</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Competência:</label><small> Apenas caso deseje mudar a data da emissão</small>
                            <div class="input-group date divDataCompetenciaProd">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" id="dataCompetenciaProd" name="dataCompetenciaProd" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'"/>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" id="optTransporteNota" style="display:none">
                     <div class="col-md-4">
                        <div class="form-group">
                            <label for="ok">CNPJ</label>
                            <select name="empresaCodigoNFProd" id="empresaCodigoNFProd" class="form-control" style="width: 100%;"></select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label>Ocorrência de transporte</label>
                        <select name="transporteNotaProd" id="transporteNotaProd" class="form-control">
                            <option value="SemOcorrenciaDeTransporte">Não</option>
                            <option value="ContratacaoPorContaDoRemetente">Contratação por conta do Remetente</option>
                            <option value="ContratacaoPorContaDoDestinatario">Contratação por conta do Destinatário</option>
                            <option value="ContratacaoPorContaDeTerceiros">Contratação por conta de Terceiros</option>
                            <option value="TransporteProprioPorContaDoRemetente">Transporte por conta do Remetente</option>
                            <option value="TransporteProprioPorContaDoDestinatario">Transporte por conta do Destinatário</option>
                        </select>
                    </div>
                </div>
                <div class="row divDadosTransporte">
                    <hr>
                    <div class="col-md-12">
                        <h5>O endereço de entrega será o endereço informado nos dados do cliente</h5>
                    </div>
                    <div class="col-md-4">
                        <label>Transportadora</label>
                        <select name="transportadoraNotaProd" id="transportadoraNotaProd" class="form-control">
                        
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>UF Veículo</label>
                        <select class="form-control" name="veiculoTranspoteNotaProd" id="veiculoTranspoteNotaProd"></select>
                    </div>
                    <div class="col-md-4">
                        <label>Placa Veículo</label>
                        <input type="text" class="form-control" name="placaVeiculoTranspoteNotaProd" id="placaVeiculoTranspoteNotaProd">
                    </div>
                </div>
                <div class="row divDadosTransporte">
                    <div class="col-md-4">
                        <label>Quantidade</label>
                        <input type="number" class="form-control" id="qtdTransporteNota" name="qtdTransporteNota">
                    </div>
                    <div class="col-md-4">
                        <label>Espécie</label>
                        <select name="especieTransporteNotaProd" id="especieTransporteNotaProd" class="form-control">
                            <option value="caixa">Caixa</option>
                            <option value="envelope">Envelope</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>Marca</label>
                        <input type="text" class="form-control" id="marcaTransporteNotaProd" name="marcaTransporteNotaProd">
                     
                    </div>
                </div>
                <div class="row divDadosTransporte">
                    <div class="col-md-4">
                        <label>Numeração</label>
                        <input type="text" class="form-control" id="numeracaoTransporteNotaProd" name="numeracaoTransporteNotaProd">
                     
                    </div>
                    <div class="col-md-4">
                        <label>Peso Bruto</label>
                        <input type="number" class="form-control" id="pesoBrutoNotaProd" name="pesoBrutoNotaProd">
                    </div>
                    <div class="col-md-4">
                        <label>Peso Líquido</label>
                        <input type="number" class="form-control" id="pesoLiquidoNotaProd" name="pesoLiquidoNotaProd">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <h4 class="text-center">Cliente</h4>
                            <div class="row"> 
                                <h4 class="text-center">Cliente  <button class="btn btn-primary btn-xs" ng-click="listaClienteTrocaProduto()">Trocar Cliente</button> <button class="btn btn-warning btn-xs" ng-click="limparDadosClienteProduto()">Limpar dados de cliente</button></h4>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nome: <span id="nomeObrigatorioProd">*</span></label><input id="cliCupomNomeProd" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Email: </label><input id="cliCupomEmailProd" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CPF: <span id="CPFObrigatorioProd">*</span></label><input id="cliCupomCPFProd" class="form-control" placeholder="{{'cpf' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Inscrição Estadual: <small>Obrigatório caso o cliente seja pessoa jurídica</small></label><input id="cliCupomIEProd" class="form-control" type="text">

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Inscrição Municipal:</label><input id="cliCupomIMProd" class="form-control" type="number">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Estado: <span id="EstadoObrigatorioProd">*</span> </label>
                                        <select name="cliCupomUFProd" id="cliCupomUFProd" class="form-control">

                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Cidade: <span id="CidadeObrigatorioProd">*</span></label><input id="cliCupomCidadeProd" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CEP: <span id="CepObrigatorioProd">*</span></label><input id="cliCupomCEPProd" class="form-control" onKeyPress="mascara(this,soCep)" placeholder="{{'cep' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group"><label>Bairro: <span id="BairroObrigatorioProd">*</span></label><input id="cliCupomBairroProd" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Logradouro: <span id="LogradouroObrigatorioProd">*</span></label><input id="cliCupomLogradouroProd" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número: <span id="NumeroObrigatorioProd">*</v></label><input id="cliCupomNumeroProd" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Complemento: </label><input id="cliCupomComplementoProd" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Telefone: </label><input id="cliCupomTelefoneProd" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Informações Adicionais: </label><input id="cliCupomAdInfo" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <small>(*) Campos obrigatórios</small>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning btn-block" data-dismiss="modal" aria-hidden="true">Fechar</button>
                    </div>
                    <div class="col-md-10">
                        <button id="btnCriaCupomProd" type="button" class="btn btn-success btn-block" ng-click="criaCupomProd()">Salvar</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="generateCupomServicoPacote-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-70">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-user"></i> Cupom Pacote - <span class="nomePacoteEmissao"></span> </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <input type="hidden" id="ppaCodigoNotaPacote">
                    <h4 class="text-center">Emissão - Serviço</h4>
                    <div class="col-md-4">
                        <input type="text" id="empresaCNAENotaPacote" hidden>
                        <!-- <input type="text" id="empresaCodigoNFNotaPacote" hidden> -->
                        <input type="text" id="empresaCSTNotaPacote" hidden>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Valor:</label>
                                    <input type="text" disabled class="form-control" id="valorCupomDisplayNotaPacote"/>
                                    <input type="hidden" disabled class="form-control" id="valorComissaoDisplayNotaPacote"/>
                                    <span hidden id="valorCupomNotaPacote"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Serviços Prestados</label>
                                    <input type="text" disabled class="form-control" id="servicosPrestadosDisplayNotaPacote"/>
                                    <span hidden id="servicosPrestadosNotaPacote"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ok">Operação</label>
                                    <select name="servicoNaturezaNotaPacote" id="servicoNaturezaNotaPacote" class="form-control" style="width: 100%;"></select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ok">CNPJ</label>
                                    <select name="empresaCodigoNFNotaPacote" id="empresaCodigoNFNotaPacote" class="form-control" style="width: 100%;"></select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="ok">Enviar via Email?</label>
                                    <select name="enviaCupomEmailNotaPacote" id="enviaCupomEmailNotaPacote" class="form-control">
                                        <option value="0">Não</option>
                                        <option value="1">Sim</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="ok">Usar endereço</label>
                                    <select name="usaEnderecoNotaPacote" id="usaEnderecoNotaPacote" class="form-control">
                                        <option value="0">Cliente</option>
                                        <option value="1">Empresa</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" id="divCSTEmpresaNotaPacote">
                    <div class="col-md-12">
                        <ul class="list-inline">
                            <li><b>Clss (R$):</b> <span id="valorClssNotaPacote"></span></li>
                            <li><b>Pis (R$):</b> <span id="valorPisNotaPacote"></span></li>
                            <li><b>Cofins (R$):</b> <span id="valorCofinsNotaPacote"></span></li>
                            <li><b>Ir (R$):</b> <span id="valorIrNotaPacote"></span></li>
                            <li><b>Inss (R$):</b> <span id="valorInssNotaPacote"></span> </li>
                        </ul>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <h4 class="text-center">Cliente <button class="btn btn-primary btn-xs" ng-click="listaClienteTrocaPacote()">Trocar Cliente</button> <button class="btn btn-warning btn-xs" ng-click="limparDadosClientePacote()">Limpar dados de cliente</button></h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nome: <span id="nomeObrigatorioNotaPacote">*</span></label><input id="cliCupomNomeNotaPacote" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email: </label><input id="cliCupomEmailNotaPacote" class="form-control">
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Tipo de Pessoa:*</label>
                                        <select name="tipoPessoaNotaPacote" id="tipoPessoaNotaPacote" class="form-control">
                                            <option value="F">Física</option>
                                            <option value="J">Juridica</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>CPF: <span id="CPFObrigatorioNotaPacote">*</span></label><input id="cliCupomCPFNotaPacote" class="form-control" placeholder="{{'cpf' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Estado: <span id="EstadoObrigatorioNotaPacote">*</span> </label>
                                        <select name="cliCupomUFNotaPacote" id="cliCupomUFNotaPacote" class="form-control">

                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Cidade: <span id="CidadeObrigatorioNotaPacote">*</span></label><input id="cliCupomCidadeNotaPacote" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CEP: <span id="CepObrigatorioNotaPacote">*</span></label><input id="cliCupomCEPNotaPacote" class="form-control" onKeyPress="mascara(this,soCep)" placeholder="{{'cep' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group"><label>Bairro: <span id="BairroObrigatorioNotaPacote">*</span></label><input id="cliCupomBairroNotaPacote" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Logradouro: <span id="LogradouroObrigatorioNotaPacote">*</span></label><input id="cliCupomLogradouroNotaPacote" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número: <span id="NumeroObrigatorioNotaPacote">*</v></label><input id="cliCupomNumeroNotaPacote" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Complemento: </label><input id="cliCupomComplementoNotaPacote" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Observação: </label><textarea id="cliCupomObsNotaPacote" class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <small>(*) Campos obrigatórios</small>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning btn-block" data-dismiss="modal" aria-hidden="true">Fechar</button>
                    </div>
                    <div class="col-md-10">

                        <button id="btnCriaCupomNotaPacote" type="button" class="btn btn-success btn-block" ng-click="criaCupomNotaPacote()">Salvar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="generateCuponProdutoPacote-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-70">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-user"></i> Cupom Pacote - <span class="nomePacoteEmissao"></span> </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <h4 class="text-center">Emissão - Produto</h4>
                    <div class="col-md-12">

                        <!-- <input type="text" id="empresaCodigoNFProdNotaPacote" hidden> -->
                        <input type="text" id="ppaCodigoNotaPacoteProduto" hidden>
                        <input type="text" id="cidCodigoNotaProdutoPacote" hidden>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Valor:</label>
                                    <input type="text" disabled class="form-control" id="valorCupomDisplayProdNotaPacote"/>
                                    <span hidden id="valorCupomProdNotaPacote"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <table class="table table-striped table-condensed">
                        <thead>
                            <th>Produto</th>
                            <th>Quantidade</th>
                            <th>Valor</th>
                        </thead>
                        <tbody id="tableItensNfProdutoNotaPacote">
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="ok">CNPJ</label>
                            <select name="empresaCodigoNFProdNotaPacote" id="empresaCodigoNFProdNotaPacote" class="form-control" style="width: 100%;"></select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="ok">Enviar via Email?</label>
                            <select name="enviaCupomEmailProdNotaPacote" id="enviaCupomEmailProdNotaPacote" class="form-control">
                                <option value="0">Não</option>
                                <option value="1">Sim</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="ok">Natureza</label>
                            <select name="naturezaNotaProdutoPacote" id="naturezaNotaProdutoPacote" class="form-control input-sm">
                            <option value="Venda">Venda</option>
                                <option value="Bonificacao">Bonificação</option>
                                <option value="Remessa">Remessa</option>
                                <option value="Exportacao">Exportação</option>
                                <option value="Industrializacao">Industrialização</option>
                                <option value="Baixa de estoque por perda ou extravio">Baixa de estoque por perda ou extravio</option>
                                <option value="Devolucao de compra">Devolução de compra</option>
                                <option value="Transferencia entre Filiais">Transferência entre Filiais</option>
                                <option value="Uso e Consumo">Uso e Consumo</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="ok">Usar endereço</label>
                            <select name="usaEnderecoProdNotaPacote" id="usaEnderecoProdNotaPacote" class="form-control">
                                <option value="0">Cliente</option>
                                <option value="1">Empresa</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <h4 class="text-center">Cliente</h4>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nome: <span id="nomeObrigatorioProdNotaPacote">*</span></label><input id="cliCupomNomeProdNotaPacote" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Email: </label><input id="cliCupomEmailProdNotaPacote" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CPF: <span id="CPFObrigatorioProdNotaPacote">*</span></label><input id="cliCupomCPFProdNotaPacote" class="form-control" maxlength="14" onKeyPress="mascara(this,soCpf)" placeholder="{{'cpf' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Estado: <span id="EstadoObrigatorioProdNotaPacote">*</span> </label>
                                        <select name="cliCupomUFProdNotaPacote" id="cliCupomUFProdNotaPacote" class="form-control">

                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Cidade: <span id="CidadeObrigatorioProdNotaPacote">*</span></label><input id="cliCupomCidadeProdNotaPacote" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CEP: <span id="CepObrigatorioProdNotaPacote">*</span></label><input id="cliCupomCEPProdNotaPacote" class="form-control" onKeyPress="mascara(this,soCep)" placeholder="{{'cep' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group"><label>Bairro: <span id="BairroObrigatorioProdNotaPacote">*</span></label><input id="cliCupomBairroProdNotaPacote" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Logradouro: <span id="LogradouroObrigatorioProdNotaPacote">*</span></label><input id="cliCupomLogradouroProdNotaPacote" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número: <span id="NumeroObrigatorioProdNotaPacote">*</v></label><input id="cliCupomNumeroProdNotaPacote" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Complemento: </label><input id="cliCupomComplementoProdNotaPacote" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Telefone: </label><input id="cliCupomTelefoneProdNotaPacote" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <small>(*) Campos obrigatórios</small>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning btn-block" data-dismiss="modal" aria-hidden="true">Fechar</button>
                    </div>
                    <div class="col-md-10">

                        <button id="btnCriaCupomProd" type="button" class="btn btn-success btn-block" ng-click="criaCupomProdPacote()">Salvar</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="jornadaProfissional-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-70">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i> Jornada <span class="nomePacoteEmissao"></span> </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <select name="profissionalJornadaSelect" id="profissionalJornadaSelect" class="form-control"></select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <button class="btn btn-success btn-block" ng-click="buscaPessoaJornadaLista()"><i class="fa fa-search"></i> Pesquisar</button>
                    </div>
                </div>
                <div class="row" id="divBotaoMaisJornada">
                    <div class="col-md-12">
                        <button class="btn btn-primary" ng-click="novoHorarioTrabalho()" id="addHorarioJornada" style="margin:5px"><i class="fa fa-plus"></i> Horário de Trabalho</button>
                    </div>
                </div>
                <div class="row" id="divTabelaJornada">
                    <div class="col-md-12">
                        <table class="table table-condensed table-striped" id="tabelaJornadaProfissional" style="width:100%"></table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editarJornadaProfissional-modal" tabindex="-1" role="dialog" aria-hidden="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title"><strong>Jornada</strong>&nbsp&nbsp</h4>
            </div>

            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Dia da Semana</label>
                            <br>
                            <input type="hidden" id="pesCodigoJornada">
                            <select id="jornadaDiaSemana" name="jornadaDiaSemana" style="width:100%;" class="form-control" required disabled>
                                <option value="1">Domingo</option>
                                <option value="2">Segunda-feira</option>
                                <option value="3">Terça-feira</option>
                                <option value="4">Quarta-feira</option>
                                <option value="5">Quinta-feira</option>
                                <option value="6">Sexta-feira</option>
                                <option value="7">Sábado</option>

                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Entrada* (Período 1)</label>
                            <input type="text" id="jornadaHoraIni1" name="jornadaHoraIni1" class="form-control timepicker" placeholder="Ex: 8:00"/>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Saída* (Período 1)</label>
                            <input type="text" id="jornadaHoraFim1" name="jornadaHoraFim1" class="form-control timepicker" placeholder="Ex: 12:00"/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Entrada* (Período 2)</label>
                            <input type="text" id="jornadaHoraIni2" name="jornadaHoraIni2" class="form-control timepicker" placeholder="Ex: 13:30"/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Saída* (Período 2)</label>
                            <input type="text" id="jornadaHoraFim2" name="jornadaHoraFim2" class="form-control timepicker" placeholder="Ex: 18:30"/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <button class="btn btn-block btn-success" ng-click="edtJornadaProfissional()">Salvar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cadastrarJornadaProfissional-modal" tabindex="-1" role="dialog" aria-hidden="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title"><strong>Horário de Trabalho</strong>&nbsp&nbsp</h4>
            </div>

            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Dia da Semana</label>
                            <br>
                            <input type="hidden" id="pesCodigoJornadaInsere">
                            <select id="jornadaDiaSemanaInsere" name="jornadaDiaSemanaInsere" style="width:100%;" class="form-control" required>
                                <option value="1">Domingo</option>
                                <option value="2">Segunda-feira</option>
                                <option value="3">Terça-feira</option>
                                <option value="4">Quarta-feira</option>
                                <option value="5">Quinta-feira</option>
                                <option value="6">Sexta-feira</option>
                                <option value="7">Sábado</option>

                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Entrada* (Período 1)</label>
                            <input type="text" id="jornadaHoraIni1Insere" name="jornadaHoraIni1Insere" class="form-control timepicker" placeholder="Ex: 8:00"/>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Saída* (Período 1)</label>
                            <input type="text" id="jornadaHoraFim1Insere" name="jornadaHoraFim1Insere" class="form-control timepicker" placeholder="Ex: 12:00"/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Entrada* (Período 2)</label>
                            <input type="text" id="jornadaHoraIni2Insere" name="jornadaHoraIni2Insere" class="form-control timepicker" placeholder="Ex: 13:30"/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hora Saída* (Período 2)</label>
                            <input type="text" id="jornadaHoraFim2Insere" name="jornadaHoraFim2Insere" class="form-control timepicker" placeholder="Ex: 18:30"/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <button class="btn btn-block btn-success" ng-click="InsereJornadaProfissional()">Salvar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="sorteioCliente-modal" tabindex="-1" role="dialog" aria-hidden="false">
    <div class="modal-dialog modal-starapp-70">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title"><strong>Sorteio</strong>&nbsp&nbsp</h4>
            </div>

            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div id="sorteioCliente">

                            <div class="sorteiowrapper">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="namesSorteio"></div>
                                        <div id="winnerSorteio"></div>
                                        <a href="#" id="rollSorteio">Carregando Clientes...</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="infoProdutoModal-modal" tabindex="-1" role="dialog" aria-hidden="false" data-backdrop="static" data-keyboard="false" style='z-index:999998'>
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header  text-center">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="nomeProdutoScan">Informações do Produto</h3>
            </div>

            <div class="modal-body flip-card-prod">
                <div class="row flip-card-prod-inner" id="flipCardprod">
                    <div class="col-md-12 text-center flip-card-prod-front">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <i class="fa fa-exclamation-triangle fa-2x" aria-hidden="true" style="color:orange"></i>
                                <h3> Para utilizar essa opção é necessário um leitor de código de barras compatível!</h3>

                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h3>Para mostrar as informações do produto, aproxime o código de barras do leitor e realize o escanemento.</h3>
                                <i class="fa fa-barcode fa-5x" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 text-center flip-card-prod-back" id="cardbackfaceprod">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="" class="img-responsive img-circle" style="padding: 0 20px; margin: 30px 0px 40px;" id="imagemProdutoScan" data-pagespeed-url-hash="83945255" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                            </div>
                            <div class="col-md-6" style="padding-top: 30px;">
                                <div class="row">

                                    <p>
                                        <h4 class="info-produto-scan-title"><strong>Marca:</strong><br><label class="info-produto-scan" id="marcaProdutoScan"></label>
                                    </p>
                                    <p>
                                        <h4 class="info-produto-scan-title"><strong>Categoria:</strong> <br><label class="info-produto-scan" id="modeloProdutoScan"></label>
                                    </p>
                                    <p>
                                        <h4 class="info-produto-scan-title"><strong>Quantidade em Estoque:</strong> <br><label class="info-produto-scan" id="qtdEmEstoqueProdutoScan"></label>
                                    </p>

                                    <p>
                                        <h4 class="info-produto-scan-title"><strong>Valor:</strong> <br><label class="info-produto-scan" id="valorProdutoScan"></label>
                                    </p>
                                    <p>
                                        <h4 class="info-produto-scan-title"><strong>Valor para Profissional:</strong> <br><label class="info-produto-scan" id="valorProfProdutoScan"></label>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" data-dismiss="modal" class="btn btn-primary">Fechar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="profissionalComissaoBarCode-modal" tabindex="-1" role="dialog" aria-hidden="false" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">

            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">Selecione o profissional que irá receber a comissão:</h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-dismiss="modal"><i class="fa fa-times"></i></button>
                    </div>
                </div>

                <div class="box-body no-padding">
                    <ul class="users-list clearfix" id="profissionaisComissaoBarCodeList">

                        <li ng-model="listProfissionaisComissaoCodigoBarras" ng-repeat="profissional in listProfissionaisComissaoCodigoBarras">
                            <div class="box box-primary pointer" ng-click="insereProdutoComissionadoComanda(profissional)">
                                <div class="box-body box-profile">
                                    <img class="profile-user-img-70 img-responsive img-circle" width="70" src="{{profissional.imagem}}" alt="{{profissional.apelido}}" data-pagespeed-url-hash="2701130328" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                                    <h5 class="text-center">{{profissional.apelido}}</h5>
                                    <p class="text-muted text-center">{{profissional.comissao}}%</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="contratacaoPixQRCode-modal" tabindex="-1" role="dialog" aria-hidden="false" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title"><strong>PIX</strong> - Detalhes da Transação</h4>
            </div>

            <div class="modal-body">

                <div class="row">
                    <div class="col-md-12 text-center">
                        <p>
                            <h3>Valor: <label id="txtValorPIX">R$ 538,80 </label><h3>
                        </p>
                        <p><h4> Instruções: </h4></p>
                        <p>1. Copie ou digitalize o código usando o seu telefone celular</p>
                        <p>2. Abra seu app de pagamentos ou Internet Banking</p>
                        <p>3. Busque a opção de pagamentos via PIX (QRCode ou CopiaECola)</p>
                        <p>4. Conclua o pagamento pelo seu app ou internet banking</p>
                        <p>5. Pronto!</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="box box-default">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12 text-center" id="pix-qrcode"></div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-12 text-center" id="divPixCopiaECola"></div>
                                </div>
                            </div>

                            <div class="overlay overlay-qrcode-pix">
                                <i class="fa fa-refresh fa-spin"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="pixMonthly-modal" tabindex="-1" role="dialog" aria-hidden="false" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">Pague seu plano mensal com <strong>PIX</strong>.</h4>
            </div>

            <div class="modal-body">

                <div class="row">
                    <div class="col-md-12 text-center">
                        <p>
                            <h3>Plano: <label id="txtPlanoPIXMonthly"></label><h3>
                        </p>
                        
                        <p>
                            <h3>Valor: <label id="txtValorPIXMonthly"></label><h3>
                        </p>
                        <br>
                        <p>
                            <h5>Observações: </h5>
                        </p>
                        <p class="text-muted">Caso já tenha efetuado o pagamento do seu plano por Boleto ou Cartão de Crédito e ainda não foi compensado, não é necessário fazer o novo pagamento.</p>
                        <p class="text-muted">Após realizar o pagamento do PIX, atualize sua página para confirmar o pagamento do plano.</p>
                        <p class="text-muted">O QRCode gerado tem validade de 30 minutos.</p>
                        <br>
                        <br>
                        <button type="button" class="btn btn-primary" id="btnGeraPixMonthly"><i class="fa fa-qrcode"></i> Gerar QRCode</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="verDadosCartao-modal" tabindex="-1" role="dialog" aria-hidden="false" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title"><strong>Cartão de Crédito</strong> - Detalhes</h4>
            </div>

            <div class="modal-body">

                <div class="box box-success">
                    <div class="box-header">
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <dl class="dl-horizontal">
                                    <dt>Número:</dt>
                                    <dd><label id="txtDadosCartaoNumber"></label></dd>
                                    <dt>Nome no Cartão:</dt>
                                    <dd><label id="txtDadosCartaoHolderName"></label></dd>
                                    <dt>Expiração:</dt>
                                    <dd><label id="txtDadosCartaoExp"></label></dd>
                                    <dt>Bandeira:</dt>
                                    <dd><label id="txtDadosCartaoBrand"></label>
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>

                    <div class="overlay overlayDadosCartao">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="cadastraVale-modal" tabindex="-1" role="dialog" aria-hidden="true" style='z-index:9999'>
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-barcode"></i> Vale </h4>
            </div>
            <input type="hidden" id="codigoCaixaVale">
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-danger">
                        <div class="box-body">
                            <div class="row" hidden>
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group ">
                                        <label>Destino do Lançamento*</label>
                                        <select name="destinoVale" id="destinoVale" class="form-control" disabled>
                                            <option value="1">Caixa</option>
                                            <option value="2">Financeiro</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group ">
                                        <label>Valor*</label>
                                        <input type="text" min="0.00" step="0.01" max="2500" name="valorValeProfissional" id="valorValeProfissional" class="form-control" onkeyup="formataValorDinheiro(this);" placeholder="Valor" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12  col-sm-12">
                                    <div class="form-group ">
                                        <label>Tipo de Vale*</label><br>

                                        <div class="input-group">
                                            <span class="input-group-btn">

                                                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#novovale-modal">
                                                    <i class="fa fa-plus"></i>
                                                </button>
                                            </span>
                                            <select name="buscaTipoVale" id="buscaTipoVale" class="form-control" style="width:100%;"></select>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Forma de Pagamento</label>
                                        <select class="form-control " id="tipoPagamentoVale"></select>
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="divDataFinVale">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Data*</label>
                                        <div class="input-group date divDataFinVale">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" name="finDataVale" id="finDataVale" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Conta</label>
                                        <select name="buscaContaValeFin" id="buscaContaValeFin" class="form-control input-sm">
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-12  col-sm-12">
                                    <div class="form-group ">
                                        <label>Profissional</label><br>
                                        <select name="profissionalSelVale" id="profissionalSelVale" class="form-control" style="width:100%;"></select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12  col-sm-12">
                                    <div class="form-group ">
                                        <label>Observação</label><br>
                                        <input type="text" name="profissionalObsVale" id="profissionalObsVale" class="form-control" style="width:100%;"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-success" id="btnSalvaMovimentacaoVale" ng-click="salvaValeProfissional()">Lançar Vale</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="novovale-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:999999">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-ticket"></i> Novo Vale </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="box box-danger">
                        <div class="box-header" data-toggle="tooltip">
                            <h3 class="box-title">Dados do Vale</h3>
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Descrição*</label>
                                        <input type="text" name="DescricaoValeSistema" id="DescricaoValeSistema" class="form-control" placeholder="Exemplo: Vale Profissionais" required>
                                        <input type="hidden" name="indicaValeSistema" id="indicaValeSistema" class="form-control" value="1" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>(*) Campos Obrigatórios.</label>
                        </div>
                        <div class="box-footer">
                            <button type="button" class="btn btn-primary" ng-click="cadastrarValeSistema()">Cadastrar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="semSaidaCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:999999;">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content" style="border-radius: 10px;">
            <div class="modal-body">
                <div class="box-body text-center">
                    <h4> <i class="fa fa-exclamation-triangle fa-3x" style="color: orange;"></i></h4>
                    <h3>
                        Não existe uma saída para o proximo caixa
                    </h3>

                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h3>
                                Você deseja passar algum valor (troco) para o próximo caixa que vai ser aberto?
                            </h3><br>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 text-center">
                            <button class="btn btn-danger btn-block btn-lg" style="margin-left: 10px; margin-right:10px" ng-click="fechaCaixaSemSaida()">Não</button>
                        </div>
                        <div class="col-md-6 text-center">
                            <button class="btn btn-success btn-block btn-lg" style="margin-left: 10px; margin-right:10px" ng-click="addSaidaProximoCaixa()">Sim</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="generateCupomAssinatura-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-70">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-user"></i> Cupom Assinatura - <span class="nomeAssinaturaEmissao"></span> </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <input type="hidden" id="apfCodigoNotaAssinatura">
                    <h4 class="text-center">Emissão - Serviço</h4>
                    <div class="col-md-4">
                        <input type="text" id="empresaCNAENotaAssinatura" hidden>
                        <!-- <input type="text" id="empresaCodigoNFAssinatura" hidden> -->
                        <input type="text" id="empresaCSTNotaAssinatura" hidden>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Valor:</label>
                                    <input type="text" disabled class="form-control" id="valorCupomDisplayNotaAssinatura"/>
                                    <input type="hidden" disabled class="form-control" id="valorComissaoDisplayNotaAssinatura"/>
                                    <span hidden id="valorCupomNotaAssinatura"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Serviços Prestados</label>
                                    <input type="text" disabled class="form-control" id="servicosPrestadosDisplayNotaAssinatura"/>
                                    <span hidden id="servicosPrestadosNotaAssinatura"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ok">Operação</label>
                                    <select name="servicoNaturezaNotaAssinatura" id="servicoNaturezaNotaAssinatura" class="form-control" style="width: 100%;"></select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ok">CNPJ</label>
                                    <select name="empresaCodigoNFAssinatura" id="empresaCodigoNFAssinatura" class="form-control" style="width: 100%;"></select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="ok">Enviar via Email?</label>
                                    <select name="enviaCupomEmailNotaAssinatura" id="enviaCupomEmailNotaAssinatura" class="form-control">
                                        <option value="0">Não</option>
                                        <option value="1">Sim</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="ok">Usar endereço</label>
                                    <select name="usaEnderecoNotaAssinatura" id="usaEnderecoNotaAssinatura" class="form-control">
                                        <option value="0">Cliente</option>
                                        <option value="1">Empresa</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" id="divCSTEmpresaNotaAssinatura" hidden>
                    <div class="col-md-12">
                        <ul class="list-inline">
                            <li><b>Clss (R$):</b> <span id="valorClssNotaAssinatura"></span></li>
                            <li><b>Pis (R$):</b> <span id="valorPisNotaAssinatura"></span></li>
                            <li><b>Cofins (R$):</b> <span id="valorCofinsNotaAssinatura"></span></li>
                            <li><b>Ir (R$):</b> <span id="valorIrNotaAssinatura"></span></li>
                            <li><b>Inss (R$):</b> <span id="valorInssNotaAssinatura"></span> </li>
                        </ul>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <h4 class="text-center">Cliente  <button class="btn btn-primary btn-xs" ng-click="listaClienteTrocaAssinatura()">Trocar Cliente</button> <button class="btn btn-warning btn-xs" ng-click="limparDadosClienteAssinatura()">Limpar dados de cliente</button></h4>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nome: <span id="nomeObrigatorioNotaAssinatura">*</span></label><input id="cliCupomNomeNotaAssinatura" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Email: </label><input id="cliCupomEmailNotaAssinatura" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CPF: <span id="CPFObrigatorioNotaAssinatura">*</span></label><input id="cliCupomCPFNotaAssinatura" class="form-control" maxlength="14" onKeyPress="mascara(this,soCpf)" placeholder="{{'cpf' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Estado: <span id="EstadoObrigatorioNotaAssinatura">*</span> </label>
                                        <select name="cliCupomUFNotaAssinatura" id="cliCupomUFNotaAssinatura" class="form-control">

                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Cidade: <span id="CidadeObrigatorioNotaAssinatura">*</span></label><input id="cliCupomCidadeNotaAssinatura" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CEP: <span id="CepObrigatorioNotaAssinatura">*</span></label><input id="cliCupomCEPNotaAssinatura" class="form-control" onKeyPress="mascara(this,soCep)" placeholder="{{'cep' | translate }}">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group"><label>Bairro: <span id="BairroObrigatorioNotaAssinatura">*</span></label><input id="cliCupomBairroNotaAssinatura" class="form-control">

                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Logradouro: <span id="LogradouroObrigatorioNotaAssinatura">*</span></label><input id="cliCupomLogradouroNotaAssinatura" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número: <span id="NumeroObrigatorioNotaAssinatura">*</v></label><input id="cliCupomNumeroNotaAssinatura" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Complemento: </label><input id="cliCupomComplementoNotaAssinatura" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Observação: </label><textarea id="cliCupomObsNotaAssinatura" class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <small>(*) Campos obrigatórios</small>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning btn-block" data-dismiss="modal" aria-hidden="true">Fechar</button>
                    </div>
                    <div class="col-md-10">

                        <button id="btnCriaCupomNotaAssinatura" type="button" class="btn btn-success btn-block" ng-click="criaCupomNotaAssinatura()">Salvar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="listaClienteTrocaNota-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <label>Cliente</label><br>
                                <select name="clienteListaTrocaNota" id="clienteListaTrocaNota" class="form-control select2" style="width:100%;"></select>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <button class="btn btn-primary btn-block" ng-click="buscaDadadosClienteTroca()">Salvar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="listaClienteTrocaNotaProduto-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <label>Cliente</label><br>
                                <select name="clienteListaTrocaNotaProduto" id="clienteListaTrocaNotaProduto" class="form-control select2" style="width:100%;"></select>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <button class="btn btn-primary btn-block" ng-click="buscaDadadosClienteTrocaProduto()">Salvar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="listaClienteTrocaNotaAssinatura-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <label>Cliente</label><br>
                                <select name="clienteListaTrocaNotaAssinatura" id="clienteListaTrocaNotaAssinatura" class="form-control select2" style="width:100%;"></select>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <button class="btn btn-primary btn-block" ng-click="buscaDadadosClienteTrocaAssinatura()">Salvar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="listaClienteTrocaNotaPacote-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <label>Cliente</label><br>
                                <select name="clienteListaTrocaNotaPacote" id="clienteListaTrocaNotaPacote" class="form-control select2" style="width:100%;"></select>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <button class="btn btn-primary btn-block" ng-click="buscaDadadosClienteTrocaPacote()">Salvar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="optCombrancaContaDigital-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-30">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h4 class="modal-title"> Como deseja cobrar? </h4>
            </div>
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row text-center">
                        <div class="col-md-6  col-sm-6" id="divCardButton">
                            <div class="form-group ">
                                <button class="btn bg-orange btn-block" ng-click="cobraContaDigitalCartao()"><i class="fa fa-credit-card fa-5x"></i> <br>Cartão de Crédito</button>
                            </div>

                        </div>
                        <div class="col-md-6  col-sm-6" id="divPixButton">
                            <div class="form-group ">
                                <button class="btn bg-orange btn-block" ng-click="cobraContaDigitalPix()"><i class="fa fa-qrcode fa-5x"></i> <br>PIX</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="button" class="btn btn-danger btn-block" data-dismiss="modal">Cancelar</button>
                </div>

            </div>
            
        </div>
    </div>
</div>

<div class="modal fade" id="qrCodePagamento-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-usd"></i> Comanda <b id="com_codigo_title_pix"></b> - PIX</h4>
            </div>
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row text-center">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <div class="text-center" id="qrcode-pagamento-comanda"></div>
                            </div>  
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="text-center" id="btnBaixarImagemQRCode_pix">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h3 id="label_timer_pix">Código PIX expira em: <span id="timer_pix">05:00</span></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confima_compra_credito-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-usd"></i> Comanda <b id="com_codigo_title_card"></b> - Cartão</h4>
            </div>
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row text-center">
                        <i class="fa fa-exclamation-triangle fa-5x" style="color:#ff851b"></i>
                        <h3>Uma tentativa de cobrança será lançada no cartão vinculado a conta do cliente.</h3><br>
                        <p>Para mais detelhes sobre a cobrança você pode consultar a conta digital posteriormente</p>
                        <hr>
                        <button class="btn bg-orange" ng-click="pay_invoice_with_card()">Prosseguir</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="param_modal-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-60">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-cog"></i> Parâmetros de assinatura</h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                    <table id="params_table" class="table table-bordered table-striped" style="width:100%;"></table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="calcularPlanos-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">
                    <i class="fa fa-calculator"></i> Sugestão para Precificação dos Planos
                </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 text-right">
								<button type="button" class="btn btn-info" data-toggle="modal" data-target="#videoModal">
									<i class="fa fa-video-camera"></i> Tutorial
								</button>
                            </div>
                        </div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Total de agendamentos (últimos 60 dias)</label>
									<input type="number" id="totalAtendimentos" class="form-control" ng-model="dados.totalAtendimentos" ng-change="validarInteiro('totalAtendimentos')" ng-keypress="bloquearNaoPositivos($event)" min="1" step="1" required>
									<!--<div class="input-group">
										<span class="input-group-btn">
											<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tabelaAgendamentos-modal">
												<i class="fa fa-table"></i> VER
											</button>
										</span>
									</div>-->
									<small class="text-muted">Considere apenas cortes, barbas e combos.</small>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Clientes únicos (últimos 60 dias)</label>
									<input type="number" id="clientesUnicos" class="form-control" ng-model="dados.clientesUnicos" ng-change="validarInteiro('clientesUnicos')" ng-keypress="bloquearNaoPositivos($event)" min="1" step="1" required>
									<small class="text-muted">Número de clientes distintos atendidos.</small>
								</div>
							</div>
						</div>
						<div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Valor do Corte</label>
									<select name="valorCorte" id="valorCorte" class="form-control"></select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-success btn-block" id="btnCalcular" ng-click="calcularPreco()">CALCULAR</button>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Plano de Corte</label>
                                    <input type="text" id="planoCorte" class="form-control" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Plano de Barba</label>
                                    <input type="text" id="planoBarba" class="form-control" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Plano de Combo</label>
                                    <input type="text" id="planoCombo" class="form-control" readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="tabelaAgendamentos-modal" tabindex="-1" role="dialog" aria-hidden="true" width="20%">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">
                    <i class="fa fa-table"></i> Tabela de Agendamentos
                </h4>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
				<button type="button" class="btn btn-primary pull-right" data-dismiss="modal">Salvar</button>
                <label style="color: red">*Selecione apenas serviços de Corte, Barba e Combo.</label>
                <table id="tabelaTotalAgendamentos" class="table table-bordered table-striped" style="width:100%;">
                </table>
            </div>
            <div class="modal-footer">
				<button type="button" class="btn btn-secondary pull-left" data-dismiss="modal">Fechar</button>
                <button type="button" class="btn btn-primary pull-left" data-dismiss="modal">Salvar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document" style="width: 50%;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="videoModalLabel">Vídeo Tutorial: Calculadora de Precificação de Clube - Gustavo Novva</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
        <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
          <iframe src="https://www.youtube.com/embed/IWaAHSDzaNc" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
          </iframe>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Entendi!</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="clientSwitchList-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:9010;">
    <div class="modal-dialog modal-starapp-40">
        <div class="modal-content">
            <div class="modal-body">
                <div class="box-body text-center">
                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <label>Cliente</label><br>
                                <select name="clientSwitchListSelect" id="clientSwitchListSelect" class="form-control select2" style="width:100%;"></select>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">
                                <button class="btn btn-primary btn-block" id="buscaDadadosClienteSwitch">Salvar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="listaComandaTotem-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:9010;">
    <div class="modal-dialog modal-starapp-60">
        <div class="modal-content">
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="form-group ">


                                <div class="nav nav-tabs-custom " id="allowInfoCli">
                                    <ul class="nav nav-tabs ">
                                        <li class="active"><a data-toggle="tab" data-target="#tab_comanda_totem">Comandas não atualizadas</a></li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="tab_comanda_totem">

                                            <table id="comandaTotemTable" class="table table-bordered table-striped" style="width:100%;"></table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="verListaCaixa-modal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:9010;">
    <div class="modal-dialog modal-starapp-90">
        
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-barcode"></i> Caixa Aberto </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="row">
                        <div class="col-lg-10 col-xs-10">
							<div class="form-group">
								<label>Caixas abertos:*</label>
								<select name="listaCaixaAberto" id="listaCaixaAberto" class="form-control">
								</select>
							</div>
						</div>
                        <div class="col-lg-2 col-xs-2">
							<div class="form-group">
                                <label>Ver caixa</label>
                                <button class="btn btn-primary btn-block" ng-click="VerCaixaAberto()">Ver caixa</button>
							</div>
						</div>
                        
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
							<div class="box box-success box-solid" id="caixaAberto">
								<div class="box-header with-border">
									<p>
										<h5 class="box-title">Usuário:
											<label id="lblNomeCaixaVer" class="lblNomeCaixaVer"></label>
										</h5>
									</p>
									<p>
										<h5 class="box-title">Data:
											<label id="lblDatCaixaVer" class="lblDatCaixaVer"></label>
										</h5>
									</p>
									<p>
										<h5 class="box-title">Valor Inicial:
											<label id="lblValorInicialCaixaVer" class="lblValorInicialCaixaVer"></label>
										</h5>
									</p>
								</div>
								<div class="box-body">
									<table id="boxMovCaixaHistoricoCaixaVer" data-search-accent-neutralise="true" class="table-sm"></table>
									<hr>
								</div>
								<div class="box-footer">
									<div class="row">
										<div class="col-md-6 col-md-offset-6">
											<div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-12" align="right" style="max-height:100px;overflow-y:scroll;">
                                                        <table class="divTotalizadorver table table-condensed table-striped" id="divTotalizadorver" name="divTotalizadorver"></table>
                                                    </div>
                                                </div>
												<div class="row">
													<h4 class="pull-right"> Saldo:
														<label id="lblTotalCaixaCaixaVer" class="lblTotalCaixaCaixaVer"></label>
													</h4>
												</div>
												<div class="row pull-right text-right">
													<label>
														<i data-toggle="tooltip" data-placement="top" title="Valor de movimentações que não constam como cartão" class="fa fa-question-circle" style="color:grey"></i>&nbsp Saldo Disponível:
														<label id="lblTotalCaixaDispCaixaVer" class="lblTotalCaixaDispCaixaVer"></label>
													</label>
													<br>
													<label>
														<i data-toggle="tooltip" data-placement="bottom" title="Total de movimentações desconsiderando as saídas e o valor inicial" class="fa fa-question-circle" style="color:grey"></i>&nbsp Total de Recebimentos:
														<label id="lblTotalCaixaReceCaixaVer" class="lblTotalCaixaReceCaixaVer"></label>
													</label>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="generateCupomConsumidor-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-starapp-95">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-user"></i> Cupom - <span id="numComandaNota"></span> </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h4 id="textEmit">Emissão</h4>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-condensed" style="width: 100%;">
                            <thead>
                                <th style="width: 5%;"></th>
                                <th style="width: 25%;">Item</th>
                                <th style="width: 10%;">QTD</th>
                                <th style="width: 10%;">Valor</th>
                                <th style="width: 45%;" id="headerTabelaItens"></th>
                            </thead>
                            <tbody id="tableNotaItem"></tbody>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <!-- <input type="text" id="CodigoNFEmpresa" hidden> -->
                        <div class="form-group">
                            <label>Valor:</label>
                            <input type="text" disabled class="form-control input-sm" id="notaValorDiplay"/>
                            <span hidden id="notaValorEmissao"></span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="ok">Enviar via Email?</label>
                            <select name="enviaEmailNota" id="enviaEmailNota" class="form-control input-sm">
                                <option value="0">Não</option>
                                <option value="1">Sim</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="ok">Usar endereço</label>
                            <select name="usaEnderecoNota" id="usaEnderecoNota" class="form-control input-sm">
                                <option value="0">Cliente</option>
                                <option value="1">Empresa</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="ok">Natureza</label>
                            <select name="naturezaNota" id="naturezaNota" class="form-control input-sm">
                                <option value="Venda">Venda</option>
                                <option value="Bonificacao">Bonificação</option>
                                <option value="Remessa">Remessa</option>
                                <option value="Exportacao">Exportação</option>
                                <option value="Industrializacao">Industrialização</option>
                                <option value="Baixa de estoque por perda ou extravio">Baixa de estoque por perda ou extravio</option>
                                <option value="Devolucao de compra">Devolução de compra</option>
                                <option value="Transferencia entre Filiais">Transferência entre Filiais</option>
                                <option value="Uso e Consumo">Uso e Consumo</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Tipo de Pessoa:*</label>
                            <select name="tipoPessoaNotaConsumidor" id="tipoPessoaNotaConsumidor" class="form-control">
                                <option value="F">Física</option>
                                <option value="J">Juridica</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="ok">CNPJ</label>
                            <select name="CodigoNFEmpresa" id="CodigoNFEmpresa" class="form-control" style="width: 100%;"></select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <h5 class="text-center">Cliente <button class="btn btn-primary btn-xs" id="clientSwitchList">Trocar Cliente</button> <button class="btn btn-warning btn-xs" id="clearNotaCliente">Limpar dados de cliente</button></h5>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="validateNome">Nome: </label><input id="cliNomeNota" class="form-control input-sm dadosCli">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Email: </label><input id="cliEmailNota" class="form-control input-sm dadosCli">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="validateCPF">CPF: </label><input id="cliCPFNota" class="form-control input-sm dadosCli" maxlength="18" onKeyPress="mascara(this,soCpfCnpj)" placeholder="{{'cpf' | translate }}">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone: </label><input id="cliTelefoneNota" class="form-control input-sm dadosCli">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="validateEndereco">Estado: </label>
                                        <select name="cliUFNota" id="cliUFNota" class="form-control input-sm dadosCli"></select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="validateEndereco">Cidade: </label><input id="cliCidadeNota" class="form-control input-sm dadosCli">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="validateEndereco">CEP: </label><input id="cliCEPNota" class="form-control input-sm dadosCli" onKeyPress="mascara(this,soCep)" placeholder="{{'cep' | translate }}">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="validateEndereco">Bairro: </label><input id="cliBairroNota" class="form-control input-sm dadosCli">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label class="validateEndereco">Logradouro: </label><input id="cliLogradouroNota" class="form-control input-sm dadosCli">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="validateEndereco">Número: </label><input id="cliEndNumeroNota" class="form-control input-sm dadosCli">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Complemento: </label><input id="cliComplementoNota" class="form-control input-sm ">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Informações Adicionais: </label><input id="infoAdiNota" class="form-control input-sm">
                                    </div>
                                </div>
                               
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <small>(*) Campos obrigatórios</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning btn-block" data-dismiss="modal" aria-hidden="true">Fechar</button>
                    </div>
                    <div class="col-md-10">
                        <button type="button" class="btn btn-success btn-block" aria-hidden="true" id="btnEmiteNotaConsumidor">Emitir </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>	<script src="https://d3verit7xckkza.cloudfront.net/js/jquery.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/jquery-ui.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap/bootstrap.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/moment/moment-with-locales.min.js" type="text/javascript"></script>
	<script src="https://momentjs.com/downloads/moment-timezone-with-data.js" type="text/javascript"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script type="text/javascript">$.widget.bridge('uibutton',$.ui.button);$.widget.bridge('dialog',$.ui.dialog);</script> 
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/angularjs/angular.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/angularjs/angular-ui-router.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/angularjs/angular-translate.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/angularjs/angular-translate-loader-partial.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/angularjs/angular-translate-loader-static-files.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/angularjs/ocLazyLoad.min.js"></script>
	
	<script src="js/app.js,q34.pagespeed.jm.qRFBdKkNbo.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/intltelinput/intlTelInput.min.js" type="text/javascript"></script>


	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
	<script src="//unpkg.com/vanilla-masker@1.1.1/build/vanilla-masker.min.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/fullcalendar/fullcalendar2.js" type="text/javascript"></script>
	<!-- <script src="./js/fullcalendarmock.js" type="text/javascript"></script> -->
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/scrollTo/jquery.scrollTo.min.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/jquery.mask.min.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/timepicker/jquery.timepicker.min.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/contextmenu/jquery.contextMenu.min.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/contextmenu/jquery.ui.position.min.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/admin/app4.min.js?1" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/admin/demo.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/admin/funcoes.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/funcoes.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/movejs/movejs.min.js"></script>

	<!-- DATA TABES SCRIPT -->
	<script type="text/javascript" src="https://d3verit7xckkza.cloudfront.net/js/plugins/datatables/datatables.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
	<script src="https://cdn.datatables.net/buttons/1.0.3/js/buttons.colVis.min.js" type="text/javascript"></script>
	<script src="https://cdn.datatables.net/plug-ins/1.10.16/sorting/datetime-moment.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/datatables/accentneutralize.js"></script>
	<!-- SELECT2 -->
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/select2/select2.full.min.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/select2/i18n/pt-BR.js" charset="UTF-8"></script>

	<!-- HIGHCHARTS -->
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/highcharts/highcharts2.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/highcharts/modules/data2.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/highcharts/modules/heatmap2.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/highcharts/modules/accessibility2.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/highcharts/modules/drilldown2.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/highcharts/modules/exporting2.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/highcharts/modules/offline-exporting2.js"></script>

	<!-- SwalAlert -->
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/sweetalert/sweet-alert.min.js" type="text/javascript"></script>

	<!-- BOOTSTRAP TABLE -->
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap-table/js/bootstrap-table.min.js" defer charset="UTF-8"></script>
	<script src="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table-locale-all.min.js" defer charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap-table/js/bootstrap-table-editable.js" defer charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap-table/js/bootstrap-table-export.js" defer charset="UTF-8"></script>
	<script src="https://rawgit.com/vitalets/x-editable/master/dist/bootstrap3-editable/js/bootstrap-editable.js" defer></script>
	<script src="https://rawgit.com/hhurz/tableExport.jquery.plugin/master/tableExport.js"></script>
	<script src="https://unpkg.com/bootstrap-table@1.11.0/dist/extensions/accent-neutralise/bootstrap-table-accent-neutralise.min.js" defer charset="UTF-8"></script>

	<!-- TOASTR -->
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/toastr/toastr.min.js" charset="UTF-8"></script>       
	
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/daterangerpicker/daterangepicker.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/slimScroll/jquery.slimscroll1.min.js" type="text/javascript"></script>        
			
			
	<script defer src='https://d3verit7xckkza.cloudfront.net/js/plugins/datepicker/locales/bootstrap-datepicker.pt-BR.js' charset='UTF-8'></script>	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/typeahead/typeahead.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/iCheck/icheck.js" type="text/javascript"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/fileinput/fileinput.min.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/fileinput/pt-BR.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootbox/bootbox.min.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/underscore/underscore.min.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/jquery-stickytabs/jquery-stickytabs.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/jstree/jstree.min.js"></script>        
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/cropper/cropper.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/jQuery-Impromptu-master/src/jquery-impromptu.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/pagarme.min.js"></script>
	
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/mask-money/jquery.maskMoney.min.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap-select/js/bootstrap-select1.13.10.min.js" charset="UTF-8"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/js/ion.rangeSlider.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/nicelabel/jquery.nicelabel.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/offline.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/html2canvas/html2canvas.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/jspdf/jspdf.debug.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/boleto/boleto.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.4/clipboard.min.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/qrcode/qrcode.min.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/qrcode/jquery.qrcode.min.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/tagify/tagify.min.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/html2pdf/html2pdf.bundle.min.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/iro/iro.js"></script>
	<script defer src="https://d3verit7xckkza.cloudfront.net/js/plugins/onscan/onscan.min.js"></script>

	<script>$_CONFIG.HASACESSOINFOCLI='1';$_CONFIG.ID='3e73df994ff3d554ce5c355c62f62996';localStorage.setItem("SES_ID",'3e73df994ff3d554ce5c355c62f62996');$_CONFIG.ESTABELECIMENTO="Gustavo Bezerra";$_CONFIG.CODESTABELECIMENTO="25899313";$_CONFIG.APELIDOESTABELECIMENTO="gustavobezerra-mbs1";$_CONFIG.CODUSUARIO="25899314";$_CONFIG.PRIMEIROACESSO="0";$_CONFIG.MOEDA="";$_CONFIG.IMAGEM="";$_CONFIG.USUIMAGEM="";$_CONFIG.USUNOME="Gustavo Bezerra";$_CONFIG.PAIS="1";$_CONFIG.ISG="1";$_CONFIG.BASE64="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAB4CAYAAADblO/uAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjg3NTE0N0M0MEYyQTExRTU5Qzc1Q0IyNjAyQ0YyQkY0IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjg3NTE0N0M1MEYyQTExRTU5Qzc1Q0IyNjAyQ0YyQkY0Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QTlBREIyMDkwRjE5MTFFNTlDNzVDQjI2MDJDRjJCRjQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QTlBREIyMEEwRjE5MTFFNTlDNzVDQjI2MDJDRjJCRjQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5LThczAAARJElEQVR42uxdC4wsRRWtp/h98GTyghoSQfpFEIMizgYeiIg4qxGiQcysgUj8kMziJ/hB2Q2K8PII7EiMJgphN1GfgiTuJKCiRNlBokF+7igERBDe+CEGlM/wUxEUvHfmFlv066ru6e6a6Z49J7mZ3Znpqts199StulV1e8Ozzz6rAACYbLwATQAAIDoAACA6AAAgOgAAIDoAACA6AAAgOgAASbEbmmCycPKmI15ILweRHCyvAck+JK8m2Uzy8tAl/yJ5iOR+kr+SdEluJ7mVXy957Pr/oVXLjw3YMDMR5GZCv4fkXSSHk2zMqeh/ktxIcjXJVUT629HaIDowWnKzp/4IyQzJASOq9i6SZZIdRPoufgUQHfBD7g30cizJZ0hqY1anTfJ18fQwIhAdyIng7yfZTvKGgqn3B5KzSC4H4UF0ID3Jj6SXr5FMFVzVDo80iOzX4VcD0YHkBOcI+VdJPlwy1b9LcjoR/iH8iiA64Cb5e+nlWyR7lfQWHiA5hch+JX5NEB3YleAvFi/+qQm5pW+Kd38Kvy6IDgxIzhtafkhy2ITd2k0kxxPZ78evPD5gC2wxSH6QEOKwCbw9vqeb5R4BePR1S3Imws9JXpHwkt+TcGSbl7V4A8tOkh7JE+Q1n5QtsHuQ7EnyGpL91WBDzaEkW0leMqZbfZTk3aTjTfjVQfT1SPJfqF33n5t4muQqkh+QtIkoD2So72X08laSE9RgR93mEd8y76s/BmQH0dcTyatC8k2Wr9xLcgHJZXqpiq7hDuF1JPuSVEh2J3kRyePs0dUg2n03ff/eBPXzdceRfJbkqBHe+mNC9g6sAESfdJLvRy83kLwq4mPeQ8474C4leaUaHFQ5WmTfITznKsm1Ite5TqGRPuzlz1Gj21b7d5LDSac/wRpA9EklOXvhm0kODH30JMn5JN8geR/Jh0jeyb9RDtVyxPsyku+4TqCRbjyk5114+4ygKTjGcCjp8wSswj8QdR89dkSQnI+CcrDsPyR3yHdqOZGcwUt3nyO5jcj8Y5KtUV8i0l0uul00gnY4UO4TgEefOG/+CXq5MPT2BeLdFmSoPiq01GAzy70O78678/b0rMcnSYeLYB0g+qSQ/PX08juSl8pb/xYvexLJ28akFs/lzyCiXWjRmZfmfqIGAUBf4CnLIaTDnbASEL3sJOcp0i9JjpS3OPL8FZLPj8BjJsEVarA3vRehO++353X+QzzWz/sC3k71PwNrwRy9zPhYiOQcGDu3ICRn8Fn3G4jUr42Yt/OS3Tt4fu+x/iOljQB49NJ6c97x9keZf/Pml5+SHG/5+i0k15D8Rq75ixrseHuKytG73XgYzdtJee37aJXvppf71GD32m0R98H6c9BwP09N9Q+S/anuR2E1IHoZiX4OvZwt/14r3tHE30guJrmUjPzPQ5bNWXx5nf2jJB9Q+UTpH1SDNe57Iurj7Da8NLjRU3Nto3rPgdWA6GUj+Wbxyhtl6PvGkAf7shqsbT+VQ13s6beRnJiD6tzhHEF63RdRD6/vX+KpyTjr7L5IWoE5etnwcSH5/SGSL8owdTGvs9pUDm99PUmG81kztPJcvSUjhnA9vGNvh6f22ihtBoDopfHmnETiNPlXH1rhQNwJRJZTfc1FqVyO7r9FDdbJs4C3xZ5r+ex0NdhX7wOnSdsBIHopwAG3vcSbb5JXXkK6wnfF0ol8UA2y1WTBGVG76Kj8h+nlC57U30vZg5UAiF44nELCB0l4+ykHuI4igtwyqso59TIJr9Ofl6EYDu5dHDWEJ3xPDVYJfLUdAKIXftjOS1G8V/1JEV6yuntM6nwp45z64CjiSQ737Z50rkkbAiB64Yft7A37wSUixW/HpYgQkgNct2Yo5ouWeTPnuLvTk11i+A6iFx7HiSe/goi2Y9zKcIopNdhT/3TKIjgl1YkR5fKW1UVPah8LMwLRizxs55xt09K2ny6KXkRKPv6aJTh3quV93s77Xw8qHyNtCYDohcSbSHiYe2GSlE4jRlMNkjSmwVY5zRbuQHjjz9UedN1D2hIA0QsJPnLK8+Lzi6YYkfIRNchgkxa2XXdXe1J5K8wJRC8qONp+B5HqwYLq9+0sw2nL+9d4HB0BIHoh8WY1WGMuJCQh469TXn64ZKINg3PN++jY8NAHEL2w4J1d3y+4jj9LeR2niD44ovPgqcodHvTcD+YEohcOsoPsmRI8Z+xXGa49wPL+XR703NuyKw8A0ceKvdXg4ErRcXuGa/e3vH+PBz1509FmmBWIXjTwmfCHi66kHEpJe+bbtjXV1xlyEB1ELxw4bdQjJdE1rZ67W9739SAGHFnNAZj/5Av2lDeWRNcrVbpgl23PPEfzf+RBz8dhVjnMgZBKCgAwdAcAAEQHAABEBwAARAcAYDRA1L0k2Lb9vAq9VEX4b3X2WWfOQ2cARJ8Mgq+owYm4MNrQGcDQfXJQg84AiA4AAIgOAACIDgAgOgAAIDoAACA6AAAgOgAAI0PhN8ycvOkIvSZbjfi4w3LJY9f3UpQb0EsQKpvL6bJQmd0MOnsrOwrbtp+3y7r12Wed2c5Y5vN2tJntTWX3RvHbF0GHmPa22uQ49YtC4c6jC0nm1GDTRZDwshbJEhGobSmzKuVpw0lSbs8ot+PQ11vZYlS2H6grRlWPqaNJRtdNaMBMqIZIENfets7EoXObrpn2rYOj/mExT+U3qbzUNpm1w53koXslwY8cBhv7CpFumaQS8fkqyYJ8LxhSj1VHub7LdiFwkNysYycZ6kICknNZO+VegiTtTdcsCzHz8pRj1yFvmxyRfuUjepyHS9C4yx7U6hugeO8yla0xR8a26CBYQ9qtkkL3lTwMuQg62EBeuYg2WXqPruc5aVEj0jQ89eorMrUoU9kaDSLDnIVgWR59XM14fSF08G2Tco8gesT8M5MH8ziEWyxh2aZnrxgEC2SYHBdPiPs96lEBwYQkH7sOCe2wqDaZCEWNurelB2XZJUotc9qGNF7UkC1g75ggus3lzxs/ZCDewTUf4xFDncpujbFsjSVpq55IRYaKjZi5ZtMwvoojmDSvA3lGkGzBYcjtlATIW4ckZ96rMTEODmK2bDYZDnAaulltcpyEKnUWWCLFnONHn9ZRePqeNQpM35mOKLc/lFbRyyfPu85n2WJAQ0ewZYhuaxc20i3iSXfmXPYWJkBSnX3qEDOKiPsNOFo+m3KEYtWNytyAoXsKECGa4slsPXbacrnMGUfZtZSRcq9lGwbVdMwpA1mfdnmz+ZiyrbqnCFSNQ4dlh3200pI8gW4Yuifw3kFo+KOH9B3lIdEBl011thzD4JoMLQtVdmjYW3V0gjWHx48LPNnafNgOauQ6yOpDzVFmYpLLiCQI6e3NJieS6ELshlrbjBL1HeW592w7yBgUuGyl3FHiiqOOiqSCipvf5jGKGqkOEvluONpr2rWjTYjttEn6jm+bnAyiy7B1wfGDZPUiw6Bb0rKTlB842jOtN6rkRfS8dZDpim1Vg4k5ayO5zOmLYpPln6MbgapGEfTJuHlnbGXLXLGrAJOorhHCjG2qYFzbKHMbFC0YN6cyBNE8dTylK9vwYMAArh13szH70Qtlk6UfuovhuzYV8JpxVIBqUflbo/T5A/s2nrRt0lPpd4HldYAjNx1kn79tGsDLaEsxI4Gi2WTp5+iuOdm8LKVFdRBdj40axBhjUcuO60i6QoioNu/FnTDLEV51kEMyNqJ2EiyjOW1SltKi6u0WjehFGroHjvlsc0w6udZ5O0Ut29il5Srftc5eH1H7etNB2sAVfJvJYpM2kmOOnm1YH4yhzoajR+9mCab5LNsYOlYcnqwb05ksZpzjWzcxhU6Z+dQhbl7ezdiRBGUiepGG7t2YgMishzqrRLoFGUL2M9UYiSRcBy1aYy5bRRmxeMFGzJBzSTxSyzHE5LJX6XO9l75tLj0ZG0X0/XRCz1RzbWbhI6X9feS+dJBtqDWHnQVRJ/mGhC+b9ILC7HUXr70zwbyyGxpa1S0993Pzesd+9LTeakofmPFZthhtnuUzGaZCHUMeZ6XDe9gXVbLlqCn5DXPTQTqAVZXPWnY7ptMcyibHude9MB5dtoW6GjZQxVjLbOad821EZffCHkg86lIO7VqNIEhsmbJ23clZh7rKd8NKGWyydHP0eVXA7YPmsNdjYNBn2dym01GbQiTyvJSx/Io595bjnXFLbR2fOqwjmywf0SUINa38bw9N621nS1h2x0byENGyPrc87NVnYsjeHYEOmSHtVlSbLK1H12Sfkh992MbtqbXEA0k2b8RFnxnsnfhs+7BGmFfZ2tt1UhCco8tTSXKeyXLRFqmrN2Q9uxyL5cCZzNtnLbp3fOuQM9nzsMmxofCJJ4zjqdWYIaA1v3tccgjZlVcN1ZEoZ7zPsqMgS06VmPbInFdc0jJVHcbbHbaeUD70VoIEEbnrkAdCEX+nTRYlv3upM8wM0VkMlQWmKGUDwMQO3QEAANEBAADRAQAA0QEARAcAAEQHAKC0WBfLawAAjw4UErxRaBzn8At0/3VYAYi+HsCZR2vrlOTPPV+NH7vl6em4IDoAmJ6VZGWMKtTWa4eXJ3ZDEwAxcD3VxTuwjRhE9z101Acq+iejdB4345HN2sv0D1bQ50t6qKkGyQ/4MEMr9L4+CKGvaUbUyd9pG+/rp4ToAxQtI3NOuEyd7aRu6L5k6M7v6TzlLfmsK+83DFLre9aHTir0HZ1okXPaNWUOXQ+XFdGWOq1TJaR7XJ1muyi1lsxCP8Wln17KfMS0re0BRN1tRK8ZXkzn9p4SA1oVMmkD6+csI6PaQtfphIQttfYscp37m9Nk6SQG+jM2xnkxUP3dnlEnp8Naks/1KaiGWjuWGS5Tf0+XozOgbJG/V+S6nlrLtTYlHUkQuqe6fFaTcnWnpMudiyhr2iSqtEeg1pJK9ElI35mRjsNZp7Sp7mA6IT30/c4y2W1tP8YMwvDoRYd+rnqEt62IoU6HP5POgWWLPn5K7/XEGFuGN9a55vh1gV6bpsFGeDIV8vwqZPBmmUHE97XnrYvHND9bVWtpp7umBxSPq72jMkYmFd3BhL6vH1s0b3SW/Y7E0K/f4RkRdWedlt9mKTTaqUs729oeRAfRrR5de4Tw3LSu7Flaq2KgdSFj3Py2o9YSCSrlSJRhkKai3PnQOio6h5k+v94JRbB7yn2mWg+pw/epItqhbRJd12d6eMmE68rBZqvTBnOaEtn23Pl5zMMHopec5KtibO0QuVwkCyzEWVLxyQp7jqQZ5rC+q+Ij0FF19Yz7qIaI0lHDpWAKLPr2Ir7XteiSN1xt34NVg+hRqIv3mYkYRreEaE2Ld6lF5X6L2fjCnckiD1stD25oyJB7yRi6p8mN9rygYUi/xSHK0fqGPWUlRGw9p44iZVvlG8m3tj0wANbRLd7P8rRTJkn/wQxMfukA6kYnUBEPPCz42jlLnT2VX47yhtnpJHyia7g9dA60hVBHNhcazu/SHjI3r6rkD6kYpv3Stj08+nqERHDrEjTqmcNhWYrSUeq6eJL+kz/kMx4FLIfmwU0Vn6iS57WLEXX25LPlrLvD2NtJZHrVqKP/wIiE7bFqzH/5Prmz22no2jRHCzIfnxHv3zC+NyNtlaTjW1EJkjG62h5LbANgec0+Vw9kmN4nsy2go9eJdSRePJ9e226bEfGINeIgtBxVNQJLHeNaPbfWw96eECmqzIo5f474PwjV0dPeOnyd+Z4EBCtyT72Qvi1HjEHrHr7WWafRjl3zvXA95nu2tgdA9DSBOr2OrZd0nlvvRgsBGLpPBrS3aBgBJ5AcgEcHAGD8QNQdAEB0AABAdAAAQHQAAEB0AABAdAAA8sL/BRgA1GvYYEH8dvcAAAAASUVORK5CYII=";$_CONFIG.MOSTRANOTAPROFISSIONAIS=false;$_CONFIG.QTDPROFISSIONAIS="";$_CONFIG.TIMEZONE="";$_CONFIG.HASCONTASTAR=false;$_CONFIG.TAMANHOSLOT="";$_CONFIG.TEMPOPADRAO="15";$_CONFIG.INICIOAGENDA_PRINCIPAL="07:00:00";$_CONFIG.FIMAGENDA_PRINCIPAL="24:00:00";$_CONFIG.INICIOAGENDA_SECUNDARIO="7:00am";$_CONFIG.FIMAGENDA_SECUNDARIO="24:00pm";$_CONFIG.CONTAZOOP="";$_CONFIG.NOTSHOWINFODATES=false;$_CONFIG.LISTA_PAGAMAENTO='';$_CONFIG.LISTA_ESTADO='';$_CONFIG.CHATWIDGET="2";parTempo=$_CONFIG.TEMPOPADRAO;</script>
	

	<script src="js/js_app.js,q79.pagespeed.ce.52s5WMohPR.js" charset="UTF-8"></script>
	<script src="js/notaConsumidor.js,q2.pagespeed.ce.7F90kOrHfz.js" charset="UTF-8"></script>
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.pt-BR.js"></script>

	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/jszip/dist/jszip.min.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/jszip/dist/jsziputils.js" charset="UTF-8"></script>
	<script src="https://d3verit7xckkza.cloudfront.net/js/plugins/jszip/dist/FileSaver.js" charset="UTF-8"></script>
	<script type="text/javascript">isGestor=1;mPesCodigo=25899313;mCodigoRecebedor=1;sisCodigo=1;</script>

	<script type="text/javascript">var tag=document.createElement('script');tag.src="https://www.youtube.com/iframe_api";var firstScriptTag=document.getElementsByTagName('script')[0];firstScriptTag.parentNode.insertBefore(tag,firstScriptTag);$(function(){$("#primeiroAcesso-modal").modal();});</script>

	<script type="text/javascript">function validaSenha(){}</script>


		
	


	
		<script type="text/javascript" id="zsiqchat">var $zoho=$zoho||{};$zoho.salesiq=$zoho.salesiq||{widgetcode:"585c47126a4e188889804e981bd3525c32b7303c2fe9ea6c3327f9c45073d0887d07e3c3c334f4ffbc4621bb7d2959eb",values:{},ready:function(){}};var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);</script>
		<script>$zoho.salesiq.ready=function(){$zoho.salesiq.visitor.name("Gustavo Bezerra");$zoho.salesiq.visitor.email("profgustavobezerra10@gmail.com");$zoho.salesiq.visitor.id("25899314");$zoho.salesiq.visitor.info({'id':$_CONFIG.ID,'estabelecimento':"Gustavo Bezerra",'codigo':"25899314",'usuario':"9773107 ",'empresa':"25899313",'gestor':"1"});$zoho.salesiq.chat.waittime(900);$zoho.salesiq.visitor.chat(function(visitid,data){fetch('./php/crm/addNote.php').then(result=>result.json()).then((data)=>{});});}</script>
	
			
		
			            <script>function mascara(o,f){v_obj=o
v_fun=f
setTimeout("execmascara()",1)}function execmascara(){v_obj.value=v_fun(v_obj.value)}function soNumeros(v){return v.replace(/\D/g,"")}function soValorReal(v){v=v.replace(/\D/g,"");v=v.replace(/(\d)(\d{2})$/,"$1,$2");return v;}function soValorReal4(v){v=v.replace(/\D/g,"");v=v.replace(/(\d)(\d{4})$/,"$1,$2");return v;};function soValorReal3(v){v=v.replace(/\D/g,"");v=v.replace(/(\d)(\d{3})$/,"$1,$2");return v;};function soValorReal1(v){v=v.replace(/\D/g,"");v=v.replace(/(\d)(\d{1})$/,"$1,$2");return v;};function soCep(v){v=v.replace(/\D/g,"")
v=v.replace(/^(\d{5})(\d)/,"$1-$2")
return v}function soTel(v){v=v.replace(/\D/g,"")
v=v.replace(/^(\d\d)(\d)/g,"($1) $2")
v=v.replace(/(\d{4})(\d)/,"$1-$2")
return v}function soCnpj(v){v=v.replace(/\D/g,"")
v=v.replace(/^(\d{2})(\d)/,"$1.$2")
v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
v=v.replace(/(\d{4})(\d)/,"$1-$2")
return v}function soCpf(v){v=v.replace(/\D/g,"")
v=v.replace(/(\d{3})(\d)/,"$1.$2")
v=v.replace(/(\d{3})(\d)/,"$1.$2")
v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
return v}function soRg(v){v=v.replace(/\D/g,"");v=v.replace(/(\d)(\d{7})$/,"$1.$2");v=v.replace(/(\d)(\d{4})$/,"$1.$2");v=v.replace(/(\d)(\d)$/,"$1-$2");return v;}function soData(v){v=v.replace(/\D/g,"");v=v.replace(/(\d{2})(\d)/,"$1/$2");v=v.replace(/(\d{2})(\d)/,"$1/$2");v=v.replace(/(\d{2})(\d{2})$/,"$1$2");return v;}function soCpfCnpj(v){i=v.length;if(i<=14){v=v.replace(/\D/g,"")
v=v.replace(/(\d{3})(\d)/,"$1.$2")
v=v.replace(/(\d{3})(\d)/,"$1.$2")
v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
return v}else{v=v.replace(/\D/g,"")
v=v.replace(/^(\d{2})(\d)/,"$1.$2")
v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
v=v.replace(/(\d{4})(\d)/,"$1-$2")
return v}}</script>
            <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDAIlYsSV_RJZ33_PoBK0L8PGezwYXVhX8" async defer></script>

            <script type="text/javascript" src=./js/utilsintelinput.js?740></script><script type="text/javascript" src=./js/controllers.js?740></script><script type="text/javascript" src=./js/controllers/sistemaCtrl.js?740></script><script type="text/javascript" src=./js/controllers/agendaCtrl.js?740></script><script type="text/javascript" src=./js/controllers/notificacaoCtrl.js?740></script><script type="text/javascript" src=./js/controllers/caixaCtrl.js?740></script>
            <script type="text/javascript">

                function sendNps(nota){
                    
                    fetch(`/php/atualizaNPS.php?nota=${nota}`)
                        .then(data => data.json())
                        .then((data) => {
                            if (data.result[0].erro == "0") {
                                showNps = false;
                                move('#nps-bottom')
                                    .y(0)
                                    .duration(1000)
                                    .end();

                                toastr.success(data.result[0].resultado);   
                            }
                        });
                }

                setTimeout(() => {
                    if (showNps && isGestor === 1){
                        if (localStorage.getItem("hasShowNPS") === null){
                            localStorage.setItem("hasShowNPS", true);
                            move('#nps-bottom')
                                .y(-250)
                                .duration(1000)
                                .end();
                        }
                    } else {
                        localStorage.removeItem("hasShowNPS");
                    }
                    
                }, 6000);

                $(".btnRemoveNPS").on('click',() => {
                    move('#nps-bottom')
                        .y(0)
                        .duration(1000)
                        .end();                    
                });

         </script>

            <script type="text/javascript">$(".btn-caixa").click(function(event){shroom=$("#caixaSide");if(shroom.hasClass('open')){shroom.removeClass('open');move('#caixaSide').x(0).duration(250).end();}else{shroom.addClass('open');move('#caixaSide').x(-650).duration(250).end();}});$(".sidebar-menu").click(function(){if($("#caixaSide").hasClass('open')){$("#caixaSide").removeClass('open');move('#caixaSide').x(0).duration(250).end();}});</script>

            <!-- <script src="https://cdn.socket.io/4.0.1/socket.io.min.js"></script>    
            <script>
                const socket = io('localhost:4333')
                socket.on('payment-pix', (data) => {
                    toastr.success("Pix Efetuado com Sucesso.")
                    console.log(data)                    
                })

            </script> -->


        </body>

</html>
