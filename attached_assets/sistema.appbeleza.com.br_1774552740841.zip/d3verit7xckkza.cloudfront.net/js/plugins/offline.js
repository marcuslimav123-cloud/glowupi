;
window.Eager = window.Eager || {};
Eager.siteId = "_lqDhg69jP";
Eager.generation = "20150805123502-5006";
Eager.installs = Eager.installs || {};;
(function() {
    Eager.createElement = function(options) {
        try {
            var element = document.createElement('eager-app');
            var container;
            try {
                container = document.querySelector(options.selector);
            } catch (e) {}
            if (!container) {
                return element;
            }
            if (!container.parentNode && (options.method == "after" || options.method == "before" || options.method == "replace")) {
                return element;
            }
            if (container == document.body) {
                if (options.method == "after")
                    options.method = "append";
                else if (options.method == "before")
                    options.method = "prepend";
            }
            switch (options.method) {
                case "prepend":
                    if (container.firstChild) {
                        container.insertBefore(element, container.firstChild);
                        break;
                    }
                case "append":
                    container.appendChild(element);
                    break;
                case "after":
                    if (container.nextSibling) {
                        container.parentNode.insertBefore(element, container.nextSibling);
                    } else {
                        container.parentNode.appendChild(element);
                    }
                    break;
                case "before":
                    container.parentNode.insertBefore(element, container);
                    break;
                case "replace":
                    container.parentNode.replaceChild(element, container);
            }
            return element;
        } catch (e) {
            if (typeof console !== "undefined" && typeof console.error !== "undefined") {
                console.error("Error creating Eager element", e);
            }
        }
    }
})();;
(function() {
    Eager.matchPage = function(patterns) {
        if (!patterns || !patterns.length) {
            return true;
        }
        if (window.Eager && Eager.proxy && Eager.proxy.originalURL) {
            var url = Eager.proxy.originalURL.parsed;
            var loc = url.host + url.path;
        } else {
            var loc = document.location.host + document.location.pathname;
        }
        for (var i = 0; i < patterns.length; i++) {
            var re = new RegExp(patterns[i], 'i');
            if (re.test(loc)) {
                return true;
            }
        }
        return false;
    }
})();;
Eager.installs["i7b89qISiVi2"] = {
    appId: "NnkeiqegQ2K4"
};;
Eager.installs["i7b89qISiVi2"].options = {
    "indicator": false,
    "language": "portuguese-brazil",
    "theme": "dark"
};;
if (Eager.matchPage(Eager.installs['i7b89qISiVi2'].URLPatterns)) {
    (function() {
        var a, b, c, d, e, f, g;
        d = function(a, b) {
            var c, d, e, f;
            e = [];
            for (d in b.prototype) try {
                f = b.prototype[d], null == a[d] && "function" != typeof f ? e.push(a[d] = f) : e.push(void 0)
            } catch (g) {
                c = g
            }
            return e
        }, a = {}, null == a.options && (a.options = {}), c = {
            checks: {
                xhr: {
                    url: function() {
                        return "/favicon.ico?_=" + Math.floor(1e9 * Math.random())
                    },
                    timeout: 5e3
                },
                image: {
                    url: function() {
                        return "/favicon.ico?_=" + Math.floor(1e9 * Math.random())
                    }
                },
                active: "xhr"
            },
            checkOnLoad: !1,
            interceptRequests: !0,
            reconnect: !0
        }, e = function(a, b) {
            var c, d, e, f, g, h;
            for (c = a, h = b.split("."), d = e = 0, f = h.length; f > e && (g = h[d], c = c[g], "object" == typeof c); d = ++e);
            return d === h.length - 1 ? c : void 0
        }, a.getOption = function(b) {
            var d, f;
            return f = null != (d = e(a.options, b)) ? d : e(c, b), "function" == typeof f ? f() : f
        }, "function" == typeof window.addEventListener && window.addEventListener("online", function() {
            return setTimeout(a.confirmUp, 100)
        }, !1), "function" == typeof window.addEventListener && window.addEventListener("offline", function() {
            return a.confirmDown()
        }, !1), a.state = "up", a.markUp = function() {
            return a.trigger("confirmed-up"), "up" !== a.state ? (a.state = "up", a.trigger("up")) : void 0
        }, a.markDown = function() {
            return a.trigger("confirmed-down"), "down" !== a.state ? (a.state = "down", a.trigger("down")) : void 0
        }, f = {}, a.on = function(b, c, d) {
            var e, g, h, i, j;
            if (g = b.split(" "), g.length > 1) {
                for (j = [], h = 0, i = g.length; i > h; h++) e = g[h], j.push(a.on(e, c, d));
                return j
            }
            return null == f[b] && (f[b] = []), f[b].push([d, c])
        }, a.off = function(a, b) {
            var c, d, e, g, h;
            if (null != f[a]) {
                if (b) {
                    for (e = 0, h = []; e < f[a].length;) g = f[a][e], d = g[0], c = g[1], c === b ? h.push(f[a].splice(e, 1)) : h.push(e++);
                    return h
                }
                return f[a] = []
            }
        }, a.trigger = function(a) {
            var b, c, d, e, g, h, i;
            if (null != f[a]) {
                for (g = f[a], i = [], d = 0, e = g.length; e > d; d++) h = g[d], b = h[0], c = h[1], i.push(c.call(b));
                return i
            }
        }, b = function(a, b, c) {
            var d, e, f, g, h;
            return h = function() {
                return a.status && a.status < 12e3 ? b() : c()
            }, null === a.onprogress ? (d = a.onerror, a.onerror = function() {
                return c(), "function" == typeof d ? d.apply(null, arguments) : void 0
            }, g = a.ontimeout, a.ontimeout = function() {
                return c(), "function" == typeof g ? g.apply(null, arguments) : void 0
            }, e = a.onload, a.onload = function() {
                return h(), "function" == typeof e ? e.apply(null, arguments) : void 0
            }) : (f = a.onreadystatechange, a.onreadystatechange = function() {
                return 4 === a.readyState ? h() : 0 === a.readyState && c(), "function" == typeof f ? f.apply(null, arguments) : void 0
            })
        }, a.checks = {}, a.checks.xhr = function() {
            var c, d;
            d = new XMLHttpRequest, d.offline = !1, d.open("HEAD", a.getOption("checks.xhr.url"), !0), null != d.timeout && (d.timeout = a.getOption("checks.xhr.timeout")), b(d, a.markUp, a.markDown);
            try {
                d.send()
            } catch (e) {
                c = e, a.markDown()
            }
            return d
        }, a.checks.image = function() {
            var b;
            return b = document.createElement("img"), b.onerror = a.markDown, b.onload = a.markUp, void(b.src = a.getOption("checks.image.url"))
        }, a.checks.down = a.markDown, a.checks.up = a.markUp, a.check = function() {
            return a.trigger("checking"), a.checks[a.getOption("checks.active")]()
        }, a.confirmUp = a.confirmDown = a.check, a.onXHR = function(a) {
            var b, c, e;
            return e = function(b, c) {
                var d;
                return d = b.open, b.open = function(e, f, g, h, i) {
                    return a({
                        type: e,
                        url: f,
                        async: g,
                        flags: c,
                        user: h,
                        password: i,
                        xhr: b
                    }), d.apply(b, arguments)
                }
            }, c = window.XMLHttpRequest, window.XMLHttpRequest = function(a) {
                var b, d, f;
                return f = new c(a), e(f, a), d = f.setRequestHeader, f.headers = {}, f.setRequestHeader = function(a, b) {
                    return f.headers[a] = b, d.call(f, a, b)
                }, b = f.overrideMimeType, f.overrideMimeType = function(a) {
                    return f.mimeType = a, b.call(f, a)
                }, f
            }, d(window.XMLHttpRequest, c), null != window.XDomainRequest ? (b = window.XDomainRequest, window.XDomainRequest = function() {
                var a;
                return a = new b, e(a), a
            }, d(window.XDomainRequest, b)) : void 0
        }, g = function() {
            return a.getOption("interceptRequests") && a.onXHR(function(c) {
                var d;
                return d = c.xhr, d.offline !== !1 ? b(d, a.markUp, a.confirmDown) : void 0
            }), a.getOption("checkOnLoad") ? a.check() : void 0
        }, setTimeout(g, 0), window.Offline = a
    }).call(this),
        function() {
            var a, b, c, d, e, f, g, h, i;
            if (!window.Offline) throw new Error("Offline Reconnect brought in without offline.js");
            d = Offline.reconnect = {}, f = null, e = function() {
                var a;
                return null != d.state && "inactive" !== d.state && Offline.trigger("reconnect:stopped"), d.state = "inactive", d.remaining = d.delay = null != (a = Offline.getOption("reconnect.initialDelay")) ? a : 3
            }, b = function() {
                var a, b;
                return a = null != (b = Offline.getOption("reconnect.delay")) ? b : Math.min(Math.ceil(1.5 * d.delay), 3600), d.remaining = d.delay = a
            }, g = function() {
                return "connecting" !== d.state ? (d.remaining -= 1, Offline.trigger("reconnect:tick"), 0 === d.remaining ? h() : void 0) : void 0
            }, h = function() {
                return "waiting" === d.state ? (Offline.trigger("reconnect:connecting"), d.state = "connecting", Offline.check()) : void 0
            }, a = function() {
                return Offline.getOption("reconnect") ? (e(), d.state = "waiting", Offline.trigger("reconnect:started"), f = setInterval(g, 1e3)) : void 0
            }, i = function() {
                return null != f && clearInterval(f), e()
            }, c = function() {
                return Offline.getOption("reconnect") && "connecting" === d.state ? (Offline.trigger("reconnect:failure"), d.state = "waiting", b()) : void 0
            }, d.tryNow = h, e(), Offline.on("down", a), Offline.on("confirmed-down", c), Offline.on("up", i)
        }.call(this),
        function() {
            var a, b, c, d, e, f;
            if (!window.Offline) throw new Error("Requests module brought in without offline.js");
            c = [], f = !1, d = function(a) {
                return Offline.trigger("requests:capture"), "down" !== Offline.state && (f = !0), c.push(a)
            }, e = function(a) {
                var b, c, d, e, f, g, h, i, j;
                j = a.xhr, g = a.url, f = a.type, h = a.user, d = a.password, b = a.body, j.abort(), j.open(f, g, !0, h, d), e = j.headers;
                for (c in e) i = e[c], j.setRequestHeader(c, i);
                return j.mimeType && j.overrideMimeType(j.mimeType), j.send(b)
            }, a = function() {
                return c = []
            }, b = function() {
                var b, d, f, g, h, i;
                for (Offline.trigger("requests:flush"), h = {}, b = 0, f = c.length; f > b; b++) g = c[b], i = g.url.replace(/(\?|&)_=[0-9]+/, function(a, b) {
                    return "?" === b ? b : ""
                }), h[g.type.toUpperCase() + " - " + i] = g;
                for (d in h) g = h[d], e(g);
                return a()
            }, setTimeout(function() {
                return Offline.getOption("requests") !== !1 ? (Offline.on("confirmed-up", function() {
                    return f ? (f = !1, a()) : void 0
                }), Offline.on("up", b), Offline.on("down", function() {
                    return f = !1
                }), Offline.onXHR(function(a) {
                    var b, c, e, f, g;
                    return g = a.xhr, e = a.async, g.offline !== !1 && (f = function() {
                        return d(a)
                    }, c = g.send, g.send = function(b) {
                        return a.body = b, c.apply(g, arguments)
                    }, e) ? null === g.onprogress ? (g.addEventListener("error", f, !1), g.addEventListener("timeout", f, !1)) : (b = g.onreadystatechange, g.onreadystatechange = function() {
                        return 0 === g.readyState ? f() : 4 === g.readyState && (0 === g.status || g.status >= 12e3) && f(), "function" == typeof b ? b.apply(null, arguments) : void 0
                    }) : void 0
                }), Offline.requests = {
                    flush: b,
                    clear: a
                }) : void 0
            }, 0)
        }.call(this),
        function() {
            var a, b, c, d, e;
            if (!Offline) throw new Error("Offline simulate brought in without offline.js");
            for (d = ["up", "down"], b = 0, c = d.length; c > b; b++) e = d[b], (document.querySelector("script[data-simulate='" + e + "']") || localStorage.OFFLINE_SIMULATE === e) && (null == Offline.options && (Offline.options = {}), null == (a = Offline.options).checks && (a.checks = {}), Offline.options.checks.active = e)
        }.call(this),
        function() {
            var a, b, c, d, e, f, g, h, i, j, k, l, m;
            if (!window.Offline) throw new Error("Offline UI brought in without offline.js");
            b = '<div class="offline-ui"><div class="offline-ui-content"></div></div>', a = '<a href class="offline-ui-retry"></a>', f = function(a) {
                var b;
                return b = document.createElement("div"), b.innerHTML = a, b.children[0]
            }, g = e = null, d = function(a) {
                return k(a), g.className += " " + a
            }, k = function(a) {
                return g.className = g.className.replace(new RegExp("(^| )" + a.split(" ").join("|") + "( |$)", "gi"), " ")
            }, i = {}, h = function(a, b) {
                return d(a), null != i[a] && clearTimeout(i[a]), i[a] = setTimeout(function() {
                    return k(a), delete i[a]
                }, 1e3 * b)
            }, m = function(a) {
                var b, c, d, e;
                d = {
                    day: 86400,
                    hour: 3600,
                    minute: 60,
                    second: 1
                };
                for (c in d)
                    if (b = d[c], a >= b) return e = Math.floor(a / b), [e, c];
                return ["now", ""]
            }, l = function() {
                var c, h;
                return g = f(b), document.body.appendChild(g), null != Offline.reconnect && Offline.getOption("reconnect") && (g.appendChild(f(a)), c = g.querySelector(".offline-ui-retry"), h = function(a) {
                    return a.preventDefault(), Offline.reconnect.tryNow()
                }, null != c.addEventListener ? c.addEventListener("click", h, !1) : c.attachEvent("click", h)), d("offline-ui-" + Offline.state), e = g.querySelector(".offline-ui-content")
            }, j = function() {
                return l(), Offline.on("up", function() {
                    return k("offline-ui-down"), d("offline-ui-up"), h("offline-ui-up-2s", 2), h("offline-ui-up-5s", 5)
                }), Offline.on("down", function() {
                    return k("offline-ui-up"), d("offline-ui-down"), h("offline-ui-down-2s", 2), h("offline-ui-down-5s", 5)
                }), Offline.on("reconnect:connecting", function() {
                    return d("offline-ui-connecting"), k("offline-ui-waiting")
                }), Offline.on("reconnect:tick", function() {
                    var a, b, c;
                    return d("offline-ui-waiting"), k("offline-ui-connecting"), a = m(Offline.reconnect.remaining), b = a[0], c = a[1], e.setAttribute("data-retry-in-value", b), e.setAttribute("data-retry-in-unit", c)
                }), Offline.on("reconnect:stopped", function() {
                    return k("offline-ui-connecting offline-ui-waiting"), e.setAttribute("data-retry-in-value", null), e.setAttribute("data-retry-in-unit", null)
                }), Offline.on("reconnect:failure", function() {
                    return h("offline-ui-reconnect-failed-2s", 2), h("offline-ui-reconnect-failed-5s", 5)
                }), Offline.on("reconnect:success", function() {
                    return h("offline-ui-reconnect-succeeded-2s", 2), h("offline-ui-reconnect-succeeded-5s", 5)
                })
            }, "complete" === document.readyState ? j() : null != document.addEventListener ? document.addEventListener("DOMContentLoaded", j, !1) : (c = document.onreadystatechange, document.onreadystatechange = function() {
                return "complete" === document.readyState && j(), "function" == typeof c ? c.apply(null, arguments) : void 0
            })
        }.call(this);
};
Eager.loadAsync = {
    "script": [],
    "style": []
};;
(function() {
    var load = Eager.reloadBody = function() {
        try {
            var head = document.getElementsByTagName('head')[0];
            for (var i = Eager.loadAsync.script.length; i--;) {
                var script = document.createElement('script');
                script.src = Eager.loadAsync.script[i];
                head.appendChild(script);
            }
            for (var i = Eager.loadAsync.style.length; i--;) {
                var link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = Eager.loadAsync.style[i];
                head.appendChild(link);
            }
        } catch (e) {
            if (typeof console !== "undefined" && typeof console.error !== "undefined")
                console.error("Error loading Eager content", e);
        }
    };
    try {
        if (Eager.loadAsync) {
            if (document.readyState == 'complete') {
                load();
            } else {
                if (document.addEventListener) {
                    document.addEventListener('DOMContentLoaded', load, false);
                } else {
                    document.attachEvent('onreadystatechange', function() {
                        if (document.readyState == 'complete') {
                            load();
                        }
                    });
                }
            }
        }
    } catch (e) {
        if (typeof console !== "undefined" && typeof console.error !== "undefined")
            console.error("Error binding Eager load event", e);
    }
})();;
(function() {
    try {
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'data:text/css;charset=utf-8;base64,QGNoYXJzZXQgIlVURi04IjsKLyogbGluZSA2LCAuLi9zYXNzL19jb250ZW50LnNhc3MgKi8KLm9mZmxpbmUtdWkgLm9mZmxpbmUtdWktcmV0cnk6YmVmb3JlIHsKICBjb250ZW50OiAiUmVjb25lY3RhciI7Cn0KLyogbGluZSAxMSwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktdXAgLm9mZmxpbmUtdWktY29udGVudDpiZWZvcmUgewogIGNvbnRlbnQ6ICJTZXUgY29tcHV0YWRvciBlc3TDoSBjb25lY3RhZG8gw6AgaW50ZXJuZXQuIjsKfQpAbWVkaWEgKG1heC13aWR0aDogMTAyNHB4KSB7CiAgLyogbGluZSAxMSwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCiAgLm9mZmxpbmUtdWkub2ZmbGluZS11aS11cCAub2ZmbGluZS11aS1jb250ZW50OmJlZm9yZSB7CiAgICBjb250ZW50OiAiTyBkaXNwb3NpdGl2byBlc3TDoSBjb25lY3RhZG8gw6AgaW50ZXJuZXQuIjsKICB9Cn0KQG1lZGlhIChtYXgtd2lkdGg6IDU2OHB4KSB7CiAgLyogbGluZSAxMSwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCiAgLm9mZmxpbmUtdWkub2ZmbGluZS11aS11cCAub2ZmbGluZS11aS1jb250ZW50OmJlZm9yZSB7CiAgICBjb250ZW50OiAiTyBkaXNwb3NpdGl2byBlc3TDoSBjb25lY3RhZG8uIjsKICB9Cn0KLyogbGluZSAyMiwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93biAub2ZmbGluZS11aS1jb250ZW50OmJlZm9yZSB7CiAgY29udGVudDogIk8gY29tcHV0YWRvciBwZXJkZXUgc3VhIGNvbmV4w6NvIGNvbSBhIGludGVybmV0LiI7Cn0KQG1lZGlhIChtYXgtd2lkdGg6IDEwMjRweCkgewogIC8qIGxpbmUgMjIsIC4uL3Nhc3MvX2NvbnRlbnQuc2FzcyAqLwogIC5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93biAub2ZmbGluZS11aS1jb250ZW50OmJlZm9yZSB7CiAgICBjb250ZW50OiAiTyBkaXNwb3NpdGl2byBwZXJkZXUgc3VhIGNvbmV4w6NvIGNvbSBhIGludGVybmV0LiI7CiAgfQp9CkBtZWRpYSAobWF4LXdpZHRoOiA1NjhweCkgewogIC8qIGxpbmUgMjIsIC4uL3Nhc3MvX2NvbnRlbnQuc2FzcyAqLwogIC5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93biAub2ZmbGluZS11aS1jb250ZW50OmJlZm9yZSB7CiAgICBjb250ZW50OiAiU2V1IGRpc3Bvc2l0aXZvIG7Do28gZXN0w6EgY29uZWN0YWRvLiI7CiAgfQp9Ci8qIGxpbmUgMzMsIC4uL3Nhc3MvX2NvbnRlbnQuc2FzcyAqLwoub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24ub2ZmbGluZS11aS1jb25uZWN0aW5nIC5vZmZsaW5lLXVpLWNvbnRlbnQ6YmVmb3JlLCAub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24ub2ZmbGluZS11aS1jb25uZWN0aW5nLTJzIC5vZmZsaW5lLXVpLWNvbnRlbnQ6YmVmb3JlIHsKICBjb250ZW50OiAiVGVudGFuZG8gcmVjb25lY3Rhci4uLiI7Cn0KLyogbGluZSA0MiwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktY29udGVudFtkYXRhLXJldHJ5LWluLXVuaXQ9InNlY29uZCJdOmJlZm9yZSB7CiAgY29udGVudDogIkNvbmV4w6NvIHBlcmRpZGEuIHJlY29uZWN0YW5kbyBlbSAiIGF0dHIoZGF0YS1yZXRyeS1pbi12YWx1ZSkgIiBzZWd1bmRvcy4uLiI7Cn0KQG1lZGlhIChtYXgtd2lkdGg6IDU2OHB4KSB7CiAgLyogbGluZSA0MiwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCiAgLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duLm9mZmxpbmUtdWktd2FpdGluZyAub2ZmbGluZS11aS1jb250ZW50W2RhdGEtcmV0cnktaW4tdW5pdD0ic2Vjb25kIl06YmVmb3JlIHsKICAgIGNvbnRlbnQ6ICJSZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICJzLi4uIjsKICB9Cn0KLyogbGluZSA1MCwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktY29udGVudFtkYXRhLXJldHJ5LWluLXVuaXQ9InNlY29uZCJdW2RhdGEtcmV0cnktaW4tdmFsdWU9IjEiXTpiZWZvcmUgewogIGNvbnRlbnQ6ICJDb25leMOjbyBwZXJkaWRhLiByZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICIgc2VndW5kby4uLiI7Cn0KQG1lZGlhIChtYXgtd2lkdGg6IDU2OHB4KSB7CiAgLyogbGluZSA1MCwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCiAgLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duLm9mZmxpbmUtdWktd2FpdGluZyAub2ZmbGluZS11aS1jb250ZW50W2RhdGEtcmV0cnktaW4tdW5pdD0ic2Vjb25kIl1bZGF0YS1yZXRyeS1pbi12YWx1ZT0iMSJdOmJlZm9yZSB7CiAgICBjb250ZW50OiAiUmVjb25lY3RhbmRvIGVtICIgYXR0cihkYXRhLXJldHJ5LWluLXZhbHVlKSAicy4uLiI7CiAgfQp9Ci8qIGxpbmUgNTgsIC4uL3Nhc3MvX2NvbnRlbnQuc2FzcyAqLwoub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24ub2ZmbGluZS11aS13YWl0aW5nIC5vZmZsaW5lLXVpLWNvbnRlbnRbZGF0YS1yZXRyeS1pbi11bml0PSJtaW51dGUiXTpiZWZvcmUgewogIGNvbnRlbnQ6ICJDb25leMOjbyBwZXJkaWRhLiByZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICIgbWludXRvcy4uLiI7Cn0KQG1lZGlhIChtYXgtd2lkdGg6IDU2OHB4KSB7CiAgLyogbGluZSA1OCwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCiAgLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duLm9mZmxpbmUtdWktd2FpdGluZyAub2ZmbGluZS11aS1jb250ZW50W2RhdGEtcmV0cnktaW4tdW5pdD0ibWludXRlIl06YmVmb3JlIHsKICAgIGNvbnRlbnQ6ICJSZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICJtLi4uIjsKICB9Cn0KLyogbGluZSA2NiwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktY29udGVudFtkYXRhLXJldHJ5LWluLXVuaXQ9Im1pbnV0ZSJdW2RhdGEtcmV0cnktaW4tdmFsdWU9IjEiXTpiZWZvcmUgewogIGNvbnRlbnQ6ICJDb25leMOjbyBwZXJkaWRhLiByZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICIgbWludXRvLi4uIjsKfQpAbWVkaWEgKG1heC13aWR0aDogNTY4cHgpIHsKICAvKiBsaW5lIDY2LCAuLi9zYXNzL19jb250ZW50LnNhc3MgKi8KICAub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24ub2ZmbGluZS11aS13YWl0aW5nIC5vZmZsaW5lLXVpLWNvbnRlbnRbZGF0YS1yZXRyeS1pbi11bml0PSJtaW51dGUiXVtkYXRhLXJldHJ5LWluLXZhbHVlPSIxIl06YmVmb3JlIHsKICAgIGNvbnRlbnQ6ICJSZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICJtLi4uIjsKICB9Cn0KLyogbGluZSA3NCwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktY29udGVudFtkYXRhLXJldHJ5LWluLXVuaXQ9ImhvdXIiXTpiZWZvcmUgewogIGNvbnRlbnQ6ICJDb25leMOjbyBwZXJkaWRhLiByZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICIgaG9yYXMuLi4iOwp9CkBtZWRpYSAobWF4LXdpZHRoOiA1NjhweCkgewogIC8qIGxpbmUgNzQsIC4uL3Nhc3MvX2NvbnRlbnQuc2FzcyAqLwogIC5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktY29udGVudFtkYXRhLXJldHJ5LWluLXVuaXQ9ImhvdXIiXTpiZWZvcmUgewogICAgY29udGVudDogIlJlY29uZWN0YW5kbyBlbSAiIGF0dHIoZGF0YS1yZXRyeS1pbi12YWx1ZSkgImguLi4iOwogIH0KfQovKiBsaW5lIDgyLCAuLi9zYXNzL19jb250ZW50LnNhc3MgKi8KLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duLm9mZmxpbmUtdWktd2FpdGluZyAub2ZmbGluZS11aS1jb250ZW50W2RhdGEtcmV0cnktaW4tdW5pdD0iaG91ciJdW2RhdGEtcmV0cnktaW4tdmFsdWU9IjEiXTpiZWZvcmUgewogIGNvbnRlbnQ6ICJDb25leMOjbyBwZXJkaWRhLiByZWNvbmVjdGFuZG8gZW0gIiBhdHRyKGRhdGEtcmV0cnktaW4tdmFsdWUpICIgaG9yYS4uLiI7Cn0KQG1lZGlhIChtYXgtd2lkdGg6IDU2OHB4KSB7CiAgLyogbGluZSA4MiwgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCiAgLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duLm9mZmxpbmUtdWktd2FpdGluZyAub2ZmbGluZS11aS1jb250ZW50W2RhdGEtcmV0cnktaW4tdW5pdD0iaG91ciJdW2RhdGEtcmV0cnktaW4tdmFsdWU9IjEiXTpiZWZvcmUgewogICAgY29udGVudDogIlJlY29uZWN0YW5kbyBlbSAiIGF0dHIoZGF0YS1yZXRyeS1pbi12YWx1ZSkgImguLi4iOwogIH0KfQovKiBsaW5lIDkwLCAuLi9zYXNzL19jb250ZW50LnNhc3MgKi8KLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duLm9mZmxpbmUtdWktcmVjb25uZWN0LWZhaWxlZC0ycy5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktcmV0cnkgewogIGRpc3BsYXk6IG5vbmU7Cn0KLyogbGluZSA5MywgLi4vc2Fzcy9fY29udGVudC5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXJlY29ubmVjdC1mYWlsZWQtMnMgLm9mZmxpbmUtdWktY29udGVudDpiZWZvcmUgewogIGNvbnRlbnQ6ICJUZW50YXRpdmEgZGUgY29uZXjDo28gZmFsaG91LiI7Cn0KLyogbGluZSA0LCAuLi9zYXNzL19vZmZsaW5lLXRoZW1lLWJhc2Uuc2FzcyAqLwoub2ZmbGluZS11aSwgLm9mZmxpbmUtdWkgKiwgLm9mZmxpbmUtdWk6YmVmb3JlLCAub2ZmbGluZS11aTphZnRlciwgLm9mZmxpbmUtdWkgKjpiZWZvcmUsIC5vZmZsaW5lLXVpICo6YWZ0ZXIgewogIC13ZWJraXQtYm94LXNpemluZzogYm9yZGVyLWJveDsKICAtbW96LWJveC1zaXppbmc6IGJvcmRlci1ib3g7CiAgYm94LXNpemluZzogYm9yZGVyLWJveDsKfQoKLyogbGluZSA3LCAuLi9zYXNzL19vZmZsaW5lLXRoZW1lLWJhc2Uuc2FzcyAqLwoub2ZmbGluZS11aSB7CiAgZGlzcGxheTogbm9uZTsKICBwb3NpdGlvbjogZml4ZWQ7CiAgYmFja2dyb3VuZDogd2hpdGU7CiAgei1pbmRleDogMjAwMDsKICBtYXJnaW46IGF1dG87CiAgdG9wOiAwOwogIGxlZnQ6IDA7CiAgcmlnaHQ6IDA7Cn0KLyogbGluZSAxNywgLi4vc2Fzcy9fb2ZmbGluZS10aGVtZS1iYXNlLnNhc3MgKi8KLm9mZmxpbmUtdWkgLm9mZmxpbmUtdWktY29udGVudDpiZWZvcmUgewogIGRpc3BsYXk6IGlubGluZTsKfQovKiBsaW5lIDIwLCAuLi9zYXNzL19vZmZsaW5lLXRoZW1lLWJhc2Uuc2FzcyAqLwoub2ZmbGluZS11aSAub2ZmbGluZS11aS1yZXRyeSB7CiAgLXdlYmtpdC11c2VyLXNlbGVjdDogbm9uZTsKICAtbW96LXVzZXItc2VsZWN0OiBub25lOwogIHVzZXItc2VsZWN0OiBub25lOwogIGRpc3BsYXk6IG5vbmU7Cn0KLyogbGluZSAyNCwgLi4vc2Fzcy9fb2ZmbGluZS10aGVtZS1iYXNlLnNhc3MgKi8KLm9mZmxpbmUtdWkgLm9mZmxpbmUtdWktcmV0cnk6YmVmb3JlIHsKICBkaXNwbGF5OiBpbmxpbmU7Cn0KLyogbGluZSAyOSwgLi4vc2Fzcy9fb2ZmbGluZS10aGVtZS1iYXNlLnNhc3MgKi8KLm9mZmxpbmUtdWkub2ZmbGluZS11aS11cC5vZmZsaW5lLXVpLXVwLTVzIHsKICBkaXNwbGF5OiBibG9jazsKfQovKiBsaW5lIDMyLCAuLi9zYXNzL19vZmZsaW5lLXRoZW1lLWJhc2Uuc2FzcyAqLwoub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24gewogIGRpc3BsYXk6IGJsb2NrOwp9Ci8qIGxpbmUgMzcsIC4uL3Nhc3MvX29mZmxpbmUtdGhlbWUtYmFzZS5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktcmV0cnkgewogIGRpc3BsYXk6IGJsb2NrOwp9Ci8qIGxpbmUgNDIsIC4uL3Nhc3MvX29mZmxpbmUtdGhlbWUtYmFzZS5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXJlY29ubmVjdC1mYWlsZWQtMnMub2ZmbGluZS11aS13YWl0aW5nIC5vZmZsaW5lLXVpLXJldHJ5IHsKICBkaXNwbGF5OiBub25lOwp9CgpALXdlYmtpdC1rZXlmcmFtZXMgb2ZmbGluZS1kcm9waW4gewogIC8qIGxpbmUgNDAsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0MywgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0OCwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAyJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAxOwogIH0KCiAgLyogbGluZSA1MSwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgb3BhY2l0eTogMTsKICB9Cn0KCkAtbW96LWtleWZyYW1lcyBvZmZsaW5lLWRyb3BpbiB7CiAgLyogbGluZSA0MCwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAwJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIG9wYWNpdHk6IDA7CiAgfQoKICAvKiBsaW5lIDQzLCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDElIHsKICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIG9wYWNpdHk6IDA7CiAgfQoKICAvKiBsaW5lIDQ4LCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDIlIHsKICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIG9wYWNpdHk6IDE7CiAgfQoKICAvKiBsaW5lIDUxLCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDEwMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICBvcGFjaXR5OiAxOwogIH0KfQoKQC1tcy1rZXlmcmFtZXMgb2ZmbGluZS1kcm9waW4gewogIC8qIGxpbmUgNDAsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0MywgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0OCwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAyJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAxOwogIH0KCiAgLyogbGluZSA1MSwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgb3BhY2l0eTogMTsKICB9Cn0KCkAtby1rZXlmcmFtZXMgb2ZmbGluZS1kcm9waW4gewogIC8qIGxpbmUgNDAsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0MywgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0OCwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAyJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAxOwogIH0KCiAgLyogbGluZSA1MSwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgb3BhY2l0eTogMTsKICB9Cn0KCkBrZXlmcmFtZXMgb2ZmbGluZS1kcm9waW4gewogIC8qIGxpbmUgNDAsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0MywgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAwOwogIH0KCiAgLyogbGluZSA0OCwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAyJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICBvcGFjaXR5OiAxOwogIH0KCiAgLyogbGluZSA1MSwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgb3BhY2l0eTogMTsKICB9Cn0KCkAtd2Via2l0LWtleWZyYW1lcyBvZmZsaW5lLWRyb3BvdXQgewogIC8qIGxpbmUgNTcsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgfQoKICAvKiBsaW5lIDU5LCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDEwMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogIH0KfQoKQC1tb3ota2V5ZnJhbWVzIG9mZmxpbmUtZHJvcG91dCB7CiAgLyogbGluZSA1NywgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAwJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICB9CgogIC8qIGxpbmUgNTksIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMTAwJSB7CiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgfQp9CgpALW1zLWtleWZyYW1lcyBvZmZsaW5lLWRyb3BvdXQgewogIC8qIGxpbmUgNTcsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgfQoKICAvKiBsaW5lIDU5LCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDEwMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogIH0KfQoKQC1vLWtleWZyYW1lcyBvZmZsaW5lLWRyb3BvdXQgewogIC8qIGxpbmUgNTcsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgfQoKICAvKiBsaW5lIDU5LCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDEwMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogIH0KfQoKQGtleWZyYW1lcyBvZmZsaW5lLWRyb3BvdXQgewogIC8qIGxpbmUgNTcsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApOwogICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgICAtby10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7CiAgfQoKICAvKiBsaW5lIDU5LCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDEwMCUgewogICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC04MDBweCk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTgwMHB4KTsKICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtODAwcHgpOwogIH0KfQoKQC13ZWJraXQta2V5ZnJhbWVzIG9mZmxpbmUtcm90YXRpb24gewogIC8qIGxpbmUgNjQsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogIH0KCiAgLyogbGluZSA2NiwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbXMtdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgfQp9CgpALW1vei1rZXlmcmFtZXMgb2ZmbGluZS1yb3RhdGlvbiB7CiAgLyogbGluZSA2NCwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAwJSB7CiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7CiAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogICAgLW1zLXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogICAgLW8tdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7CiAgfQoKICAvKiBsaW5lIDY2LCAuLi9zYXNzL19rZXlmcmFtZXMuc2FzcyAqLwogIDEwMCUgewogICAgdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICAgIC1tb3otdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgzNTlkZWcpOwogICAgLW8tdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICB9Cn0KCkAtbXMta2V5ZnJhbWVzIG9mZmxpbmUtcm90YXRpb24gewogIC8qIGxpbmUgNjQsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogIH0KCiAgLyogbGluZSA2NiwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbXMtdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgfQp9CgpALW8ta2V5ZnJhbWVzIG9mZmxpbmUtcm90YXRpb24gewogIC8qIGxpbmUgNjQsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogIH0KCiAgLyogbGluZSA2NiwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbXMtdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgfQp9CgpAa2V5ZnJhbWVzIG9mZmxpbmUtcm90YXRpb24gewogIC8qIGxpbmUgNjQsIC4uL3Nhc3MvX2tleWZyYW1lcy5zYXNzICovCiAgMCUgewogICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDBkZWcpOwogIH0KCiAgLyogbGluZSA2NiwgLi4vc2Fzcy9fa2V5ZnJhbWVzLnNhc3MgKi8KICAxMDAlIHsKICAgIHRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgICAtbXMtdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTsKICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7CiAgfQp9CgovKiBsaW5lIDE2LCAuLi9zYXNzL29mZmxpbmUtdGhlbWUtZGFyay5zYXNzICovCi5vZmZsaW5lLXVpIHsKICAtd2Via2l0LWJvcmRlci1yYWRpdXM6IDAgMCA0cHggNHB4OwogIC1tb3otYm9yZGVyLXJhZGl1czogMCAwIDRweCA0cHg7CiAgLW1zLWJvcmRlci1yYWRpdXM6IDAgMCA0cHggNHB4OwogIC1vLWJvcmRlci1yYWRpdXM6IDAgMCA0cHggNHB4OwogIGJvcmRlci1yYWRpdXM6IDAgMCA0cHggNHB4OwogIGZvbnQtZmFtaWx5OiAiSGVsdmV0aWNhIE5ldWUiLCBzYW5zLXNlcmlmOwogIGZvbnQtd2VpZ2h0OiAzMDA7CiAgcGFkZGluZzogMWVtOwogIHdpZHRoOiAzOGVtOwogIG1heC13aWR0aDogMTAwJTsKICBiYWNrZ3JvdW5kOiBibGFjazsKICBjb2xvcjogI2NjY2NjYzsKICBvdmVyZmxvdzogaGlkZGVuOwp9CkBtZWRpYSAobWF4LXdpZHRoOiAzOGVtKSB7CiAgLyogbGluZSAxNiwgLi4vc2Fzcy9vZmZsaW5lLXRoZW1lLWRhcmsuc2FzcyAqLwogIC5vZmZsaW5lLXVpIHsKICAgIC13ZWJraXQtYm9yZGVyLXJhZGl1czogMDsKICAgIC1tb3otYm9yZGVyLXJhZGl1czogMDsKICAgIC1tcy1ib3JkZXItcmFkaXVzOiAwOwogICAgLW8tYm9yZGVyLXJhZGl1czogMDsKICAgIGJvcmRlci1yYWRpdXM6IDA7CiAgfQp9Ci8qIGxpbmUgMzAsIC4uL3Nhc3Mvb2ZmbGluZS10aGVtZS1kYXJrLnNhc3MgKi8KLm9mZmxpbmUtdWkgLm9mZmxpbmUtdWktY29udGVudCB7CiAgcGFkZGluZy1sZWZ0OiAyZW07Cn0KLyogbGluZSAzMywgLi4vc2Fzcy9vZmZsaW5lLXRoZW1lLWRhcmsuc2FzcyAqLwoub2ZmbGluZS11aSAub2ZmbGluZS11aS1jb250ZW50OmJlZm9yZSB7CiAgbGluZS1oZWlnaHQ6IDEuMjVlbTsKfQovKiBsaW5lIDM2LCAuLi9zYXNzL29mZmxpbmUtdGhlbWUtZGFyay5zYXNzICovCi5vZmZsaW5lLXVpIC5vZmZsaW5lLXVpLWNvbnRlbnQ6YWZ0ZXIgewogIC13ZWJraXQtYm9yZGVyLXJhZGl1czogNTAlOwogIC1tb3otYm9yZGVyLXJhZGl1czogNTAlOwogIC1tcy1ib3JkZXItcmFkaXVzOiA1MCU7CiAgLW8tYm9yZGVyLXJhZGl1czogNTAlOwogIGJvcmRlci1yYWRpdXM6IDUwJTsKICBjb250ZW50OiAiICI7CiAgZGlzcGxheTogYmxvY2s7CiAgcG9zaXRpb246IGFic29sdXRlOwogIHRvcDogMDsKICBib3R0b206IDA7CiAgbGVmdDogMWVtOwogIG1hcmdpbjogYXV0bzsKICBoZWlnaHQ6IDFlbTsKICB3aWR0aDogMWVtOwp9Ci8qIGxpbmUgNDgsIC4uL3Nhc3Mvb2ZmbGluZS10aGVtZS1kYXJrLnNhc3MgKi8KLm9mZmxpbmUtdWkgLm9mZmxpbmUtdWktcmV0cnkgewogIHBvc2l0aW9uOiBhYnNvbHV0ZTsKICByaWdodDogM2VtOwogIHRvcDogMDsKICBib3R0b206IDA7CiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjIpOwogIHRleHQtZGVjb3JhdGlvbjogbm9uZTsKICBjb2xvcjogaW5oZXJpdDsKICBsaW5lLWhlaWdodDogMy41ZW07CiAgaGVpZ2h0OiAzLjVlbTsKICBtYXJnaW46IGF1dG87CiAgcGFkZGluZzogMCAxZW07Cn0KLyogbGluZSA2MSwgLi4vc2Fzcy9vZmZsaW5lLXRoZW1lLWRhcmsuc2FzcyAqLwoub2ZmbGluZS11aS5vZmZsaW5lLXVpLXVwIHsKICAtd2Via2l0LWFuaW1hdGlvbjogb2ZmbGluZS1kcm9wb3V0IGZvcndhcmRzIDAuNXMgMnM7CiAgLW1vei1hbmltYXRpb246IG9mZmxpbmUtZHJvcG91dCBmb3J3YXJkcyAwLjVzIDJzOwogIC1tcy1hbmltYXRpb246IG9mZmxpbmUtZHJvcG91dCBmb3J3YXJkcyAwLjVzIDJzOwogIC1vLWFuaW1hdGlvbjogb2ZmbGluZS1kcm9wb3V0IGZvcndhcmRzIDAuNXMgMnM7CiAgYW5pbWF0aW9uOiBvZmZsaW5lLWRyb3BvdXQgZm9yd2FyZHMgMC41cyAyczsKICAtd2Via2l0LWJhY2tmYWNlLXZpc2liaWxpdHk6IGhpZGRlbjsKfQovKiBsaW5lIDY0LCAuLi9zYXNzL29mZmxpbmUtdGhlbWUtZGFyay5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktdXAgLm9mZmxpbmUtdWktY29udGVudDphZnRlciB7CiAgYmFja2dyb3VuZDogIzgwZDU4MDsKfQovKiBsaW5lIDY3LCAuLi9zYXNzL29mZmxpbmUtdGhlbWUtZGFyay5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93biB7CiAgLXdlYmtpdC1hbmltYXRpb246IG9mZmxpbmUtZHJvcGluIDAuNXM7CiAgLW1vei1hbmltYXRpb246IG9mZmxpbmUtZHJvcGluIDAuNXM7CiAgLW1zLWFuaW1hdGlvbjogb2ZmbGluZS1kcm9waW4gMC41czsKICAtby1hbmltYXRpb246IG9mZmxpbmUtZHJvcGluIDAuNXM7CiAgYW5pbWF0aW9uOiBvZmZsaW5lLWRyb3BpbiAwLjVzOwogIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogaGlkZGVuOwp9Ci8qIGxpbmUgNzAsIC4uL3Nhc3Mvb2ZmbGluZS10aGVtZS1kYXJrLnNhc3MgKi8KLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duIC5vZmZsaW5lLXVpLWNvbnRlbnQ6YWZ0ZXIgewogIGJhY2tncm91bmQ6ICNlMjQ5NDk7Cn0KLyogbGluZSA3MywgLi4vc2Fzcy9vZmZsaW5lLXRoZW1lLWRhcmsuc2FzcyAqLwoub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24ub2ZmbGluZS11aS1jb25uZWN0aW5nLCAub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24ub2ZmbGluZS11aS13YWl0aW5nIHsKICBwYWRkaW5nLXJpZ2h0OiAzZW07Cn0KLyogbGluZSA3NiwgLi4vc2Fzcy9vZmZsaW5lLXRoZW1lLWRhcmsuc2FzcyAqLwoub2ZmbGluZS11aS5vZmZsaW5lLXVpLWRvd24ub2ZmbGluZS11aS1jb25uZWN0aW5nIC5vZmZsaW5lLXVpLWNvbnRlbnQ6YWZ0ZXIsIC5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcgLm9mZmxpbmUtdWktY29udGVudDphZnRlciB7CiAgYmFja2dyb3VuZDogI2UyNDk0OTsKfQovKiBsaW5lIDc5LCAuLi9zYXNzL29mZmxpbmUtdGhlbWUtZGFyay5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLWNvbm5lY3Rpbmc6YWZ0ZXIsIC5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmc6YWZ0ZXIgewogIC13ZWJraXQtYW5pbWF0aW9uOiBvZmZsaW5lLXJvdGF0aW9uIDAuN3MgbGluZWFyIGluZmluaXRlOwogIC1tb3otYW5pbWF0aW9uOiBvZmZsaW5lLXJvdGF0aW9uIDAuN3MgbGluZWFyIGluZmluaXRlOwogIC1tcy1hbmltYXRpb246IG9mZmxpbmUtcm90YXRpb24gMC43cyBsaW5lYXIgaW5maW5pdGU7CiAgLW8tYW5pbWF0aW9uOiBvZmZsaW5lLXJvdGF0aW9uIDAuN3MgbGluZWFyIGluZmluaXRlOwogIGFuaW1hdGlvbjogb2ZmbGluZS1yb3RhdGlvbiAwLjdzIGxpbmVhciBpbmZpbml0ZTsKICAtd2Via2l0LWJhY2tmYWNlLXZpc2liaWxpdHk6IGhpZGRlbjsKICAtd2Via2l0LWJvcmRlci1yYWRpdXM6IDUwJTsKICAtbW96LWJvcmRlci1yYWRpdXM6IDUwJTsKICAtbXMtYm9yZGVyLXJhZGl1czogNTAlOwogIC1vLWJvcmRlci1yYWRpdXM6IDUwJTsKICBib3JkZXItcmFkaXVzOiA1MCU7CiAgY29udGVudDogIiAiOwogIGRpc3BsYXk6IGJsb2NrOwogIHBvc2l0aW9uOiBhYnNvbHV0ZTsKICByaWdodDogMWVtOwogIHRvcDogMDsKICBib3R0b206IDA7CiAgbWFyZ2luOiBhdXRvOwogIGhlaWdodDogMWVtOwogIHdpZHRoOiAxZW07CiAgYm9yZGVyOiAycHggc29saWQgdHJhbnNwYXJlbnQ7CiAgYm9yZGVyLXRvcC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjUpOwogIGJvcmRlci1sZWZ0LWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSk7CiAgb3BhY2l0eTogMC43Owp9Ci8qIGxpbmUgOTYsIC4uL3Nhc3Mvb2ZmbGluZS10aGVtZS1kYXJrLnNhc3MgKi8KLm9mZmxpbmUtdWkub2ZmbGluZS11aS1kb3duLm9mZmxpbmUtdWktd2FpdGluZyB7CiAgcGFkZGluZy1yaWdodDogMTFlbTsKfQovKiBsaW5lIDk5LCAuLi9zYXNzL29mZmxpbmUtdGhlbWUtZGFyay5zYXNzICovCi5vZmZsaW5lLXVpLm9mZmxpbmUtdWktZG93bi5vZmZsaW5lLXVpLXdhaXRpbmcub2ZmbGluZS11aS1yZWNvbm5lY3QtZmFpbGVkLTJzIHsKICBwYWRkaW5nLXJpZ2h0OiAwOwp9Cg==';
        document.getElementsByTagName('head')[0].appendChild(link);
    } catch (e) {}
})();