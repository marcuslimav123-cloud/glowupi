/*! For license information please see jquery-ed472032c65bb4295993684c673d706a.js.LICENSE.txt */ ! function(e, t) {
    var n, r, i = "undefined",
        o = e.document,
        a = e.location,
        s = e.jQuery,
        u = e.$,
        l = {},
        c = [],
        f = "1.9.1",
        p = c.concat,
        d = c.push,
        h = c.slice,
        g = c.indexOf,
        m = l.toString,
        y = l.hasOwnProperty,
        v = f.trim,
        x = function(e, t) {
            return new x.fn.init(e, t, r)
        },
        b = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        w = /\S+/g,
        T = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
        N = /^(?:(<[\w\W]+>)[^>]*|#([\w-]*))$/,
        C = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
        k = /^[\],:{}\s]*$/,
        E = /(?:^|:|,)(?:\s*\[)+/g,
        S = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
        A = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g,
        j = /^-ms-/,
        D = /-([\da-z])/gi,
        L = function(e, t) {
            return t.toUpperCase()
        },
        H = function(e) {
            (o.addEventListener || "load" === e.type || "complete" === o.readyState) && (q(), x.ready())
        },
        q = function() {
            o.addEventListener ? (o.removeEventListener("DOMContentLoaded", H, !1), e.removeEventListener("load", H, !1)) : (o.detachEvent("onreadystatechange", H), e.detachEvent("onload", H))
        };

    function M(e) {
        var t = e.length,
            n = x.type(e);
        return !x.isWindow(e) && (!(1 !== e.nodeType || !t) || ("array" === n || "function" !== n && (0 === t || "number" == typeof t && t > 0 && t - 1 in e)))
    }
    x.fn = x.prototype = {
        jquery: f,
        constructor: x,
        init: function(e, n, r) {
            var i, a;
            if (!e) return this;
            if ("string" == typeof e) {
                if (!(i = "<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && e.length >= 3 ? [null, e, null] : N.exec(e)) || !i[1] && n) return !n || n.jquery ? (n || r).find(e) : this.constructor(n).find(e);
                if (i[1]) {
                    if (n = n instanceof x ? n[0] : n, x.merge(this, x.parseHTML(i[1], n && n.nodeType ? n.ownerDocument || n : o, !0)), C.test(i[1]) && x.isPlainObject(n))
                        for (i in n) x.isFunction(this[i]) ? this[i](n[i]) : this.attr(i, n[i]);
                    return this
                }
                if ((a = o.getElementById(i[2])) && a.parentNode) {
                    if (a.id !== i[2]) return r.find(e);
                    this.length = 1, this[0] = a
                }
                return this.context = o, this.selector = e, this
            }
            return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : x.isFunction(e) ? r.ready(e) : (e.selector !== t && (this.selector = e.selector, this.context = e.context), x.makeArray(e, this))
        },
        selector: "",
        length: 0,
        size: function() {
            return this.length
        },
        toArray: function() {
            return h.call(this)
        },
        get: function(e) {
            return null == e ? this.toArray() : e < 0 ? this[this.length + e] : this[e]
        },
        pushStack: function(e) {
            var t = x.merge(this.constructor(), e);
            return t.prevObject = this, t.context = this.context, t
        },
        each: function(e, t) {
            return x.each(this, e, t)
        },
        ready: function(e) {
            return x.ready.promise().done(e), this
        },
        slice: function() {
            return this.pushStack(h.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        eq: function(e) {
            var t = this.length,
                n = +e + (e < 0 ? t : 0);
            return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
        },
        map: function(e) {
            return this.pushStack(x.map(this, (function(t, n) {
                return e.call(t, n, t)
            })))
        },
        end: function() {
            return this.prevObject || this.constructor(null)
        },
        push: d,
        sort: [].sort,
        splice: [].splice
    }, x.fn.init.prototype = x.fn, x.extend = x.fn.extend = function() {
        var e, n, r, i, o, a, s = arguments[0] || {},
            u = 1,
            l = arguments.length,
            c = !1;
        for ("boolean" == typeof s && (c = s, s = arguments[1] || {}, u = 2), "object" == typeof s || x.isFunction(s) || (s = {}), l === u && (s = this, --u); u < l; u++)
            if (null != (o = arguments[u]))
                for (i in o) e = s[i], s !== (r = o[i]) && (c && r && (x.isPlainObject(r) || (n = x.isArray(r))) ? (n ? (n = !1, a = e && x.isArray(e) ? e : []) : a = e && x.isPlainObject(e) ? e : {}, s[i] = x.extend(c, a, r)) : r !== t && (s[i] = r));
        return s
    }, x.extend({
        noConflict: function(t) {
            return e.$ === x && (e.$ = u), t && e.jQuery === x && (e.jQuery = s), x
        },
        isReady: !1,
        readyWait: 1,
        holdReady: function(e) {
            e ? x.readyWait++ : x.ready(!0)
        },
        ready: function(e) {
            if (!(!0 === e ? --x.readyWait : x.isReady)) {
                if (!o.body) return setTimeout(x.ready);
                x.isReady = !0, !0 !== e && --x.readyWait > 0 || (n.resolveWith(o, [x]), x.fn.trigger && x(o).trigger("ready").off("ready"))
            }
        },
        isFunction: function(e) {
            return "function" === x.type(e)
        },
        isArray: Array.isArray || function(e) {
            return "array" === x.type(e)
        },
        isWindow: function(e) {
            return null != e && e == e.window
        },
        isNumeric: function(e) {
            return !isNaN(parseFloat(e)) && isFinite(e)
        },
        type: function(e) {
            return null == e ? String(e) : "object" == typeof e || "function" == typeof e ? l[m.call(e)] || "object" : typeof e
        },
        isPlainObject: function(e) {
            if (!e || "object" !== x.type(e) || e.nodeType || x.isWindow(e)) return !1;
            try {
                if (e.constructor && !y.call(e, "constructor") && !y.call(e.constructor.prototype, "isPrototypeOf")) return !1
            } catch (e) {
                return !1
            }
            var n;
            for (n in e);
            return n === t || y.call(e, n)
        },
        isEmptyObject: function(e) {
            var t;
            for (t in e) return !1;
            return !0
        },
        error: function(e) {
            throw new Error(e)
        },
        parseHTML: function(e, t, n) {
            if (!e || "string" != typeof e) return null;
            "boolean" == typeof t && (n = t, t = !1), t = t || o;
            var r = C.exec(e),
                i = !n && [];
            return r ? [t.createElement(r[1])] : (r = x.buildFragment([e], t, i), i && x(i).remove(), x.merge([], r.childNodes))
        },
        parseJSON: function(t) {
            return e.JSON && e.JSON.parse ? e.JSON.parse(t) : null === t ? t : "string" == typeof t && (t = x.trim(t)) && k.test(t.replace(S, "@").replace(A, "]").replace(E, "")) ? new Function("return " + t)() : void x.error("Invalid JSON: " + t)
        },
        parseXML: function(n) {
            var r;
            if (!n || "string" != typeof n) return null;
            try {
                e.DOMParser ? r = (new DOMParser).parseFromString(n, "text/xml") : ((r = new ActiveXObject("Microsoft.XMLDOM")).async = "false", r.loadXML(n))
            } catch (e) {
                r = t
            }
            return r && r.documentElement && !r.getElementsByTagName("parsererror").length || x.error("Invalid XML: " + n), r
        },
        noop: function() {},
        globalEval: function(t) {
            t && x.trim(t) && (e.execScript || function(t) {
                e.eval.call(e, t)
            })(t)
        },
        camelCase: function(e) {
            return e.replace(j, "ms-").replace(D, L)
        },
        nodeName: function(e, t) {
            return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
        },
        each: function(e, t, n) {
            var r = 0,
                i = e.length,
                o = M(e);
            if (n) {
                if (o)
                    for (; r < i && !1 !== t.apply(e[r], n); r++);
                else
                    for (r in e)
                        if (!1 === t.apply(e[r], n)) break
            } else if (o)
                for (; r < i && !1 !== t.call(e[r], r, e[r]); r++);
            else
                for (r in e)
                    if (!1 === t.call(e[r], r, e[r])) break;
            return e
        },
        trim: v && !v.call("\ufeff ") ? function(e) {
            return null == e ? "" : v.call(e)
        } : function(e) {
            return null == e ? "" : (e + "").replace(T, "")
        },
        makeArray: function(e, t) {
            var n = t || [];
            return null != e && (M(Object(e)) ? x.merge(n, "string" == typeof e ? [e] : e) : d.call(n, e)), n
        },
        inArray: function(e, t, n) {
            var r;
            if (t) {
                if (g) return g.call(t, e, n);
                for (r = t.length, n = n ? n < 0 ? Math.max(0, r + n) : n : 0; n < r; n++)
                    if (n in t && t[n] === e) return n
            }
            return -1
        },
        merge: function(e, n) {
            var r = n.length,
                i = e.length,
                o = 0;
            if ("number" == typeof r)
                for (; o < r; o++) e[i++] = n[o];
            else
                for (; n[o] !== t;) e[i++] = n[o++];
            return e.length = i, e
        },
        grep: function(e, t, n) {
            var r = [],
                i = 0,
                o = e.length;
            for (n = !!n; i < o; i++) n !== !!t(e[i], i) && r.push(e[i]);
            return r
        },
        map: function(e, t, n) {
            var r, i = 0,
                o = e.length,
                a = [];
            if (M(e))
                for (; i < o; i++) null != (r = t(e[i], i, n)) && (a[a.length] = r);
            else
                for (i in e) null != (r = t(e[i], i, n)) && (a[a.length] = r);
            return p.apply([], a)
        },
        guid: 1,
        proxy: function(e, n) {
            var r, i, o;
            return "string" == typeof n && (o = e[n], n = e, e = o), x.isFunction(e) ? (r = h.call(arguments, 2), i = function() {
                return e.apply(n || this, r.concat(h.call(arguments)))
            }, i.guid = e.guid = e.guid || x.guid++, i) : t
        },
        access: function(e, n, r, i, o, a, s) {
            var u = 0,
                l = e.length,
                c = null == r;
            if ("object" === x.type(r))
                for (u in o = !0, r) x.access(e, n, u, r[u], !0, a, s);
            else if (i !== t && (o = !0, x.isFunction(i) || (s = !0), c && (s ? (n.call(e, i), n = null) : (c = n, n = function(e, t, n) {
                    return c.call(x(e), n)
                })), n))
                for (; u < l; u++) n(e[u], r, s ? i : i.call(e[u], u, n(e[u], r)));
            return o ? e : c ? n.call(e) : l ? n(e[0], r) : a
        },
        now: function() {
            return (new Date).getTime()
        }
    }), x.ready.promise = function(t) {
        if (!n)
            if (n = x.Deferred(), "complete" === o.readyState) setTimeout(x.ready);
            else if (o.addEventListener) o.addEventListener("DOMContentLoaded", H, !1), e.addEventListener("load", H, !1);
        else {
            o.attachEvent("onreadystatechange", H), e.attachEvent("onload", H);
            var r = !1;
            try {
                r = null == e.frameElement && o.documentElement
            } catch (e) {}
            r && r.doScroll && function e() {
                if (!x.isReady) {
                    try {
                        r.doScroll("left")
                    } catch (t) {
                        return setTimeout(e, 50)
                    }
                    q(), x.ready()
                }
            }()
        }
        return n.promise(t)
    }, x.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), (function(e, t) {
        l["[object " + t + "]"] = t.toLowerCase()
    })), r = x(o);
    var _ = {};
    x.Callbacks = function(e) {
        e = "string" == typeof e ? _[e] || function(e) {
            var t = _[e] = {};
            return x.each(e.match(w) || [], (function(e, n) {
                t[n] = !0
            })), t
        }(e) : x.extend({}, e);
        var n, r, i, o, a, s, u = [],
            l = !e.once && [],
            c = function(t) {
                for (r = e.memory && t, i = !0, a = s || 0, s = 0, o = u.length, n = !0; u && a < o; a++)
                    if (!1 === u[a].apply(t[0], t[1]) && e.stopOnFalse) {
                        r = !1;
                        break
                    }
                n = !1, u && (l ? l.length && c(l.shift()) : r ? u = [] : f.disable())
            },
            f = {
                add: function() {
                    if (u) {
                        var t = u.length;
                        ! function t(n) {
                            x.each(n, (function(n, r) {
                                var i = x.type(r);
                                "function" === i ? e.unique && f.has(r) || u.push(r) : r && r.length && "string" !== i && t(r)
                            }))
                        }(arguments), n ? o = u.length : r && (s = t, c(r))
                    }
                    return this
                },
                remove: function() {
                    return u && x.each(arguments, (function(e, t) {
                        for (var r;
                            (r = x.inArray(t, u, r)) > -1;) u.splice(r, 1), n && (r <= o && o--, r <= a && a--)
                    })), this
                },
                has: function(e) {
                    return e ? x.inArray(e, u) > -1 : !(!u || !u.length)
                },
                empty: function() {
                    return u = [], this
                },
                disable: function() {
                    return u = l = r = t, this
                },
                disabled: function() {
                    return !u
                },
                lock: function() {
                    return l = t, r || f.disable(), this
                },
                locked: function() {
                    return !l
                },
                fireWith: function(e, t) {
                    return t = [e, (t = t || []).slice ? t.slice() : t], !u || i && !l || (n ? l.push(t) : c(t)), this
                },
                fire: function() {
                    return f.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!i
                }
            };
        return f
    }, x.extend({
        Deferred: function(e) {
            var t = [
                    ["resolve", "done", x.Callbacks("once memory"), "resolved"],
                    ["reject", "fail", x.Callbacks("once memory"), "rejected"],
                    ["notify", "progress", x.Callbacks("memory")]
                ],
                n = "pending",
                r = {
                    state: function() {
                        return n
                    },
                    always: function() {
                        return i.done(arguments).fail(arguments), this
                    },
                    then: function() {
                        var e = arguments;
                        return x.Deferred((function(n) {
                            x.each(t, (function(t, o) {
                                var a = o[0],
                                    s = x.isFunction(e[t]) && e[t];
                                i[o[1]]((function() {
                                    var e = s && s.apply(this, arguments);
                                    e && x.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[a + "With"](this === r ? n.promise() : this, s ? [e] : arguments)
                                }))
                            })), e = null
                        })).promise()
                    },
                    promise: function(e) {
                        return null != e ? x.extend(e, r) : r
                    }
                },
                i = {};
            return r.pipe = r.then, x.each(t, (function(e, o) {
                var a = o[2],
                    s = o[3];
                r[o[1]] = a.add, s && a.add((function() {
                    n = s
                }), t[1 ^ e][2].disable, t[2][2].lock), i[o[0]] = function() {
                    return i[o[0] + "With"](this === i ? r : this, arguments), this
                }, i[o[0] + "With"] = a.fireWith
            })), r.promise(i), e && e.call(i, i), i
        },
        when: function(e) {
            var t, n, r, i = 0,
                o = h.call(arguments),
                a = o.length,
                s = 1 !== a || e && x.isFunction(e.promise) ? a : 0,
                u = 1 === s ? e : x.Deferred(),
                l = function(e, n, r) {
                    return function(i) {
                        n[e] = this, r[e] = arguments.length > 1 ? h.call(arguments) : i, r === t ? u.notifyWith(n, r) : --s || u.resolveWith(n, r)
                    }
                };
            if (a > 1)
                for (t = new Array(a), n = new Array(a), r = new Array(a); i < a; i++) o[i] && x.isFunction(o[i].promise) ? o[i].promise().done(l(i, r, o)).fail(u.reject).progress(l(i, n, t)) : --s;
            return s || u.resolveWith(r, o), u.promise()
        }
    }), x.support = function() {
        var t, n, r, a, s, u, l, c, f, p, d = o.createElement("div");
        if (d.setAttribute("className", "t"), d.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", n = d.getElementsByTagName("*"), r = d.getElementsByTagName("a")[0], !n || !r || !n.length) return {};
        l = (s = o.createElement("select")).appendChild(o.createElement("option")), a = d.getElementsByTagName("input")[0], r.style.cssText = "top:1px;float:left;opacity:.5", t = {
            getSetAttribute: "t" !== d.className,
            leadingWhitespace: 3 === d.firstChild.nodeType,
            tbody: !d.getElementsByTagName("tbody").length,
            htmlSerialize: !!d.getElementsByTagName("link").length,
            style: /top/.test(r.getAttribute("style")),
            hrefNormalized: "/a" === r.getAttribute("href"),
            opacity: /^0.5/.test(r.style.opacity),
            cssFloat: !!r.style.cssFloat,
            checkOn: !!a.value,
            optSelected: l.selected,
            enctype: !!o.createElement("form").enctype,
            html5Clone: "<:nav></:nav>" !== o.createElement("nav").cloneNode(!0).outerHTML,
            boxModel: "CSS1Compat" === o.compatMode,
            deleteExpando: !0,
            noCloneEvent: !0,
            inlineBlockNeedsLayout: !1,
            shrinkWrapBlocks: !1,
            reliableMarginRight: !0,
            boxSizingReliable: !0,
            pixelPosition: !1
        }, a.checked = !0, t.noCloneChecked = a.cloneNode(!0).checked, s.disabled = !0, t.optDisabled = !l.disabled;
        try {
            delete d.test
        } catch (e) {
            t.deleteExpando = !1
        }
        for (p in (a = o.createElement("input")).setAttribute("value", ""), t.input = "" === a.getAttribute("value"), a.value = "t", a.setAttribute("type", "radio"), t.radioValue = "t" === a.value, a.setAttribute("checked", "t"), a.setAttribute("name", "t"), (u = o.createDocumentFragment()).appendChild(a), t.appendChecked = a.checked, t.checkClone = u.cloneNode(!0).cloneNode(!0).lastChild.checked, d.attachEvent && (d.attachEvent("onclick", (function() {
                t.noCloneEvent = !1
            })), d.cloneNode(!0).click()), {
                submit: !0,
                change: !0,
                focusin: !0
            }) d.setAttribute(c = "on" + p, "t"), t[p + "Bubbles"] = c in e || !1 === d.attributes[c].expando;
        return d.style.backgroundClip = "content-box", d.cloneNode(!0).style.backgroundClip = "", t.clearCloneStyle = "content-box" === d.style.backgroundClip, x((function() {
            var n, r, a, s = "padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",
                u = o.getElementsByTagName("body")[0];
            u && ((n = o.createElement("div")).style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", u.appendChild(n).appendChild(d), d.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", (a = d.getElementsByTagName("td"))[0].style.cssText = "padding:0;margin:0;border:0;display:none", f = 0 === a[0].offsetHeight, a[0].style.display = "", a[1].style.display = "none", t.reliableHiddenOffsets = f && 0 === a[0].offsetHeight, d.innerHTML = "", d.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;", t.boxSizing = 4 === d.offsetWidth, t.doesNotIncludeMarginInBodyOffset = 1 !== u.offsetTop, e.getComputedStyle && (t.pixelPosition = "1%" !== (e.getComputedStyle(d, null) || {}).top, t.boxSizingReliable = "4px" === (e.getComputedStyle(d, null) || {
                width: "4px"
            }).width, (r = d.appendChild(o.createElement("div"))).style.cssText = d.style.cssText = s, r.style.marginRight = r.style.width = "0", d.style.width = "1px", t.reliableMarginRight = !parseFloat((e.getComputedStyle(r, null) || {}).marginRight)), typeof d.style.zoom !== i && (d.innerHTML = "", d.style.cssText = s + "width:1px;padding:1px;display:inline;zoom:1", t.inlineBlockNeedsLayout = 3 === d.offsetWidth, d.style.display = "block", d.innerHTML = "<div></div>", d.firstChild.style.width = "5px", t.shrinkWrapBlocks = 3 !== d.offsetWidth, t.inlineBlockNeedsLayout && (u.style.zoom = 1)), u.removeChild(n), n = d = a = r = null)
        })), n = s = u = l = r = a = null, t
    }();
    var F = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/,
        O = /([A-Z])/g;

    function B(e, n, r, i) {
        if (x.acceptData(e)) {
            var o, a, s = x.expando,
                u = "string" == typeof n,
                l = e.nodeType,
                f = l ? x.cache : e,
                p = l ? e[s] : e[s] && s;
            if (p && f[p] && (i || f[p].data) || !u || r !== t) return p || (l ? e[s] = p = c.pop() || x.guid++ : p = s), f[p] || (f[p] = {}, l || (f[p].toJSON = x.noop)), "object" != typeof n && "function" != typeof n || (i ? f[p] = x.extend(f[p], n) : f[p].data = x.extend(f[p].data, n)), o = f[p], i || (o.data || (o.data = {}), o = o.data), r !== t && (o[x.camelCase(n)] = r), u ? null == (a = o[n]) && (a = o[x.camelCase(n)]) : a = o, a
        }
    }

    function P(e, t, n) {
        if (x.acceptData(e)) {
            var r, i, o, a = e.nodeType,
                s = a ? x.cache : e,
                u = a ? e[x.expando] : x.expando;
            if (s[u]) {
                if (t && (o = n ? s[u] : s[u].data)) {
                    for ((r = 0, i = (t = x.isArray(t) ? t.concat(x.map(t, x.camelCase)) : t in o || (t = x.camelCase(t)) in o ? [t] : t.split(" ")).length); r < i; r++) delete o[t[r]];
                    if (!(n ? W : x.isEmptyObject)(o)) return
                }(n || (delete s[u].data, W(s[u]))) && (a ? x.cleanData([e], !0) : x.support.deleteExpando || s != s.window ? delete s[u] : s[u] = null)
            }
        }
    }

    function R(e, n, r) {
        if (r === t && 1 === e.nodeType) {
            var i = "data-" + n.replace(O, "-$1").toLowerCase();
            if ("string" == typeof(r = e.getAttribute(i))) {
                try {
                    r = "true" === r || "false" !== r && ("null" === r ? null : +r + "" === r ? +r : F.test(r) ? x.parseJSON(r) : r)
                } catch (e) {}
                x.data(e, n, r)
            } else r = t
        }
        return r
    }

    function W(e) {
        var t;
        for (t in e)
            if (("data" !== t || !x.isEmptyObject(e[t])) && "toJSON" !== t) return !1;
        return !0
    }
    x.extend({
        cache: {},
        expando: "jQuery" + (f + Math.random()).replace(/\D/g, ""),
        noData: {
            embed: !0,
            object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
            applet: !0
        },
        hasData: function(e) {
            return !!(e = e.nodeType ? x.cache[e[x.expando]] : e[x.expando]) && !W(e)
        },
        data: function(e, t, n) {
            return B(e, t, n)
        },
        removeData: function(e, t) {
            return P(e, t)
        },
        _data: function(e, t, n) {
            return B(e, t, n, !0)
        },
        _removeData: function(e, t) {
            return P(e, t, !0)
        },
        acceptData: function(e) {
            if (e.nodeType && 1 !== e.nodeType && 9 !== e.nodeType) return !1;
            var t = e.nodeName && x.noData[e.nodeName.toLowerCase()];
            return !t || !0 !== t && e.getAttribute("classid") === t
        }
    }), x.fn.extend({
        data: function(e, n) {
            var r, i, o = this[0],
                a = 0,
                s = null;
            if (e === t) {
                if (this.length && (s = x.data(o), 1 === o.nodeType && !x._data(o, "parsedAttrs"))) {
                    for (r = o.attributes; a < r.length; a++)(i = r[a].name).indexOf("data-") || (i = x.camelCase(i.slice(5)), R(o, i, s[i]));
                    x._data(o, "parsedAttrs", !0)
                }
                return s
            }
            return "object" == typeof e ? this.each((function() {
                x.data(this, e)
            })) : x.access(this, (function(n) {
                if (n === t) return o ? R(o, e, x.data(o, e)) : null;
                this.each((function() {
                    x.data(this, e, n)
                }))
            }), null, n, arguments.length > 1, null, !0)
        },
        removeData: function(e) {
            return this.each((function() {
                x.removeData(this, e)
            }))
        }
    }), x.extend({
        queue: function(e, t, n) {
            var r;
            if (e) return t = (t || "fx") + "queue", r = x._data(e, t), n && (!r || x.isArray(n) ? r = x._data(e, t, x.makeArray(n)) : r.push(n)), r || []
        },
        dequeue: function(e, t) {
            t = t || "fx";
            var n = x.queue(e, t),
                r = n.length,
                i = n.shift(),
                o = x._queueHooks(e, t);
            "inprogress" === i && (i = n.shift(), r--), o.cur = i, i && ("fx" === t && n.unshift("inprogress"), delete o.stop, i.call(e, (function() {
                x.dequeue(e, t)
            }), o)), !r && o && o.empty.fire()
        },
        _queueHooks: function(e, t) {
            var n = t + "queueHooks";
            return x._data(e, n) || x._data(e, n, {
                empty: x.Callbacks("once memory").add((function() {
                    x._removeData(e, t + "queue"), x._removeData(e, n)
                }))
            })
        }
    }), x.fn.extend({
        queue: function(e, n) {
            var r = 2;
            return "string" != typeof e && (n = e, e = "fx", r--), arguments.length < r ? x.queue(this[0], e) : n === t ? this : this.each((function() {
                var t = x.queue(this, e, n);
                x._queueHooks(this, e), "fx" === e && "inprogress" !== t[0] && x.dequeue(this, e)
            }))
        },
        dequeue: function(e) {
            return this.each((function() {
                x.dequeue(this, e)
            }))
        },
        delay: function(e, t) {
            return e = x.fx && x.fx.speeds[e] || e, t = t || "fx", this.queue(t, (function(t, n) {
                var r = setTimeout(t, e);
                n.stop = function() {
                    clearTimeout(r)
                }
            }))
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, n) {
            var r, i = 1,
                o = x.Deferred(),
                a = this,
                s = this.length,
                u = function() {
                    --i || o.resolveWith(a, [a])
                };
            for ("string" != typeof e && (n = e, e = t), e = e || "fx"; s--;)(r = x._data(a[s], e + "queueHooks")) && r.empty && (i++, r.empty.add(u));
            return u(), o.promise(n)
        }
    });
    var $, I, z = /[\t\r\n]/g,
        X = /\r/g,
        U = /^(?:input|select|textarea|button|object)$/i,
        V = /^(?:a|area)$/i,
        Y = /^(?:checked|selected|autofocus|autoplay|async|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped)$/i,
        J = /^(?:checked|selected)$/i,
        G = x.support.getSetAttribute,
        Q = x.support.input;
    x.fn.extend({
        attr: function(e, t) {
            return x.access(this, x.attr, e, t, arguments.length > 1)
        },
        removeAttr: function(e) {
            return this.each((function() {
                x.removeAttr(this, e)
            }))
        },
        prop: function(e, t) {
            return x.access(this, x.prop, e, t, arguments.length > 1)
        },
        removeProp: function(e) {
            return e = x.propFix[e] || e, this.each((function() {
                try {
                    this[e] = t, delete this[e]
                } catch (e) {}
            }))
        },
        addClass: function(e) {
            var t, n, r, i, o, a = 0,
                s = this.length,
                u = "string" == typeof e && e;
            if (x.isFunction(e)) return this.each((function(t) {
                x(this).addClass(e.call(this, t, this.className))
            }));
            if (u)
                for (t = (e || "").match(w) || []; a < s; a++)
                    if (r = 1 === (n = this[a]).nodeType && (n.className ? (" " + n.className + " ").replace(z, " ") : " ")) {
                        for (o = 0; i = t[o++];) r.indexOf(" " + i + " ") < 0 && (r += i + " ");
                        n.className = x.trim(r)
                    }
            return this
        },
        removeClass: function(e) {
            var t, n, r, i, o, a = 0,
                s = this.length,
                u = 0 === arguments.length || "string" == typeof e && e;
            if (x.isFunction(e)) return this.each((function(t) {
                x(this).removeClass(e.call(this, t, this.className))
            }));
            if (u)
                for (t = (e || "").match(w) || []; a < s; a++)
                    if (r = 1 === (n = this[a]).nodeType && (n.className ? (" " + n.className + " ").replace(z, " ") : "")) {
                        for (o = 0; i = t[o++];)
                            for (; r.indexOf(" " + i + " ") >= 0;) r = r.replace(" " + i + " ", " ");
                        n.className = e ? x.trim(r) : ""
                    }
            return this
        },
        toggleClass: function(e, t) {
            var n = typeof e,
                r = "boolean" == typeof t;
            return x.isFunction(e) ? this.each((function(n) {
                x(this).toggleClass(e.call(this, n, this.className, t), t)
            })) : this.each((function() {
                if ("string" === n)
                    for (var o, a = 0, s = x(this), u = t, l = e.match(w) || []; o = l[a++];) u = r ? u : !s.hasClass(o), s[u ? "addClass" : "removeClass"](o);
                else n !== i && "boolean" !== n || (this.className && x._data(this, "__className__", this.className), this.className = this.className || !1 === e ? "" : x._data(this, "__className__") || "")
            }))
        },
        hasClass: function(e) {
            for (var t = " " + e + " ", n = 0, r = this.length; n < r; n++)
                if (1 === this[n].nodeType && (" " + this[n].className + " ").replace(z, " ").indexOf(t) >= 0) return !0;
            return !1
        },
        val: function(e) {
            var n, r, i, o = this[0];
            return arguments.length ? (i = x.isFunction(e), this.each((function(n) {
                var o, a = x(this);
                1 === this.nodeType && (null == (o = i ? e.call(this, n, a.val()) : e) ? o = "" : "number" == typeof o ? o += "" : x.isArray(o) && (o = x.map(o, (function(e) {
                    return null == e ? "" : e + ""
                }))), (r = x.valHooks[this.type] || x.valHooks[this.nodeName.toLowerCase()]) && "set" in r && r.set(this, o, "value") !== t || (this.value = o))
            }))) : o ? (r = x.valHooks[o.type] || x.valHooks[o.nodeName.toLowerCase()]) && "get" in r && (n = r.get(o, "value")) !== t ? n : "string" == typeof(n = o.value) ? n.replace(X, "") : null == n ? "" : n : void 0
        }
    }), x.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var t = e.attributes.value;
                    return !t || t.specified ? e.value : e.text
                }
            },
            select: {
                get: function(e) {
                    for (var t, n, r = e.options, i = e.selectedIndex, o = "select-one" === e.type || i < 0, a = o ? null : [], s = o ? i + 1 : r.length, u = i < 0 ? s : o ? i : 0; u < s; u++)
                        if (((n = r[u]).selected || u === i) && (x.support.optDisabled ? !n.disabled : null === n.getAttribute("disabled")) && (!n.parentNode.disabled || !x.nodeName(n.parentNode, "optgroup"))) {
                            if (t = x(n).val(), o) return t;
                            a.push(t)
                        }
                    return a
                },
                set: function(e, t) {
                    var n = x.makeArray(t);
                    return x(e).find("option").each((function() {
                        this.selected = x.inArray(x(this).val(), n) >= 0
                    })), n.length || (e.selectedIndex = -1), n
                }
            }
        },
        attr: function(e, n, r) {
            var o, a, s, u = e.nodeType;
            if (e && 3 !== u && 8 !== u && 2 !== u) return typeof e.getAttribute === i ? x.prop(e, n, r) : ((a = 1 !== u || !x.isXMLDoc(e)) && (n = n.toLowerCase(), o = x.attrHooks[n] || (Y.test(n) ? I : $)), r === t ? o && a && "get" in o && null !== (s = o.get(e, n)) ? s : (typeof e.getAttribute !== i && (s = e.getAttribute(n)), null == s ? t : s) : null !== r ? o && a && "set" in o && (s = o.set(e, r, n)) !== t ? s : (e.setAttribute(n, r + ""), r) : void x.removeAttr(e, n))
        },
        removeAttr: function(e, t) {
            var n, r, i = 0,
                o = t && t.match(w);
            if (o && 1 === e.nodeType)
                for (; n = o[i++];) r = x.propFix[n] || n, Y.test(n) ? !G && J.test(n) ? e[x.camelCase("default-" + n)] = e[r] = !1 : e[r] = !1 : x.attr(e, n, ""), e.removeAttribute(G ? n : r)
        },
        attrHooks: {
            type: {
                set: function(e, t) {
                    if (!x.support.radioValue && "radio" === t && x.nodeName(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            }
        },
        propFix: {
            tabindex: "tabIndex",
            readonly: "readOnly",
            for: "htmlFor",
            class: "className",
            maxlength: "maxLength",
            cellspacing: "cellSpacing",
            cellpadding: "cellPadding",
            rowspan: "rowSpan",
            colspan: "colSpan",
            usemap: "useMap",
            frameborder: "frameBorder",
            contenteditable: "contentEditable"
        },
        prop: function(e, n, r) {
            var i, o, a = e.nodeType;
            if (e && 3 !== a && 8 !== a && 2 !== a) return (1 !== a || !x.isXMLDoc(e)) && (n = x.propFix[n] || n, o = x.propHooks[n]), r !== t ? o && "set" in o && (i = o.set(e, r, n)) !== t ? i : e[n] = r : o && "get" in o && null !== (i = o.get(e, n)) ? i : e[n]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var n = e.getAttributeNode("tabindex");
                    return n && n.specified ? parseInt(n.value, 10) : U.test(e.nodeName) || V.test(e.nodeName) && e.href ? 0 : t
                }
            }
        }
    }), I = {
        get: function(e, n) {
            var r = x.prop(e, n),
                i = "boolean" == typeof r && e.getAttribute(n),
                o = "boolean" == typeof r ? Q && G ? null != i : J.test(n) ? e[x.camelCase("default-" + n)] : !!i : e.getAttributeNode(n);
            return o && !1 !== o.value ? n.toLowerCase() : t
        },
        set: function(e, t, n) {
            return !1 === t ? x.removeAttr(e, n) : Q && G || !J.test(n) ? e.setAttribute(!G && x.propFix[n] || n, n) : e[x.camelCase("default-" + n)] = e[n] = !0, n
        }
    }, Q && G || (x.attrHooks.value = {
        get: function(e, n) {
            var r = e.getAttributeNode(n);
            return x.nodeName(e, "input") ? e.defaultValue : r && r.specified ? r.value : t
        },
        set: function(e, t, n) {
            if (!x.nodeName(e, "input")) return $ && $.set(e, t, n);
            e.defaultValue = t
        }
    }), G || ($ = x.valHooks.button = {
        get: function(e, n) {
            var r = e.getAttributeNode(n);
            return r && ("id" === n || "name" === n || "coords" === n ? "" !== r.value : r.specified) ? r.value : t
        },
        set: function(e, n, r) {
            var i = e.getAttributeNode(r);
            return i || e.setAttributeNode(i = e.ownerDocument.createAttribute(r)), i.value = n += "", "value" === r || n === e.getAttribute(r) ? n : t
        }
    }, x.attrHooks.contenteditable = {
        get: $.get,
        set: function(e, t, n) {
            $.set(e, "" !== t && t, n)
        }
    }, x.each(["width", "height"], (function(e, t) {
        x.attrHooks[t] = x.extend(x.attrHooks[t], {
            set: function(e, n) {
                if ("" === n) return e.setAttribute(t, "auto"), n
            }
        })
    }))), x.support.hrefNormalized || (x.each(["href", "src", "width", "height"], (function(e, n) {
        x.attrHooks[n] = x.extend(x.attrHooks[n], {
            get: function(e) {
                var r = e.getAttribute(n, 2);
                return null == r ? t : r
            }
        })
    })), x.each(["href", "src"], (function(e, t) {
        x.propHooks[t] = {
            get: function(e) {
                return e.getAttribute(t, 4)
            }
        }
    }))), x.support.style || (x.attrHooks.style = {
        get: function(e) {
            return e.style.cssText || t
        },
        set: function(e, t) {
            return e.style.cssText = t + ""
        }
    }), x.support.optSelected || (x.propHooks.selected = x.extend(x.propHooks.selected, {
        get: function(e) {
            var t = e.parentNode;
            return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
        }
    })), x.support.enctype || (x.propFix.enctype = "encoding"), x.support.checkOn || x.each(["radio", "checkbox"], (function() {
        x.valHooks[this] = {
            get: function(e) {
                return null === e.getAttribute("value") ? "on" : e.value
            }
        }
    })), x.each(["radio", "checkbox"], (function() {
        x.valHooks[this] = x.extend(x.valHooks[this], {
            set: function(e, t) {
                if (x.isArray(t)) return e.checked = x.inArray(x(e).val(), t) >= 0
            }
        })
    }));
    var K = /^(?:input|select|textarea)$/i,
        Z = /^key/,
        ee = /^(?:mouse|contextmenu)|click/,
        te = /^(?:focusinfocus|focusoutblur)$/,
        ne = /^([^.]*)(?:\.(.+)|)$/;

    function re() {
        return !0
    }

    function ie() {
        return !1
    }
    x.event = {
            global: {},
            add: function(e, n, r, o, a) {
                var s, u, l, c, f, p, d, h, g, m, y, v = x._data(e);
                if (v) {
                    for (r.handler && (r = (c = r).handler, a = c.selector), r.guid || (r.guid = x.guid++), (u = v.events) || (u = v.events = {}), (p = v.handle) || (p = v.handle = function(e) {
                            return typeof x === i || e && x.event.triggered === e.type ? t : x.event.dispatch.apply(p.elem, arguments)
                        }, p.elem = e), l = (n = (n || "").match(w) || [""]).length; l--;) g = y = (s = ne.exec(n[l]) || [])[1], m = (s[2] || "").split(".").sort(), f = x.event.special[g] || {}, g = (a ? f.delegateType : f.bindType) || g, f = x.event.special[g] || {}, d = x.extend({
                        type: g,
                        origType: y,
                        data: o,
                        handler: r,
                        guid: r.guid,
                        selector: a,
                        needsContext: a && x.expr.match.needsContext.test(a),
                        namespace: m.join(".")
                    }, c), (h = u[g]) || ((h = u[g] = []).delegateCount = 0, f.setup && !1 !== f.setup.call(e, o, m, p) || (e.addEventListener ? e.addEventListener(g, p, !1) : e.attachEvent && e.attachEvent("on" + g, p))), f.add && (f.add.call(e, d), d.handler.guid || (d.handler.guid = r.guid)), a ? h.splice(h.delegateCount++, 0, d) : h.push(d), x.event.global[g] = !0;
                    e = null
                }
            },
            remove: function(e, t, n, r, i) {
                var o, a, s, u, l, c, f, p, d, h, g, m = x.hasData(e) && x._data(e);
                if (m && (c = m.events)) {
                    for (l = (t = (t || "").match(w) || [""]).length; l--;)
                        if (d = g = (s = ne.exec(t[l]) || [])[1], h = (s[2] || "").split(".").sort(), d) {
                            for (f = x.event.special[d] || {}, p = c[d = (r ? f.delegateType : f.bindType) || d] || [], s = s[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"), u = o = p.length; o--;) a = p[o], !i && g !== a.origType || n && n.guid !== a.guid || s && !s.test(a.namespace) || r && r !== a.selector && ("**" !== r || !a.selector) || (p.splice(o, 1), a.selector && p.delegateCount--, f.remove && f.remove.call(e, a));
                            u && !p.length && (f.teardown && !1 !== f.teardown.call(e, h, m.handle) || x.removeEvent(e, d, m.handle), delete c[d])
                        } else
                            for (d in c) x.event.remove(e, d + t[l], n, r, !0);
                    x.isEmptyObject(c) && (delete m.handle, x._removeData(e, "events"))
                }
            },
            trigger: function(n, r, i, a) {
                var s, u, l, c, f, p, d, h = [i || o],
                    g = y.call(n, "type") ? n.type : n,
                    m = y.call(n, "namespace") ? n.namespace.split(".") : [];
                if (l = p = i = i || o, 3 !== i.nodeType && 8 !== i.nodeType && !te.test(g + x.event.triggered) && (g.indexOf(".") >= 0 && (m = g.split("."), g = m.shift(), m.sort()), u = g.indexOf(":") < 0 && "on" + g, (n = n[x.expando] ? n : new x.Event(g, "object" == typeof n && n)).isTrigger = !0, n.namespace = m.join("."), n.namespace_re = n.namespace ? new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, n.result = t, n.target || (n.target = i), r = null == r ? [n] : x.makeArray(r, [n]), f = x.event.special[g] || {}, a || !f.trigger || !1 !== f.trigger.apply(i, r))) {
                    if (!a && !f.noBubble && !x.isWindow(i)) {
                        for (c = f.delegateType || g, te.test(c + g) || (l = l.parentNode); l; l = l.parentNode) h.push(l), p = l;
                        p === (i.ownerDocument || o) && h.push(p.defaultView || p.parentWindow || e)
                    }
                    for (d = 0;
                        (l = h[d++]) && !n.isPropagationStopped();) n.type = d > 1 ? c : f.bindType || g, (s = (x._data(l, "events") || {})[n.type] && x._data(l, "handle")) && s.apply(l, r), (s = u && l[u]) && x.acceptData(l) && s.apply && !1 === s.apply(l, r) && n.preventDefault();
                    if (n.type = g, !a && !n.isDefaultPrevented() && (!f._default || !1 === f._default.apply(i.ownerDocument, r)) && ("click" !== g || !x.nodeName(i, "a")) && x.acceptData(i) && u && i[g] && !x.isWindow(i)) {
                        (p = i[u]) && (i[u] = null), x.event.triggered = g;
                        try {
                            i[g]()
                        } catch (e) {}
                        x.event.triggered = t, p && (i[u] = p)
                    }
                    return n.result
                }
            },
            dispatch: function(e) {
                e = x.event.fix(e);
                var n, r, i, o, a, s = [],
                    u = h.call(arguments),
                    l = (x._data(this, "events") || {})[e.type] || [],
                    c = x.event.special[e.type] || {};
                if (u[0] = e, e.delegateTarget = this, !c.preDispatch || !1 !== c.preDispatch.call(this, e)) {
                    for (s = x.event.handlers.call(this, e, l), n = 0;
                        (o = s[n++]) && !e.isPropagationStopped();)
                        for (e.currentTarget = o.elem, a = 0;
                            (i = o.handlers[a++]) && !e.isImmediatePropagationStopped();) e.namespace_re && !e.namespace_re.test(i.namespace) || (e.handleObj = i, e.data = i.data, (r = ((x.event.special[i.origType] || {}).handle || i.handler).apply(o.elem, u)) !== t && !1 === (e.result = r) && (e.preventDefault(), e.stopPropagation()));
                    return c.postDispatch && c.postDispatch.call(this, e), e.result
                }
            },
            handlers: function(e, n) {
                var r, i, o, a, s = [],
                    u = n.delegateCount,
                    l = e.target;
                if (u && l.nodeType && (!e.button || "click" !== e.type))
                    for (; l != this; l = l.parentNode || this)
                        if (1 === l.nodeType && (!0 !== l.disabled || "click" !== e.type)) {
                            for (o = [], a = 0; a < u; a++) o[r = (i = n[a]).selector + " "] === t && (o[r] = i.needsContext ? x(r, this).index(l) >= 0 : x.find(r, this, null, [l]).length), o[r] && o.push(i);
                            o.length && s.push({
                                elem: l,
                                handlers: o
                            })
                        }
                return u < n.length && s.push({
                    elem: this,
                    handlers: n.slice(u)
                }), s
            },
            fix: function(e) {
                if (e[x.expando]) return e;
                var t, n, r, i = e.type,
                    a = e,
                    s = this.fixHooks[i];
                for (s || (this.fixHooks[i] = s = ee.test(i) ? this.mouseHooks : Z.test(i) ? this.keyHooks : {}), r = s.props ? this.props.concat(s.props) : this.props, e = new x.Event(a), t = r.length; t--;) e[n = r[t]] = a[n];
                return e.target || (e.target = a.srcElement || o), 3 === e.target.nodeType && (e.target = e.target.parentNode), e.metaKey = !!e.metaKey, s.filter ? s.filter(e, a) : e
            },
            props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
            fixHooks: {},
            keyHooks: {
                props: "char charCode key keyCode".split(" "),
                filter: function(e, t) {
                    return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
                }
            },
            mouseHooks: {
                props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
                filter: function(e, n) {
                    var r, i, a, s = n.button,
                        u = n.fromElement;
                    return null == e.pageX && null != n.clientX && (a = (i = e.target.ownerDocument || o).documentElement, r = i.body, e.pageX = n.clientX + (a && a.scrollLeft || r && r.scrollLeft || 0) - (a && a.clientLeft || r && r.clientLeft || 0), e.pageY = n.clientY + (a && a.scrollTop || r && r.scrollTop || 0) - (a && a.clientTop || r && r.clientTop || 0)), !e.relatedTarget && u && (e.relatedTarget = u === e.target ? n.toElement : u), e.which || s === t || (e.which = 1 & s ? 1 : 2 & s ? 3 : 4 & s ? 2 : 0), e
                }
            },
            special: {
                load: {
                    noBubble: !0
                },
                click: {
                    trigger: function() {
                        if (x.nodeName(this, "input") && "checkbox" === this.type && this.click) return this.click(), !1
                    }
                },
                focus: {
                    trigger: function() {
                        if (this !== o.activeElement && this.focus) try {
                            return this.focus(), !1
                        } catch (e) {}
                    },
                    delegateType: "focusin"
                },
                blur: {
                    trigger: function() {
                        if (this === o.activeElement && this.blur) return this.blur(), !1
                    },
                    delegateType: "focusout"
                },
                beforeunload: {
                    postDispatch: function(e) {
                        e.result !== t && (e.originalEvent.returnValue = e.result)
                    }
                }
            },
            simulate: function(e, t, n, r) {
                var i = x.extend(new x.Event, n, {
                    type: e,
                    isSimulated: !0,
                    originalEvent: {}
                });
                r ? x.event.trigger(i, null, t) : x.event.dispatch.call(t, i), i.isDefaultPrevented() && n.preventDefault()
            }
        }, x.removeEvent = o.removeEventListener ? function(e, t, n) {
            e.removeEventListener && e.removeEventListener(t, n, !1)
        } : function(e, t, n) {
            var r = "on" + t;
            e.detachEvent && (typeof e[r] === i && (e[r] = null), e.detachEvent(r, n))
        }, x.Event = function(e, t) {
            if (!(this instanceof x.Event)) return new x.Event(e, t);
            e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || !1 === e.returnValue || e.getPreventDefault && e.getPreventDefault() ? re : ie) : this.type = e, t && x.extend(this, t), this.timeStamp = e && e.timeStamp || x.now(), this[x.expando] = !0
        }, x.Event.prototype = {
            isDefaultPrevented: ie,
            isPropagationStopped: ie,
            isImmediatePropagationStopped: ie,
            preventDefault: function() {
                var e = this.originalEvent;
                this.isDefaultPrevented = re, e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
            },
            stopPropagation: function() {
                var e = this.originalEvent;
                this.isPropagationStopped = re, e && (e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0)
            },
            stopImmediatePropagation: function() {
                this.isImmediatePropagationStopped = re, this.stopPropagation()
            }
        }, x.each({
            mouseenter: "mouseover",
            mouseleave: "mouseout"
        }, (function(e, t) {
            x.event.special[e] = {
                delegateType: t,
                bindType: t,
                handle: function(e) {
                    var n, r = this,
                        i = e.relatedTarget,
                        o = e.handleObj;
                    return i && (i === r || x.contains(r, i)) || (e.type = o.origType, n = o.handler.apply(this, arguments), e.type = t), n
                }
            }
        })), x.support.submitBubbles || (x.event.special.submit = {
            setup: function() {
                if (x.nodeName(this, "form")) return !1;
                x.event.add(this, "click._submit keypress._submit", (function(e) {
                    var n = e.target,
                        r = x.nodeName(n, "input") || x.nodeName(n, "button") ? n.form : t;
                    r && !x._data(r, "submitBubbles") && (x.event.add(r, "submit._submit", (function(e) {
                        e._submit_bubble = !0
                    })), x._data(r, "submitBubbles", !0))
                }))
            },
            postDispatch: function(e) {
                e._submit_bubble && (delete e._submit_bubble, this.parentNode && !e.isTrigger && x.event.simulate("submit", this.parentNode, e, !0))
            },
            teardown: function() {
                if (x.nodeName(this, "form")) return !1;
                x.event.remove(this, "._submit")
            }
        }), x.support.changeBubbles || (x.event.special.change = {
            setup: function() {
                if (K.test(this.nodeName)) return "checkbox" !== this.type && "radio" !== this.type || (x.event.add(this, "propertychange._change", (function(e) {
                    "checked" === e.originalEvent.propertyName && (this._just_changed = !0)
                })), x.event.add(this, "click._change", (function(e) {
                    this._just_changed && !e.isTrigger && (this._just_changed = !1), x.event.simulate("change", this, e, !0)
                }))), !1;
                x.event.add(this, "beforeactivate._change", (function(e) {
                    var t = e.target;
                    K.test(t.nodeName) && !x._data(t, "changeBubbles") && (x.event.add(t, "change._change", (function(e) {
                        !this.parentNode || e.isSimulated || e.isTrigger || x.event.simulate("change", this.parentNode, e, !0)
                    })), x._data(t, "changeBubbles", !0))
                }))
            },
            handle: function(e) {
                var t = e.target;
                if (this !== t || e.isSimulated || e.isTrigger || "radio" !== t.type && "checkbox" !== t.type) return e.handleObj.handler.apply(this, arguments)
            },
            teardown: function() {
                return x.event.remove(this, "._change"), !K.test(this.nodeName)
            }
        }), x.support.focusinBubbles || x.each({
            focus: "focusin",
            blur: "focusout"
        }, (function(e, t) {
            var n = 0,
                r = function(e) {
                    x.event.simulate(t, e.target, x.event.fix(e), !0)
                };
            x.event.special[t] = {
                setup: function() {
                    0 == n++ && o.addEventListener(e, r, !0)
                },
                teardown: function() {
                    0 == --n && o.removeEventListener(e, r, !0)
                }
            }
        })), x.fn.extend({
            on: function(e, n, r, i, o) {
                var a, s;
                if ("object" == typeof e) {
                    for (a in "string" != typeof n && (r = r || n, n = t), e) this.on(a, n, r, e[a], o);
                    return this
                }
                if (null == r && null == i ? (i = n, r = n = t) : null == i && ("string" == typeof n ? (i = r, r = t) : (i = r, r = n, n = t)), !1 === i) i = ie;
                else if (!i) return this;
                return 1 === o && (s = i, i = function(e) {
                    return x().off(e), s.apply(this, arguments)
                }, i.guid = s.guid || (s.guid = x.guid++)), this.each((function() {
                    x.event.add(this, e, i, r, n)
                }))
            },
            one: function(e, t, n, r) {
                return this.on(e, t, n, r, 1)
            },
            off: function(e, n, r) {
                var i, o;
                if (e && e.preventDefault && e.handleObj) return i = e.handleObj, x(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler), this;
                if ("object" == typeof e) {
                    for (o in e) this.off(o, n, e[o]);
                    return this
                }
                return !1 !== n && "function" != typeof n || (r = n, n = t), !1 === r && (r = ie), this.each((function() {
                    x.event.remove(this, e, r, n)
                }))
            },
            bind: function(e, t, n) {
                return this.on(e, null, t, n)
            },
            unbind: function(e, t) {
                return this.off(e, null, t)
            },
            delegate: function(e, t, n, r) {
                return this.on(t, e, n, r)
            },
            undelegate: function(e, t, n) {
                return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
            },
            trigger: function(e, t) {
                return this.each((function() {
                    x.event.trigger(e, t, this)
                }))
            },
            triggerHandler: function(e, t) {
                var n = this[0];
                if (n) return x.event.trigger(e, t, n, !0)
            }
        }),
        function(e, t) {
            var n, r, i, o, a, s, u, l, c, f, p, d, h, g, m, y, v, b = "sizzle" + -new Date,
                w = e.document,
                T = {},
                N = 0,
                C = 0,
                k = ne(),
                E = ne(),
                S = ne(),
                A = "undefined",
                j = 1 << 31,
                D = [],
                L = D.pop,
                H = D.push,
                q = D.slice,
                M = D.indexOf || function(e) {
                    for (var t = 0, n = this.length; t < n; t++)
                        if (this[t] === e) return t;
                    return -1
                },
                _ = "[\\x20\\t\\r\\n\\f]",
                F = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
                O = F.replace("w", "w#"),
                B = "\\[[\\x20\\t\\r\\n\\f]*(" + F + ")" + _ + "*(?:([*^$|!~]?=)" + _ + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + O + ")|)|)" + _ + "*\\]",
                P = ":(" + F + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + B.replace(3, 8) + ")*)|.*)\\)|)",
                R = new RegExp("^[\\x20\\t\\r\\n\\f]+|((?:^|[^\\\\])(?:\\\\.)*)[\\x20\\t\\r\\n\\f]+$", "g"),
                W = new RegExp("^[\\x20\\t\\r\\n\\f]*,[\\x20\\t\\r\\n\\f]*"),
                $ = new RegExp("^[\\x20\\t\\r\\n\\f]*([\\x20\\t\\r\\n\\f>+~])[\\x20\\t\\r\\n\\f]*"),
                I = new RegExp(P),
                z = new RegExp("^" + O + "$"),
                X = {
                    ID: new RegExp("^#(" + F + ")"),
                    CLASS: new RegExp("^\\.(" + F + ")"),
                    NAME: new RegExp("^\\[name=['\"]?(" + F + ")['\"]?\\]"),
                    TAG: new RegExp("^(" + F.replace("w", "w*") + ")"),
                    ATTR: new RegExp("^" + B),
                    PSEUDO: new RegExp("^" + P),
                    CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\([\\x20\\t\\r\\n\\f]*(even|odd|(([+-]|)(\\d*)n|)[\\x20\\t\\r\\n\\f]*(?:([+-]|)[\\x20\\t\\r\\n\\f]*(\\d+)|))[\\x20\\t\\r\\n\\f]*\\)|)", "i"),
                    needsContext: new RegExp("^[\\x20\\t\\r\\n\\f]*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\([\\x20\\t\\r\\n\\f]*((?:-\\d)?\\d*)[\\x20\\t\\r\\n\\f]*\\)|)(?=[^-]|$)", "i")
                },
                U = /[\x20\t\r\n\f]*[+~]/,
                V = /^[^{]+\{\s*\[native code/,
                Y = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                J = /^(?:input|select|textarea|button)$/i,
                G = /^h\d$/i,
                Q = /'|\\/g,
                K = /\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,
                Z = /\\([\da-fA-F]{1,6}[\x20\t\r\n\f]?|.)/g,
                ee = function(e, t) {
                    var n = "0x" + t - 65536;
                    return n != n ? t : n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320)
                };
            try {
                q.call(w.documentElement.childNodes, 0)[0].nodeType
            } catch (e) {
                q = function(e) {
                    for (var t, n = []; t = this[e++];) n.push(t);
                    return n
                }
            }

            function te(e) {
                return V.test(e + "")
            }

            function ne() {
                var e, t = [];
                return e = function(n, r) {
                    return t.push(n += " ") > i.cacheLength && delete e[t.shift()], e[n] = r
                }
            }

            function re(e) {
                return e[b] = !0, e
            }

            function ie(e) {
                var t = f.createElement("div");
                try {
                    return e(t)
                } catch (e) {
                    return !1
                } finally {
                    t = null
                }
            }

            function oe(e, t, n, r) {
                var o, a, u, l, p, g, m, v, x, N;
                if ((t ? t.ownerDocument || t : w) !== f && c(t), n = n || [], !e || "string" != typeof e) return n;
                if (1 !== (l = (t = t || f).nodeType) && 9 !== l) return [];
                if (!d && !r) {
                    if (o = Y.exec(e))
                        if (u = o[1]) {
                            if (9 === l) {
                                if (!(a = t.getElementById(u)) || !a.parentNode) return n;
                                if (a.id === u) return n.push(a), n
                            } else if (t.ownerDocument && (a = t.ownerDocument.getElementById(u)) && y(t, a) && a.id === u) return n.push(a), n
                        } else {
                            if (o[2]) return H.apply(n, q.call(t.getElementsByTagName(e), 0)), n;
                            if ((u = o[3]) && T.getByClassName && t.getElementsByClassName) return H.apply(n, q.call(t.getElementsByClassName(u), 0)), n
                        }
                    if (T.qsa && !h.test(e)) {
                        if (m = !0, v = b, x = t, N = 9 === l && e, 1 === l && "object" !== t.nodeName.toLowerCase()) {
                            for (g = ce(e), (m = t.getAttribute("id")) ? v = m.replace(Q, "\\$&") : t.setAttribute("id", v), v = "[id='" + v + "'] ", p = g.length; p--;) g[p] = v + fe(g[p]);
                            x = U.test(e) && t.parentNode || t, N = g.join(",")
                        }
                        if (N) try {
                            return H.apply(n, q.call(x.querySelectorAll(N), 0)), n
                        } catch (e) {} finally {
                            m || t.removeAttribute("id")
                        }
                    }
                }
                return function(e, t, n, r) {
                    var o, a, u, l, c, f = ce(e);
                    if (!r && 1 === f.length) {
                        if ((a = f[0] = f[0].slice(0)).length > 2 && "ID" === (u = a[0]).type && 9 === t.nodeType && !d && i.relative[a[1].type]) {
                            if (!(t = i.find.ID(u.matches[0].replace(Z, ee), t)[0])) return n;
                            e = e.slice(a.shift().value.length)
                        }
                        for (o = X.needsContext.test(e) ? 0 : a.length; o-- && (u = a[o], !i.relative[l = u.type]);)
                            if ((c = i.find[l]) && (r = c(u.matches[0].replace(Z, ee), U.test(a[0].type) && t.parentNode || t))) {
                                if (a.splice(o, 1), !(e = r.length && fe(a))) return H.apply(n, q.call(r, 0)), n;
                                break
                            }
                    }
                    return s(e, f)(r, t, d, n, U.test(e)), n
                }(e.replace(R, "$1"), t, n, r)
            }

            function ae(e, t) {
                var n = t && e,
                    r = n && (~t.sourceIndex || j) - (~e.sourceIndex || j);
                if (r) return r;
                if (n)
                    for (; n = n.nextSibling;)
                        if (n === t) return -1;
                return e ? 1 : -1
            }

            function se(e) {
                return function(t) {
                    return "input" === t.nodeName.toLowerCase() && t.type === e
                }
            }

            function ue(e) {
                return function(t) {
                    var n = t.nodeName.toLowerCase();
                    return ("input" === n || "button" === n) && t.type === e
                }
            }

            function le(e) {
                return re((function(t) {
                    return t = +t, re((function(n, r) {
                        for (var i, o = e([], n.length, t), a = o.length; a--;) n[i = o[a]] && (n[i] = !(r[i] = n[i]))
                    }))
                }))
            }
            for (n in a = oe.isXML = function(e) {
                    var t = e && (e.ownerDocument || e).documentElement;
                    return !!t && "HTML" !== t.nodeName
                }, c = oe.setDocument = function(e) {
                    var n = e ? e.ownerDocument || e : w;
                    return n !== f && 9 === n.nodeType && n.documentElement ? (f = n, p = n.documentElement, d = a(n), T.tagNameNoComments = ie((function(e) {
                        return e.appendChild(n.createComment("")), !e.getElementsByTagName("*").length
                    })), T.attributes = ie((function(e) {
                        e.innerHTML = "<select></select>";
                        var t = typeof e.lastChild.getAttribute("multiple");
                        return "boolean" !== t && "string" !== t
                    })), T.getByClassName = ie((function(e) {
                        return e.innerHTML = "<div class='hidden e'></div><div class='hidden'></div>", !(!e.getElementsByClassName || !e.getElementsByClassName("e").length) && (e.lastChild.className = "e", 2 === e.getElementsByClassName("e").length)
                    })), T.getByName = ie((function(e) {
                        e.id = b + 0, e.innerHTML = "<a name='" + b + "'></a><div name='" + b + "'></div>", p.insertBefore(e, p.firstChild);
                        var t = n.getElementsByName && n.getElementsByName(b).length === 2 + n.getElementsByName(b + 0).length;
                        return T.getIdNotName = !n.getElementById(b), p.removeChild(e), t
                    })), i.attrHandle = ie((function(e) {
                        return e.innerHTML = "<a href='#'></a>", e.firstChild && typeof e.firstChild.getAttribute !== A && "#" === e.firstChild.getAttribute("href")
                    })) ? {} : {
                        href: function(e) {
                            return e.getAttribute("href", 2)
                        },
                        type: function(e) {
                            return e.getAttribute("type")
                        }
                    }, T.getIdNotName ? (i.find.ID = function(e, t) {
                        if (typeof t.getElementById !== A && !d) {
                            var n = t.getElementById(e);
                            return n && n.parentNode ? [n] : []
                        }
                    }, i.filter.ID = function(e) {
                        var t = e.replace(Z, ee);
                        return function(e) {
                            return e.getAttribute("id") === t
                        }
                    }) : (i.find.ID = function(e, n) {
                        if (typeof n.getElementById !== A && !d) {
                            var r = n.getElementById(e);
                            return r ? r.id === e || typeof r.getAttributeNode !== A && r.getAttributeNode("id").value === e ? [r] : t : []
                        }
                    }, i.filter.ID = function(e) {
                        var t = e.replace(Z, ee);
                        return function(e) {
                            var n = typeof e.getAttributeNode !== A && e.getAttributeNode("id");
                            return n && n.value === t
                        }
                    }), i.find.TAG = T.tagNameNoComments ? function(e, t) {
                        if (typeof t.getElementsByTagName !== A) return t.getElementsByTagName(e)
                    } : function(e, t) {
                        var n, r = [],
                            i = 0,
                            o = t.getElementsByTagName(e);
                        if ("*" === e) {
                            for (; n = o[i++];) 1 === n.nodeType && r.push(n);
                            return r
                        }
                        return o
                    }, i.find.NAME = T.getByName && function(e, t) {
                        if (typeof t.getElementsByName !== A) return t.getElementsByName(name)
                    }, i.find.CLASS = T.getByClassName && function(e, t) {
                        if (typeof t.getElementsByClassName !== A && !d) return t.getElementsByClassName(e)
                    }, g = [], h = [":focus"], (T.qsa = te(n.querySelectorAll)) && (ie((function(e) {
                        e.innerHTML = "<select><option selected=''></option></select>", e.querySelectorAll("[selected]").length || h.push("\\[[\\x20\\t\\r\\n\\f]*(?:checked|disabled|ismap|multiple|readonly|selected|value)"), e.querySelectorAll(":checked").length || h.push(":checked")
                    })), ie((function(e) {
                        e.innerHTML = "<input type='hidden' i=''/>", e.querySelectorAll("[i^='']").length && h.push("[*^$]=[\\x20\\t\\r\\n\\f]*(?:\"\"|'')"), e.querySelectorAll(":enabled").length || h.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), h.push(",.*:")
                    }))), (T.matchesSelector = te(m = p.matchesSelector || p.mozMatchesSelector || p.webkitMatchesSelector || p.oMatchesSelector || p.msMatchesSelector)) && ie((function(e) {
                        T.disconnectedMatch = m.call(e, "div"), m.call(e, "[s!='']:x"), g.push("!=", P)
                    })), h = new RegExp(h.join("|")), g = new RegExp(g.join("|")), y = te(p.contains) || p.compareDocumentPosition ? function(e, t) {
                        var n = 9 === e.nodeType ? e.documentElement : e,
                            r = t && t.parentNode;
                        return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)))
                    } : function(e, t) {
                        if (t)
                            for (; t = t.parentNode;)
                                if (t === e) return !0;
                        return !1
                    }, v = p.compareDocumentPosition ? function(e, t) {
                        var r;
                        return e === t ? (u = !0, 0) : (r = t.compareDocumentPosition && e.compareDocumentPosition && e.compareDocumentPosition(t)) ? 1 & r || e.parentNode && 11 === e.parentNode.nodeType ? e === n || y(w, e) ? -1 : t === n || y(w, t) ? 1 : 0 : 4 & r ? -1 : 1 : e.compareDocumentPosition ? -1 : 1
                    } : function(e, t) {
                        var r, i = 0,
                            o = e.parentNode,
                            a = t.parentNode,
                            s = [e],
                            l = [t];
                        if (e === t) return u = !0, 0;
                        if (!o || !a) return e === n ? -1 : t === n ? 1 : o ? -1 : a ? 1 : 0;
                        if (o === a) return ae(e, t);
                        for (r = e; r = r.parentNode;) s.unshift(r);
                        for (r = t; r = r.parentNode;) l.unshift(r);
                        for (; s[i] === l[i];) i++;
                        return i ? ae(s[i], l[i]) : s[i] === w ? -1 : l[i] === w ? 1 : 0
                    }, u = !1, [0, 0].sort(v), T.detectDuplicates = u, f) : f
                }, oe.matches = function(e, t) {
                    return oe(e, null, null, t)
                }, oe.matchesSelector = function(e, t) {
                    if ((e.ownerDocument || e) !== f && c(e), t = t.replace(K, "='$1']"), T.matchesSelector && !d && (!g || !g.test(t)) && !h.test(t)) try {
                        var n = m.call(e, t);
                        if (n || T.disconnectedMatch || e.document && 11 !== e.document.nodeType) return n
                    } catch (e) {}
                    return oe(t, f, null, [e]).length > 0
                }, oe.contains = function(e, t) {
                    return (e.ownerDocument || e) !== f && c(e), y(e, t)
                }, oe.attr = function(e, t) {
                    var n;
                    return (e.ownerDocument || e) !== f && c(e), d || (t = t.toLowerCase()), (n = i.attrHandle[t]) ? n(e) : d || T.attributes ? e.getAttribute(t) : ((n = e.getAttributeNode(t)) || e.getAttribute(t)) && !0 === e[t] ? t : n && n.specified ? n.value : null
                }, oe.error = function(e) {
                    throw new Error("Syntax error, unrecognized expression: " + e)
                }, oe.uniqueSort = function(e) {
                    var t, n = [],
                        r = 1,
                        i = 0;
                    if (u = !T.detectDuplicates, e.sort(v), u) {
                        for (; t = e[r]; r++) t === e[r - 1] && (i = n.push(r));
                        for (; i--;) e.splice(n[i], 1)
                    }
                    return e
                }, o = oe.getText = function(e) {
                    var t, n = "",
                        r = 0,
                        i = e.nodeType;
                    if (i) {
                        if (1 === i || 9 === i || 11 === i) {
                            if ("string" == typeof e.textContent) return e.textContent;
                            for (e = e.firstChild; e; e = e.nextSibling) n += o(e)
                        } else if (3 === i || 4 === i) return e.nodeValue
                    } else
                        for (; t = e[r]; r++) n += o(t);
                    return n
                }, i = oe.selectors = {
                    cacheLength: 50,
                    createPseudo: re,
                    match: X,
                    find: {},
                    relative: {
                        ">": {
                            dir: "parentNode",
                            first: !0
                        },
                        " ": {
                            dir: "parentNode"
                        },
                        "+": {
                            dir: "previousSibling",
                            first: !0
                        },
                        "~": {
                            dir: "previousSibling"
                        }
                    },
                    preFilter: {
                        ATTR: function(e) {
                            return e[1] = e[1].replace(Z, ee), e[3] = (e[4] || e[5] || "").replace(Z, ee), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                        },
                        CHILD: function(e) {
                            return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || oe.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && oe.error(e[0]), e
                        },
                        PSEUDO: function(e) {
                            var t, n = !e[5] && e[2];
                            return X.CHILD.test(e[0]) ? null : (e[4] ? e[2] = e[4] : n && I.test(n) && (t = ce(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                        }
                    },
                    filter: {
                        TAG: function(e) {
                            return "*" === e ? function() {
                                return !0
                            } : (e = e.replace(Z, ee).toLowerCase(), function(t) {
                                return t.nodeName && t.nodeName.toLowerCase() === e
                            })
                        },
                        CLASS: function(e) {
                            var t = k[e + " "];
                            return t || (t = new RegExp("(^|[\\x20\\t\\r\\n\\f])" + e + "(" + _ + "|$)")) && k(e, (function(e) {
                                return t.test(e.className || typeof e.getAttribute !== A && e.getAttribute("class") || "")
                            }))
                        },
                        ATTR: function(e, t, n) {
                            return function(r) {
                                var i = oe.attr(r, e);
                                return null == i ? "!=" === t : !t || (i += "", "=" === t ? i === n : "!=" === t ? i !== n : "^=" === t ? n && 0 === i.indexOf(n) : "*=" === t ? n && i.indexOf(n) > -1 : "$=" === t ? n && i.slice(-n.length) === n : "~=" === t ? (" " + i + " ").indexOf(n) > -1 : "|=" === t && (i === n || i.slice(0, n.length + 1) === n + "-"))
                            }
                        },
                        CHILD: function(e, t, n, r, i) {
                            var o = "nth" !== e.slice(0, 3),
                                a = "last" !== e.slice(-4),
                                s = "of-type" === t;
                            return 1 === r && 0 === i ? function(e) {
                                return !!e.parentNode
                            } : function(t, n, u) {
                                var l, c, f, p, d, h, g = o !== a ? "nextSibling" : "previousSibling",
                                    m = t.parentNode,
                                    y = s && t.nodeName.toLowerCase(),
                                    v = !u && !s;
                                if (m) {
                                    if (o) {
                                        for (; g;) {
                                            for (f = t; f = f[g];)
                                                if (s ? f.nodeName.toLowerCase() === y : 1 === f.nodeType) return !1;
                                            h = g = "only" === e && !h && "nextSibling"
                                        }
                                        return !0
                                    }
                                    if (h = [a ? m.firstChild : m.lastChild], a && v) {
                                        for (d = (l = (c = m[b] || (m[b] = {}))[e] || [])[0] === N && l[1], p = l[0] === N && l[2], f = d && m.childNodes[d]; f = ++d && f && f[g] || (p = d = 0) || h.pop();)
                                            if (1 === f.nodeType && ++p && f === t) {
                                                c[e] = [N, d, p];
                                                break
                                            }
                                    } else if (v && (l = (t[b] || (t[b] = {}))[e]) && l[0] === N) p = l[1];
                                    else
                                        for (;
                                            (f = ++d && f && f[g] || (p = d = 0) || h.pop()) && ((s ? f.nodeName.toLowerCase() !== y : 1 !== f.nodeType) || !++p || (v && ((f[b] || (f[b] = {}))[e] = [N, p]), f !== t)););
                                    return (p -= i) === r || p % r == 0 && p / r >= 0
                                }
                            }
                        },
                        PSEUDO: function(e, t) {
                            var n, r = i.pseudos[e] || i.setFilters[e.toLowerCase()] || oe.error("unsupported pseudo: " + e);
                            return r[b] ? r(t) : r.length > 1 ? (n = [e, e, "", t], i.setFilters.hasOwnProperty(e.toLowerCase()) ? re((function(e, n) {
                                for (var i, o = r(e, t), a = o.length; a--;) e[i = M.call(e, o[a])] = !(n[i] = o[a])
                            })) : function(e) {
                                return r(e, 0, n)
                            }) : r
                        }
                    },
                    pseudos: {
                        not: re((function(e) {
                            var t = [],
                                n = [],
                                r = s(e.replace(R, "$1"));
                            return r[b] ? re((function(e, t, n, i) {
                                for (var o, a = r(e, null, i, []), s = e.length; s--;)(o = a[s]) && (e[s] = !(t[s] = o))
                            })) : function(e, i, o) {
                                return t[0] = e, r(t, null, o, n), !n.pop()
                            }
                        })),
                        has: re((function(e) {
                            return function(t) {
                                return oe(e, t).length > 0
                            }
                        })),
                        contains: re((function(e) {
                            return function(t) {
                                return (t.textContent || t.innerText || o(t)).indexOf(e) > -1
                            }
                        })),
                        lang: re((function(e) {
                            return z.test(e || "") || oe.error("unsupported lang: " + e), e = e.replace(Z, ee).toLowerCase(),
                                function(t) {
                                    var n;
                                    do {
                                        if (n = d ? t.getAttribute("xml:lang") || t.getAttribute("lang") : t.lang) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-")
                                    } while ((t = t.parentNode) && 1 === t.nodeType);
                                    return !1
                                }
                        })),
                        target: function(t) {
                            var n = e.location && e.location.hash;
                            return n && n.slice(1) === t.id
                        },
                        root: function(e) {
                            return e === p
                        },
                        focus: function(e) {
                            return e === f.activeElement && (!f.hasFocus || f.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                        },
                        enabled: function(e) {
                            return !1 === e.disabled
                        },
                        disabled: function(e) {
                            return !0 === e.disabled
                        },
                        checked: function(e) {
                            var t = e.nodeName.toLowerCase();
                            return "input" === t && !!e.checked || "option" === t && !!e.selected
                        },
                        selected: function(e) {
                            return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
                        },
                        empty: function(e) {
                            for (e = e.firstChild; e; e = e.nextSibling)
                                if (e.nodeName > "@" || 3 === e.nodeType || 4 === e.nodeType) return !1;
                            return !0
                        },
                        parent: function(e) {
                            return !i.pseudos.empty(e)
                        },
                        header: function(e) {
                            return G.test(e.nodeName)
                        },
                        input: function(e) {
                            return J.test(e.nodeName)
                        },
                        button: function(e) {
                            var t = e.nodeName.toLowerCase();
                            return "input" === t && "button" === e.type || "button" === t
                        },
                        text: function(e) {
                            var t;
                            return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || t.toLowerCase() === e.type)
                        },
                        first: le((function() {
                            return [0]
                        })),
                        last: le((function(e, t) {
                            return [t - 1]
                        })),
                        eq: le((function(e, t, n) {
                            return [n < 0 ? n + t : n]
                        })),
                        even: le((function(e, t) {
                            for (var n = 0; n < t; n += 2) e.push(n);
                            return e
                        })),
                        odd: le((function(e, t) {
                            for (var n = 1; n < t; n += 2) e.push(n);
                            return e
                        })),
                        lt: le((function(e, t, n) {
                            for (var r = n < 0 ? n + t : n; --r >= 0;) e.push(r);
                            return e
                        })),
                        gt: le((function(e, t, n) {
                            for (var r = n < 0 ? n + t : n; ++r < t;) e.push(r);
                            return e
                        }))
                    }
                }, {
                    radio: !0,
                    checkbox: !0,
                    file: !0,
                    password: !0,
                    image: !0
                }) i.pseudos[n] = se(n);
            for (n in {
                    submit: !0,
                    reset: !0
                }) i.pseudos[n] = ue(n);

            function ce(e, t) {
                var n, r, o, a, s, u, l, c = E[e + " "];
                if (c) return t ? 0 : c.slice(0);
                for (s = e, u = [], l = i.preFilter; s;) {
                    for (a in n && !(r = W.exec(s)) || (r && (s = s.slice(r[0].length) || s), u.push(o = [])), n = !1, (r = $.exec(s)) && (n = r.shift(), o.push({
                            value: n,
                            type: r[0].replace(R, " ")
                        }), s = s.slice(n.length)), i.filter) !(r = X[a].exec(s)) || l[a] && !(r = l[a](r)) || (n = r.shift(), o.push({
                        value: n,
                        type: a,
                        matches: r
                    }), s = s.slice(n.length));
                    if (!n) break
                }
                return t ? s.length : s ? oe.error(e) : E(e, u).slice(0)
            }

            function fe(e) {
                for (var t = 0, n = e.length, r = ""; t < n; t++) r += e[t].value;
                return r
            }

            function pe(e, t, n) {
                var i = t.dir,
                    o = n && "parentNode" === i,
                    a = C++;
                return t.first ? function(t, n, r) {
                    for (; t = t[i];)
                        if (1 === t.nodeType || o) return e(t, n, r)
                } : function(t, n, s) {
                    var u, l, c, f = N + " " + a;
                    if (s) {
                        for (; t = t[i];)
                            if ((1 === t.nodeType || o) && e(t, n, s)) return !0
                    } else
                        for (; t = t[i];)
                            if (1 === t.nodeType || o)
                                if ((l = (c = t[b] || (t[b] = {}))[i]) && l[0] === f) {
                                    if (!0 === (u = l[1]) || u === r) return !0 === u
                                } else if ((l = c[i] = [f])[1] = e(t, n, s) || r, !0 === l[1]) return !0
                }
            }

            function de(e) {
                return e.length > 1 ? function(t, n, r) {
                    for (var i = e.length; i--;)
                        if (!e[i](t, n, r)) return !1;
                    return !0
                } : e[0]
            }

            function he(e, t, n, r, i) {
                for (var o, a = [], s = 0, u = e.length, l = null != t; s < u; s++)(o = e[s]) && (n && !n(o, r, i) || (a.push(o), l && t.push(s)));
                return a
            }

            function ge(e, t, n, r, i, o) {
                return r && !r[b] && (r = ge(r)), i && !i[b] && (i = ge(i, o)), re((function(o, a, s, u) {
                    var l, c, f, p = [],
                        d = [],
                        h = a.length,
                        g = o || function(e, t, n) {
                            for (var r = 0, i = t.length; r < i; r++) oe(e, t[r], n);
                            return n
                        }(t || "*", s.nodeType ? [s] : s, []),
                        m = !e || !o && t ? g : he(g, p, e, s, u),
                        y = n ? i || (o ? e : h || r) ? [] : a : m;
                    if (n && n(m, y, s, u), r)
                        for (l = he(y, d), r(l, [], s, u), c = l.length; c--;)(f = l[c]) && (y[d[c]] = !(m[d[c]] = f));
                    if (o) {
                        if (i || e) {
                            if (i) {
                                for (l = [], c = y.length; c--;)(f = y[c]) && l.push(m[c] = f);
                                i(null, y = [], l, u)
                            }
                            for (c = y.length; c--;)(f = y[c]) && (l = i ? M.call(o, f) : p[c]) > -1 && (o[l] = !(a[l] = f))
                        }
                    } else y = he(y === a ? y.splice(h, y.length) : y), i ? i(null, a, y, u) : H.apply(a, y)
                }))
            }

            function me(e) {
                for (var t, n, r, o = e.length, a = i.relative[e[0].type], s = a || i.relative[" "], u = a ? 1 : 0, c = pe((function(e) {
                        return e === t
                    }), s, !0), f = pe((function(e) {
                        return M.call(t, e) > -1
                    }), s, !0), p = [function(e, n, r) {
                        return !a && (r || n !== l) || ((t = n).nodeType ? c(e, n, r) : f(e, n, r))
                    }]; u < o; u++)
                    if (n = i.relative[e[u].type]) p = [pe(de(p), n)];
                    else {
                        if ((n = i.filter[e[u].type].apply(null, e[u].matches))[b]) {
                            for (r = ++u; r < o && !i.relative[e[r].type]; r++);
                            return ge(u > 1 && de(p), u > 1 && fe(e.slice(0, u - 1)).replace(R, "$1"), n, u < r && me(e.slice(u, r)), r < o && me(e = e.slice(r)), r < o && fe(e))
                        }
                        p.push(n)
                    }
                return de(p)
            }

            function ye() {}
            s = oe.compile = function(e, t) {
                var n, o = [],
                    a = [],
                    s = S[e + " "];
                if (!s) {
                    for (t || (t = ce(e)), n = t.length; n--;)(s = me(t[n]))[b] ? o.push(s) : a.push(s);
                    s = S(e, function(e, t) {
                        var n = 0,
                            o = t.length > 0,
                            a = e.length > 0,
                            s = function(s, u, c, p, d) {
                                var h, g, m, y = [],
                                    v = 0,
                                    x = "0",
                                    b = s && [],
                                    w = null != d,
                                    T = l,
                                    C = s || a && i.find.TAG("*", d && u.parentNode || u),
                                    k = N += null == T ? 1 : Math.random() || .1;
                                for (w && (l = u !== f && u, r = n); null != (h = C[x]); x++) {
                                    if (a && h) {
                                        for (g = 0; m = e[g++];)
                                            if (m(h, u, c)) {
                                                p.push(h);
                                                break
                                            }
                                        w && (N = k, r = ++n)
                                    }
                                    o && ((h = !m && h) && v--, s && b.push(h))
                                }
                                if (v += x, o && x !== v) {
                                    for (g = 0; m = t[g++];) m(b, y, u, c);
                                    if (s) {
                                        if (v > 0)
                                            for (; x--;) b[x] || y[x] || (y[x] = L.call(p));
                                        y = he(y)
                                    }
                                    H.apply(p, y), w && !s && y.length > 0 && v + t.length > 1 && oe.uniqueSort(p)
                                }
                                return w && (N = k, l = T), b
                            };
                        return o ? re(s) : s
                    }(a, o))
                }
                return s
            }, i.pseudos.nth = i.pseudos.eq, i.filters = ye.prototype = i.pseudos, i.setFilters = new ye, c(), oe.attr = x.attr, x.find = oe, x.expr = oe.selectors, x.expr[":"] = x.expr.pseudos, x.unique = oe.uniqueSort, x.text = oe.getText, x.isXMLDoc = oe.isXML, x.contains = oe.contains
        }(e);
    var oe = /Until$/,
        ae = /^(?:parents|prev(?:Until|All))/,
        se = /^.[^:#\[\.,]*$/,
        ue = x.expr.match.needsContext,
        le = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };

    function ce(e, t) {
        do {
            e = e[t]
        } while (e && 1 !== e.nodeType);
        return e
    }

    function fe(e, t, n) {
        if (t = t || 0, x.isFunction(t)) return x.grep(e, (function(e, r) {
            return !!t.call(e, r, e) === n
        }));
        if (t.nodeType) return x.grep(e, (function(e) {
            return e === t === n
        }));
        if ("string" == typeof t) {
            var r = x.grep(e, (function(e) {
                return 1 === e.nodeType
            }));
            if (se.test(t)) return x.filter(t, r, !n);
            t = x.filter(t, r)
        }
        return x.grep(e, (function(e) {
            return x.inArray(e, t) >= 0 === n
        }))
    }

    function pe(e) {
        var t = de.split("|"),
            n = e.createDocumentFragment();
        if (n.createElement)
            for (; t.length;) n.createElement(t.pop());
        return n
    }
    x.fn.extend({
        find: function(e) {
            var t, n, r, i = this.length;
            if ("string" != typeof e) return r = this, this.pushStack(x(e).filter((function() {
                for (t = 0; t < i; t++)
                    if (x.contains(r[t], this)) return !0
            })));
            for (n = [], t = 0; t < i; t++) x.find(e, this[t], n);
            return (n = this.pushStack(i > 1 ? x.unique(n) : n)).selector = (this.selector ? this.selector + " " : "") + e, n
        },
        has: function(e) {
            var t, n = x(e, this),
                r = n.length;
            return this.filter((function() {
                for (t = 0; t < r; t++)
                    if (x.contains(this, n[t])) return !0
            }))
        },
        not: function(e) {
            return this.pushStack(fe(this, e, !1))
        },
        filter: function(e) {
            return this.pushStack(fe(this, e, !0))
        },
        is: function(e) {
            return !!e && ("string" == typeof e ? ue.test(e) ? x(e, this.context).index(this[0]) >= 0 : x.filter(e, this).length > 0 : this.filter(e).length > 0)
        },
        closest: function(e, t) {
            for (var n, r = 0, i = this.length, o = [], a = ue.test(e) || "string" != typeof e ? x(e, t || this.context) : 0; r < i; r++)
                for (n = this[r]; n && n.ownerDocument && n !== t && 11 !== n.nodeType;) {
                    if (a ? a.index(n) > -1 : x.find.matchesSelector(n, e)) {
                        o.push(n);
                        break
                    }
                    n = n.parentNode
                }
            return this.pushStack(o.length > 1 ? x.unique(o) : o)
        },
        index: function(e) {
            return e ? "string" == typeof e ? x.inArray(this[0], x(e)) : x.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(e, t) {
            var n = "string" == typeof e ? x(e, t) : x.makeArray(e && e.nodeType ? [e] : e),
                r = x.merge(this.get(), n);
            return this.pushStack(x.unique(r))
        },
        addBack: function(e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), x.fn.andSelf = x.fn.addBack, x.each({
        parent: function(e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t : null
        },
        parents: function(e) {
            return x.dir(e, "parentNode")
        },
        parentsUntil: function(e, t, n) {
            return x.dir(e, "parentNode", n)
        },
        next: function(e) {
            return ce(e, "nextSibling")
        },
        prev: function(e) {
            return ce(e, "previousSibling")
        },
        nextAll: function(e) {
            return x.dir(e, "nextSibling")
        },
        prevAll: function(e) {
            return x.dir(e, "previousSibling")
        },
        nextUntil: function(e, t, n) {
            return x.dir(e, "nextSibling", n)
        },
        prevUntil: function(e, t, n) {
            return x.dir(e, "previousSibling", n)
        },
        siblings: function(e) {
            return x.sibling((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return x.sibling(e.firstChild)
        },
        contents: function(e) {
            return x.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : x.merge([], e.childNodes)
        }
    }, (function(e, t) {
        x.fn[e] = function(n, r) {
            var i = x.map(this, t, n);
            return oe.test(e) || (r = n), r && "string" == typeof r && (i = x.filter(r, i)), i = this.length > 1 && !le[e] ? x.unique(i) : i, this.length > 1 && ae.test(e) && (i = i.reverse()), this.pushStack(i)
        }
    })), x.extend({
        filter: function(e, t, n) {
            return n && (e = ":not(" + e + ")"), 1 === t.length ? x.find.matchesSelector(t[0], e) ? [t[0]] : [] : x.find.matches(e, t)
        },
        dir: function(e, n, r) {
            for (var i = [], o = e[n]; o && 9 !== o.nodeType && (r === t || 1 !== o.nodeType || !x(o).is(r));) 1 === o.nodeType && i.push(o), o = o[n];
            return i
        },
        sibling: function(e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        }
    });
    var de = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
        he = / jQuery\d+="(?:null|\d+)"/g,
        ge = new RegExp("<(?:" + de + ")[\\s/>]", "i"),
        me = /^\s+/,
        ye = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
        ve = /<([\w:]+)/,
        xe = /<tbody/i,
        be = /<|&#?\w+;/,
        we = /<(?:script|style|link)/i,
        Te = /^(?:checkbox|radio)$/i,
        Ne = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Ce = /^$|\/(?:java|ecma)script/i,
        ke = /^true\/(.*)/,
        Ee = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
        Se = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            legend: [1, "<fieldset>", "</fieldset>"],
            area: [1, "<map>", "</map>"],
            param: [1, "<object>", "</object>"],
            thead: [1, "<table>", "</table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: x.support.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
        },
        Ae = pe(o).appendChild(o.createElement("div"));

    function je(e) {
        var t = e.getAttributeNode("type");
        return e.type = (t && t.specified) + "/" + e.type, e
    }

    function De(e) {
        var t = ke.exec(e.type);
        return t ? e.type = t[1] : e.removeAttribute("type"), e
    }

    function Le(e, t) {
        for (var n, r = 0; null != (n = e[r]); r++) x._data(n, "globalEval", !t || x._data(t[r], "globalEval"))
    }

    function He(e, t) {
        if (1 === t.nodeType && x.hasData(e)) {
            var n, r, i, o = x._data(e),
                a = x._data(t, o),
                s = o.events;
            if (s)
                for (n in delete a.handle, a.events = {}, s)
                    for (r = 0, i = s[n].length; r < i; r++) x.event.add(t, n, s[n][r]);
            a.data && (a.data = x.extend({}, a.data))
        }
    }

    function qe(e, t) {
        var n, r, i;
        if (1 === t.nodeType) {
            if (n = t.nodeName.toLowerCase(), !x.support.noCloneEvent && t[x.expando]) {
                for (r in (i = x._data(t)).events) x.removeEvent(t, r, i.handle);
                t.removeAttribute(x.expando)
            }
            "script" === n && t.text !== e.text ? (je(t).text = e.text, De(t)) : "object" === n ? (t.parentNode && (t.outerHTML = e.outerHTML), x.support.html5Clone && e.innerHTML && !x.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : "input" === n && Te.test(e.type) ? (t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value)) : "option" === n ? t.defaultSelected = t.selected = e.defaultSelected : "input" !== n && "textarea" !== n || (t.defaultValue = e.defaultValue)
        }
    }

    function Me(e, n) {
        var r, o, a = 0,
            s = typeof e.getElementsByTagName !== i ? e.getElementsByTagName(n || "*") : typeof e.querySelectorAll !== i ? e.querySelectorAll(n || "*") : t;
        if (!s)
            for (s = [], r = e.childNodes || e; null != (o = r[a]); a++) !n || x.nodeName(o, n) ? s.push(o) : x.merge(s, Me(o, n));
        return n === t || n && x.nodeName(e, n) ? x.merge([e], s) : s
    }

    function _e(e) {
        Te.test(e.type) && (e.defaultChecked = e.checked)
    }
    Se.optgroup = Se.option, Se.tbody = Se.tfoot = Se.colgroup = Se.caption = Se.thead, Se.th = Se.td, x.fn.extend({
        text: function(e) {
            return x.access(this, (function(e) {
                return e === t ? x.text(this) : this.empty().append((this[0] && this[0].ownerDocument || o).createTextNode(e))
            }), null, e, arguments.length)
        },
        wrapAll: function(e) {
            if (x.isFunction(e)) return this.each((function(t) {
                x(this).wrapAll(e.call(this, t))
            }));
            if (this[0]) {
                var t = x(e, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && t.insertBefore(this[0]), t.map((function() {
                    for (var e = this; e.firstChild && 1 === e.firstChild.nodeType;) e = e.firstChild;
                    return e
                })).append(this)
            }
            return this
        },
        wrapInner: function(e) {
            return x.isFunction(e) ? this.each((function(t) {
                x(this).wrapInner(e.call(this, t))
            })) : this.each((function() {
                var t = x(this),
                    n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            }))
        },
        wrap: function(e) {
            var t = x.isFunction(e);
            return this.each((function(n) {
                x(this).wrapAll(t ? e.call(this, n) : e)
            }))
        },
        unwrap: function() {
            return this.parent().each((function() {
                x.nodeName(this, "body") || x(this).replaceWith(this.childNodes)
            })).end()
        },
        append: function() {
            return this.domManip(arguments, !0, (function(e) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || this.appendChild(e)
            }))
        },
        prepend: function() {
            return this.domManip(arguments, !0, (function(e) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || this.insertBefore(e, this.firstChild)
            }))
        },
        before: function() {
            return this.domManip(arguments, !1, (function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            }))
        },
        after: function() {
            return this.domManip(arguments, !1, (function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            }))
        },
        remove: function(e, t) {
            for (var n, r = 0; null != (n = this[r]); r++)(!e || x.filter(e, [n]).length > 0) && (t || 1 !== n.nodeType || x.cleanData(Me(n)), n.parentNode && (t && x.contains(n.ownerDocument, n) && Le(Me(n, "script")), n.parentNode.removeChild(n)));
            return this
        },
        empty: function() {
            for (var e, t = 0; null != (e = this[t]); t++) {
                for (1 === e.nodeType && x.cleanData(Me(e, !1)); e.firstChild;) e.removeChild(e.firstChild);
                e.options && x.nodeName(e, "select") && (e.options.length = 0)
            }
            return this
        },
        clone: function(e, t) {
            return e = null != e && e, t = null == t ? e : t, this.map((function() {
                return x.clone(this, e, t)
            }))
        },
        html: function(e) {
            return x.access(this, (function(e) {
                var n = this[0] || {},
                    r = 0,
                    i = this.length;
                if (e === t) return 1 === n.nodeType ? n.innerHTML.replace(he, "") : t;
                if ("string" == typeof e && !we.test(e) && (x.support.htmlSerialize || !ge.test(e)) && (x.support.leadingWhitespace || !me.test(e)) && !Se[(ve.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = e.replace(ye, "<$1></$2>");
                    try {
                        for (; r < i; r++) 1 === (n = this[r] || {}).nodeType && (x.cleanData(Me(n, !1)), n.innerHTML = e);
                        n = 0
                    } catch (e) {}
                }
                n && this.empty().append(e)
            }), null, e, arguments.length)
        },
        replaceWith: function(e) {
            return x.isFunction(e) || "string" == typeof e || (e = x(e).not(this).detach()), this.domManip([e], !0, (function(e) {
                var t = this.nextSibling,
                    n = this.parentNode;
                n && (x(this).remove(), n.insertBefore(e, t))
            }))
        },
        detach: function(e) {
            return this.remove(e, !0)
        },
        domManip: function(e, n, r) {
            e = p.apply([], e);
            var i, o, a, s, u, l, c, f, d = 0,
                h = this.length,
                g = this,
                m = h - 1,
                y = e[0],
                v = x.isFunction(y);
            if (v || !(h <= 1 || "string" != typeof y || x.support.checkClone) && Ne.test(y)) return this.each((function(i) {
                var o = g.eq(i);
                v && (e[0] = y.call(this, i, n ? o.html() : t)), o.domManip(e, n, r)
            }));
            if (h && (i = (l = x.buildFragment(e, this[0].ownerDocument, !1, this)).firstChild, 1 === l.childNodes.length && (l = i), i)) {
                for (n = n && x.nodeName(i, "tr"), a = (s = x.map(Me(l, "script"), je)).length; d < h; d++) o = l, d !== m && (o = x.clone(o, !0, !0), a && x.merge(s, Me(o, "script"))), r.call(n && x.nodeName(this[d], "table") ? (c = this[d], f = "tbody", c.getElementsByTagName(f)[0] || c.appendChild(c.ownerDocument.createElement(f))) : this[d], o, d);
                if (a)
                    for (u = s[s.length - 1].ownerDocument, x.map(s, De), d = 0; d < a; d++) o = s[d], Ce.test(o.type || "") && !x._data(o, "globalEval") && x.contains(u, o) && (o.src ? x.ajax({
                        url: o.src,
                        type: "GET",
                        dataType: "script",
                        async: !1,
                        global: !1,
                        throws: !0
                    }) : x.globalEval((o.text || o.textContent || o.innerHTML || "").replace(Ee, "")));
                l = i = null
            }
            return this
        }
    }), x.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, (function(e, t) {
        x.fn[e] = function(e) {
            for (var n, r = 0, i = [], o = x(e), a = o.length - 1; r <= a; r++) n = r === a ? this : this.clone(!0), x(o[r])[t](n), d.apply(i, n.get());
            return this.pushStack(i)
        }
    })), x.extend({
        clone: function(e, t, n) {
            var r, i, o, a, s, u = x.contains(e.ownerDocument, e);
            if (x.support.html5Clone || x.isXMLDoc(e) || !ge.test("<" + e.nodeName + ">") ? o = e.cloneNode(!0) : (Ae.innerHTML = e.outerHTML, Ae.removeChild(o = Ae.firstChild)), !(x.support.noCloneEvent && x.support.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || x.isXMLDoc(e)))
                for (r = Me(o), s = Me(e), a = 0; null != (i = s[a]); ++a) r[a] && qe(i, r[a]);
            if (t)
                if (n)
                    for (s = s || Me(e), r = r || Me(o), a = 0; null != (i = s[a]); a++) He(i, r[a]);
                else He(e, o);
            return (r = Me(o, "script")).length > 0 && Le(r, !u && Me(e, "script")), r = s = i = null, o
        },
        buildFragment: function(e, t, n, r) {
            for (var i, o, a, s, u, l, c, f = e.length, p = pe(t), d = [], h = 0; h < f; h++)
                if ((o = e[h]) || 0 === o)
                    if ("object" === x.type(o)) x.merge(d, o.nodeType ? [o] : o);
                    else if (be.test(o)) {
                for (s = s || p.appendChild(t.createElement("div")), u = (ve.exec(o) || ["", ""])[1].toLowerCase(), c = Se[u] || Se._default, s.innerHTML = c[1] + o.replace(ye, "<$1></$2>") + c[2], i = c[0]; i--;) s = s.lastChild;
                if (!x.support.leadingWhitespace && me.test(o) && d.push(t.createTextNode(me.exec(o)[0])), !x.support.tbody)
                    for (i = (o = "table" !== u || xe.test(o) ? "<table>" !== c[1] || xe.test(o) ? 0 : s : s.firstChild) && o.childNodes.length; i--;) x.nodeName(l = o.childNodes[i], "tbody") && !l.childNodes.length && o.removeChild(l);
                for (x.merge(d, s.childNodes), s.textContent = ""; s.firstChild;) s.removeChild(s.firstChild);
                s = p.lastChild
            } else d.push(t.createTextNode(o));
            for (s && p.removeChild(s), x.support.appendChecked || x.grep(Me(d, "input"), _e), h = 0; o = d[h++];)
                if ((!r || -1 === x.inArray(o, r)) && (a = x.contains(o.ownerDocument, o), s = Me(p.appendChild(o), "script"), a && Le(s), n))
                    for (i = 0; o = s[i++];) Ce.test(o.type || "") && n.push(o);
            return s = null, p
        },
        cleanData: function(e, t) {
            for (var n, r, o, a, s = 0, u = x.expando, l = x.cache, f = x.support.deleteExpando, p = x.event.special; null != (n = e[s]); s++)
                if ((t || x.acceptData(n)) && (a = (o = n[u]) && l[o])) {
                    if (a.events)
                        for (r in a.events) p[r] ? x.event.remove(n, r) : x.removeEvent(n, r, a.handle);
                    l[o] && (delete l[o], f ? delete n[u] : typeof n.removeAttribute !== i ? n.removeAttribute(u) : n[u] = null, c.push(o))
                }
        }
    });
    var Fe, Oe, Be, Pe = /alpha\([^)]*\)/i,
        Re = /opacity\s*=\s*([^)]*)/,
        We = /^(top|right|bottom|left)$/,
        $e = /^(none|table(?!-c[ea]).+)/,
        Ie = /^margin/,
        ze = new RegExp("^(" + b + ")(.*)$", "i"),
        Xe = new RegExp("^(" + b + ")(?!px)[a-z%]+$", "i"),
        Ue = new RegExp("^([+-])=(" + b + ")", "i"),
        Ve = {
            BODY: "block"
        },
        Ye = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        Je = {
            letterSpacing: 0,
            fontWeight: 400
        },
        Ge = ["Top", "Right", "Bottom", "Left"],
        Qe = ["Webkit", "O", "Moz", "ms"];

    function Ke(e, t) {
        if (t in e) return t;
        for (var n = t.charAt(0).toUpperCase() + t.slice(1), r = t, i = Qe.length; i--;)
            if ((t = Qe[i] + n) in e) return t;
        return r
    }

    function Ze(e, t) {
        return e = t || e, "none" === x.css(e, "display") || !x.contains(e.ownerDocument, e)
    }

    function et(e, t) {
        for (var n, r, i, o = [], a = 0, s = e.length; a < s; a++)(r = e[a]).style && (o[a] = x._data(r, "olddisplay"), n = r.style.display, t ? (o[a] || "none" !== n || (r.style.display = ""), "" === r.style.display && Ze(r) && (o[a] = x._data(r, "olddisplay", it(r.nodeName)))) : o[a] || (i = Ze(r), (n && "none" !== n || !i) && x._data(r, "olddisplay", i ? n : x.css(r, "display"))));
        for (a = 0; a < s; a++)(r = e[a]).style && (t && "none" !== r.style.display && "" !== r.style.display || (r.style.display = t ? o[a] || "" : "none"));
        return e
    }

    function tt(e, t, n) {
        var r = ze.exec(t);
        return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
    }

    function nt(e, t, n, r, i) {
        for (var o = n === (r ? "border" : "content") ? 4 : "width" === t ? 1 : 0, a = 0; o < 4; o += 2) "margin" === n && (a += x.css(e, n + Ge[o], !0, i)), r ? ("content" === n && (a -= x.css(e, "padding" + Ge[o], !0, i)), "margin" !== n && (a -= x.css(e, "border" + Ge[o] + "Width", !0, i))) : (a += x.css(e, "padding" + Ge[o], !0, i), "padding" !== n && (a += x.css(e, "border" + Ge[o] + "Width", !0, i)));
        return a
    }

    function rt(e, t, n) {
        var r = !0,
            i = "width" === t ? e.offsetWidth : e.offsetHeight,
            o = Oe(e),
            a = x.support.boxSizing && "border-box" === x.css(e, "boxSizing", !1, o);
        if (i <= 0 || null == i) {
            if (((i = Be(e, t, o)) < 0 || null == i) && (i = e.style[t]), Xe.test(i)) return i;
            r = a && (x.support.boxSizingReliable || i === e.style[t]), i = parseFloat(i) || 0
        }
        return i + nt(e, t, n || (a ? "border" : "content"), r, o) + "px"
    }

    function it(e) {
        var t = o,
            n = Ve[e];
        return n || ("none" !== (n = ot(e, t)) && n || ((t = ((Fe = (Fe || x("<iframe frameborder='0' width='0' height='0'/>").css("cssText", "display:block !important")).appendTo(t.documentElement))[0].contentWindow || Fe[0].contentDocument).document).write("<!doctype html><html><body>"), t.close(), n = ot(e, t), Fe.detach()), Ve[e] = n), n
    }

    function ot(e, t) {
        var n = x(t.createElement(e)).appendTo(t.body),
            r = x.css(n[0], "display");
        return n.remove(), r
    }
    x.fn.extend({
        css: function(e, n) {
            return x.access(this, (function(e, n, r) {
                var i, o, a = {},
                    s = 0;
                if (x.isArray(n)) {
                    for (o = Oe(e), i = n.length; s < i; s++) a[n[s]] = x.css(e, n[s], !1, o);
                    return a
                }
                return r !== t ? x.style(e, n, r) : x.css(e, n)
            }), e, n, arguments.length > 1)
        },
        show: function() {
            return et(this, !0)
        },
        hide: function() {
            return et(this)
        },
        toggle: function(e) {
            var t = "boolean" == typeof e;
            return this.each((function() {
                (t ? e : Ze(this)) ? x(this).show(): x(this).hide()
            }))
        }
    }), x.extend({
        cssHooks: {
            opacity: {
                get: function(e, t) {
                    if (t) {
                        var n = Be(e, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            float: x.support.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function(e, n, r, i) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var o, a, s, u = x.camelCase(n),
                    l = e.style;
                if (n = x.cssProps[u] || (x.cssProps[u] = Ke(l, u)), s = x.cssHooks[n] || x.cssHooks[u], r === t) return s && "get" in s && (o = s.get(e, !1, i)) !== t ? o : l[n];
                if (!("string" === (a = typeof r) && (o = Ue.exec(r)) && (r = (o[1] + 1) * o[2] + parseFloat(x.css(e, n)), a = "number"), null == r || "number" === a && isNaN(r) || ("number" !== a || x.cssNumber[u] || (r += "px"), x.support.clearCloneStyle || "" !== r || 0 !== n.indexOf("background") || (l[n] = "inherit"), s && "set" in s && (r = s.set(e, r, i)) === t))) try {
                    l[n] = r
                } catch (e) {}
            }
        },
        css: function(e, n, r, i) {
            var o, a, s, u = x.camelCase(n);
            return n = x.cssProps[u] || (x.cssProps[u] = Ke(e.style, u)), (s = x.cssHooks[n] || x.cssHooks[u]) && "get" in s && (a = s.get(e, !0, r)), a === t && (a = Be(e, n, i)), "normal" === a && n in Je && (a = Je[n]), "" === r || r ? (o = parseFloat(a), !0 === r || x.isNumeric(o) ? o || 0 : a) : a
        },
        swap: function(e, t, n, r) {
            var i, o, a = {};
            for (o in t) a[o] = e.style[o], e.style[o] = t[o];
            for (o in i = n.apply(e, r || []), t) e.style[o] = a[o];
            return i
        }
    }), e.getComputedStyle ? (Oe = function(t) {
        return e.getComputedStyle(t, null)
    }, Be = function(e, n, r) {
        var i, o, a, s = r || Oe(e),
            u = s ? s.getPropertyValue(n) || s[n] : t,
            l = e.style;
        return s && ("" !== u || x.contains(e.ownerDocument, e) || (u = x.style(e, n)), Xe.test(u) && Ie.test(n) && (i = l.width, o = l.minWidth, a = l.maxWidth, l.minWidth = l.maxWidth = l.width = u, u = s.width, l.width = i, l.minWidth = o, l.maxWidth = a)), u
    }) : o.documentElement.currentStyle && (Oe = function(e) {
        return e.currentStyle
    }, Be = function(e, n, r) {
        var i, o, a, s = r || Oe(e),
            u = s ? s[n] : t,
            l = e.style;
        return null == u && l && l[n] && (u = l[n]), Xe.test(u) && !We.test(n) && (i = l.left, (a = (o = e.runtimeStyle) && o.left) && (o.left = e.currentStyle.left), l.left = "fontSize" === n ? "1em" : u, u = l.pixelLeft + "px", l.left = i, a && (o.left = a)), "" === u ? "auto" : u
    }), x.each(["height", "width"], (function(e, t) {
        x.cssHooks[t] = {
            get: function(e, n, r) {
                if (n) return 0 === e.offsetWidth && $e.test(x.css(e, "display")) ? x.swap(e, Ye, (function() {
                    return rt(e, t, r)
                })) : rt(e, t, r)
            },
            set: function(e, n, r) {
                var i = r && Oe(e);
                return tt(0, n, r ? nt(e, t, r, x.support.boxSizing && "border-box" === x.css(e, "boxSizing", !1, i), i) : 0)
            }
        }
    })), x.support.opacity || (x.cssHooks.opacity = {
        get: function(e, t) {
            return Re.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
        },
        set: function(e, t) {
            var n = e.style,
                r = e.currentStyle,
                i = x.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")" : "",
                o = r && r.filter || n.filter || "";
            n.zoom = 1, (t >= 1 || "" === t) && "" === x.trim(o.replace(Pe, "")) && n.removeAttribute && (n.removeAttribute("filter"), "" === t || r && !r.filter) || (n.filter = Pe.test(o) ? o.replace(Pe, i) : o + " " + i)
        }
    }), x((function() {
        x.support.reliableMarginRight || (x.cssHooks.marginRight = {
            get: function(e, t) {
                if (t) return x.swap(e, {
                    display: "inline-block"
                }, Be, [e, "marginRight"])
            }
        }), !x.support.pixelPosition && x.fn.position && x.each(["top", "left"], (function(e, t) {
            x.cssHooks[t] = {
                get: function(e, n) {
                    if (n) return n = Be(e, t), Xe.test(n) ? x(e).position()[t] + "px" : n
                }
            }
        }))
    })), x.expr && x.expr.filters && (x.expr.filters.hidden = function(e) {
        return e.offsetWidth <= 0 && e.offsetHeight <= 0 || !x.support.reliableHiddenOffsets && "none" === (e.style && e.style.display || x.css(e, "display"))
    }, x.expr.filters.visible = function(e) {
        return !x.expr.filters.hidden(e)
    }), x.each({
        margin: "",
        padding: "",
        border: "Width"
    }, (function(e, t) {
        x.cssHooks[e + t] = {
            expand: function(n) {
                for (var r = 0, i = {}, o = "string" == typeof n ? n.split(" ") : [n]; r < 4; r++) i[e + Ge[r] + t] = o[r] || o[r - 2] || o[0];
                return i
            }
        }, Ie.test(e) || (x.cssHooks[e + t].set = tt)
    }));
    var at = /%20/g,
        st = /\[\]$/,
        ut = /\r?\n/g,
        lt = /^(?:submit|button|image|reset|file)$/i,
        ct = /^(?:input|select|textarea|keygen)/i;

    function ft(e, t, n, r) {
        var i;
        if (x.isArray(t)) x.each(t, (function(t, i) {
            n || st.test(e) ? r(e, i) : ft(e + "[" + ("object" == typeof i ? t : "") + "]", i, n, r)
        }));
        else if (n || "object" !== x.type(t)) r(e, t);
        else
            for (i in t) ft(e + "[" + i + "]", t[i], n, r)
    }
    x.fn.extend({
        serialize: function() {
            return x.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map((function() {
                var e = x.prop(this, "elements");
                return e ? x.makeArray(e) : this
            })).filter((function() {
                var e = this.type;
                return this.name && !x(this).is(":disabled") && ct.test(this.nodeName) && !lt.test(e) && (this.checked || !Te.test(e))
            })).map((function(e, t) {
                var n = x(this).val();
                return null == n ? null : x.isArray(n) ? x.map(n, (function(e) {
                    return {
                        name: t.name,
                        value: e.replace(ut, "\r\n")
                    }
                })) : {
                    name: t.name,
                    value: n.replace(ut, "\r\n")
                }
            })).get()
        }
    }), x.param = function(e, n) {
        var r, i = [],
            o = function(e, t) {
                t = x.isFunction(t) ? t() : null == t ? "" : t, i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
            };
        if (n === t && (n = x.ajaxSettings && x.ajaxSettings.traditional), x.isArray(e) || e.jquery && !x.isPlainObject(e)) x.each(e, (function() {
            o(this.name, this.value)
        }));
        else
            for (r in e) ft(r, e[r], n, o);
        return i.join("&").replace(at, "+")
    }, x.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), (function(e, t) {
        x.fn[t] = function(e, n) {
            return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
        }
    })), x.fn.hover = function(e, t) {
        return this.mouseenter(e).mouseleave(t || e)
    };
    var pt, dt, ht = x.now(),
        gt = /\?/,
        mt = /#.*$/,
        yt = /([?&])_=[^&]*/,
        vt = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
        xt = /^(?:GET|HEAD)$/,
        bt = /^\/\//,
        wt = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,
        Tt = x.fn.load,
        Nt = {},
        Ct = {},
        kt = "*/".concat("*");
    try {
        dt = a.href
    } catch (e) {
        (dt = o.createElement("a")).href = "", dt = dt.href
    }

    function Et(e) {
        return function(t, n) {
            "string" != typeof t && (n = t, t = "*");
            var r, i = 0,
                o = t.toLowerCase().match(w) || [];
            if (x.isFunction(n))
                for (; r = o[i++];) "+" === r[0] ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
        }
    }

    function St(e, t, n, r) {
        var i = {},
            o = e === Ct;

        function a(s) {
            var u;
            return i[s] = !0, x.each(e[s] || [], (function(e, s) {
                var l = s(t, n, r);
                return "string" != typeof l || o || i[l] ? o ? !(u = l) : void 0 : (t.dataTypes.unshift(l), a(l), !1)
            })), u
        }
        return a(t.dataTypes[0]) || !i["*"] && a("*")
    }

    function At(e, n) {
        var r, i, o = x.ajaxSettings.flatOptions || {};
        for (i in n) n[i] !== t && ((o[i] ? e : r || (r = {}))[i] = n[i]);
        return r && x.extend(!0, e, r), e
    }
    pt = wt.exec(dt.toLowerCase()) || [], x.fn.load = function(e, n, r) {
        if ("string" != typeof e && Tt) return Tt.apply(this, arguments);
        var i, o, a, s = this,
            u = e.indexOf(" ");
        return u >= 0 && (i = e.slice(u, e.length), e = e.slice(0, u)), x.isFunction(n) ? (r = n, n = t) : n && "object" == typeof n && (a = "POST"), s.length > 0 && x.ajax({
            url: e,
            type: a,
            dataType: "html",
            data: n
        }).done((function(e) {
            o = arguments, s.html(i ? x("<div>").append(x.parseHTML(e)).find(i) : e)
        })).complete(r && function(e, t) {
            s.each(r, o || [e.responseText, t, e])
        }), this
    }, x.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], (function(e, t) {
        x.fn[t] = function(e) {
            return this.on(t, e)
        }
    })), x.each(["get", "post"], (function(e, n) {
        x[n] = function(e, r, i, o) {
            return x.isFunction(r) && (o = o || i, i = r, r = t), x.ajax({
                url: e,
                type: n,
                dataType: o,
                data: r,
                success: i
            })
        }
    })), x.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: dt,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(pt[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": kt,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText"
            },
            converters: {
                "* text": e.String,
                "text html": !0,
                "text json": x.parseJSON,
                "text xml": x.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, t) {
            return t ? At(At(e, x.ajaxSettings), t) : At(x.ajaxSettings, e)
        },
        ajaxPrefilter: Et(Nt),
        ajaxTransport: Et(Ct),
        ajax: function(e, n) {
            "object" == typeof e && (n = e, e = t), n = n || {};
            var r, i, o, a, s, u, l, c, f = x.ajaxSetup({}, n),
                p = f.context || f,
                d = f.context && (p.nodeType || p.jquery) ? x(p) : x.event,
                h = x.Deferred(),
                g = x.Callbacks("once memory"),
                m = f.statusCode || {},
                y = {},
                v = {},
                b = 0,
                T = "canceled",
                N = {
                    readyState: 0,
                    getResponseHeader: function(e) {
                        var t;
                        if (2 === b) {
                            if (!c)
                                for (c = {}; t = vt.exec(a);) c[t[1].toLowerCase()] = t[2];
                            t = c[e.toLowerCase()]
                        }
                        return null == t ? null : t
                    },
                    getAllResponseHeaders: function() {
                        return 2 === b ? a : null
                    },
                    setRequestHeader: function(e, t) {
                        var n = e.toLowerCase();
                        return b || (e = v[n] = v[n] || e, y[e] = t), this
                    },
                    overrideMimeType: function(e) {
                        return b || (f.mimeType = e), this
                    },
                    statusCode: function(e) {
                        var t;
                        if (e)
                            if (b < 2)
                                for (t in e) m[t] = [m[t], e[t]];
                            else N.always(e[N.status]);
                        return this
                    },
                    abort: function(e) {
                        var t = e || T;
                        return l && l.abort(t), C(0, t), this
                    }
                };
            if (h.promise(N).complete = g.add, N.success = N.done, N.error = N.fail, f.url = ((e || f.url || dt) + "").replace(mt, "").replace(bt, pt[1] + "//"), f.type = n.method || n.type || f.method || f.type, f.dataTypes = x.trim(f.dataType || "*").toLowerCase().match(w) || [""], null == f.crossDomain && (r = wt.exec(f.url.toLowerCase()), f.crossDomain = !(!r || r[1] === pt[1] && r[2] === pt[2] && (r[3] || ("http:" === r[1] ? 80 : 443)) == (pt[3] || ("http:" === pt[1] ? 80 : 443)))), f.data && f.processData && "string" != typeof f.data && (f.data = x.param(f.data, f.traditional)), St(Nt, f, n, N), 2 === b) return N;
            for (i in (u = f.global) && 0 == x.active++ && x.event.trigger("ajaxStart"), f.type = f.type.toUpperCase(), f.hasContent = !xt.test(f.type), o = f.url, f.hasContent || (f.data && (o = f.url += (gt.test(o) ? "&" : "?") + f.data, delete f.data), !1 === f.cache && (f.url = yt.test(o) ? o.replace(yt, "$1_=" + ht++) : o + (gt.test(o) ? "&" : "?") + "_=" + ht++)), f.ifModified && (x.lastModified[o] && N.setRequestHeader("If-Modified-Since", x.lastModified[o]), x.etag[o] && N.setRequestHeader("If-None-Match", x.etag[o])), (f.data && f.hasContent && !1 !== f.contentType || n.contentType) && N.setRequestHeader("Content-Type", f.contentType), N.setRequestHeader("Accept", f.dataTypes[0] && f.accepts[f.dataTypes[0]] ? f.accepts[f.dataTypes[0]] + ("*" !== f.dataTypes[0] ? ", " + kt + "; q=0.01" : "") : f.accepts["*"]), f.headers) N.setRequestHeader(i, f.headers[i]);
            if (f.beforeSend && (!1 === f.beforeSend.call(p, N, f) || 2 === b)) return N.abort();
            for (i in T = "abort", {
                    success: 1,
                    error: 1,
                    complete: 1
                }) N[i](f[i]);
            if (l = St(Ct, f, n, N)) {
                N.readyState = 1, u && d.trigger("ajaxSend", [N, f]), f.async && f.timeout > 0 && (s = setTimeout((function() {
                    N.abort("timeout")
                }), f.timeout));
                try {
                    b = 1, l.send(y, C)
                } catch (e) {
                    if (!(b < 2)) throw e;
                    C(-1, e)
                }
            } else C(-1, "No Transport");

            function C(e, n, r, i) {
                var c, y, v, w, T, C = n;
                2 !== b && (b = 2, s && clearTimeout(s), l = t, a = i || "", N.readyState = e > 0 ? 4 : 0, r && (w = function(e, n, r) {
                    var i, o, a, s, u = e.contents,
                        l = e.dataTypes,
                        c = e.responseFields;
                    for (s in c) s in r && (n[c[s]] = r[s]);
                    for (;
                        "*" === l[0];) l.shift(), o === t && (o = e.mimeType || n.getResponseHeader("Content-Type"));
                    if (o)
                        for (s in u)
                            if (u[s] && u[s].test(o)) {
                                l.unshift(s);
                                break
                            }
                    if (l[0] in r) a = l[0];
                    else {
                        for (s in r) {
                            if (!l[0] || e.converters[s + " " + l[0]]) {
                                a = s;
                                break
                            }
                            i || (i = s)
                        }
                        a = a || i
                    }
                    if (a) return a !== l[0] && l.unshift(a), r[a]
                }(f, N, r)), e >= 200 && e < 300 || 304 === e ? (f.ifModified && ((T = N.getResponseHeader("Last-Modified")) && (x.lastModified[o] = T), (T = N.getResponseHeader("etag")) && (x.etag[o] = T)), 204 === e ? (c = !0, C = "nocontent") : 304 === e ? (c = !0, C = "notmodified") : (c = function(e, t) {
                    var n, r, i, o, a = {},
                        s = 0,
                        u = e.dataTypes.slice(),
                        l = u[0];
                    e.dataFilter && (t = e.dataFilter(t, e.dataType));
                    if (u[1])
                        for (i in e.converters) a[i.toLowerCase()] = e.converters[i];
                    for (; r = u[++s];)
                        if ("*" !== r) {
                            if ("*" !== l && l !== r) {
                                if (!(i = a[l + " " + r] || a["* " + r]))
                                    for (n in a)
                                        if ((o = n.split(" "))[1] === r && (i = a[l + " " + o[0]] || a["* " + o[0]])) {
                                            !0 === i ? i = a[n] : !0 !== a[n] && (r = o[0], u.splice(s--, 0, r));
                                            break
                                        }
                                if (!0 !== i)
                                    if (i && e.throws) t = i(t);
                                    else try {
                                        t = i(t)
                                    } catch (e) {
                                        return {
                                            state: "parsererror",
                                            error: i ? e : "No conversion from " + l + " to " + r
                                        }
                                    }
                            }
                            l = r
                        }
                    return {
                        state: "success",
                        data: t
                    }
                }(f, w), C = c.state, y = c.data, c = !(v = c.error))) : (v = C, !e && C || (C = "error", e < 0 && (e = 0))), N.status = e, N.statusText = (n || C) + "", c ? h.resolveWith(p, [y, C, N]) : h.rejectWith(p, [N, C, v]), N.statusCode(m), m = t, u && d.trigger(c ? "ajaxSuccess" : "ajaxError", [N, f, c ? y : v]), g.fireWith(p, [N, C]), u && (d.trigger("ajaxComplete", [N, f]), --x.active || x.event.trigger("ajaxStop")))
            }
            return N
        },
        getScript: function(e, n) {
            return x.get(e, t, n, "script")
        },
        getJSON: function(e, t, n) {
            return x.get(e, t, n, "json")
        }
    }), x.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /(?:java|ecma)script/
        },
        converters: {
            "text script": function(e) {
                return x.globalEval(e), e
            }
        }
    }), x.ajaxPrefilter("script", (function(e) {
        e.cache === t && (e.cache = !1), e.crossDomain && (e.type = "GET", e.global = !1)
    })), x.ajaxTransport("script", (function(e) {
        if (e.crossDomain) {
            var n, r = o.head || x("head")[0] || o.documentElement;
            return {
                send: function(t, i) {
                    (n = o.createElement("script")).async = !0, e.scriptCharset && (n.charset = e.scriptCharset), n.src = e.url, n.onload = n.onreadystatechange = function(e, t) {
                        (t || !n.readyState || /loaded|complete/.test(n.readyState)) && (n.onload = n.onreadystatechange = null, n.parentNode && n.parentNode.removeChild(n), n = null, t || i(200, "success"))
                    }, r.insertBefore(n, r.firstChild)
                },
                abort: function() {
                    n && n.onload(t, !0)
                }
            }
        }
    }));
    var jt = [],
        Dt = /(=)\?(?=&|$)|\?\?/;
    x.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = jt.pop() || x.expando + "_" + ht++;
            return this[e] = !0, e
        }
    }), x.ajaxPrefilter("json jsonp", (function(n, r, i) {
        var o, a, s, u = !1 !== n.jsonp && (Dt.test(n.url) ? "url" : "string" == typeof n.data && !(n.contentType || "").indexOf("application/x-www-form-urlencoded") && Dt.test(n.data) && "data");
        if (u || "jsonp" === n.dataTypes[0]) return o = n.jsonpCallback = x.isFunction(n.jsonpCallback) ? n.jsonpCallback() : n.jsonpCallback, u ? n[u] = n[u].replace(Dt, "$1" + o) : !1 !== n.jsonp && (n.url += (gt.test(n.url) ? "&" : "?") + n.jsonp + "=" + o), n.converters["script json"] = function() {
            return s || x.error(o + " was not called"), s[0]
        }, n.dataTypes[0] = "json", a = e[o], e[o] = function() {
            s = arguments
        }, i.always((function() {
            e[o] = a, n[o] && (n.jsonpCallback = r.jsonpCallback, jt.push(o)), s && x.isFunction(a) && a(s[0]), s = a = t
        })), "script"
    }));
    var Lt, Ht, qt = 0,
        Mt = e.ActiveXObject && function() {
            var e;
            for (e in Lt) Lt[e](t, !0)
        };

    function _t() {
        try {
            return new e.XMLHttpRequest
        } catch (e) {}
    }
    x.ajaxSettings.xhr = e.ActiveXObject ? function() {
        return !this.isLocal && _t() || function() {
            try {
                return new e.ActiveXObject("Microsoft.XMLHTTP")
            } catch (e) {}
        }()
    } : _t, Ht = x.ajaxSettings.xhr(), x.support.cors = !!Ht && "withCredentials" in Ht, (Ht = x.support.ajax = !!Ht) && x.ajaxTransport((function(n) {
        var r;
        if (!n.crossDomain || x.support.cors) return {
            send: function(i, o) {
                var a, s, u = n.xhr();
                if (n.username ? u.open(n.type, n.url, n.async, n.username, n.password) : u.open(n.type, n.url, n.async), n.xhrFields)
                    for (s in n.xhrFields) u[s] = n.xhrFields[s];
                n.mimeType && u.overrideMimeType && u.overrideMimeType(n.mimeType), n.crossDomain || i["X-Requested-With"] || (i["X-Requested-With"] = "XMLHttpRequest");
                try {
                    for (s in i) u.setRequestHeader(s, i[s])
                } catch (e) {}
                u.send(n.hasContent && n.data || null), r = function(e, i) {
                    var s, l, c, f;
                    try {
                        if (r && (i || 4 === u.readyState))
                            if (r = t, a && (u.onreadystatechange = x.noop, Mt && delete Lt[a]), i) 4 !== u.readyState && u.abort();
                            else {
                                f = {}, s = u.status, l = u.getAllResponseHeaders(), "string" == typeof u.responseText && (f.text = u.responseText);
                                try {
                                    c = u.statusText
                                } catch (e) {
                                    c = ""
                                }
                                s || !n.isLocal || n.crossDomain ? 1223 === s && (s = 204) : s = f.text ? 200 : 404
                            }
                    } catch (e) {
                        i || o(-1, e)
                    }
                    f && o(s, c, f, l)
                }, n.async ? 4 === u.readyState ? setTimeout(r) : (a = ++qt, Mt && (Lt || (Lt = {}, x(e).unload(Mt)), Lt[a] = r), u.onreadystatechange = r) : r()
            },
            abort: function() {
                r && r(t, !0)
            }
        }
    }));
    var Ft, Ot, Bt = /^(?:toggle|show|hide)$/,
        Pt = new RegExp("^(?:([+-])=|)(" + b + ")([a-z%]*)$", "i"),
        Rt = /queueHooks$/,
        Wt = [function(e, t, n) {
            var r, i, o, a, s, u, l, c, f, p = this,
                d = e.style,
                h = {},
                g = [],
                m = e.nodeType && Ze(e);
            n.queue || (null == (c = x._queueHooks(e, "fx")).unqueued && (c.unqueued = 0, f = c.empty.fire, c.empty.fire = function() {
                c.unqueued || f()
            }), c.unqueued++, p.always((function() {
                p.always((function() {
                    c.unqueued--, x.queue(e, "fx").length || c.empty.fire()
                }))
            })));
            1 === e.nodeType && ("height" in t || "width" in t) && (n.overflow = [d.overflow, d.overflowX, d.overflowY], "inline" === x.css(e, "display") && "none" === x.css(e, "float") && (x.support.inlineBlockNeedsLayout && "inline" !== it(e.nodeName) ? d.zoom = 1 : d.display = "inline-block"));
            n.overflow && (d.overflow = "hidden", x.support.shrinkWrapBlocks || p.always((function() {
                d.overflow = n.overflow[0], d.overflowX = n.overflow[1], d.overflowY = n.overflow[2]
            })));
            for (i in t)
                if (a = t[i], Bt.exec(a)) {
                    if (delete t[i], u = u || "toggle" === a, a === (m ? "hide" : "show")) continue;
                    g.push(i)
                }
            if (o = g.length) {
                "hidden" in (s = x._data(e, "fxshow") || x._data(e, "fxshow", {})) && (m = s.hidden), u && (s.hidden = !m), m ? x(e).show() : p.done((function() {
                    x(e).hide()
                })), p.done((function() {
                    var t;
                    for (t in x._removeData(e, "fxshow"), h) x.style(e, t, h[t])
                }));
                for (i = 0; i < o; i++) r = g[i], l = p.createTween(r, m ? s[r] : 0), h[r] = s[r] || x.style(e, r), r in s || (s[r] = l.start, m && (l.end = l.start, l.start = "width" === r || "height" === r ? 1 : 0))
            }
        }],
        $t = {
            "*": [function(e, t) {
                var n, r, i = this.createTween(e, t),
                    o = Pt.exec(t),
                    a = i.cur(),
                    s = +a || 0,
                    u = 1,
                    l = 20;
                if (o) {
                    if (n = +o[2], "px" !== (r = o[3] || (x.cssNumber[e] ? "" : "px")) && s) {
                        s = x.css(i.elem, e, !0) || n || 1;
                        do {
                            s /= u = u || ".5", x.style(i.elem, e, s + r)
                        } while (u !== (u = i.cur() / a) && 1 !== u && --l)
                    }
                    i.unit = r, i.start = s, i.end = o[1] ? s + (o[1] + 1) * n : n
                }
                return i
            }]
        };

    function It() {
        return setTimeout((function() {
            Ft = t
        })), Ft = x.now()
    }

    function zt(e, t, n) {
        var r, i, o = 0,
            a = Wt.length,
            s = x.Deferred().always((function() {
                delete u.elem
            })),
            u = function() {
                if (i) return !1;
                for (var t = Ft || It(), n = Math.max(0, l.startTime + l.duration - t), r = 1 - (n / l.duration || 0), o = 0, a = l.tweens.length; o < a; o++) l.tweens[o].run(r);
                return s.notifyWith(e, [l, r, n]), r < 1 && a ? n : (s.resolveWith(e, [l]), !1)
            },
            l = s.promise({
                elem: e,
                props: x.extend({}, t),
                opts: x.extend(!0, {
                    specialEasing: {}
                }, n),
                originalProperties: t,
                originalOptions: n,
                startTime: Ft || It(),
                duration: n.duration,
                tweens: [],
                createTween: function(t, n) {
                    var r = x.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                    return l.tweens.push(r), r
                },
                stop: function(t) {
                    var n = 0,
                        r = t ? l.tweens.length : 0;
                    if (i) return this;
                    for (i = !0; n < r; n++) l.tweens[n].run(1);
                    return t ? s.resolveWith(e, [l, t]) : s.rejectWith(e, [l, t]), this
                }
            }),
            c = l.props;
        for (! function(e, t) {
                var n, r, i, o, a;
                for (i in e)
                    if (o = t[r = x.camelCase(i)], n = e[i], x.isArray(n) && (o = n[1], n = e[i] = n[0]), i !== r && (e[r] = n, delete e[i]), (a = x.cssHooks[r]) && "expand" in a)
                        for (i in n = a.expand(n), delete e[r], n) i in e || (e[i] = n[i], t[i] = o);
                    else t[r] = o
            }(c, l.opts.specialEasing); o < a; o++)
            if (r = Wt[o].call(l, e, c, l.opts)) return r;
        return function(e, t) {
            x.each(t, (function(t, n) {
                for (var r = ($t[t] || []).concat($t["*"]), i = 0, o = r.length; i < o; i++)
                    if (r[i].call(e, t, n)) return
            }))
        }(l, c), x.isFunction(l.opts.start) && l.opts.start.call(e, l), x.fx.timer(x.extend(u, {
            elem: e,
            anim: l,
            queue: l.opts.queue
        })), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always)
    }

    function Xt(e, t, n, r, i) {
        return new Xt.prototype.init(e, t, n, r, i)
    }

    function Ut(e, t) {
        var n, r = {
                height: e
            },
            i = 0;
        for (t = t ? 1 : 0; i < 4; i += 2 - t) r["margin" + (n = Ge[i])] = r["padding" + n] = e;
        return t && (r.opacity = r.width = e), r
    }

    function Vt(e) {
        return x.isWindow(e) ? e : 9 === e.nodeType && (e.defaultView || e.parentWindow)
    }
    x.Animation = x.extend(zt, {
        tweener: function(e, t) {
            x.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
            for (var n, r = 0, i = e.length; r < i; r++) n = e[r], $t[n] = $t[n] || [], $t[n].unshift(t)
        },
        prefilter: function(e, t) {
            t ? Wt.unshift(e) : Wt.push(e)
        }
    }), x.Tween = Xt, Xt.prototype = {
        constructor: Xt,
        init: function(e, t, n, r, i, o) {
            this.elem = e, this.prop = n, this.easing = i || "swing", this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = o || (x.cssNumber[n] ? "" : "px")
        },
        cur: function() {
            var e = Xt.propHooks[this.prop];
            return e && e.get ? e.get(this) : Xt.propHooks._default.get(this)
        },
        run: function(e) {
            var t, n = Xt.propHooks[this.prop];
            return this.options.duration ? this.pos = t = x.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : Xt.propHooks._default.set(this), this
        }
    }, Xt.prototype.init.prototype = Xt.prototype, Xt.propHooks = {
        _default: {
            get: function(e) {
                var t;
                return null == e.elem[e.prop] || e.elem.style && null != e.elem.style[e.prop] ? (t = x.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0 : e.elem[e.prop]
            },
            set: function(e) {
                x.fx.step[e.prop] ? x.fx.step[e.prop](e) : e.elem.style && (null != e.elem.style[x.cssProps[e.prop]] || x.cssHooks[e.prop]) ? x.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
            }
        }
    }, Xt.propHooks.scrollTop = Xt.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, x.each(["toggle", "show", "hide"], (function(e, t) {
        var n = x.fn[t];
        x.fn[t] = function(e, r, i) {
            return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(Ut(t, !0), e, r, i)
        }
    })), x.fn.extend({
        fadeTo: function(e, t, n, r) {
            return this.filter(Ze).css("opacity", 0).show().end().animate({
                opacity: t
            }, e, n, r)
        },
        animate: function(e, t, n, r) {
            var i = x.isEmptyObject(e),
                o = x.speed(t, n, r),
                a = function() {
                    var t = zt(this, x.extend({}, e), o);
                    a.finish = function() {
                        t.stop(!0)
                    }, (i || x._data(this, "finish")) && t.stop(!0)
                };
            return a.finish = a, i || !1 === o.queue ? this.each(a) : this.queue(o.queue, a)
        },
        stop: function(e, n, r) {
            var i = function(e) {
                var t = e.stop;
                delete e.stop, t(r)
            };
            return "string" != typeof e && (r = n, n = e, e = t), n && !1 !== e && this.queue(e || "fx", []), this.each((function() {
                var t = !0,
                    n = null != e && e + "queueHooks",
                    o = x.timers,
                    a = x._data(this);
                if (n) a[n] && a[n].stop && i(a[n]);
                else
                    for (n in a) a[n] && a[n].stop && Rt.test(n) && i(a[n]);
                for (n = o.length; n--;) o[n].elem !== this || null != e && o[n].queue !== e || (o[n].anim.stop(r), t = !1, o.splice(n, 1));
                !t && r || x.dequeue(this, e)
            }))
        },
        finish: function(e) {
            return !1 !== e && (e = e || "fx"), this.each((function() {
                var t, n = x._data(this),
                    r = n[e + "queue"],
                    i = n[e + "queueHooks"],
                    o = x.timers,
                    a = r ? r.length : 0;
                for (n.finish = !0, x.queue(this, e, []), i && i.cur && i.cur.finish && i.cur.finish.call(this), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                for (t = 0; t < a; t++) r[t] && r[t].finish && r[t].finish.call(this);
                delete n.finish
            }))
        }
    }), x.each({
        slideDown: Ut("show"),
        slideUp: Ut("hide"),
        slideToggle: Ut("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, (function(e, t) {
        x.fn[e] = function(e, n, r) {
            return this.animate(t, e, n, r)
        }
    })), x.speed = function(e, t, n) {
        var r = e && "object" == typeof e ? x.extend({}, e) : {
            complete: n || !n && t || x.isFunction(e) && e,
            duration: e,
            easing: n && t || t && !x.isFunction(t) && t
        };
        return r.duration = x.fx.off ? 0 : "number" == typeof r.duration ? r.duration : r.duration in x.fx.speeds ? x.fx.speeds[r.duration] : x.fx.speeds._default, null != r.queue && !0 !== r.queue || (r.queue = "fx"), r.old = r.complete, r.complete = function() {
            x.isFunction(r.old) && r.old.call(this), r.queue && x.dequeue(this, r.queue)
        }, r
    }, x.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        }
    }, x.timers = [], x.fx = Xt.prototype.init, x.fx.tick = function() {
        var e, n = x.timers,
            r = 0;
        for (Ft = x.now(); r < n.length; r++)(e = n[r])() || n[r] !== e || n.splice(r--, 1);
        n.length || x.fx.stop(), Ft = t
    }, x.fx.timer = function(e) {
        e() && x.timers.push(e) && x.fx.start()
    }, x.fx.interval = 13, x.fx.start = function() {
        Ot || (Ot = setInterval(x.fx.tick, x.fx.interval))
    }, x.fx.stop = function() {
        clearInterval(Ot), Ot = null
    }, x.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    }, x.fx.step = {}, x.expr && x.expr.filters && (x.expr.filters.animated = function(e) {
        return x.grep(x.timers, (function(t) {
            return e === t.elem
        })).length
    }), x.fn.offset = function(e) {
        if (arguments.length) return e === t ? this : this.each((function(t) {
            x.offset.setOffset(this, e, t)
        }));
        var n, r, o = {
                top: 0,
                left: 0
            },
            a = this[0],
            s = a && a.ownerDocument;
        return s ? (n = s.documentElement, x.contains(n, a) ? (typeof a.getBoundingClientRect !== i && (o = a.getBoundingClientRect()), r = Vt(s), {
            top: o.top + (r.pageYOffset || n.scrollTop) - (n.clientTop || 0),
            left: o.left + (r.pageXOffset || n.scrollLeft) - (n.clientLeft || 0)
        }) : o) : void 0
    }, x.offset = {
        setOffset: function(e, t, n) {
            var r = x.css(e, "position");
            "static" === r && (e.style.position = "relative");
            var i, o, a = x(e),
                s = a.offset(),
                u = x.css(e, "top"),
                l = x.css(e, "left"),
                c = {},
                f = {};
            ("absolute" === r || "fixed" === r) && x.inArray("auto", [u, l]) > -1 ? (i = (f = a.position()).top, o = f.left) : (i = parseFloat(u) || 0, o = parseFloat(l) || 0), x.isFunction(t) && (t = t.call(e, n, s)), null != t.top && (c.top = t.top - s.top + i), null != t.left && (c.left = t.left - s.left + o), "using" in t ? t.using.call(e, c) : a.css(c)
        }
    }, x.fn.extend({
        position: function() {
            if (this[0]) {
                var e, t, n = {
                        top: 0,
                        left: 0
                    },
                    r = this[0];
                return "fixed" === x.css(r, "position") ? t = r.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), x.nodeName(e[0], "html") || (n = e.offset()), n.top += x.css(e[0], "borderTopWidth", !0), n.left += x.css(e[0], "borderLeftWidth", !0)), {
                    top: t.top - n.top - x.css(r, "marginTop", !0),
                    left: t.left - n.left - x.css(r, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map((function() {
                for (var e = this.offsetParent || o.documentElement; e && !x.nodeName(e, "html") && "static" === x.css(e, "position");) e = e.offsetParent;
                return e || o.documentElement
            }))
        }
    }), x.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, (function(e, n) {
        var r = /Y/.test(n);
        x.fn[e] = function(i) {
            return x.access(this, (function(e, i, o) {
                var a = Vt(e);
                if (o === t) return a ? n in a ? a[n] : a.document.documentElement[i] : e[i];
                a ? a.scrollTo(r ? x(a).scrollLeft() : o, r ? o : x(a).scrollTop()) : e[i] = o
            }), e, i, arguments.length, null)
        }
    })), x.each({
        Height: "height",
        Width: "width"
    }, (function(e, n) {
        x.each({
            padding: "inner" + e,
            content: n,
            "": "outer" + e
        }, (function(r, i) {
            x.fn[i] = function(i, o) {
                var a = arguments.length && (r || "boolean" != typeof i),
                    s = r || (!0 === i || !0 === o ? "margin" : "border");
                return x.access(this, (function(n, r, i) {
                    var o;
                    return x.isWindow(n) ? n.document.documentElement["client" + e] : 9 === n.nodeType ? (o = n.documentElement, Math.max(n.body["scroll" + e], o["scroll" + e], n.body["offset" + e], o["offset" + e], o["client" + e])) : i === t ? x.css(n, r, s) : x.style(n, r, i, s)
                }), n, a ? i : t, a, null)
            }
        }))
    })), e.jQuery = e.$ = x, "function" == typeof define && define.amd && define.amd.jQuery && define("jquery", [], (function() {
        return x
    }))
}(window);