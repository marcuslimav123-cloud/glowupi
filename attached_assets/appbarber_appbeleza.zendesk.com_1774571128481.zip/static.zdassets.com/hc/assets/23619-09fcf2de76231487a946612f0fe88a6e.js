"use strict";
(self.webpackChunkhelp_center = self.webpackChunkhelp_center || []).push([
    [23619], {
        23619: function(n, o, e) {
            e.d(o, {
                W1: function() {
                    return a.W1
                },
                IU: function() {
                    return E
                },
                Dr: function() {
                    return x
                },
                w4: function() {
                    return b
                },
                cO: function() {
                    return g
                },
                bX: function() {
                    return m
                }
            });
            var r = e(75357),
                d = e(97032),
                A = e(96540),
                c = e(5556),
                l = e.n(c),
                a = e(79202),
                t = e(68414),
                C = e.n(t);

            function s() {
                for (var n = arguments.length, o = new Array(n), e = 0; e < n; e++) o[e] = arguments[e];
                var r = (0, A.useRef)();
                return (0, A.useEffect)((function() {
                    o.forEach((function(n) {
                        n && ("function" == typeof n ? n(r.current) : n.current = r.current)
                    }))
                }), [o]), r
            }
            var z = e(85072),
                i = e.n(z),
                B = e(12245),
                f = {
                    insert: "head",
                    singleton: !1
                },
                p = (i()(B.A, f), B.A.locals || {}),
                u = ["position"],
                E = (0, A.forwardRef)((function(n, o) {
                    var e = s(o, A.useRef(null));
                    return (0, A.useEffect)((function() {
                        e.current.removeAttribute("data-reach-menu-button"), setTimeout((function() {
                            e.current.removeAttribute("aria-controls")
                        }), 500)
                    }), [e, o]), A.createElement(a.IU, (0, d.A)({
                        ref: e,
                        id: C().v4()
                    }, n))
                }));
            E.displayName = a.IU.displayName;
            var y = (0, A.forwardRef)((function(n, o) {
                var e = s(o, A.useRef(null));
                return (0, A.useEffect)((function() {
                    e.current.removeAttribute("data-reach-menu-items"), e.current.parentElement.removeAttribute("data-reach-popover"), e.current.parentElement.removeAttribute("data-reach-menu"), e.current.parentElement.removeAttribute("data-reach-menu-popover")
                }), [e, o]), A.createElement(a.c, (0, d.A)({
                    ref: e,
                    className: p.list
                }, n))
            }));
            y.displayName = a.c.displayName;
            var g = (0, A.forwardRef)((function(n, o) {
                var e = n.position,
                    d = (0, r.A)(n, u);
                return A.createElement(a.bi, {
                    ref: o,
                    position: e
                }, A.createElement(y, d))
            }));
            g.propTypes = {
                position: l().any
            }, g.displayName = a.cO.displayName;
            var x = (0, A.forwardRef)((function(n, o) {
                var e = s(o, A.useRef(null));
                return A.createElement(a.Dr, (0, d.A)({
                    ref: e,
                    className: p.item
                }, n))
            }));
            x.displayName = a.Dr.displayName;
            var b = (0, A.forwardRef)((function(n, o) {
                var e = s(o, A.useRef(null));
                return (0, A.useEffect)((function() {
                    e.current.removeAttribute("data-reach-menu-item"), e.current.removeAttribute("data-reach-menu-link")
                }), [e, o]), A.createElement(a.w4, (0, d.A)({
                    ref: e,
                    className: p.item
                }, n))
            }));
            b.displayName = a.w4.displayName;
            var m = function(n) {
                return A.createElement("div", (0, d.A)({
                    className: p.separator
                }, n))
            }
        },
        12245: function(n, o, e) {
            var r = e(71354),
                d = e.n(r),
                A = e(76314),
                c = e.n(A)()(d());
            c.push([n.id, "/**\n * Copyright Zendesk, Inc.\n *\n * Use of this source code is governed under the Apache License, Version 2.0\n * found at http://www.apache.org/licenses/LICENSE-2.0.\n */\n\n:root {\n  --zd-color-black: #000;\n  --zd-color-green-100: #edf8f4;\n  --zd-color-green-200: #d1e8df;\n  --zd-color-green-300: #aecfc2;\n  --zd-color-green-400: #5eae91;\n  --zd-color-green-500: #228f67;\n  --zd-color-green-600: #038153;\n  --zd-color-green-700: #186146;\n  --zd-color-green-800: #0b3b29;\n  --zd-color-grey-100: #f8f9f9;\n  --zd-color-grey-200: #e9ebed;\n  --zd-color-grey-300: #d8dcde;\n  --zd-color-grey-400: #c2c8cc;\n  --zd-color-grey-500: #87929d;\n  --zd-color-grey-600: #68737d;\n  --zd-color-grey-700: #49545c;\n  --zd-color-grey-800: #2f3941;\n  --zd-color-blue-100: #edf7ff;\n  --zd-color-blue-200: #cee2f2;\n  --zd-color-blue-300: #adcce4;\n  --zd-color-blue-400: #5293c7;\n  --zd-color-blue-500: #337fbd;\n  --zd-color-blue-600: #1f73b7;\n  --zd-color-blue-700: #144a75;\n  --zd-color-blue-800: #0f3554;\n  --zd-color-kale-100: #f5fcfc;\n  --zd-color-kale-200: #daeded;\n  --zd-color-kale-300: #bdd9d7;\n  --zd-color-kale-400: #90bbbb;\n  --zd-color-kale-500: #498283;\n  --zd-color-kale-600: #17494d;\n  --zd-color-kale-700: #03363d;\n  --zd-color-kale-800: #012b30;\n  --zd-color-red-100: #fff0f1;\n  --zd-color-red-200: #f5d5d8;\n  --zd-color-red-300: #f5b5ba;\n  --zd-color-red-400: #e35b66;\n  --zd-color-red-500: #d93f4c;\n  --zd-color-red-600: #cc3340;\n  --zd-color-red-700: #8c232c;\n  --zd-color-red-800: #681219;\n  --zd-color-yellow-100: #fff7ed;\n  --zd-color-yellow-200: #ffeedb;\n  --zd-color-yellow-300: #fed6a8;\n  --zd-color-yellow-400: #ffb057;\n  --zd-color-yellow-500: #f79a3e;\n  --zd-color-yellow-600: #ed8f1c;\n  --zd-color-yellow-700: #ad5918;\n  --zd-color-yellow-800: #703815;\n  --zd-color-white: #fff;\n  --zd-color-secondary-azure-400: #3091ec;\n  --zd-color-secondary-azure-600: #1371d6;\n  --zd-color-secondary-crimson-400: #e34f32;\n  --zd-color-secondary-crimson-600: #c72a1c;\n  --zd-color-secondary-fuschia-400: #d653c2;\n  --zd-color-secondary-fuschia-600: #a81897;\n  --zd-color-secondary-lemon-400: #ffd424;\n  --zd-color-secondary-lemon-600: #ffbb10;\n  --zd-color-secondary-lime-400: #43b324;\n  --zd-color-secondary-lime-600: #2e8200;\n  --zd-color-secondary-mint-400: #00a656;\n  --zd-color-secondary-mint-600: #058541;\n  --zd-color-secondary-orange-400: #de701d;\n  --zd-color-secondary-orange-600: #bf5000;\n  --zd-color-secondary-pink-400: #ec4d63;\n  --zd-color-secondary-pink-600: #d42054;\n  --zd-color-secondary-purple-400: #b552e2;\n  --zd-color-secondary-purple-600: #6a27b8;\n  --zd-color-secondary-royal-400: #5d7df5;\n  --zd-color-secondary-royal-600: #3353e2;\n  --zd-color-secondary-teal-400: #02a191;\n  --zd-color-secondary-teal-600: #028079;\n  --zd-color-secondary-azure-M400: #5f8dcf;\n  --zd-color-secondary-azure-M600: #3a70b2;\n  --zd-color-secondary-crimson-M400: #cc6c5b;\n  --zd-color-secondary-crimson-M600: #b24a3c;\n  --zd-color-secondary-fuschia-M400: #cf62a8;\n  --zd-color-secondary-fuschia-M600: #a8458c;\n  --zd-color-secondary-lemon-M400: #e7a500;\n  --zd-color-secondary-lemon-M600: #c38f00;\n  --zd-color-secondary-lime-M400: #519e2d;\n  --zd-color-secondary-lime-M600: #47782c;\n  --zd-color-secondary-mint-M400: #299c66;\n  --zd-color-secondary-mint-M600: #2e8057;\n  --zd-color-secondary-orange-M400: #d4772c;\n  --zd-color-secondary-orange-M600: #b35827;\n  --zd-color-secondary-pink-M400: #d57287;\n  --zd-color-secondary-pink-M600: #b23a5d;\n  --zd-color-secondary-purple-M400: #b072cc;\n  --zd-color-secondary-purple-M600: #9358b0;\n  --zd-color-secondary-royal-M400: #7986d8;\n  --zd-color-secondary-royal-M600: #4b61c3;\n  --zd-color-secondary-teal-M400: #2d9e8f;\n  --zd-color-secondary-teal-M600: #3c7873;\n  --zd-color-chat-orange: #f79a3e;\n  --zd-color-connect-red: #ff6224;\n  --zd-color-explore-blue: #30aabc;\n  --zd-color-gather-pink: #f6c8be;\n  --zd-color-guide-pink: #eb4962;\n  --zd-color-message-green: #37b8af;\n  --zd-color-sell-gold: #c38f00;\n  --zd-color-support-green: #00a656;\n  --zd-color-talk-yellow: #efc93d;\n  --zd-font-family-monospace: SFMono-Regular, Consolas, 'Liberation Mono', Menlo, Courier, monospace;\n  --zd-font-family-system: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', Arial, sans-serif;\n  --zd-font-size-xs: 10px;\n  --zd-font-size-sm: 12px;\n  --zd-font-size-md: 14px;\n  --zd-font-size-lg: 18px;\n  --zd-font-size-xl: 22px;\n  --zd-font-size-xxl: 26px;\n  --zd-font-size-xxxl: 36px;\n  --zd-font-size-sm-monospace: 11px;\n  --zd-font-size-md-monospace: 13px;\n  --zd-font-size-lg-monospace: 17px;\n  --zd-font-weight-thin: 100;\n  --zd-font-weight-extralight: 200;\n  --zd-font-weight-light: 300;\n  --zd-font-weight-regular: 400;\n  --zd-font-weight-medium: 500;\n  --zd-font-weight-semibold: 600;\n  --zd-font-weight-bold: 700;\n  --zd-font-weight-extrabold: 800;\n  --zd-font-weight-black: 900;\n  --zd-font-weight-ultralight: 200;\n  --zd-font-weight-ultrabold: 800;\n  --zd-font-weight-heavy: 900;\n  --zd-line-height-sm: 16px;\n  --zd-line-height-md: 20px;\n  --zd-line-height-lg: 24px;\n  --zd-line-height-xl: 28px;\n  --zd-line-height-xxl: 32px;\n  --zd-line-height-xxxl: 44px;\n  --zd-spacing-xxs: 4px;\n  --zd-spacing-xs: 8px;\n  --zd-spacing-sm: 12px;\n  --zd-spacing: 20px;\n  --zd-spacing-lg: 32px;\n  --zd-spacing-xl: 40px;\n  --zd-spacing-xxl: 48px;\n}\n\n:root {\n  --reach-menu-button: 1;\n}\n\n._8RHFYPTt0CxuUudzL8wxA9oZq1ynL1u {\n  background: #fff;\n  border: 1px solid #d8d8d8;\n  border-radius: 3px;\n  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);\n  font-size: 14px;\n  font-style: normal;\n  font-weight: normal;\n  left: 0;\n  min-width: 170px;\n  outline: none;\n  padding: 10px 0;\n  position: relative;\n  z-index: 1000;\n}\n\n._s7IdTkp038IFCdlKs8vwOcioOy4uK5h {\n  color: #333;\n  cursor: pointer;\n  display: block;\n  padding: 7px 40px 7px 20px;\n  outline: none;\n  white-space: nowrap;\n}\n\n[data-reach-menu-item][data-selected] {\n  background-color: rgba(92, 105, 112, 0.08);\n  box-shadow: #49545c 3px 0px inset;\n  box-shadow: var(--zd-color-grey-700) 3px 0px inset;\n}\n\n.XmCiWBUhr_QflETEQRaOWgLkfbAj8oS7 {\n  border-bottom: 1px solid #d8d8d8;\n  color: #969696;\n  display: block;\n  font-weight: normal;\n  font-size: 11px;\n  padding: 5px 0;\n  margin: 5px 20px 10px 20px;\n}\n\n.NFPgFc0gI0HvonfLdOrjAWlpe6fhsgu2 {\n  display: inline-block;\n  width: 10px;\n}\n", "", {
                version: 3,
                sources: ["webpack://./node_modules/@zendeskgarden/css-variables/dist/index.css", "webpack://./ui/components/MenuButton/index.css"],
                names: [],
                mappings: "AAAA;;;;;EAKE;;AAEF;EACE,sBAAsB;EACtB,6BAA6B;EAC7B,6BAA6B;EAC7B,6BAA6B;EAC7B,6BAA6B;EAC7B,6BAA6B;EAC7B,6BAA6B;EAC7B,6BAA6B;EAC7B,6BAA6B;EAC7B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,4BAA4B;EAC5B,2BAA2B;EAC3B,2BAA2B;EAC3B,2BAA2B;EAC3B,2BAA2B;EAC3B,2BAA2B;EAC3B,2BAA2B;EAC3B,2BAA2B;EAC3B,2BAA2B;EAC3B,8BAA8B;EAC9B,8BAA8B;EAC9B,8BAA8B;EAC9B,8BAA8B;EAC9B,8BAA8B;EAC9B,8BAA8B;EAC9B,8BAA8B;EAC9B,8BAA8B;EAC9B,sBAAsB;EACtB,uCAAuC;EACvC,uCAAuC;EACvC,yCAAyC;EACzC,yCAAyC;EACzC,yCAAyC;EACzC,yCAAyC;EACzC,uCAAuC;EACvC,uCAAuC;EACvC,sCAAsC;EACtC,sCAAsC;EACtC,sCAAsC;EACtC,sCAAsC;EACtC,wCAAwC;EACxC,wCAAwC;EACxC,sCAAsC;EACtC,sCAAsC;EACtC,wCAAwC;EACxC,wCAAwC;EACxC,uCAAuC;EACvC,uCAAuC;EACvC,sCAAsC;EACtC,sCAAsC;EACtC,wCAAwC;EACxC,wCAAwC;EACxC,0CAA0C;EAC1C,0CAA0C;EAC1C,0CAA0C;EAC1C,0CAA0C;EAC1C,wCAAwC;EACxC,wCAAwC;EACxC,uCAAuC;EACvC,uCAAuC;EACvC,uCAAuC;EACvC,uCAAuC;EACvC,yCAAyC;EACzC,yCAAyC;EACzC,uCAAuC;EACvC,uCAAuC;EACvC,yCAAyC;EACzC,yCAAyC;EACzC,wCAAwC;EACxC,wCAAwC;EACxC,uCAAuC;EACvC,uCAAuC;EACvC,+BAA+B;EAC/B,+BAA+B;EAC/B,gCAAgC;EAChC,+BAA+B;EAC/B,8BAA8B;EAC9B,iCAAiC;EACjC,6BAA6B;EAC7B,iCAAiC;EACjC,+BAA+B;EAC/B,kGAAkG;EAClG,0NAA8J;EAC9J,uBAAuB;EACvB,uBAAuB;EACvB,uBAAuB;EACvB,uBAAuB;EACvB,uBAAuB;EACvB,wBAAwB;EACxB,yBAAyB;EACzB,iCAAiC;EACjC,iCAAiC;EACjC,iCAAiC;EACjC,0BAA0B;EAC1B,gCAAgC;EAChC,2BAA2B;EAC3B,6BAA6B;EAC7B,4BAA4B;EAC5B,8BAA8B;EAC9B,0BAA0B;EAC1B,+BAA+B;EAC/B,2BAA2B;EAC3B,gCAAgC;EAChC,+BAA+B;EAC/B,2BAA2B;EAC3B,yBAAyB;EACzB,yBAAyB;EACzB,yBAAyB;EACzB,yBAAyB;EACzB,0BAA0B;EAC1B,2BAA2B;EAC3B,qBAAqB;EACrB,oBAAoB;EACpB,qBAAqB;EACrB,kBAAkB;EAClB,qBAAqB;EACrB,qBAAqB;EACrB,sBAAsB;AACxB;;AClJA;EACE,sBAAsB;AACxB;;AAEA;EACE,gBAAgB;EAChB,yBAAyB;EACzB,kBAAkB;EAClB,wCAAwC;EACxC,eAAe;EACf,kBAAkB;EAClB,mBAAmB;EACnB,OAAO;EACP,gBAAgB;EAChB,aAAa;EACb,eAAe;EACf,kBAAkB;EAClB,aAAa;AACf;;AAEA;EACE,WAAW;EACX,eAAe;EACf,cAAc;EACd,0BAA0B;EAC1B,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,0CAA0C;EAC1C,iCAAkD;EAAlD,kDAAkD;AACpD;;AAEA;EACE,gCAAgC;EAChC,cAAc;EACd,cAAc;EACd,mBAAmB;EACnB,eAAe;EACf,cAAc;EACd,0BAA0B;AAC5B;;AAEA;EACE,qBAAqB;EACrB,WAAW;AACb",
                sourcesContent: ["/**\n * Copyright Zendesk, Inc.\n *\n * Use of this source code is governed under the Apache License, Version 2.0\n * found at http://www.apache.org/licenses/LICENSE-2.0.\n */\n\n:root {\n  --zd-color-black: #000;\n  --zd-color-green-100: #edf8f4;\n  --zd-color-green-200: #d1e8df;\n  --zd-color-green-300: #aecfc2;\n  --zd-color-green-400: #5eae91;\n  --zd-color-green-500: #228f67;\n  --zd-color-green-600: #038153;\n  --zd-color-green-700: #186146;\n  --zd-color-green-800: #0b3b29;\n  --zd-color-grey-100: #f8f9f9;\n  --zd-color-grey-200: #e9ebed;\n  --zd-color-grey-300: #d8dcde;\n  --zd-color-grey-400: #c2c8cc;\n  --zd-color-grey-500: #87929d;\n  --zd-color-grey-600: #68737d;\n  --zd-color-grey-700: #49545c;\n  --zd-color-grey-800: #2f3941;\n  --zd-color-blue-100: #edf7ff;\n  --zd-color-blue-200: #cee2f2;\n  --zd-color-blue-300: #adcce4;\n  --zd-color-blue-400: #5293c7;\n  --zd-color-blue-500: #337fbd;\n  --zd-color-blue-600: #1f73b7;\n  --zd-color-blue-700: #144a75;\n  --zd-color-blue-800: #0f3554;\n  --zd-color-kale-100: #f5fcfc;\n  --zd-color-kale-200: #daeded;\n  --zd-color-kale-300: #bdd9d7;\n  --zd-color-kale-400: #90bbbb;\n  --zd-color-kale-500: #498283;\n  --zd-color-kale-600: #17494d;\n  --zd-color-kale-700: #03363d;\n  --zd-color-kale-800: #012b30;\n  --zd-color-red-100: #fff0f1;\n  --zd-color-red-200: #f5d5d8;\n  --zd-color-red-300: #f5b5ba;\n  --zd-color-red-400: #e35b66;\n  --zd-color-red-500: #d93f4c;\n  --zd-color-red-600: #cc3340;\n  --zd-color-red-700: #8c232c;\n  --zd-color-red-800: #681219;\n  --zd-color-yellow-100: #fff7ed;\n  --zd-color-yellow-200: #ffeedb;\n  --zd-color-yellow-300: #fed6a8;\n  --zd-color-yellow-400: #ffb057;\n  --zd-color-yellow-500: #f79a3e;\n  --zd-color-yellow-600: #ed8f1c;\n  --zd-color-yellow-700: #ad5918;\n  --zd-color-yellow-800: #703815;\n  --zd-color-white: #fff;\n  --zd-color-secondary-azure-400: #3091ec;\n  --zd-color-secondary-azure-600: #1371d6;\n  --zd-color-secondary-crimson-400: #e34f32;\n  --zd-color-secondary-crimson-600: #c72a1c;\n  --zd-color-secondary-fuschia-400: #d653c2;\n  --zd-color-secondary-fuschia-600: #a81897;\n  --zd-color-secondary-lemon-400: #ffd424;\n  --zd-color-secondary-lemon-600: #ffbb10;\n  --zd-color-secondary-lime-400: #43b324;\n  --zd-color-secondary-lime-600: #2e8200;\n  --zd-color-secondary-mint-400: #00a656;\n  --zd-color-secondary-mint-600: #058541;\n  --zd-color-secondary-orange-400: #de701d;\n  --zd-color-secondary-orange-600: #bf5000;\n  --zd-color-secondary-pink-400: #ec4d63;\n  --zd-color-secondary-pink-600: #d42054;\n  --zd-color-secondary-purple-400: #b552e2;\n  --zd-color-secondary-purple-600: #6a27b8;\n  --zd-color-secondary-royal-400: #5d7df5;\n  --zd-color-secondary-royal-600: #3353e2;\n  --zd-color-secondary-teal-400: #02a191;\n  --zd-color-secondary-teal-600: #028079;\n  --zd-color-secondary-azure-M400: #5f8dcf;\n  --zd-color-secondary-azure-M600: #3a70b2;\n  --zd-color-secondary-crimson-M400: #cc6c5b;\n  --zd-color-secondary-crimson-M600: #b24a3c;\n  --zd-color-secondary-fuschia-M400: #cf62a8;\n  --zd-color-secondary-fuschia-M600: #a8458c;\n  --zd-color-secondary-lemon-M400: #e7a500;\n  --zd-color-secondary-lemon-M600: #c38f00;\n  --zd-color-secondary-lime-M400: #519e2d;\n  --zd-color-secondary-lime-M600: #47782c;\n  --zd-color-secondary-mint-M400: #299c66;\n  --zd-color-secondary-mint-M600: #2e8057;\n  --zd-color-secondary-orange-M400: #d4772c;\n  --zd-color-secondary-orange-M600: #b35827;\n  --zd-color-secondary-pink-M400: #d57287;\n  --zd-color-secondary-pink-M600: #b23a5d;\n  --zd-color-secondary-purple-M400: #b072cc;\n  --zd-color-secondary-purple-M600: #9358b0;\n  --zd-color-secondary-royal-M400: #7986d8;\n  --zd-color-secondary-royal-M600: #4b61c3;\n  --zd-color-secondary-teal-M400: #2d9e8f;\n  --zd-color-secondary-teal-M600: #3c7873;\n  --zd-color-chat-orange: #f79a3e;\n  --zd-color-connect-red: #ff6224;\n  --zd-color-explore-blue: #30aabc;\n  --zd-color-gather-pink: #f6c8be;\n  --zd-color-guide-pink: #eb4962;\n  --zd-color-message-green: #37b8af;\n  --zd-color-sell-gold: #c38f00;\n  --zd-color-support-green: #00a656;\n  --zd-color-talk-yellow: #efc93d;\n  --zd-font-family-monospace: SFMono-Regular, Consolas, 'Liberation Mono', Menlo, Courier, monospace;\n  --zd-font-family-system: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', Arial, sans-serif;\n  --zd-font-size-xs: 10px;\n  --zd-font-size-sm: 12px;\n  --zd-font-size-md: 14px;\n  --zd-font-size-lg: 18px;\n  --zd-font-size-xl: 22px;\n  --zd-font-size-xxl: 26px;\n  --zd-font-size-xxxl: 36px;\n  --zd-font-size-sm-monospace: 11px;\n  --zd-font-size-md-monospace: 13px;\n  --zd-font-size-lg-monospace: 17px;\n  --zd-font-weight-thin: 100;\n  --zd-font-weight-extralight: 200;\n  --zd-font-weight-light: 300;\n  --zd-font-weight-regular: 400;\n  --zd-font-weight-medium: 500;\n  --zd-font-weight-semibold: 600;\n  --zd-font-weight-bold: 700;\n  --zd-font-weight-extrabold: 800;\n  --zd-font-weight-black: 900;\n  --zd-font-weight-ultralight: 200;\n  --zd-font-weight-ultrabold: 800;\n  --zd-font-weight-heavy: 900;\n  --zd-line-height-sm: 16px;\n  --zd-line-height-md: 20px;\n  --zd-line-height-lg: 24px;\n  --zd-line-height-xl: 28px;\n  --zd-line-height-xxl: 32px;\n  --zd-line-height-xxxl: 44px;\n  --zd-spacing-xxs: 4px;\n  --zd-spacing-xs: 8px;\n  --zd-spacing-sm: 12px;\n  --zd-spacing: 20px;\n  --zd-spacing-lg: 32px;\n  --zd-spacing-xl: 40px;\n  --zd-spacing-xxl: 48px;\n}\n", '@import "@zendeskgarden/css-variables";\n\n:root {\n  --reach-menu-button: 1;\n}\n\n.list {\n  background: #fff;\n  border: 1px solid #d8d8d8;\n  border-radius: 3px;\n  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);\n  font-size: 14px;\n  font-style: normal;\n  font-weight: normal;\n  left: 0;\n  min-width: 170px;\n  outline: none;\n  padding: 10px 0;\n  position: relative;\n  z-index: 1000;\n}\n\n.item {\n  color: #333;\n  cursor: pointer;\n  display: block;\n  padding: 7px 40px 7px 20px;\n  outline: none;\n  white-space: nowrap;\n}\n\n[data-reach-menu-item][data-selected] {\n  background-color: rgba(92, 105, 112, 0.08);\n  box-shadow: var(--zd-color-grey-700) 3px 0px inset;\n}\n\n.separator {\n  border-bottom: 1px solid #d8d8d8;\n  color: #969696;\n  display: block;\n  font-weight: normal;\n  font-size: 11px;\n  padding: 5px 0;\n  margin: 5px 20px 10px 20px;\n}\n\n.spacer {\n  display: inline-block;\n  width: 10px;\n}\n'],
                sourceRoot: ""
            }]), c.locals = {
                list: "_8RHFYPTt0CxuUudzL8wxA9oZq1ynL1u",
                item: "_s7IdTkp038IFCdlKs8vwOcioOy4uK5h",
                separator: "XmCiWBUhr_QflETEQRaOWgLkfbAj8oS7",
                spacer: "NFPgFc0gI0HvonfLdOrjAWlpe6fhsgu2"
            }, o.A = c
        }
    }
]);