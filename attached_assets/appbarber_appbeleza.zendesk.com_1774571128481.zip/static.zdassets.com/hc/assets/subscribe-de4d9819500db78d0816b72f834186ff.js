/*! For license information please see subscribe-de4d9819500db78d0816b72f834186ff.js.LICENSE.txt */
(self.webpackChunkhelp_center = self.webpackChunkhelp_center || []).push([
    [33321], {
        47130: function(e, t, n) {
            "use strict";
            var r, o = n(96540);

            function i() {
                return i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, i.apply(null, arguments)
            }
            t.A = function(e) {
                return o.createElement("svg", i({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 12,
                    height: 12,
                    viewBox: "0 0 12 12"
                }, e), r || (r = o.createElement("path", {
                    fill: "none",
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M1 7l3 3 7-7"
                })))
            }
        },
        31136: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return U
                }
            });
            var r = n(49763),
                o = n.n(r),
                i = n(96540),
                c = n(40961),
                u = n(15493),
                a = n.n(u),
                s = n(49859),
                l = n(5773),
                f = n(34963),
                p = n(71426),
                d = n.n(p),
                A = n(48079),
                b = n.n(A),
                h = n(50697),
                m = n.n(h),
                v = n(26100),
                x = n.n(v),
                w = n(96319),
                g = n.n(w),
                y = n(78928),
                E = n.n(y),
                C = n(36751),
                k = n.n(C),
                B = n(44828),
                _ = n.n(B),
                O = n(5556),
                S = n.n(O),
                j = n(84354),
                $ = n.n(j),
                D = n(58327),
                R = n(47130),
                T = n(89677),
                q = n(23619),
                P = n(18784),
                W = n(85072),
                N = n.n(W),
                X = n(6704),
                M = {
                    insert: "head",
                    singleton: !1
                },
                z = (N()(X.A, M), X.A.locals || {});

            function Q(e, t) {
                var n = m()(e);
                if (x()) {
                    var r = x()(e);
                    t && (r = g()(r).call(r, (function(t) {
                        return E()(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function Y(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Q(Object(n), !0).forEach((function(t) {
                        (0, s.A)(e, t, n[t])
                    })) : k() ? Object.defineProperties(e, k()(n)) : Q(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, E()(n, t))
                    }))
                }
                return e
            }
            var F = function() {
                    var e = (0, f.A)(_().mark((function e(t, n) {
                        var r;
                        return _().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.t0 = fetch, e.t1 = t, e.t2 = n, e.next = 5, (0, D.S3)();
                                case 5:
                                    return e.t3 = e.sent, e.t4 = {
                                        "X-CSRF-Token": e.t3
                                    }, e.t5 = {
                                        method: e.t2,
                                        credentials: "same-origin",
                                        headers: e.t4
                                    }, e.next = 10, (0, e.t0)(e.t1, e.t5);
                                case 10:
                                    if ((r = e.sent).ok) {
                                        e.next = 13;
                                        break
                                    }
                                    throw new Error(r.statusText);
                                case 13:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }(),
                J = {
                    section: $()("txt.help_center.views.user.following.type.section"),
                    article: $()("txt.help_center.views.user.following.type.article"),
                    topic: $()("txt.help_center.views.user.following.type.topic"),
                    post: $()("txt.help_center.views.user.following.type.community_post"),
                    question: $()("txt.help_center.views.user.following.type.question"),
                    user: $()("txt.help_center.views.user.following.type.user")
                };

            function K(e) {
                var t = e.url,
                    n = (0, i.useState)(e.options),
                    r = (0, l.A)(n, 2),
                    o = r[0],
                    c = r[1],
                    u = (0, i.useState)(e.isSubscribed),
                    a = (0, l.A)(u, 2),
                    s = a[0],
                    p = a[1],
                    A = (0, i.useState)(e.followerCount || 0),
                    h = (0, l.A)(A, 2),
                    m = h[0],
                    v = h[1],
                    x = "anonymous" !== T.A.get("user.role"),
                    w = null == o ? void 0 : d()(o).call(o, (function(e) {
                        return e.selected
                    })),
                    g = "subscriptons-description-".concat(Math.random()),
                    y = "follow-button-".concat(Math.random()),
                    E = function() {
                        var e = (0, f.A)(_().mark((function e(n) {
                            var r;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return r = s, p(!0), c(null == o ? void 0 : b()(o).call(o, (function(e) {
                                            return Y(Y({}, e), {}, {
                                                selected: e === n
                                            })
                                        }))), void 0 === m || s || v(m + 1), e.prev = 4, e.next = 7, F((null == n ? void 0 : n.url) || t, "POST");
                                    case 7:
                                        e.next = 15;
                                        break;
                                    case 9:
                                        e.prev = 9, e.t0 = e.catch(4), P.$.push({
                                            type: "error",
                                            title: $()("txt.help_center.views.subscribe.error_message")
                                        }), p(r), c(null == o ? void 0 : b()(o).call(o, (function(e) {
                                            return Y(Y({}, e), {}, {
                                                selected: e === w
                                            })
                                        }))), void 0 === m || r || v(m);
                                    case 15:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [4, 9]
                            ])
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }(),
                    C = function() {
                        var e = (0, f.A)(_().mark((function e() {
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return p(!1), c(null == o ? void 0 : b()(o).call(o, (function(e) {
                                            return Y(Y({}, e), {}, {
                                                selected: !1
                                            })
                                        }))), void 0 !== m && v(Math.max(m - 1, 0)), e.prev = 3, e.next = 6, F(t, "DELETE");
                                    case 6:
                                        e.next = 14;
                                        break;
                                    case 8:
                                        e.prev = 8, e.t0 = e.catch(3), P.$.push({
                                            type: "error",
                                            title: $()("txt.help_center.views.subscribe.error_message")
                                        }), p(!0), c(null == o ? void 0 : b()(o).call(o, (function(e) {
                                            return Y(Y({}, e), {}, {
                                                selected: e === w
                                            })
                                        }))), void 0 !== m && v(m);
                                    case 14:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [3, 8]
                            ])
                        })));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }(),
                    k = function() {
                        x && !o && (s ? C() : E())
                    },
                    B = J[e.item],
                    O = s ? o ? $()("txt.help_center.views.section._subscription.following") : $()("txt.help_center.views.section._subscription.unfollow") : $()("txt.help_center.views.section._subscription.follow"),
                    S = s ? o ? $()("txt.help_center.views.item._subscription.following", {
                        item: B
                    }) : $()("txt.help_center.views.item._subscription.unfollow", {
                        item: B
                    }) : $()("txt.help_center.views.item._subscription.follow", {
                        item: B
                    }),
                    j = "Section" === B ? S : $()("txt.help_center.views.section._subscription.aria_description", {
                        count: m
                    });
                return x && o ? i.createElement(q.W1, null, i.createElement(q.IU, {
                    onClick: k,
                    "data-auth-action": x ? void 0 : "signin",
                    id: y,
                    "data-follower-count": m,
                    "data-selected": s,
                    "aria-describedby": g,
                    "aria-label": S
                }, O), i.createElement("span", {
                    className: z.invisible,
                    id: g
                }, j), i.createElement(q.cO, {
                    className: z.list,
                    "aria-labelledby": y
                }, b()(o).call(o, (function(e) {
                    return i.createElement(q.Dr, {
                        key: e.url,
                        className: z.item,
                        onSelect: function() {
                            return E(e)
                        },
                        role: "menuitemcheckbox",
                        "aria-checked": e.selected ? "true" : "false"
                    }, e.label, e.selected && i.createElement(i.Fragment, null, i.createElement("span", {
                        className: z.spacer
                    }), i.createElement(R.A, {
                        "aria-hidden": !0
                    })))
                })), s && i.createElement(q.Dr, {
                    key: t,
                    className: z.item,
                    onSelect: C,
                    role: "menuitemcheckbox"
                }, $()("txt.help_center.views.section._subscription.unfollow")))) : i.createElement(i.Fragment, null, i.createElement("button", {
                    type: "button",
                    onClick: k,
                    id: y,
                    "data-auth-action": x ? void 0 : "signin",
                    "data-follower-count": m,
                    "data-selected": s,
                    "aria-describedby": g,
                    "aria-label": S,
                    "aria-pressed": o ? null : s
                }, O), i.createElement("span", {
                    className: z.invisible,
                    id: g
                }, j))
            }

            function U() {
                var e = document.querySelectorAll("[data-helper='subscribe']");
                o()(e).forEach((function(e) {
                    var t = e.getAttribute("data-json"),
                        n = a()(JSON.parse(t));
                    e.removeAttribute("data-helper"), e.removeAttribute("data-json"), c.render(i.createElement(K, n), e)
                }))
            }
            K.propTypes = {
                item: S().string.isRequired,
                url: S().string.isRequired,
                isSubscribed: S().bool.isRequired,
                followerCount: S().number,
                options: S().arrayOf(S().shape({
                    label: S().string.isRequired,
                    url: S().string.isRequired,
                    selected: S().bool.isRequired
                }))
            }
        },
        14299: function(e, t, n) {
            n(54079);
            var r = n(87675).Object,
                o = e.exports = function(e, t) {
                    return r.getOwnPropertyDescriptor(e, t)
                };
            r.getOwnPropertyDescriptor.sham && (o.sham = !0)
        },
        88014: function(e, t, n) {
            n(7450);
            var r = n(87675);
            e.exports = r.Object.getOwnPropertyDescriptors
        },
        79069: function(e, t, n) {
            n(87375);
            var r = n(87675);
            e.exports = r.Object.getOwnPropertySymbols
        },
        99768: function(e, t, n) {
            n(69676);
            var r = n(87675);
            e.exports = r.Object.keys
        },
        54079: function(e, t, n) {
            var r = n(61938),
                o = n(97131),
                i = n(69441),
                c = n(45687).f,
                u = n(85560),
                a = o((function() {
                    c(1)
                }));
            r({
                target: "Object",
                stat: !0,
                forced: !u || a,
                sham: !u
            }, {
                getOwnPropertyDescriptor: function(e, t) {
                    return c(i(e), t)
                }
            })
        },
        7450: function(e, t, n) {
            var r = n(61938),
                o = n(85560),
                i = n(68195),
                c = n(69441),
                u = n(45687),
                a = n(58724);
            r({
                target: "Object",
                stat: !0,
                sham: !o
            }, {
                getOwnPropertyDescriptors: function(e) {
                    for (var t, n, r = c(e), o = u.f, s = i(r), l = {}, f = 0; s.length > f;) void 0 !== (n = o(r, t = s[f++])) && a(l, t, n);
                    return l
                }
            })
        },
        69676: function(e, t, n) {
            var r = n(61938),
                o = n(55809),
                i = n(55556);
            r({
                target: "Object",
                stat: !0,
                forced: n(97131)((function() {
                    i(1)
                }))
            }, {
                keys: function(e) {
                    return i(o(e))
                }
            })
        },
        5234: function(e, t, n) {
            var r = n(14299);
            e.exports = r
        },
        85777: function(e, t, n) {
            var r = n(88014);
            e.exports = r
        },
        96158: function(e, t, n) {
            var r = n(79069);
            e.exports = r
        },
        13959: function(e, t, n) {
            var r = n(99768);
            e.exports = r
        },
        6704: function(e, t, n) {
            "use strict";
            var r = n(71354),
                o = n.n(r),
                i = n(76314),
                c = n.n(i)()(o());
            c.push([e.id, ":root {\n  --reach-menu-button: 1;\n}\n\n.vb0q01gYhxX6xjoZDd0O4Qb7TxhiDaKD {\n  background: #fff;\n  border: 1px solid rgb(216, 216, 216);\n  border-radius: 3px;\n  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);\n  font-size: 14px;\n  font-style: normal;\n  font-weight: normal;\n  left: 0;\n  min-width: 170px;\n  outline: none;\n  padding: 10px 0;\n  z-index: 1000;\n}\n\n.OZgYUTQTaNinWRRb5SyjeQ8WEtA09RuF {\n  color: #333;\n  cursor: pointer;\n  display: block;\n  padding: 7px 40px 7px 20px;\n  white-space: nowrap;\n}\n\n.p1JvbEyYxbSfz1_7MmGKUQzT0SOap8Vu {\n  display: inline-block;\n  width: 10px;\n}\n\n.IJDXXdfgVXcY6MRd9u66HghwrbdhBtJv {\n  position: absolute;\n  top: auto;\n  overflow: hidden;\n  clip: rect(1px, 1px, 1px, 1px);\n  width: 1px;\n  height: 1px;\n  white-space: nowrap;\n}\n", "", {
                version: 3,
                sources: ["webpack://./ui/components/Subscribe/index.css"],
                names: [],
                mappings: "AAAA;EACE,sBAAsB;AACxB;;AAEA;EACE,gBAAgB;EAChB,oCAAoC;EACpC,kBAAkB;EAClB,wCAAwC;EACxC,eAAe;EACf,kBAAkB;EAClB,mBAAmB;EACnB,OAAO;EACP,gBAAgB;EAChB,aAAa;EACb,eAAe;EACf,aAAa;AACf;;AAEA;EACE,WAAW;EACX,eAAe;EACf,cAAc;EACd,0BAA0B;EAC1B,mBAAmB;AACrB;;AAEA;EACE,qBAAqB;EACrB,WAAW;AACb;;AAEA;EACE,kBAAkB;EAClB,SAAS;EACT,gBAAgB;EAChB,8BAA8B;EAC9B,UAAU;EACV,WAAW;EACX,mBAAmB;AACrB",
                sourcesContent: [":root {\n  --reach-menu-button: 1;\n}\n\n.list {\n  background: #fff;\n  border: 1px solid rgb(216, 216, 216);\n  border-radius: 3px;\n  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);\n  font-size: 14px;\n  font-style: normal;\n  font-weight: normal;\n  left: 0;\n  min-width: 170px;\n  outline: none;\n  padding: 10px 0;\n  z-index: 1000;\n}\n\n.item {\n  color: #333;\n  cursor: pointer;\n  display: block;\n  padding: 7px 40px 7px 20px;\n  white-space: nowrap;\n}\n\n.spacer {\n  display: inline-block;\n  width: 10px;\n}\n\n.invisible {\n  position: absolute;\n  top: auto;\n  overflow: hidden;\n  clip: rect(1px, 1px, 1px, 1px);\n  width: 1px;\n  height: 1px;\n  white-space: nowrap;\n}\n"],
                sourceRoot: ""
            }]), c.locals = {
                list: "vb0q01gYhxX6xjoZDd0O4Qb7TxhiDaKD",
                item: "OZgYUTQTaNinWRRb5SyjeQ8WEtA09RuF",
                spacer: "p1JvbEyYxbSfz1_7MmGKUQzT0SOap8Vu",
                invisible: "IJDXXdfgVXcY6MRd9u66HghwrbdhBtJv"
            }, t.A = c
        },
        22799: function(e, t) {
            "use strict";
            var n = 60103,
                r = 60106,
                o = 60107,
                i = 60108,
                c = 60114,
                u = 60109,
                a = 60110,
                s = 60112,
                l = 60113,
                f = 60120,
                p = 60115,
                d = 60116,
                A = 60121,
                b = 60122,
                h = 60117,
                m = 60129,
                v = 60131;
            if ("function" == typeof Symbol && Symbol.for) {
                var x = Symbol.for;
                n = x("react.element"), r = x("react.portal"), o = x("react.fragment"), i = x("react.strict_mode"), c = x("react.profiler"), u = x("react.provider"), a = x("react.context"), s = x("react.forward_ref"), l = x("react.suspense"), f = x("react.suspense_list"), p = x("react.memo"), d = x("react.lazy"), A = x("react.block"), b = x("react.server.block"), h = x("react.fundamental"), m = x("react.debug_trace_mode"), v = x("react.legacy_hidden")
            }

            function w(e) {
                if ("object" == typeof e && null !== e) {
                    var t = e.$$typeof;
                    switch (t) {
                        case n:
                            switch (e = e.type) {
                                case o:
                                case c:
                                case i:
                                case l:
                                case f:
                                    return e;
                                default:
                                    switch (e = e && e.$$typeof) {
                                        case a:
                                        case s:
                                        case d:
                                        case p:
                                        case u:
                                            return e;
                                        default:
                                            return t
                                    }
                            }
                        case r:
                            return t
                    }
                }
            }
            t.isFragment = function(e) {
                return w(e) === o
            }, t.isValidElementType = function(e) {
                return "string" == typeof e || "function" == typeof e || e === o || e === c || e === m || e === i || e === l || e === f || e === v || "object" == typeof e && null !== e && (e.$$typeof === d || e.$$typeof === p || e.$$typeof === u || e.$$typeof === a || e.$$typeof === s || e.$$typeof === h || e.$$typeof === A || e[0] === b)
            }, t.typeOf = w
        },
        44363: function(e, t, n) {
            "use strict";
            e.exports = n(22799)
        },
        78928: function(e, t, n) {
            e.exports = n(5234)
        },
        36751: function(e, t, n) {
            e.exports = n(85777)
        },
        26100: function(e, t, n) {
            e.exports = n(96158)
        },
        50697: function(e, t, n) {
            e.exports = n(13959)
        },
        16144: function(e, t, n) {
            "use strict";
            var r;
            n.d(t, {
                B: function() {
                    return l
                }
            });
            var o = n(96540),
                i = n(83224),
                c = !1,
                u = 0;

            function a() {
                return ++u
            }
            var s = (r || (r = n.t(o, 2)))["useId".toString()];

            function l(e) {
                if (void 0 !== s) {
                    let t = s();
                    return e ? ? t
                }
                let t = e ? ? (c ? a() : null),
                    [n, r] = o.useState(t);
                return (0, i.Es)((() => {
                    null === n && r(a())
                }), []), o.useEffect((() => {
                    !1 === c && (c = !0)
                }), []), e ? ? n ? ? void 0
            }
        },
        83224: function(e, t, n) {
            "use strict";
            n.d(t, {
                CH: function() {
                    return h
                },
                Es: function() {
                    return m
                },
                Kg: function() {
                    return a
                },
                Kr: function() {
                    return x
                },
                Lm: function() {
                    return c
                },
                M4: function() {
                    return A
                },
                TW: function() {
                    return f
                },
                Tn: function() {
                    return u
                },
                ZC: function() {
                    return v
                },
                lQ: function() {
                    return b
                },
                mK: function() {
                    return i
                },
                nO: function() {
                    return d
                },
                q6: function() {
                    return p
                },
                sC: function() {
                    return l
                }
            });
            var r = n(96540);

            function o() {
                return !("undefined" == typeof window || !window.document || !window.document.createElement)
            }

            function i(e, t) {
                return n => {
                    if (e && e(n), !n.defaultPrevented) return t(n)
                }
            }

            function c(e) {
                return "boolean" == typeof e
            }

            function u(e) {
                return !(!e || "[object Function]" != {}.toString.call(e))
            }

            function a(e) {
                return "string" == typeof e
            }

            function s(e, t) {
                if (null != e)
                    if (u(e)) e(t);
                    else try {
                        e.current = t
                    } catch (n) {
                        throw new Error(`Cannot assign value "${t}" to ref "${e}"`)
                    }
            }

            function l(...e) {
                return (0, r.useCallback)((t => {
                    for (let n of e) s(n, t)
                }), e)
            }

            function f(e) {
                return o() ? e ? e.ownerDocument : document : null
            }

            function p(e, t) {
                let n = r.createContext(t);

                function o(e) {
                    let {
                        children: t,
                        ...o
                    } = e, i = r.useMemo((() => o), Object.values(o));
                    return r.createElement(n.Provider, {
                        value: i
                    }, t)
                }
                return n.displayName = `${e}Context`, o.displayName = `${e}Provider`, [o, function(o) {
                    let i = r.useContext(n);
                    if (i) return i;
                    if (t) return t;
                    throw Error(`${o} must be rendered inside of a ${e} component.`)
                }]
            }

            function d(e) {
                return "which" in e ? 3 === e.which : "button" in e && 2 === e.button
            }

            function A(...e) {
                return e.filter((e => null != e)).join("--")
            }

            function b() {}

            function h() {
                let [, e] = (0, r.useState)(Object.create(null));
                return (0, r.useCallback)((() => {
                    e(Object.create(null))
                }), [])
            }
            var m = o() ? r.useLayoutEffect : r.useEffect;

            function v(e) {
                const t = (0, r.useRef)(null);
                return (0, r.useEffect)((() => {
                    t.current = e
                }), [e]), t.current
            }

            function x(e, t) {
                let [n, o] = (0, r.useState)(t);
                return [n, (0, r.useCallback)((t => {
                    e.current = t, o(t)
                }), [])]
            }
        }
    }
]);